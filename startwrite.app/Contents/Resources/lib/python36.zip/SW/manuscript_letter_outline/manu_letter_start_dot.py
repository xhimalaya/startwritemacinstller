# Letter OutLine StartDot
# SWFNT71D.TTF


# 14
def glyph_A():
    x = [866]
    y = [1500]
    return x, y


# 15
def glyph_B():
    x = [115]
    y = [1498]
    return x, y


def glyph_C():
    x = [1414]
    y = [1272]
    return x, y


def glyph_D():
    x = [122]
    y = [1499]
    return x, y


def glyph_E():
    x = [120]
    y = [1500]
    return x, y


def glyph_F():
    x = [129]
    y = [1491]
    return x, y


def glyph_G():
    x = [1477]
    y = [1187]
    return x, y


def glyph_H():
    x = [120]
    y = [1500]
    return x, y


def glyph_I():
    x = [292]
    y = [1500]
    return x, y


def glyph_J():
    x = [861]
    y = [1500]
    return x, y


def glyph_K():
    x = [118]
    y = [1500]
    return x, y


def glyph_L():
    x = [120]
    y = [1500]
    return x, y


def glyph_M():
    x = [116]
    y = [1500]
    return x, y


def glyph_N():
    x = [120]
    y = [1500]
    return x, y


def glyph_O():
    x = [862]
    y = [1500]
    return x, y


def glyph_P():
    x = [120]
    y = [1500]
    return x, y


def glyph_Q():
    x = [862]
    y = [1500]
    return x, y


def glyph_R():
    x = [122]
    y = [1497]
    return x, y


def glyph_S():
    x = [1123]
    y = [1376]
    return x, y


def glyph_T():
    x = [120]
    y = [1500]
    return x, y


def glyph_U():
    x = [120]
    y = [1500]
    return x, y


def glyph_V():
    x = [121]
    y = [1500]
    return x, y


def glyph_W():
    x = [118]
    y = [1500]
    return x, y


def glyph_X():
    x = [120]
    y = [1500]
    return x, y


def glyph_Y():
    x = [121]
    y = [1500]
    return x, y


def glyph_Z():
    x = [120]
    y = [1494]
    return x, y


# 40
def glyph_a():
    x = [884]
    y = [375]
    return x, y


def glyph_b():
    x = [120]
    y = [1500]
    return x, y


def glyph_c():
    x = [767]
    y = [635]
    return x, y


def glyph_d():
    x = [864]
    y = [438]
    return x, y


def glyph_e():
    x = [154]
    y = [471]
    return x, y


def glyph_f():
    x = [588]
    y = [1334]
    return x, y


def glyph_g():
    x = [863]
    y = [394]
    return x, y


def glyph_h():
    x = [120]
    y = [1500]
    return x, y


def glyph_i():
    x = [120]
    y = [752]
    return x, y


def glyph_j():
    x = [728]
    y = [750]
    return x, y


def glyph_k():
    x = [120]
    y = [1500]
    return x, y


def glyph_l():
    x = [120]
    y = [1500]
    return x, y


def glyph_m():
    x = [120]
    y = [750]
    return x, y


def glyph_n():
    x = [120]
    y = [750]
    return x, y


def glyph_o():
    x = [487]
    y = [749]
    return x, y


def glyph_p():
    x = [120]
    y = [753]
    return x, y


def glyph_q():
    x = [878]
    y = [404]
    return x, y


def glyph_r():
    x = [120]
    y = [748]
    return x, y


def glyph_s():
    x = [626]
    y = [693]
    return x, y


def glyph_t():
    x = [374]
    y = [1126]
    return x, y


def glyph_u():
    x = [120]
    y = [751]
    return x, y


def glyph_v():
    x = [181]
    y = [752]
    return x, y


def glyph_w():
    x = [161]
    y = [752]
    return x, y


def glyph_x():
    x = [210]
    y = [746]
    return x, y


def glyph_y():
    x = [120]
    y = [750]
    return x, y


def glyph_z():
    x = [120]
    y = [748]
    return x, y


def return_letter_outline_start_dot(xxx):
    x = []
    y = []
    if xxx == 'A':
        x, y = glyph_A()
        return x, y
    if xxx == 'B':
        x, y = glyph_B()
        return x, y
    if xxx == 'C':
        x, y = glyph_C()
        return x, y
    if xxx == 'D':
        x, y = glyph_D()
        return x, y
    if xxx == 'E':
        x, y = glyph_E()
        return x, y
    if xxx == 'F':
        x, y = glyph_F()
        return x, y
    if xxx == 'G':
        x, y = glyph_G()
        return x, y
    if xxx == 'H':
        x, y = glyph_H()
        return x, y
    if xxx == 'I':
        x, y = glyph_I()
        return x, y
    if xxx == 'J':
        x, y = glyph_J()
        return x, y
    if xxx == 'K':
        x, y = glyph_K()
        return x, y
    if xxx == 'L':
        x, y = glyph_L()
        return x, y
    if xxx == 'M':
        x, y = glyph_M()
        return x, y
    if xxx == 'N':
        x, y = glyph_N()
        return x, y
    if xxx == 'O':
        x, y = glyph_O()
        return x, y
    if xxx == 'P':
        x, y = glyph_P()
        return x, y
    if xxx == 'Q':
        x, y = glyph_Q()
        return x, y
    if xxx == 'R':
        x, y = glyph_R()
        return x, y
    if xxx == 'S':
        x, y = glyph_S()
        return x, y
    if xxx == 'T':
        x, y = glyph_T()
        return x, y
    if xxx == 'U':
        x, y = glyph_U()
        return x, y
    if xxx == 'V':
        x, y = glyph_V()
        return x, y
    if xxx == 'W':
        x, y = glyph_W()
        return x, y
    if xxx == 'X':
        x, y = glyph_X()
        return x, y
    if xxx == 'Y':
        x, y = glyph_Y()
        return x, y
    if xxx == 'Z':
        x, y = glyph_Z()
        return x, y

    if xxx == 'a':
        x, y = glyph_a()
        return x, y
    if xxx == 'b':
        x, y = glyph_b()
        return x, y
    if xxx == 'c':
        x, y = glyph_c()
        return x, y
    if xxx == 'd':
        x, y = glyph_d()
        return x, y
    if xxx == 'e':
        x, y = glyph_e()
        return x, y
    if xxx == 'f':
        x, y = glyph_f()
        return x, y
    if xxx == 'g':
        x, y = glyph_g()
        return x, y
    if xxx == 'h':
        x, y = glyph_h()
        return x, y
    if xxx == 'i':
        x, y = glyph_i()
        return x, y
    if xxx == 'j':
        x, y = glyph_j()
        return x, y
    if xxx == 'k':
        x, y = glyph_k()
        return x, y
    if xxx == 'l':
        x, y = glyph_l()
        return x, y
    if xxx == 'm':
        x, y = glyph_m()
        return x, y
    if xxx == 'n':
        x, y = glyph_n()
        return x, y
    if xxx == 'o':
        x, y = glyph_o()
        return x, y
    if xxx == 'p':
        x, y = glyph_p()
        return x, y
    if xxx == 'q':
        x, y = glyph_q()
        return x, y
    if xxx == 'r':
        x, y = glyph_r()
        return x, y
    if xxx == 's':
        x, y = glyph_s()
        return x, y
    if xxx == 't':
        x, y = glyph_t()
        return x, y
    if xxx == 'u':
        x, y = glyph_u()
        return x, y
    if xxx == 'v':
        x, y = glyph_v()
        return x, y
    if xxx == 'w':
        x, y = glyph_w()
        return x, y
    if xxx == 'x':
        x, y = glyph_x()
        return x, y
    if xxx == 'y':
        x, y = glyph_y()
        return x, y
    if xxx == 'z':
        x, y = glyph_z()
        return x, y

# Letter OutLine StartDot
# SWFNT71 .TTF


def glyph_A():
    x = []
    y = []
    return x, y


def glyph_B():
    x = []
    y = []
    return x, y


def glyph_C():
    x = []
    y = []
    return x, y


def glyph_D():
    x = []
    y = []
    return x, y


def glyph_E():
    x = []
    y = []
    return x, y


def glyph_F():
    x = []
    y = []
    return x, y


def glyph_G():
    x = []
    y = []
    return x, y


def glyph_H():
    x = []
    y = []
    return x, y


def glyph_I():
    x = []
    y = []
    return x, y


def glyph_J():
    x = []
    y = []
    return x, y


def glyph_K():
    x = []
    y = []
    return x, y


def glyph_L():
    x = []
    y = []
    return x, y


def glyph_M():
    x = []
    y = []
    return x, y


def glyph_N():
    x = []
    y = []
    return x, y


def glyph_O():
    x = []
    y = []
    return x, y


def glyph_P():
    x = []
    y = []
    return x, y


def glyph_Q():
    x = []
    y = []
    return x, y


def glyph_R():
    x = []
    y = []
    return x, y


def glyph_S():
    x = []
    y = []
    return x, y


def glyph_T():
    x = []
    y = []
    return x, y


def glyph_U():
    x = []
    y = []
    return x, y


def glyph_V():
    x = []
    y = []
    return x, y


def glyph_W():
    x = []
    y = []
    return x, y


def glyph_X():
    x = []
    y = []
    return x, y


def glyph_Y():
    x = []
    y = []
    return x, y


def glyph_Z():
    x = []
    y = []
    return x, y


# 40
def glyph_a():
    x = []
    y = []
    return x, y


def glyph_b():
    x = []
    y = []
    return x, y


def glyph_c():
    x = []
    y = []
    return x, y


def glyph_d():
    x = []
    y = []
    return x, y


def glyph_e():
    x = []
    y = []
    return x, y


def glyph_f():
    x = []
    y = []
    return x, y


def glyph_g():
    x = []
    y = []
    return x, y


def glyph_h():
    x = []
    y = []
    return x, y


def glyph_i():
    x = []
    y = []
    return x, y


def glyph_j():
    x = []
    y = []
    return x, y


def glyph_k():
    x = []
    y = []
    return x, y


def glyph_l():
    x = []
    y = []
    return x, y


def glyph_m():
    x = []
    y = []
    return x, y


def glyph_n():
    x = []
    y = []
    return x, y


def glyph_o():
    x = []
    y = []
    return x, y


def glyph_p():
    x = []
    y = []
    return x, y


def glyph_q():
    x = []
    y = []
    return x, y


def glyph_r():
    x = []
    y = []
    return x, y


def glyph_s():
    x = []
    y = []
    return x, y


def glyph_t():
    x = []
    y = []
    return x, y


def glyph_u():
    x = []
    y = []
    return x, y


def glyph_v():
    x = []
    y = []
    return x, y


def glyph_w():
    x = []
    y = []
    return x, y


def glyph_x():
    x = []
    y = []
    return x, y


def glyph_y():
    x = []
    y = []
    return x, y


def glyph_z():
    x = []
    y = []
    return x, y


def return_letter_outline_decision_dot(xxx):
    x = []
    y = []
    if xxx == 'A':
        x, y = glyph_A()
        return x, y
    if xxx == 'B':
        x, y = glyph_B()
        return x, y
    if xxx == 'C':
        x, y = glyph_C()
        return x, y
    if xxx == 'D':
        x, y = glyph_D()
        return x, y
    if xxx == 'E':
        x, y = glyph_E()
        return x, y
    if xxx == 'F':
        x, y = glyph_F()
        return x, y
    if xxx == 'G':
        x, y = glyph_G()
        return x, y
    if xxx == 'H':
        x, y = glyph_H()
        return x, y
    if xxx == 'I':
        x, y = glyph_I()
        return x, y
    if xxx == 'J':
        x, y = glyph_J()
        return x, y
    if xxx == 'K':
        x, y = glyph_K()
        return x, y
    if xxx == 'L':
        x, y = glyph_L()
        return x, y
    if xxx == 'M':
        x, y = glyph_M()
        return x, y
    if xxx == 'N':
        x, y = glyph_N()
        return x, y
    if xxx == 'O':
        x, y = glyph_O()
        return x, y
    if xxx == 'P':
        x, y = glyph_P()
        return x, y
    if xxx == 'Q':
        x, y = glyph_Q()
        return x, y
    if xxx == 'R':
        x, y = glyph_R()
        return x, y
    if xxx == 'S':
        x, y = glyph_S()
        return x, y
    if xxx == 'T':
        x, y = glyph_T()
        return x, y
    if xxx == 'U':
        x, y = glyph_U()
        return x, y
    if xxx == 'V':
        x, y = glyph_V()
        return x, y
    if xxx == 'W':
        x, y = glyph_W()
        return x, y
    if xxx == 'X':
        x, y = glyph_X()
        return x, y
    if xxx == 'Y':
        x, y = glyph_Y()
        return x, y
    if xxx == 'Z':
        x, y = glyph_Z()
        return x, y

    if xxx == 'a':
        x, y = glyph_a()
        return x, y
    if xxx == 'b':
        x, y = glyph_b()
        return x, y
    if xxx == 'c':
        x, y = glyph_c()
        return x, y
    if xxx == 'd':
        x, y = glyph_d()
        return x, y
    if xxx == 'e':
        x, y = glyph_e()
        return x, y
    if xxx == 'f':
        x, y = glyph_f()
        return x, y
    if xxx == 'g':
        x, y = glyph_g()
        return x, y
    if xxx == 'h':
        x, y = glyph_h()
        return x, y
    if xxx == 'i':
        x, y = glyph_i()
        return x, y
    if xxx == 'j':
        x, y = glyph_j()
        return x, y
    if xxx == 'k':
        x, y = glyph_k()
        return x, y
    if xxx == 'l':
        x, y = glyph_l()
        return x, y
    if xxx == 'm':
        x, y = glyph_m()
        return x, y
    if xxx == 'n':
        x, y = glyph_n()
        return x, y
    if xxx == 'o':
        x, y = glyph_o()
        return x, y
    if xxx == 'p':
        x, y = glyph_p()
        return x, y
    if xxx == 'q':
        x, y = glyph_q()
        return x, y
    if xxx == 'r':
        x, y = glyph_r()
        return x, y
    if xxx == 's':
        x, y = glyph_s()
        return x, y
    if xxx == 't':
        x, y = glyph_t()
        return x, y
    if xxx == 'u':
        x, y = glyph_u()
        return x, y
    if xxx == 'v':
        x, y = glyph_v()
        return x, y
    if xxx == 'w':
        x, y = glyph_w()
        return x, y
    if xxx == 'x':
        x, y = glyph_x()
        return x, y
    if xxx == 'y':
        x, y = glyph_y()
        return x, y
    if xxx == 'z':
        x, y = glyph_z()
        return x, y

// TrueType Directory Table

#ifndef _DIRECTORY_TABLE_H_
#define _DIRECTORY_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

class DirectoryTable 
{
	private:
		// Table Directory
		typedef struct Directory
		{
			Fixed	SNFTVersion;		// 0x00010000 for version 1.0
			UShort	NumTables;			// Number of tables
			UShort	SearchRange;		// (Maximum poser of2 <= NumTables) * 16
			UShort	EntrySelector;		// Log2(maximum power of 2 <= NumTables)
			UShort	RangeShift;			// NumTables * 16 - SearchRange (??)
		} Directory;
		
		// Table Directory Entry (Little Endian Form)
		struct DirectoryEntry_LE 
		{
			UShort	TagHi, TagLo;
			UShort	CheckSumHi, CheckSumLo;
			UShort	OffsetHi, OffsetLo;
			UShort	LengthHi, LengthLo;
		};

		// Directory Entry  
		typedef struct DirectoryEntry 
		{
			Byte	Tag3, Tag2, Tag1, Tag0;	// 4-byte identifier
			ULong		CheckSum;			// CheckSum for this table
			ULong		Offset;				// Offset from beginning of TrueType font file
			ULong		Length;				// Length of this table
		} DirectoryEntry;					

		Directory Table;		
		DirectoryEntry *OriginalP;
		DirectoryEntry *Entries;
		char	CurrentTag[5];
		ULong	CurrentCheckSum;
		ULong	CurrentOffset;
		ULong	CurrentLength;
		
	public:

		
		DirectoryTable();
		~DirectoryTable();

		// Members for directory table
		// These will be added when actually needed outside of class...
		
        // Members for directory entries
        // Get the internal vars for the 'table' entry
        // Return value indicates existence of table in font file
		int		GetTag(char *tag);		
		ULong 	GetCheckSum();
		ULong 	GetOffset();
		ULong 	GetLength();
		
		int 	Read(fstream *fin);
		
		int 	Print();
};

#endif // _DIECTORY_TABLE_H_
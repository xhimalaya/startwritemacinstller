// Font Header Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Loca.h"
 
#include <stdio.h>
 
LocaTable::LocaTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER LocaTable::LocaTable()"); 
	#endif

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT LocaTable::LocaTable: void"); 
	#endif
	
	Offsets = NULL;
}

LocaTable::~LocaTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER LocaTable::~LocaTable()"); 
	#endif

	FreeMem();
	// malloc #1
	//if( Offsets != NULL) { free(Offsets);}
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT LocaTable::~LocaTable: void"); 
	#endif
}

void LocaTable::FreeMem()
{
	if (Offsets)     
	{
		free(Offsets);
		Offsets = NULL;
	}
}

int
LocaTable::Read(fstream *fin, DirectoryTable *dir, 
				Short format, UShort numglyphs)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER LocaTable::Read(?,?,?,?)"); 
	#endif
    
    // Save to args to instance vars
    Format = format;
    NumGlyphs = numglyphs;
    
	// Read loca table
	
	// Check for existence of loca table
	if( !dir->GetTag("loca"))
	{
		Report( TO_LIST, "ERROR LocaTable::Read: Unable to GetTag(loca)"); 
		return ERROR;
	}
	
	// Head table begins at offset specified in directory table
	//Offsets = (Offsets *)malloc(dir->GetLength());
	// malloc #1		 
	FreeMem();
	if(( Offsets = (char *)malloc((int)dir->GetLength())) == NULL)
	{
		Report( TO_LIST, "ERROR LocaTable::Read: Malloc #1 == NULL"); 
		return ERROR;	
	}
	
	fin->seekg(dir->GetOffset());
	fin->read( (char *)Offsets, (int)dir->GetLength());
 	
 	// Swab the shorts...
    myswab( (unsigned char *)Offsets, (int)dir->GetLength());
    
    // Setup both pointers
    UShortOffsets = (UShort *)Offsets;
    ULongOffsets = (ULong *)Offsets;

	// Swap the His and Los of the ULong data    
	UShort tmp;
    if( Format == 1 )
    {
		for( int i = 0; i < (int)NumGlyphs * 2; i += 2)
		{   
			tmp = UShortOffsets[i];
			UShortOffsets[i] = UShortOffsets[i+1];
			UShortOffsets[i+1] = tmp;
		}		
    
    }
	                                               
	return OK;
}

int
LocaTable::GetOffset( ULong* offset, ULong index)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER LocaTable::GetOffset(ULong*,ULong)"); 
	#endif

	if( Format == 0)
	{
		Report( TO_LIST, "ERROR LocaTable::GetOffset: UShort format for loca table not implemented!"); 
	 	return ERROR;
	}
	else if( Format == 1)
	{
		*offset = ULongOffsets[index];
		return OK;
	}
	
	return ERROR;
}


ULong
LocaTable::GetOffset( ULong index, int *status)
{
	if( Format == 0)
	{
	 	// In format 0 the offset is stored as offset / 2
	 	*status = OK;
	 	return (ULong)(UShortOffsets[index] * 2);
	}
	else if( Format == 1)
	{	
		*status = OK;
		return ULongOffsets[index];
	}
	
	*status = ERROR;
	return ((ULong)(-1));
}

int
LocaTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER LocaTable::Print()"); 
	#endif
	      
	int i = 0;      
	cout << "** Loca **" << endl;
	cout << dec;
	if( Format == 0 )  // print data as shorts
	{
		// In format 0 the offset is stored as offset / 2
		for( i = 0; i < (int)NumGlyphs; ++i)		
		{
			cout << i << ":\t0x" << hex << UShortOffsets[i] * 2 << dec << endl;	
		}		
	}
	else if( Format == 1 )	// print data as longs
	{
		for( i = 0; i < (int)NumGlyphs; ++i)		
		{
			cout << i << ":\t0x" << hex << ULongOffsets[i] << dec << endl;	
		}		
	}
	else
	{
		cout << "Error: LocaTable::Print: Format is not 0 or 1." << endl;
	}
	cout << dec;

	return OK;
}
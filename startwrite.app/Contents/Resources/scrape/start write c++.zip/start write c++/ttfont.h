// TrueType Font Class Header

#ifndef _TTFONT_H_
#define _TTFONT_H_

#include "TTCommon.h"
#include "TTTypes.h"
#include "Dir.h"
#include "Name.h"
#include "Cmap.h"
#include "Head.h"
#include "Maxp.h"
#include "Loca.h"
#include "Glyf.h"
#include "Kern.h"

class TTFont 
{
	private:
		char File[128];
		DirectoryTable	*Dir;
		NameTable		*Name;
		CMapTable		*CMap;
		HeadTable		*Head;
		MaxPTable		*MaxP;
		LocaTable		*Loca;
		GlyfTable		*Glyf;
		KernTable		*Kern;
		
		char Error[128];
			
	public:
		bool isOpen;
		TTFont();
		int SetFile(char *file);
		int Open();
		int Print();
		int Close();		
		~TTFont();
		int GetGlyfData( GlyfData* glyfdata, unsigned short *c);		
		short GetKern(UShort cleft, UShort cright);
		char* GetError();
		int Print(char *string);
		
		// These are tmp to make into test library.... 
		int GetCharacter( unsigned char* c);
		int GetEndPoint( int ep);
		int GetNumberOfContours();
		int GetMaxPoints();
		int GetX( int x);
		int GetY( int y);
		
};

#endif // _TTFONT_H_

// BorderArtDlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "borderartdlg.h"
#include "SwBorderManager.h"

// CBorderArtDlg dialog

IMPLEMENT_DYNAMIC(CBorderArtDlg, CDialog)

CBorderArtDlg::CBorderArtDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBorderArtDlg::IDD, pParent)
{
	m_nBorderArtSource = BORDER_ART_SOURCE_NONE;
	m_nBorderArtShrink = FALSE;
	m_nBorderArtSize = 0;
	m_strBorderArtName = "";
	m_pBox = new BBox;
	m_pTextItem = new TextItem;
	BasePath = theApp.m_strArtPath;		// Get the system art path
	LoadFileLists();
	doInitialization = TRUE;
}

CBorderArtDlg::~CBorderArtDlg()
{
}

void CBorderArtDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBorderArtDlg)
	DDX_Control(pDX, IDC_LISTSWBORDERART, m_ctlListSWBorderArt);
	DDX_Control(pDX, IDC_LISTBORDERARTSIZE, m_ctlListBorderArtSize);
	DDX_Radio(pDX, IDC_RADIOBORDERART0, m_nBorderArtSource);
	//}}AFX_DATA_MAP
	if (pDX->m_bSaveAndValidate)
	{
	}
	else
	{
		if (doInitialization)
		{
			FillSizeList();
			InitPreview();
			InitControls();
			doInitialization = FALSE;
		}
	}
}


BEGIN_MESSAGE_MAP(CBorderArtDlg, CDialog)
	ON_WM_PAINT()
	ON_LBN_SELCHANGE(IDC_LISTSWBORDERART, &CBorderArtDlg::OnLbnSelchangeListswborderart)
	ON_LBN_SELCHANGE(IDC_LISTBORDERARTSIZE, &CBorderArtDlg::OnLbnSelchangeListborderartsize)
	ON_BN_CLICKED(IDC_RADIOBORDERART0, &CBorderArtDlg::OnBnClickedRadioborderart0)
	ON_BN_CLICKED(IDC_RADIOBORDERART1, &CBorderArtDlg::OnBnClickedRadioborderart1)
	ON_BN_CLICKED(IDC_RADIOBORDERART2, &CBorderArtDlg::OnBnClickedRadioborderart2)
	ON_BN_CLICKED(IDC_CHKBORDERARTSHRINK, &CBorderArtDlg::OnBnClickedChkborderartshrink)
END_MESSAGE_MAP()


// CBorderArtDlg message handlers


BOOL CBorderArtDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

bool CBorderArtDlg::GetCurrentSelections()
{
	if (!doInitialization)
	{
		m_nBorderArtSize = 0;
		m_strBorderArtName = "";
	}
	int picIndex = m_ctlListSWBorderArt.GetCurSel();
	int fileIndex = 0;
	int sizeIndex = m_ctlListBorderArtSize.GetCurSel();
	bool isValid = TRUE;
	if (m_nBorderArtSource == BORDER_ART_SOURCE_SWCOLOR || m_nBorderArtSource == BORDER_ART_SOURCE_SWBW)
	{
		if (picIndex > -1)
		{
			fileIndex = m_ctlListSWBorderArt.GetItemData(picIndex);
			if (m_nBorderArtSource == BORDER_ART_SOURCE_SWCOLOR)
			{
				m_strBorderArtName = BasePath + filesColor[fileIndex];
			}
			else
			{
				m_strBorderArtName = BasePath + filesBW[fileIndex];
			}
		}
		else
		{
			isValid = FALSE;
		}
		if (isValid && sizeIndex > -1)
		{
			m_nBorderArtSize = MIN_BORDERARTSIZE + sizeIndex * INC_BORDERARTSIZE;
		}
		else
		{
			isValid = FALSE;
		}
	}
	return isValid;
}

void CBorderArtDlg::OnOK()
{
	bool isValid = GetCurrentSelections();
	if (isValid)
	{
		CDialog::OnOK();
	}
	else
	{
		MessageBox("Please select the Border Art and the Size.", "Border Art", 0);
	}
}

void CBorderArtDlg::InitControls()
{
	switch (m_nBorderArtSource)
	{
	case BORDER_ART_SOURCE_NONE:
		OnBnClickedRadioborderart0();
		break;

	case BORDER_ART_SOURCE_SWCOLOR:
		OnBnClickedRadioborderart1();
		SetSWBorderArtSelection();
		SetBorderArtSizeSelection();
		break;

	case BORDER_ART_SOURCE_SWBW:
		OnBnClickedRadioborderart2();
		SetSWBorderArtSelection();
		SetBorderArtSizeSelection();
		break;

	default:
		OnBnClickedRadioborderart0();
		break;

	}
}

void CBorderArtDlg::SetSWBorderArtSelection()
{
	int i = 0, filesNdx = 0;
	CString strTemp = "";
	for (i=0; i<m_ctlListSWBorderArt.GetCount();i++)
	{
		filesNdx = m_ctlListSWBorderArt.GetItemData(i);
		if (m_nBorderArtSource == BORDER_ART_SOURCE_SWCOLOR && m_strBorderArtName.Find(filesColor[filesNdx], 0) > -1
			|| m_nBorderArtSource == BORDER_ART_SOURCE_SWBW && m_strBorderArtName.Find(filesBW[filesNdx], 0) > -1)
		{
			m_ctlListSWBorderArt.SetCurSel(i);
			break;
		}
	}
}

void CBorderArtDlg::SetBorderArtSizeSelection()
{
	int i = 0;
	int nSize = MIN_BORDERARTSIZE;
	for (i=0; i<m_ctlListBorderArtSize.GetCount();i++)
	{
		if (nSize == m_nBorderArtSize)
		{
			m_ctlListBorderArtSize.SetCurSel(i);
			break;
		}
		nSize += INC_BORDERARTSIZE;
	}
}

void CBorderArtDlg::FillSizeList()
{
	m_ctlListBorderArtSize.ResetContent();
	CString str;
	for (int nSize=MIN_BORDERARTSIZE; nSize<=MAX_BORDERARTSIZE; nSize+=INC_BORDERARTSIZE)
	{
		str.Format("%d", nSize);
		m_ctlListBorderArtSize.AddString(str);
	}
}

CString CBorderArtDlg::MakeDisplayName(CString name)
{
	CString strRet = "";
	int ndx = 0;
	if ((ndx = name.Find("_TL")) > 0)
	{
		strRet = name.Left(ndx);
	}
	else if ((ndx = name.Find("_tl")) > 0)
	{
		strRet = name.Left(ndx);
	}
	else if ((ndx = name.Find(".")) > 0)
	{
		strRet = name.Left(ndx);
	}
	return strRet;
}

bool CBorderArtDlg::IsFileForList(CString name)
{
	bool bRet = FALSE;
	if (name.Find("_TR") < 0 &&
	name.Find("_TH") < 0 &&
	name.Find("_H") < 0 &&
	name.Find("_B") < 0 &&
	name.Find("_V") < 0 &&
	name.Find("_th") < 0 &&
	name.Find("_h") < 0 &&
	name.Find("_b") < 0 &&
	name.Find("_v") < 0)
	{
		bRet = TRUE;
	}
	return bRet;
}

void CBorderArtDlg::LoadFileLists()
{
	filesColor.RemoveAll();
	filesBW.RemoveAll();
	displayColor.RemoveAll();
	displayBW.RemoveAll();
	CFileFind hFile;
	CString name;
	SwBorderManagement borderInfoColor(1);
	SwBorderManagement borderInfoBW(2);
	bool doUseActualFolder=false;

	// First load the Color Border Art images
	if (doUseActualFolder) {
		CString sPath = theApp.m_BasePath + "\\bdMisc\\BorderArtColor\\";
		BOOL bFound = hFile.FindFile(sPath + _T("*.*"));
		while (bFound)   
		{
			bFound = hFile.FindNextFile();
			if(!hFile.IsDirectory())		
			{
				name = hFile.GetFileName();
				if (IsFileForList(name))
				{
					filesColor.Add(name);
					displayColor.Add(MakeDisplayName(name));
				}
			}
		}
	}
	else {	// user hidden/combined  file
		bool bFirstTime=true;

		while(borderInfoColor.getNextItem(bFirstTime, name) != 0) {
			bFirstTime=false;
			if (IsFileForList(name))
			{
				filesColor.Add(name);
				displayColor.Add(MakeDisplayName(name));
			}
		}
	}

	if (doUseActualFolder) {
		// Next load the Black and White Border Art images
		CString sPath = theApp.m_BasePath + "\\bdMisc\\BorderArtBW\\";
		BOOL bFound = hFile.FindFile(sPath + _T("*.*"));
		while (bFound)   
		{
			bFound = hFile.FindNextFile();
			if(!hFile.IsDirectory())		
			{
				name = hFile.GetFileName();
				if (IsFileForList(name))
				{
					filesBW.Add(name);
					displayBW.Add(MakeDisplayName(name));
				}
			}
		}
	}
	else {	// user hidden/combined  file
		bool bFirstTime=true;

		while(borderInfoBW.getNextItem(bFirstTime, name) != 0) {
			bFirstTime=false;
			if (IsFileForList(name))
			{
				filesBW.Add(name);
				displayBW.Add(MakeDisplayName(name));
			}
		}
	}
}

void CBorderArtDlg::FillArtList()
{
	int i, ndx;

	// We don't use the list if NONE, but the dialog looks bad if the list is empty...
	if (m_nBorderArtSource != BORDER_ART_SOURCE_NONE)
	{
		m_ctlListSWBorderArt.ResetContent();
	}
	if (m_nBorderArtSource == BORDER_ART_SOURCE_SWCOLOR || m_nBorderArtSource == BORDER_ART_SOURCE_NONE && m_ctlListSWBorderArt.GetCount() < 1)
	{
		for (i=0;i<displayColor.GetCount();i++)
		{
			ndx = m_ctlListSWBorderArt.AddString(displayColor[i]);
			m_ctlListSWBorderArt.SetItemData(ndx, i);// save index into real filenames
		}
	}
	else if (m_nBorderArtSource == BORDER_ART_SOURCE_SWBW)
	{
		for (i=0;i<displayBW.GetCount();i++)
		{
			ndx = m_ctlListSWBorderArt.AddString(displayBW[i]);
			m_ctlListSWBorderArt.SetItemData(ndx, i);// save index into real filenames
		}
	}
}

void CBorderArtDlg::InitPreview()
{
	int status;

	m_pBox->Message(BBOX_ITEM_SET, m_pTextItem, &status);
	m_pTextItem->Message(ITEM_PARENT_SET, m_pBox, &status);

	RECT 		rect;
	CPaintDC	dc(this);
	CWnd		*pPreview = GetDlgItem(IDC_BORDERARTEXAMPLE);

	pPreview->GetClientRect(&rect);
	m_rectPreview = rect;
	pPreview->MapWindowPoints(this, &m_rectPreview);

	// Give the 3D look stuff some room.
	InflateRect(&rect, -2, -2);

	PrepareDC(&dc);
	dc.DPtoLP(&rect);
	m_rectBox = rect;

	m_pBox->Message(BBOX_SIZE_SET, 
		CPoint((rect.right - rect.left) * 4, 
		(rect.bottom - rect.top) * 4), 
		&status);

	m_pBox->Message(BBOX_VISIBLE_SET, TRUE, &status);

	// if we do this, then the point size and font changes, and doesn't go back on ok
	m_pBox->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);
	m_pTextItem->nPointSize = m_nSize;// Just so they see how the line size looks with the border
}

void CBorderArtDlg::PrepareDC(CDC *pDC)
{
	// This sets the 'zoom'
	pDC->SetMapMode(MM_ANISOTROPIC);

	pDC->SetWindowExt( DOC_X_EXTENT, DOC_Y_EXTENT);

	pDC->SetViewportExt((int)(pDC->GetDeviceCaps(LOGPIXELSX) * (100 / 100)),
		(int)(-pDC->GetDeviceCaps(LOGPIXELSY) * (100 / 100)));
}

void CBorderArtDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	DrawTextItem(&dc);
}

extern void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);

void CBorderArtDlg::DrawTextItem(CDC *pDC)
{
	int 		status;
	BOOL		bDelete;     

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	// First draw the 3D look stuff.
	CPen 	*ppenOld,
			pen;

	// We need to clear the window first
	//pDC->FillRect(&m_rectPreview, (CBrush *) GetStockObject(BLACK_BRUSH));

	// Dk gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNSHADOW));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.left, m_rectPreview.top);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Black
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNTEXT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.left + 1, m_rectPreview.top + 1);
	pDC->LineTo(m_rectPreview.right - 2, m_rectPreview.top + 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Lt gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNFACE));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// White
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNHIGHLIGHT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	CDC		dcTemp;   
	CBrush *holdBrush;
	CBitmap	bmpTemp,
				*pbmpOld;
	RECT		rectBmp = {0, 0, 
								(m_rectPreview.right - m_rectPreview.left) * 4, 
								(m_rectPreview.bottom - m_rectPreview.top) * 4};

	//InflateRect(&rectBmp, -1, -1);
	if (dcTemp.CreateCompatibleDC(NULL) == FALSE) {
		return;
	}
	if (bmpTemp.CreateCompatibleBitmap(pDC, rectBmp.right, rectBmp.bottom) == FALSE) {
		return;
	}

	pbmpOld = dcTemp.SelectObject(&bmpTemp);
	if (pbmpOld == NULL) {
		return;
	}

	holdBrush = (CBrush *) GetStockObject(HOLLOW_BRUSH);
	if (holdBrush == NULL) {
		return;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) dcTemp.SelectStockObject(NULL_PEN);

	dcTemp.SelectStockObject(WHITE_BRUSH);
	dcTemp.Rectangle(&rectBmp);
	dcTemp.SelectObject(oldpen);		// Restore pen

	// Get the DC ready.
	PrepareDC(&dcTemp);

	m_pTextItem->Draw(&dcTemp, &status);

   // Now blt the TextItem stuff onto the preview area.
	dcTemp.SelectObject(pbmpOld);


	DrawBitmap(pDC->m_hDC, (HBITMAP) bmpTemp.m_hObject, 
		m_rectPreview.left + 2, m_rectPreview.top + 2, SRCCOPY,
		m_rectPreview.right - m_rectPreview.left - 4,
		m_rectPreview.bottom - m_rectPreview.top - 4
		);

	dcTemp.DeleteDC();
	bmpTemp.DeleteObject();

	if (bDelete)
		delete pDC;
}

void CBorderArtDlg::UpdateTextItem()
{
	bool bValid = GetCurrentSelections();
	m_pTextItem->BorderArtFile[0] = m_strBorderArtName;
	m_pTextItem->BorderArtSizeOption = m_nBorderArtSize;
	m_pTextItem->BorderArtSource = m_nBorderArtSource;
	m_pTextItem->BorderArtShrink = m_nBorderArtShrink;
	m_pTextItem->RestoreBorderArt();
	m_pTextItem->SetViaMembers();

	DrawTextItem();
}


void CBorderArtDlg::OnLbnSelchangeListswborderart()
{
	if (m_ctlListBorderArtSize.GetCurSel() < 0)
	{
		m_ctlListBorderArtSize.SetCurSel(0);
	}
	// BorderArtShrink has been made always true and not available as a user choice, but all code is available, just disabled
	// If we decide to re-enable it AS A USER OPTION, enable the code below and also see note in Read in textitem.cpp
	// You will also need to make the checkbox (IDC_CHKBORDERARTSHRINK) visible on the form
	m_nBorderArtShrink = TRUE;// Delete this if you activate code below
#if FALSE
	// If this is a Simple type border art (one image) default Shrink to FALSE and enable it
	// If this is a Complex type border art (8 Startwrite-provided pieces) set Shrink to TRUE and disable changing it
	bool bValid = GetCurrentSelections();
	m_nBorderArtShrink = (m_strBorderArtName.Find("_TL.") > -1 || m_strBorderArtName.Find("_tl.") > -1);
	((CButton *)GetDlgItem(IDC_CHKBORDERARTSHRINK))->SetCheck(m_nBorderArtShrink);
	GetDlgItem(IDC_CHKBORDERARTSHRINK)->EnableWindow(!m_nBorderArtShrink);
#endif

	UpdateTextItem();
}

void CBorderArtDlg::OnLbnSelchangeListborderartsize()
{
	UpdateTextItem();
}

void CBorderArtDlg::OnBnClickedRadioborderart0()
{
	m_nBorderArtSource = BORDER_ART_SOURCE_NONE;
	m_ctlListBorderArtSize.SetCurSel(-1);
	m_ctlListSWBorderArt.SetCurSel(-1);
	FillArtList();
	m_ctlListSWBorderArt.EnableWindow(FALSE);
	m_ctlListBorderArtSize.EnableWindow(FALSE);
	m_nBorderArtShrink = FALSE;
	GetDlgItem(IDC_CHKBORDERARTSHRINK)->EnableWindow(FALSE);
	UpdateTextItem();
}

void CBorderArtDlg::OnBnClickedRadioborderart1()
{
	BasePath = theApp.m_BasePath + "\\bdMisc\\BorderArtColor\\";
	m_nBorderArtSource = BORDER_ART_SOURCE_SWCOLOR;
	m_ctlListSWBorderArt.SetCurSel(-1);
	FillArtList();
	m_ctlListSWBorderArt.EnableWindow(TRUE);
	m_ctlListBorderArtSize.EnableWindow(TRUE);
	UpdateTextItem();
}

void CBorderArtDlg::OnBnClickedRadioborderart2()
{
	BasePath = theApp.m_BasePath + "\\bdMisc\\BorderArtBW\\";
	m_nBorderArtSource = BORDER_ART_SOURCE_SWBW;
	m_ctlListSWBorderArt.SetCurSel(-1);
	FillArtList();
	m_ctlListSWBorderArt.EnableWindow(TRUE);
	m_ctlListBorderArtSize.EnableWindow(TRUE);
	UpdateTextItem();
}


void CBorderArtDlg::OnBnClickedChkborderartshrink()
{
	m_nBorderArtShrink = ((CButton *)GetDlgItem(IDC_CHKBORDERARTSHRINK))->GetCheck();
	UpdateTextItem();
}

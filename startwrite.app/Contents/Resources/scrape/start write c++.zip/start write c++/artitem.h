// Art Item Class Header

#ifndef _ART_ITEM_H_
#define _ART_ITEM_H_

#include <direct.h>
#include "typedef.h"
#include "resource.h"

#include "module.h"
#include "docunits.h"
#include "messages.h"
#include "filefmt.h"

//#include "cdib.h"


#define SIZE_NORMAL	10		// Keep the image in proportion
#define SIZE_FILL	12		// Make the image fill the box

class ArtItem : public Module
{
	private:

		Module *pParentBBox;
		
		CString BasePath;
		CString ImagePath;
		CString saveImagePath;
		CString saveBasePath;
		long	artBufId;		// unique buffer id for this picture
		long	artViewId;		// unique view id
		CPoint	lastPos;
		CPoint	lastSize;
		long		lastFlag;
		CPoint	lastScrollPos;	// Keep track of scrolled position
		CPoint	currScrollPos;	// Keep track of the current scroll
		
		WBOOL PictureLoaded;
		WBOOL ReloadImage;
		WBOOL IsOverlappedByABox;
		WBOOL SizeFormat;

	public:
	
		ArtItem();
		~ArtItem();

		void Read(fstream *fin, Module *pmodule, int *status);
		void Write(fstream *fout, Module *pmodule, int *status);

		void Delete();

		float Message(int message, float number, int *status);
		int Message( int message, int number, int *status);
		CPoint Message( int message, CPoint point, int *status);
		Module* Message( int message, Module *pmodule, int *status);
		
		void Draw(CDC* pDC, int *status);
		int ImagePathDialog();        

	private:
		WBOOL LoadArt(CDC *pDC);
	
};

#endif // _ART_ITEM_H_
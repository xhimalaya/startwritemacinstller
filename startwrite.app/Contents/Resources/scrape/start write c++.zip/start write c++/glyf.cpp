// Glyf Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Glyf.h"
#include "miscutil.h"
 
#include <stdio.h>

 
GlyfTable::GlyfTable( HeadTable *head)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::GlyfTable(HeadTable*)"); 
	#endif
	head;	/* no warning */
	
	Data = NULL;	// Initialize Data

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfTable::GlyfTable: void"); 
	#endif
}

GlyfTable::~GlyfTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::~GlyfTable()"); 
	#endif

	if (Data != NULL) {
		free(Data);
		Data = NULL;
	}
	// malloc #1 is not in Read. Malloc #1 is alloced & freed in GetGlyf.
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfTable::~GlyfTable: void"); 
	#endif
}

int
GlyfTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::Read(ifstream,DirectoryTable*)"); 
	#endif
	
	// tmp for now
	//DIR = dir;
    
	// Read glyf table
	
	// Check for existence of loca table
	if( !dir->GetTag("glyf"))
	{
		Report( TO_LIST, "ENTER GlyfTable::Read: Unable to GetTag(glyf)"); 
		return ERROR;
	}
	
	// Glyf table begins at offset specified in directory table
	// Apparently an int here is not enough to hold the length of the glyf table
	// Load glyf data 'on demand'

	//Data = (char *)malloc((size_t)dir->GetLength());
	//fin->seekg(dir->GetOffset());
	//fin->read( (char *)Data, (size_t)dir->GetLength());
	//cout << "GLYF: data length = " << (size_t)dir->GetLength() << endl;
 	
 	// Swab the shorts...
    //myswab( (char *)Data, (int)dir->GetLength());
    // Hmm... what about other headers in the data...
    //myswab( (char *)Data, sizeof(GlyfHeader));

	//ghp = &gh;
    //gdp = &gd;
	
	//Header = &gh;
	//Description = &gd;
	                                               
	return OK;
}

// This is just a 'copy' function
int
GlyfTable::GetGlyf( GlyfData* glyfdata, fstream *fin, 
					DirectoryTable *dir, CMapTable *cmap,
					LocaTable *loca, unsigned short *c)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::GetGlyf(?,?,?,?,?,?)"); 
	#endif
 	
 	int status = ERROR;
    ULong index = 0;
    ULong offset = 0;
    ULong size = 0;
    
	// Steps to get glyf data for character:
	// 1:  Use cmap table to turn character code into index 
	// 2:  Use loca table to turn index into offset from beginning of glyph data
	// 3:  Use loca table to turn index + 1 for size (size - offset)
	// 4:  Use glyph table to get data at this offset and size

	#ifdef DEBUG_XXX
	cout << "\tTTFont::GetGlyfData: character = " << *c << dec << endl << flush;
	cout << "\tTTFont::GetGlyfData: ascii = " << dec << (int)(*c) << dec << endl << flush;
	#endif

	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Calling cmap->GetIndex...");
	#endif
	
	// 1:  Use cmap table to turn character code into index	
	if( (cmap == NULL) || (loca == NULL) || (cmap->GetIndex( &index, c) == ERROR)) 
	{ 
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Unable to get index!");
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Returning ERROR");
       	return ERROR;
	}
	if (index == 0) {
		return ERROR;
	}
	glyfdata->Index = index;
	
	#ifdef DEBUG_TT
	int tmpint1 = (int)index;
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: index = %d", &tmpint1);
	#endif

	#ifdef DEBUG_TT	
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Calling cmap->GetOffset...");
	#endif
	
	// 2:  Use loca table to turn index into offset from beginning of glyph dat	
	//if( loca->GetOffset( &offset, index) == ERROR) 
	offset = loca->GetOffset( index, &status);
	if( status == ERROR ) 
	{ 
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Unable to get offset!");
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Returning ERROR");
		return ERROR;
	}
    glyfdata->Offset = offset;

	#ifdef DEBUG_TT
	int tmpint2 = (int)offset;
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: offset = %d", &tmpint2);
	#endif

	#ifdef DEBUG_TT    
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Calling cmap->GetOffset...");
	#endif
	
	// 3:  Use loca table to turn index + 1 into size
	//if( loca->GetOffset( &size, index + 1) == ERROR)
	size = loca->GetOffset( index + 1, &status);
	if( status == ERROR ) 
	{ 
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Unable to get offset (for size)!");
       	Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Returning ERROR");
		return ERROR;
	}
    size -= offset;
    glyfdata->Size = size;
	
	#ifdef DEBUG_TT
	int tmpint3 = (int)size;
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: size = %d", &tmpint3);
	#endif

	// If the glyf is 'empty' there is no need to try to read the data.    
    if( size <= 0)
    {
    	// Bad, bad, bad... This caused trouble because when glyf data structures
    	// are reused these public pointers are never reset...
    	//glyfdata->Header = NULL;
    	//glyfdata->Description = NULL;
	
		// Instead zero out the variables and header (but not descrption...)
		glyfdata->Index = 0;
		glyfdata->Offset = 0;
		glyfdata->Size = 0;

		glyfdata->Header->NumberOfContours = 0;
		glyfdata->Header->XMin = 0;
		glyfdata->Header->YMin = 0;
		glyfdata->Header->XMax = 0;
		glyfdata->Header->YMax = 0;
		
		status = (index == 3 ? OK : ERROR);
		return status;
    }

	#ifdef DEBUG_TT    
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Mallocing, seeking & reading...");
	#endif

	// malloc #1	
	if (Data != NULL) {
		free(Data);
	}

	if(( Data = (unsigned char *)malloc((int)size)) == NULL)
	{
		Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Malloc #1 == NULL"); 
		return ERROR;	
	}
	
	fin->seekg( dir->GetOffset() + offset);
	fin->read( (char *)Data, (int)size);
	if( fin->bad() || fin->eof() )
	{
		Report( TO_LIST, "ERROR GlyfTable::GetGlyf: bad or eof on fin");	
		return ERROR;
	}
	fin->close();

	//cout << "GLYF: data length = " << (size_t)dir->GetLength() << endl;
    
    #ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Calling ReadGlyf...");
	#endif
	
    ReadGlyf( glyfdata, Data);
    
	// malloc #1
    free(Data);
	Data = NULL;
    
    status = OK;
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfTable::GetGlyf: %d", &status); 
	#endif
    
	return status;
}

int
GlyfTable::ReadGlyf( GlyfData *glyfdata, unsigned char *cpraw)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::ReadGlyf(?,?)"); 
	#endif

	int status = ERROR;	
	int i = 0;	
	short repeat = 0;
    //char *cpraw;

	GlyfHeader *ghp = glyfdata->Header;
	GlyfDescription *gdp = glyfdata->Description;

    if( ghp == NULL || gdp == NULL)
    {
		Report( TO_LIST, "ERROR GlyfTable::ReadGlyf: ghp or gdp == NULL"); 
		return ERROR;    
    }
    
    //wrwcpraw = copy_short( cpraw, &(ghp->NumberOfContours));
    //wrwcpraw = copy_short( cpraw, &(ghp->XMin));
    //wrwcpraw = copy_short( cpraw, &(ghp->YMin));
    //wrwcpraw = copy_short( cpraw, &(ghp->XMax));
    //wrwcpraw = copy_short( cpraw, &(ghp->YMax));

    ghp->NumberOfContours = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
	if (ghp->NumberOfContours > GLYF_ITEMSIZE) {
		Report( TO_LIST, "ERROR Too many contours"); 
		return ERROR;
	}
    ghp->XMin = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
    ghp->YMin = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
    ghp->XMax = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
    ghp->YMax = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
    
    //for( i=0; i<8; ++i) { cout << i << ": 0x" << hex << (int)cpraw[i] << dec << endl; }
	
	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Getting NumberOfContours...");
	#endif
	
	Report(TO_LIST, "Begin");
    for( i = 0; i < ghp->NumberOfContours; ++i)
    {
		//wrwcpraw = copy_ushort( cpraw, &(gdp->EndPointsOfContours[i]));

		gdp->EndPointsOfContours[i] = (unsigned short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF));
		cpraw += 2;

		gdp->MaxPoints = (unsigned short)(gdp->EndPointsOfContours[i] + 1);
		{
			char buf[128];
#ifdef _CRT_SECURE_NO_DEPRECATE
			_snprintf(buf, 128,"maxpoints=%d", gdp->MaxPoints);
#else
			_snprintf_s(buf, 128, 128,"maxpoints=%d", gdp->MaxPoints);
#endif
			Report(TO_LIST, buf);
		}

		//cout << "\tGlyfTable::GetGlyf: MaxPoints = " << gdp->MaxPoints << endl;
    }   
	Report(TO_LIST, "End");
	/* Don't let the size get too big */
	if (gdp->MaxPoints > GLYF_ITEMSIZE) {
		gdp->MaxPoints = GLYF_ITEMSIZE-1;
		Report( TO_LIST, "ERROR GlyfTable::GetGlyf: Too many points");
		return ERROR;
	}

	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Getting InstructionLength...");
	#endif
	
	//wrwcpraw = copy_ushort( cpraw, &(gdp->InstructionLength));
	gdp->InstructionLength = (unsigned short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF));
	cpraw += 2;


	// Skip over the byte array of insructions
	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Skipping Instructions...");
	#endif
	
	cpraw += gdp->InstructionLength;
    
    // Load flags...
    #ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Getting Flags...");
	#endif
	

	
    for( i = 0; i < (int)gdp->MaxPoints; ++i)
    {
		//cpraw = copy_byte2ushort( cpraw, &(gdp->Flags[i]));
		gdp->Flags[i] = *cpraw++;

		if( gdp->Flags[i] & GLYF_REPEAT)
		{
			//wrwcpraw = copy_byte2short( cpraw, &repeat);
			repeat = *cpraw++;

			while( repeat-- > 0) {
				if (i > gdp->MaxPoints) {
					break;
				}
				gdp->Flags[i+1] = (unsigned short)((gdp->Flags[i] & ~GLYF_REPEAT));
				++i;				
			}			
		}
    }

	unsigned short flags;

	// Load X Coordinates...
	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Getting X Coordinates...");	
	#endif
	
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{
		flags = gdp->Flags[i];
		
		if( flags & GLYF_XBYTE)
		{
			//wrwcpraw = copy_byte2short( cpraw, &(gdp->XCoordinates[i]));

			gdp->XCoordinates[i] = *cpraw++;


			// XDual is sign bit here; 1 = positive & 0 = negative
			if( flags & GLYF_XDUAL){;}
			else { gdp->XCoordinates[i] *= -1; }
			// When XBYTE clear XBYTE and XDUAL 
			// since sign & size are taken care of here
			// THESE MUST BE COMMENTED OUT TO GET THE FLAGS AS THEY EXIST IN THE FILE!!!
			gdp->Flags[i] &= ~GLYF_XBYTE;
			gdp->Flags[i] &= ~GLYF_XDUAL;
		}
		else if( flags & GLYF_XDUAL && i >= 0)
		{
			// Set the dual value to 0 as default
			gdp->XCoordinates[i] = 0;		
		}
		else
		{
			// X is a signed 16-bit delta
			//wrw cpraw = copy_short( cpraw, &(gdp->XCoordinates[i]));		
			gdp->XCoordinates[i] = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
		}
	}

	// Load Y Coordinates...
	#ifdef DEBUG_TT
	Report( TO_LIST, "DEBUG GlyfTable::GetGlyf: Getting Y Coordinates...");	
	#endif
	
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{
		flags = gdp->Flags[i];
		
		if( flags & GLYF_YBYTE)
		{
			//wrwcpraw = copy_byte2short( cpraw, &(gdp->YCoordinates[i]));

			gdp->YCoordinates[i] = *cpraw++;


			// YDual is sign bit here; 1 = positive & 0 = negative
			if( flags & GLYF_YDUAL){;}
			else { gdp->YCoordinates[i] *= -1; }		
			// When YBYTE clear YBYTE and YDUAL
			// since sign & size are taken care of here
			// THESE MUST BE COMMENTED OUT TO GET THE FLAGS AS THEY EXIST IN THE FILE!!!
			gdp->Flags[i] &= ~GLYF_YBYTE;
			gdp->Flags[i] &= ~GLYF_YDUAL;
		}
		else if( flags & GLYF_YDUAL && i >= 0)
		{
			// Set the dual value to 0 as default
			gdp->YCoordinates[i] = 0;		
		}
		else
		{
			// X is a signed 16-bit delta
			//wrw cpraw = copy_short( cpraw, &(gdp->YCoordinates[i]));		
			gdp->YCoordinates[i] = (short)(((cpraw[0] & 0x00FF) << 8) | (cpraw[1] & 0x00FF)); cpraw += 2;
		}
	}
	
	// For testing purposes....
	#ifdef DEBUG_XXX
	int tmp;
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{	
		// Print relative points...
		Report( TO_LIST, "Point: %d", &i);
		tmp = gdp->XCoordinates[i];
		Report( TO_LIST, "X = %d", &tmp);
		tmp = gdp->YCoordinates[i]; 
		Report( TO_LIST, "Y = %d", &tmp); 
		//cout << "XY[" << i << "]: " << dec << gdp->XCoordinates[i] << ", " << gdp->YCoordinates[i] << dec;
	}
    #endif
    
    status = OK;
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfTable::ReadGlyf: %d", &status); 
	#endif
	
	return status;
}


int
GlyfTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfTable::Print()"); 
	#endif

	cout << "** Glyf **" << endl;

	cout << "This space has been intentionally left blank." << endl;

	return OK;
}


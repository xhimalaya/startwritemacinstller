// fontdlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "fontdlg.h"
#include "miscutil.h"

#include "GuideStypeDlg.h"
extern FONTINFO szFonts[];

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFontDlg dialog


CFontDlg::CFontDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFontDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFontDlg)
	m_setAsDefault = FALSE;
	//}}AFX_DATA_INIT

	m_nSize = 48;
	m_strFont = "Arial";
	m_nFontIndex = 2;

	m_pBox = new BBox;
	m_pTextItem = new TextItem;
	m_pCustomColors = NULL;
	m_showGuidelinesButton = FALSE;
}

void CFontDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFontDlg)
	DDX_Control(pDX, IDC_FONTS, m_ctlFonts);
	DDX_Control(pDX, IDC_SIZES, m_ctlSizes);
	DDX_Check(pDX, IDC_FONTDEFAULT, m_setAsDefault);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		CString 	strWhich;
		int		iWhich;

		m_ctlFonts.GetWindowText(strWhich);
		iWhich = m_ctlFonts.FindString(-1, strWhich);
		m_nFontIndex = iWhich;
		
		if (iWhich != CB_ERR)
			m_ctlFonts.GetLBText(iWhich, m_strFont);

		m_nSize = GetDlgItemInt(IDC_SIZES);
		if (m_nSize < 0)
			m_nSize *= -1;
	}
	else
	{
		//m_ctlFonts.AddFonts();
		theApp.CreatePrinterDC(theApp.m_dcPrinter);
		m_ctlFonts.EnumFontFamiliesEx(theApp.m_dcPrinter);
		CMainFrame::AddFontSizes(&m_ctlSizes);

		m_nFontIndex = m_ctlFonts.SelectString(-1, m_strFont);

		CString str;

		str.Format("%d", m_nSize);
		m_ctlSizes.SelectString(-1, str);
		m_ctlSizes.SetWindowText(str);

		InitPreview();
	}
}

BEGIN_MESSAGE_MAP(CFontDlg, CDialog)
	//{{AFX_MSG_MAP(CFontDlg)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_FONTS, OnSelchangeFonts)
	ON_CBN_EDITUPDATE(IDC_SIZES, OnEditupdateSizes)
	ON_CBN_SELCHANGE(IDC_SIZES, OnSelchangeSizes)
	ON_BN_CLICKED(IDC_FONTDEFAULT, OnFontdefault)
	ON_BN_CLICKED(IDC_EDIT_LEDGER, OnEditLedger)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

extern unsigned int defaultFont, defaultSize;

/////////////////////////////////////////////////////////////////////////////
// CFontDlg message handlers

BOOL CFontDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_fontLines = -1;
	(GetDlgItem(IDC_EDIT_LEDGER))->ShowWindow(m_showGuidelinesButton ? SW_SHOW : SW_HIDE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFontDlg::OnOK()
{
	if (m_setAsDefault) {
		theApp.setFontSettings(m_strFont, m_nSize);
		// Update the default font and size
		defaultSize = m_nSize;
		defaultFont = m_ctlFonts.GetCurSel();
	}
	CDialog::OnOK();
}

CFontDlg::~CFontDlg()
{
	if (m_pBox)
		delete m_pBox;

//	Is done by ~BBox.
//	if (m_pTextItem)
//		delete m_pTextItem;
}

void CFontDlg::InitPreview()
{
	int status;
	int saveGrow;
	CString strToAdd;
	int testSize = m_nSize;

	testSize = testSize * 1440 / 72;

	m_pBox->Message(BBOX_ITEM_SET, m_pTextItem, &status);
	m_pTextItem->Message(ITEM_PARENT_SET, m_pBox, &status);

	RECT 		rect;
	CPaintDC	dc(this);
	CWnd		*pPreview = GetDlgItem(IDS_PREVIEW);

	pPreview->GetClientRect(&rect);
	m_rectPreview = rect;
	pPreview->MapWindowPoints(this, &m_rectPreview);

	// Give the 3D look stuff some room.
	InflateRect(&rect, -2, -2);

	PrepareDC(&dc);
	dc.DPtoLP(&rect);
	m_rectBox = rect;

	int middle = (rect.bottom + rect.top)/2;
	middle += testSize;
	if (middle > rect.top) {
		middle = rect.top;
	}

	m_pBox->Message(BBOX_POSITION_SET, CPoint(rect.left, middle), &status);
	saveGrow = m_pBox->Message(BBOX_CAN_GROW, 1, &status);
	m_pBox->Message(BBOX_SET_GROW, 1, &status);
	
	m_pBox->Message(BBOX_SIZE_SET, 
		CPoint((rect.right - rect.left) * 4, 
		(rect.bottom - rect.top) * 4), 
		&status);
	
	m_pBox->Message(BBOX_SET_GROW, saveGrow, &status);

	m_pBox->Message(BBOX_VISIBLE_SET, TRUE, &status);
	m_pBox->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);

	m_pBox->Message(ITEM_ENTER_EDIT_MODE, EMPTY_INT, &status);

	if (theApp.m_isDemo == DEMO_ON) {
		strToAdd = "Aa Cc Zz ";
	}
	else {
		strToAdd = "Dog and Cat";
	}

	// Make sure the initial font stuff is setup correctly
	m_pTextItem->sFontName = m_strFont;
	m_pTextItem->sFontIndex = m_ctlFonts.GetCurSel();
	m_pTextItem->nPointSize = m_nSize;
	m_pTextItem->SetViaMembers();

	m_pTextItem->nAnnoyingFontMsg = TRUE;
	m_pTextItem->nAnnoyingArrowMsg = TRUE;
	m_pTextItem->nAnnoyingOverlayMsg = TRUE;
	m_pTextItem->nOverfullWarning = FALSE;

	for (int i = 0; i < strToAdd.GetLength(); i++)
		m_pTextItem->KeyDown(strToAdd[i], &status);

	int iWhich = -1;
	for(int i = 0; szFonts[i].f_fontname[0]; i++) {
		if (!strcmp(m_strFont, szFonts[i].f_fontname)) {
			iWhich = i;
			break;
		}
	}
	if (iWhich != -1) {
		m_fontLines = szFonts[iWhich].f_fontLine ;
	}

	//m_pTextItem->nDot2DotLinesButton = 7;
	m_pTextItem->nDot2DotDensityButton = 4;
	m_pTextItem->nDot2DotShadeButton = 4;
	m_pTextItem->nDot2DotArrowsButton = 1;
	m_pTextItem->ReadTextBar(FALSE);
}



void CFontDlg::PrepareDC(CDC *pDC)
{
	// This sets the 'zoom'
	pDC->SetMapMode(MM_ANISOTROPIC);

	pDC->SetWindowExt( DOC_X_EXTENT, DOC_Y_EXTENT);

	pDC->SetViewportExt((int)(pDC->GetDeviceCaps(LOGPIXELSX) * (100 / 100)),
		(int)(-pDC->GetDeviceCaps(LOGPIXELSY) * (100 / 100)));
}

void CFontDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	DrawTextItem(&dc);
}

extern void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);

void CFontDlg::DrawTextItem(CDC *pDC)
{
	int 		status;
	BOOL		bDelete;     

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	// First draw the 3D look stuff.
	CPen 	*ppenOld,
			pen;

	// We need to clear the window first
	//pDC->FillRect(&m_rectPreview, (CBrush *) GetStockObject(BLACK_BRUSH));
	int testSize = m_nSize;

	testSize = testSize * 1440 / 72;

	int middle = (m_rectBox .bottom + m_rectBox .top)/2;
	middle += testSize;
	if (middle > m_rectBox .top) {
		middle = m_rectBox .top;
	}
	m_pBox->Message(BBOX_POSITION_SET, CPoint(m_rectBox .left, middle), &status);

	// Dk gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNSHADOW));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.left, m_rectPreview.top);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Black
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNTEXT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.left + 1, m_rectPreview.top + 1);
	pDC->LineTo(m_rectPreview.right - 2, m_rectPreview.top + 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Lt gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNFACE));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// White
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNHIGHLIGHT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	CDC		dcTemp;   
	CBrush *holdBrush;
	CBitmap	bmpTemp,
				*pbmpOld;
	RECT		rectBmp = {0, 0, 
								(m_rectPreview.right - m_rectPreview.left) * 4, 
								(m_rectPreview.bottom - m_rectPreview.top) * 4};

	//InflateRect(&rectBmp, -1, -1);
	if (dcTemp.CreateCompatibleDC(NULL) == FALSE) {
		return;
	}
	if (bmpTemp.CreateCompatibleBitmap(pDC, rectBmp.right, rectBmp.bottom) == FALSE) {
		return;
	}

	pbmpOld = dcTemp.SelectObject(&bmpTemp);
	if (pbmpOld == NULL) {
		return;
	}

	holdBrush = (CBrush *) GetStockObject(HOLLOW_BRUSH);
	if (holdBrush == NULL) {
		return;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) dcTemp.SelectStockObject(NULL_PEN);

	dcTemp.SelectStockObject(WHITE_BRUSH);
	dcTemp.Rectangle(&rectBmp);
	dcTemp.SelectObject(oldpen);		// Restore pen

//	dcTemp.FillRect(&rectBmp, holdBrush);

	// Get the DC ready.
	PrepareDC(&dcTemp);

	m_pTextItem->Draw(&dcTemp, &status);

   // Now blt the TextItem stuff onto the preview area.
	dcTemp.SelectObject(pbmpOld);


	DrawBitmap(pDC->m_hDC, (HBITMAP) bmpTemp.m_hObject, 
		m_rectPreview.left + 2, m_rectPreview.top + 2, SRCCOPY,
		m_rectPreview.right - m_rectPreview.left - 4,
		m_rectPreview.bottom - m_rectPreview.top - 4
		);

	dcTemp.DeleteDC();
	bmpTemp.DeleteObject();

	if (bDelete)
		delete pDC;
}

void CFontDlg::UpdateTextItem()
{
	m_pTextItem->sFontName = m_strFont;
	m_pTextItem->sFontIndex = m_ctlFonts.GetCurSel();
	m_pTextItem->nPointSize = m_nSize;
	m_pTextItem->SetViaMembers(1);
	if (m_fontLines != -1) {
		m_pTextItem->nDot2DotLinesButton = m_fontLines;
	}

	DrawTextItem();
}

void CFontDlg::OnSelchangeFonts()
{
	int iWhich;

	iWhich = m_ctlFonts.GetCurSel();

	if (iWhich == CB_ERR)
		return;

	m_ctlFonts.GetLBText(iWhich, m_strFont);

	UpdateTextItem();
}

void CFontDlg::OnEditupdateSizes()
{
	CString 	strWhich;

	m_ctlSizes.GetWindowText(strWhich);

	m_nSize = atoi(strWhich);

	UpdateTextItem();
}

void CFontDlg::OnSelchangeSizes()
{
	CString 	strWhich;
	int		iWhich;

	iWhich = m_ctlSizes.GetCurSel();

	if (iWhich == CB_ERR)
		return;

	m_ctlSizes.GetLBText(iWhich, strWhich);
	m_nSize = atoi(strWhich);

	UpdateTextItem();
}


void CFontDlg::OnFontdefault() 
{
	m_setAsDefault = m_setAsDefault ^ 1;
}

void CFontDlg::OnEditLedger() 
{
	CGuideStypeDlg cDlg;
	int iWhich = m_ctlFonts.GetCurSel();
	int newSetting=0;

	if (iWhich == CB_ERR)
		return;

	m_ctlFonts.GetLBText(iWhich, m_strFont);

	iWhich = -1;
	for(int i = 0; szFonts[i].f_fontname[0]; i++) {
		if (!strcmp(m_strFont, szFonts[i].f_fontname)) {
			iWhich = i;
			break;
		}
	}

	if (iWhich != -1) {
		cDlg.m_pCustomColors = m_pCustomColors;
		cDlg.m_fontName = szFonts[iWhich].f_fontname;
		cDlg.m_topType = szFonts[iWhich].f_TopLine;
		cDlg.m_midType = szFonts[iWhich].f_MidLine;
		cDlg.m_basType = szFonts[iWhich].f_BasLine;
		cDlg.m_botType = szFonts[iWhich].f_BotLine;

		cDlg.m_crGuideTop = szFonts[iWhich].f_TopColor;
		cDlg.m_crGuideMiddle = szFonts[iWhich].f_MidColor;
		cDlg.m_crGuideBase = szFonts[iWhich].f_BasColor;
		cDlg.m_crGuideBottom = szFonts[iWhich].f_BotColor;
		cDlg.m_LedgeThickness = LINE_THICK_NORMAL;
		if (cDlg.DoModal() != IDOK) {
			return;
		}

		szFonts[iWhich].f_TopColor = cDlg.m_crGuideTop;
		szFonts[iWhich].f_TopLine = (char)cDlg.m_topType;
		newSetting |= (cDlg.m_topType ? SWLINE_TOP : 0);
		m_pTextItem->ColorGuidelineTop = cDlg.m_crGuideTop;

		szFonts[iWhich].f_MidColor = cDlg.m_crGuideMiddle;
		szFonts[iWhich].f_MidLine = (char)cDlg.m_midType;
		newSetting |= (cDlg.m_midType ? SWLINE_MID : 0);
		m_pTextItem->ColorGuidelineMiddle = cDlg.m_crGuideMiddle;

		szFonts[iWhich].f_BasColor = cDlg.m_crGuideBase;
		szFonts[iWhich].f_BasLine = (char)cDlg.m_basType;
		newSetting |= (cDlg.m_basType ? SWLINE_BAS : 0);
		m_pTextItem->ColorGuidelineBase = cDlg.m_crGuideBase;

		szFonts[iWhich].f_BotColor = cDlg.m_crGuideBottom;
		szFonts[iWhich].f_BotLine = (char)cDlg.m_botType;
		newSetting |= (cDlg.m_botType ? SWLINE_BOT : 0);
		m_pTextItem->ColorGuidelineBottom = cDlg.m_crGuideBottom;

#if FALSE
		//!!! Saving previous code-- edit or remove as required...
		cDlg.m_topColor = szFonts[iWhich].f_TopColorInd;
		cDlg.m_topType = szFonts[iWhich].f_TopLine;

		cDlg.m_midColor = szFonts[iWhich].f_MidColorInd;
		cDlg.m_midType = szFonts[iWhich].f_MidLine;
	//	if (cDlg.m_midType & 2) {
	//		cDlg.m_midType &= ~1;
	//	}
		
		cDlg.m_basColor = szFonts[iWhich].f_BasColorInd;
		cDlg.m_basType = szFonts[iWhich].f_BasLine;
		
		cDlg.m_botColor = szFonts[iWhich].f_BotColorInd;
		cDlg.m_botType = szFonts[iWhich].f_BotLine;
		if (cDlg.DoModal() != IDOK) {
			return;
		}

		szFonts[iWhich].f_TopColorInd = cDlg.m_topColor;
		szFonts[iWhich].f_TopLine = (char)cDlg.m_topType;
		newSetting |= (cDlg.m_topType ? SWLINE_TOP : 0);
		switch(szFonts[iWhich].f_TopColorInd) {
		default:
		case 1:
			szFonts[iWhich].f_TopColor = RGB(0,0,255);
			break;
		case 0:
			szFonts[iWhich].f_TopColor = RGB(255,0,0);
			break;
		case 2:
			szFonts[iWhich].f_TopColor = RGB(0,0,0);
			break;
		}
			
		szFonts[iWhich].f_MidColorInd = cDlg.m_midColor;
		szFonts[iWhich].f_MidLine = (char)cDlg.m_midType;
		newSetting |= (cDlg.m_midType ? SWLINE_MID : 0);
		switch(szFonts[iWhich].f_MidColorInd) {
		default:
		case 1:
			szFonts[iWhich].f_MidColor = RGB(0,0,255);
			break;
		case 0:
			szFonts[iWhich].f_MidColor = RGB(255,0,0);
			break;
		case 2:
			szFonts[iWhich].f_MidColor = RGB(0,0,0);
			break;
		}

		szFonts[iWhich].f_BasColorInd = cDlg.m_basColor;
		szFonts[iWhich].f_BasLine = (char)cDlg.m_basType;
		newSetting |= (cDlg.m_basType ? SWLINE_BAS : 0);
		switch(szFonts[iWhich].f_BasColorInd) {
		default:
		case 1:
			szFonts[iWhich].f_BasColor = RGB(0,0,255);
			break;
		case 0:
			szFonts[iWhich].f_BasColor = RGB(255,0,0);
			break;
		case 2:
			szFonts[iWhich].f_BasColor = RGB(0,0,0);
			break;
		}
		
		szFonts[iWhich].f_BotColorInd = cDlg.m_botColor;
		szFonts[iWhich].f_BotLine = (char)cDlg.m_botType;
		newSetting |= (cDlg.m_botType ? SWLINE_BOT : 0);
		switch(szFonts[iWhich].f_BotColorInd) {
		default:
		case 1:
			szFonts[iWhich].f_BotColor = RGB(0,0,255);
			break;
		case 0:
			szFonts[iWhich].f_BotColor = RGB(255,0,0);
			break;
		case 2:
			szFonts[iWhich].f_BotColor = RGB(0,0,0);
			break;
		}
#endif
		m_fontLines = newSetting;
		szFonts[iWhich].f_fontLine = newSetting;
		UpdateTextItem();
		m_fontLines = -1;

		theApp.swSetLedgerSettings(NULL);
	}
}

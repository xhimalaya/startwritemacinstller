/** swabout.cpp **/

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
#include "stdafx.h"
#include "resource.h"
#include "swabout.h"
#include "sw.h"
#include "swregister.h"
#include "artdisp.h"
#include "deactivate.h"
#include "Registration60.h"
#include "ReadLicense.h"
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_COMMAND(IDD_REGISTER, OnRegister)
	ON_BN_CLICKED(IDC_MONEYBACK, OnMoneyback)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_ENTER_REG, &CAboutDlg::OnBnClickedEnterReg)
	ON_BN_CLICKED(IDC_READ_LICENSE, &CAboutDlg::OnBnClickedReadLicense)
END_MESSAGE_MAP()


void CAboutDlg::OnPaint()
{
	// Do not call CDialog::OnPaint() for painting messages
	CDialog::OnPaint();
}

extern CString SetLicenseInfo();

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	if ((theApp.m_wasDemo == 0) || (*swType == swOXD)) {
		CWnd	*pChildButton = GetDlgItem(IDC_MONEYBACK);
		pChildButton->DestroyWindow();
	}
	if (theApp.m_isDemo != DEMO_RELEASE) {
		CWnd	*pChildButton = GetDlgItem(IDC_ENTER_REG);
		pChildButton->DestroyWindow();
	}

	CWnd	*pChild = GetDlgItem(IDS_SPLASH);
	pChild->GetClientRect(&m_rectSplash);
	pChild->MapWindowPoints(this, &m_rectSplash); 

	CString strAbout, strAbout2;
	if (*swType == swDEM)  { //theApp.m_isDemo == DEMO_ON) {
		strAbout.LoadString(IDS_ABOUT_STRING_DEMO);	// Still in demo mode
		strAbout2.LoadString(IDS_ABOUT_STR2_DEMO);	// Still in demo mode
	}
	else {
		if (*swType == swSHR) {	//#ifdef SW_SHERSTON
			strAbout.LoadString(IDS_ABOUT_SHERSTON);	// Sherston About
		}
		else if (*swType == swOXF) {
			strAbout.LoadString(IDS_ABOUT_OXFORD);	// Sherston About
		}
		else if (*swType == swOXD) {
			strAbout.LoadString(IDS_ABOUT_OXFORD_DEMO);	// Sherston About
		}
		else {
			strAbout.LoadString(IDS_ABOUT_STRING);		// Regular Startwrite, Inc About
		}
		if (*swType != swOXD) {
			strAbout2 = SetLicenseInfo();
		}
		else {
			strAbout2.Empty();
		}
	}

	if ((*swType == swHOP) || (*swType == swHPD)) {
		CString strAboutHooked;
		strAboutHooked.LoadString(IDS_ABOUT_STRING_HOOKED);
		SetDlgItemText(IDS_ABOUT_STRING2, strAboutHooked);
	}

	SetDlgItemText(IDS_ABOUT_STRING, strAbout);
	SetDlgItemText(IDS_ABOUT_STR2, strAbout2);

	// now paint the graphics in the the dialog
	CPoint pos = CPoint(m_rectSplash.left,m_rectSplash.top);
	CPoint size = CPoint(m_rectSplash.right-m_rectSplash.left, m_rectSplash.bottom - m_rectSplash.top);
	CString dummy;

	artDisplay(m_hWnd, ABOUTVIEW1, ABOUTBUF1, pos, size, SWA_RESOURCE+SWA_FLUSH, theApp.m_splashStr, 0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAboutDlg::OnDestroy()
{
	CDialog::OnDestroy();
}


void CAboutDlg::OnRegister() 
{
	
}

void CAboutDlg::OnMoneyback() 
{
	CDeactivate cDlg;

	cDlg.DoModal();
}


void CAboutDlg::OnBnClickedEnterReg()
{
	CRegistration60 CDlg;

	CDlg.DoModal();
	if (theApp.m_isDemo == false)
		this->OnOK();
}


void CAboutDlg::OnBnClickedReadLicense()
{
	CReadLicense CDlg;

	CDlg.DoModal();
}

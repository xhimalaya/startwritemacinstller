// Document Class Header

#ifndef _PAGE_H_
#define _PAGE_H_

#include "module.h"
#include "docunits.h"
#include "messages.h"
#include "filefmt.h"

#include "bbox.h"
#include "textitem.h"
#include "artitem.h"


class Page : public Module
{
	public:
		float dCurrentZoom;


	private:

		int nXPixels;
		int nYPixels;
		int m_saveGrow;

		// All of the bboxes on the page
		// 0 is never a valid bbox (so 0s can represend 'no bbox' in the int arrays)
		BBox* pBBoxes[MAX_BBOXES+1];

	    // Can select every box on the page
	    //int CurrentBBoxes[MAX_BBOXES+1];
	    int nCurrentBBox;
		int nCurrentRedraw;  // Sometimes we need to redraw after nCurrentBBox is cleared

		// A true or false state
	    int nHoldingLButton;

		int nDontDraw;	// true when we don't want to draw display
	    
	    // Position that the button was pressed down
	    CPoint HoldingPosition;
	    
	    CPoint TmpPosition;

		BBox HiliteBBox, *pHiliteBBox;
		
		int nCurrentTool;
		int nSelection;	// For Text selection
		int nChangePaper;
		int nChangeOrientation;

		int nFirstStoryBox;
		int nStoryBoxes;//The number of story boxes on the page
				
	public:
	
		Page(int doInitPage, int defOrientation);
		~Page();

		void Read(fstream *fin, Module *pmodule, int *status);
		void Write(fstream *fout, Module *pmodule, int *status);

		void Delete();

		float Message(int message, float number, int *status);
		int Message( int message, int number, int *status);
		CPoint Message( int message, CPoint point, int *status);
		Module* Message( int message, Module *pmodule, int *status);
		
		void Draw(CDC* pDC, int *status);
		BOOL IsLandscape() {return nChangeOrientation == PAGE_ORIENTATION_LANDSCAPE;}
		BBox *GetBBoxAtPoint( CPoint point);
	   BBox *GetCurrentBox();
	   TextItem *GetStoryItem(int orderNumber);

	private:
	
		void SetPixelsFromMembers(int nPaper, int nOrientation);			

		int PageBBoxNew( int *status);
		int PageBBoxAdd( BBox *pnbbox, int *status);

		CPoint MouseLButtonDown( CPoint point, int *status);		
		CPoint MouseMove( CPoint point, int *status);		
		CPoint MouseLButtonUp( CPoint point, int *status);		
        
        CPoint ToolBeginUsing( CPoint point, int *status);
        CPoint ToolWhileUsing( CPoint point, int *status);
        CPoint ToolEndUsing( CPoint point, int *status);

		BOOL ClearArtBoxesOverlappedByThisBox(BBox *pcbbox, BOOL doReshow, int nMax);
		BOOL ShowArtBoxIfNotOverlapped(BBox *pcbbox, Module *pcItem, int nBBoxIndex, int *status);
		int GetBoxScootSnapPos(int nDirection, int curPos);

#ifdef DO_OVERLAP
		int IsOverlappingAnythingOnLayer( int nlayer, BBox* pbbox, int *status);
#endif
		int GetBBoxAtPoint( CPoint point, int *status);
				
};

#endif // _PAGE_H_
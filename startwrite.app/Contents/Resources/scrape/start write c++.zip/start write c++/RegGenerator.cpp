#include "stdafx.h"
#include "RegGenerator.h"
#include "math.h"
#include "string.h"

CRegGenerator::CRegGenerator(void)
{
	listOne[0] = 'A';
	listOne[1] = 'B';
	listOne[2] = 'C';
	listOne[3] = 'D';
	listOne[4] = 'E';
	listOne[5] = 'F';
	listOne[6] = 'G';
	listOne[7] = 'H';
	listOne[8] = 'J';
	listOne[9] = 'K';
	listOne[10] = 'V';
	listOne[11] = 'U';
	listOne[12] = 'T';
	listOne[13] = 'Z';

	listTwo[0] = 'L';
	listTwo[1] = 'M';
	listTwo[2] = 'N';
	listTwo[3] = 'P';
	listTwo[4] = 'R';
	listTwo[5] = 'S';
	listTwo[6] = 'T';
	listTwo[7] = 'W';
	listTwo[8] = 'X';
	listTwo[9] = 'Z';
	listTwo[10] = 'A';
	listTwo[11] = 'D';
	listTwo[12] = 'F';
	listTwo[13] = 'G';

}

CRegGenerator::~CRegGenerator(void)
{
}

// SWSnnnnnLnnnnL  Single
// SWLnnnnnLnnnnL  LabPack
// SWNnnnnnLnnnnL  Network

bool CRegGenerator::VerifyRegistration(char *regString)
{
	int wholeNum;
	int firstNum;

	if (regString == NULL) {
		return(false);
	}

	if (strlen(regString) != 14) {
#ifdef _DEBUG
		AfxMessageBox("Bad Length");
#endif
		return(false);
	}
	if ((*(regString+0) == 'S') && (*(regString+1) == 'W')) {
		wholeNum = atoi(regString+3);
		if ((wholeNum <= 9999) || (wholeNum > 99999)) {
#ifdef _DEBUG
			AfxMessageBox("Wrong Number");
#endif
			return(false);
		}
		firstNum = (*(regString+12)-'0');
		if ((firstNum < 0) || (firstNum > 13)) {
#ifdef _DEBUG
			AfxMessageBox("First Number out of range");
#endif
			return(false);
		}
		if (listOne[firstNum] == *(regString+8)) {
			if (listTwo[firstNum] == *(regString+13)) {
				return(true);
			}
#ifdef _DEBUG
			else {
				AfxMessageBox("listTwo misMatch");
			}
#endif
		}
#ifdef _DEBUG
		else {
			AfxMessageBox("listOne misMatch");
		}
#endif
	}
#ifdef _DEBUG
	else {
		AfxMessageBox("Invalid Pre-fix");
	}
#endif
	return(false);
}

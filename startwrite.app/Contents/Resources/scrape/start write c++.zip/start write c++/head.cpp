// Font Header Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Head.h"
 
#include <stdio.h>
 
HeadTable::HeadTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER HeadTable::HeadTable()"); 
	#endif

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT HeadTable::HeadTable: void"); 
	#endif
}

HeadTable::~HeadTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER HeadTable::~HeadTable()"); 
	#endif

	// NO malloc

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT HeadTable::~HeadTable: void"); 
	#endif
}

int
HeadTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER HeadTable::Read(ifstream,DirectoryTable*)"); 
	#endif
	
	// Read head table
	
	// Check for existence of name table
	if( !dir->GetTag("head"))
	{
		Report( TO_LIST, "ERROR HeadTable::Read: Unable to GetTag(head)"); 
		return ERROR;
	}
	
	// Head table begins at offset specified in directory table		 
	fin->seekg(dir->GetOffset());	 
	fin->read( (char *)&Table, sizeof(Table));	
 	
 	// Swab the shorts...
    myswab( (unsigned char *)&Table, sizeof(Table));

// Note: The ULongs and dates in this header are not fixed yet....	    
#ifdef notnow
	// Swap the His & Los of the longs...
	{
		int i = 0;
		EncodingRecord_LE *entry;
		unsigned short tmp;    
    	for( i = 0; i < (int)Table.NumRecords; ++i)
    	{
			entry = (EncodingRecord_LE *)Records + i;
 			tmp = entry->EncodingOffsetHi; 
 			entry->EncodingOffsetHi = entry->EncodingOffsetLo; 
 			entry->EncodingOffsetLo = tmp;
 		}	
 	}    
#endif // notnow    
	
	// NO malloc
	                                               
	return OK;
}


Short
HeadTable::GetIndexToLocFormat()
{
	return Table.IndexToLocFormat;
}


int
HeadTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER HeadTable::Print()"); 
	#endif

	cout << "** Head **" << endl;
	cout << dec;
	cout << "Version:\t" << Table.Version << endl;
	cout << "FontRevision:\t" << Table.FontRevision << endl;
	cout << "CheckSumAdjustment:\t0x" << hex << Table.CheckSumAdjustment << dec << endl;
	cout << "MagicNumber:\t0x" << hex << Table.MagicNumber << dec << endl;
	cout << "Flags:\t0x" << hex << Table.Flags << dec << endl;
	cout << "UnitsPerEm:\t" << Table.UnitsPerEm << endl;
	cout << "XMin:\t" << Table.XMin << endl;
	cout << "YMin:\t" << Table.YMin << endl;
	cout << "XMax:\t" << Table.XMax << endl;
	cout << "YMax:\t" << Table.YMax << endl;
	cout << "MacStyle:\t0x" << hex << Table.MacStyle << dec << endl;	
	cout << "LowestRecPPEM:\t" << Table.LowestRecPPEM << endl;
	cout << "FontDirectionHint:\t" << Table.FontDirectionHint << endl;
	cout << "IndexToLocFormat:\t" << Table.IndexToLocFormat << endl;
	cout << "GlyphDataFormat:\t" << Table.GlyphDataFormat << endl;		
	cout << dec;

	return OK;
}
// Deactivate.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "Deactivate.h"
#include "moneyback.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDeactivate dialog


CDeactivate::CDeactivate(CWnd* pParent /*=NULL*/)
	: CDialog(CDeactivate::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDeactivate)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDeactivate::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDeactivate)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDeactivate, CDialog)
	//{{AFX_MSG_MAP(CDeactivate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeactivate message handlers

void CDeactivate::OnOK() 
{
	CMoneyBack cDlg;
	int ret;

	ret = AfxMessageBox("Are you sure you want to disable Startwrite?", MB_YESNO);

	if(ret == IDYES) {
		cDlg.DoModal();
	}

	CDialog::OnOK();
}

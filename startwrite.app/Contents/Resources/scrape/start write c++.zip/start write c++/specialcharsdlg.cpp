// specialcharsdlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swdoc.h"
#include "swview.h"
#include "specialcharsdlg.h"
#include "miscutil.h"

#include "GuideStypeDlg.h"
extern FONTINFO szFonts[];
extern int beginMathFonts;

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif
extern int numSwFonts;

/////////////////////////////////////////////////////////////////////////////
// CSpecialCharsDlg dialog


CSpecialCharsDlg::CSpecialCharsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSpecialCharsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpecialCharsDlg)
	//}}AFX_DATA_INIT

	m_nSize = 14;
	m_strFont = "Arial";
	m_nFontIndex = 2;

	m_pBox = new BBox;
	m_pSpecialCharsItem = new SpecialCharsItem;
	m_pTextItem = NULL;
	m_pView = NULL;

	m_nGridCellWidth = SHAPES_CELL_WIDTH;
	m_nGridCellHeight = 0;
	m_nGridWidth = SHAPES_GRID_WIDTH;
	m_nGridHeight = 0;
	m_nGridCols = SHAPES_GRID_COLS;
	m_nGridRows = 0;

	m_nCharIndexCurrent = -1;
	m_nCharIndexPrevious = -1;

	for (int i=0; i<SHAPES_MAX; i++) {
		m_rectChar[i].top = 0;
		m_rectChar[i].left = 0;
		m_rectChar[i].bottom = 0;
		m_rectChar[i].right = 0;
	}
}

void CSpecialCharsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpecialCharsDlg)
	DDX_Control(pDX, IDC_BUTTON_INSERT, m_buttonInsert);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
	}
	else
	{
		InitPreview();
	}
}

BEGIN_MESSAGE_MAP(CSpecialCharsDlg, CDialog)
	//{{AFX_MSG_MAP(CSpecialCharsDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_BN_CLICKED(IDC_BUTTON_INSERT, &CSpecialCharsDlg::OnBnClickedButtonInsert)
END_MESSAGE_MAP()

extern unsigned int defaultFont, defaultSize;

/////////////////////////////////////////////////////////////////////////////
// CSpecialCharsDlg message handlers

BOOL CSpecialCharsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

CSpecialCharsDlg::~CSpecialCharsDlg()
{
	if (m_pBox)
		delete m_pBox;
}

void CSpecialCharsDlg::InitPreview()
{
	int status;
	int saveGrow;

	m_pBox->Message(BBOX_ITEM_SET, m_pSpecialCharsItem, &status);
	m_pSpecialCharsItem->Message(ITEM_PARENT_SET, m_pBox, &status);

	RECT 		rect;
	CPaintDC	dc(this);
	CWnd		*pPreview = GetDlgItem(IDS_PREVIEW);

	pPreview->GetClientRect(&rect);
	m_rectPreview = rect;
	pPreview->MapWindowPoints(this, &m_rectPreview);

	// Give the 3D look stuff some room.
	InflateRect(&rect, -2, -2);

	PrepareDC(&dc);
	dc.DPtoLP(&rect);
	m_rectBox = rect;

	m_rectBox.left += 80;
	m_rectBox.top -= 100;

	m_pBox->Message(BBOX_POSITION_SET, CPoint(m_rectBox.left, m_rectBox.top), &status);
	saveGrow = m_pBox->Message(BBOX_CAN_GROW, 1, &status);
	m_pBox->Message(BBOX_SET_GROW, 1, &status);
	
	m_pBox->Message(BBOX_SIZE_SET, 
		CPoint((m_rectBox.right - m_rectBox.left), 
		(m_rectBox.bottom - m_rectBox.top) ), 
		&status);
	
	m_pBox->Message(BBOX_SET_GROW, saveGrow, &status);

	m_pBox->Message(BBOX_VISIBLE_SET, TRUE, &status);
	m_pBox->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);

	m_pBox->Message(ITEM_ENTER_EDIT_MODE, EMPTY_INT, &status);

	this->SetWindowTextA("Special Characters - " + m_strFont);

	m_pSpecialCharsItem->sFontName = m_strFont;
	m_pSpecialCharsItem->sFontIndex = m_nFontIndex;
	m_pSpecialCharsItem->nPointSize = m_nSize;
	m_pSpecialCharsItem->SetViaMembers();

	m_pSpecialCharsItem->nAnnoyingFontMsg = TRUE;
	m_pSpecialCharsItem->nAnnoyingArrowMsg = TRUE;
	m_pSpecialCharsItem->nAnnoyingOverlayMsg = TRUE;
	m_pSpecialCharsItem->nOverfullWarning = FALSE;

	m_pSpecialCharsItem->nDot2DotDensityButton = 4;
	m_pSpecialCharsItem->nDot2DotShadeButton = 4;
	m_pSpecialCharsItem->nDot2DotArrowsButton = 1;
	m_pSpecialCharsItem->ReadTextBar(FALSE);

	// Range is SHAPES_START_UNSIGNED through SHAPES_END_EXTENDED  (130 through 420 per spec)
	m_pSpecialCharsItem->IsFromSpecialCharDlg = TRUE;

	for (int i = SHAPES_START_UNSIGNED; i <= SHAPES_END_UNSIGNED; i++) {
		m_pSpecialCharsItem->KeyDown(i, &status);
		m_pSpecialCharsItem->KeyDown(32, &status);
	}
	// The special StartWrite fonts can have special characters up to 420
	// (Chars above 420 are hidden characters that are used internally for special purposes)
	if (m_nFontIndex < beginMathFonts) {
		m_pSpecialCharsItem->IsFromSpecialCharDlg = TRUE;
		for (int i = SHAPES_START_EXTENDED; i <= SHAPES_END_EXTENDED; i++) {
			m_pSpecialCharsItem->KeyDown(i, &status);
			m_pSpecialCharsItem->KeyDown(32, &status);
		}
		m_pSpecialCharsItem->IsFromSpecialCharDlg = FALSE;
	}
}


void CSpecialCharsDlg::PrepareDC(CDC *pDC)
{
	// This sets the 'zoom'
	pDC->SetMapMode(MM_ANISOTROPIC);

	pDC->SetWindowExt( DOC_X_EXTENT, DOC_Y_EXTENT);

	pDC->SetViewportExt((int)(pDC->GetDeviceCaps(LOGPIXELSX) * (100 / 100)),
		(int)(-pDC->GetDeviceCaps(LOGPIXELSY) * (100 / 100)));
}

void CSpecialCharsDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	if (m_pSpecialCharsItem != NULL && !m_pSpecialCharsItem->bIsSetupDone) {
		DrawSpecialCharsItem(&dc);
	}
	DrawSpecialCharsGrid(&dc);
}

extern void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);


void CSpecialCharsDlg::DrawSpecialCharsItem(CDC *pDC)
{
	if (m_pSpecialCharsItem == NULL || m_pSpecialCharsItem->bIsSetupDone) {
		return;
	}

	int status;
	BOOL bDelete;

	CDC dcTemp;   
	CBrush *holdBrush;
	CBitmap bmpTemp, *pbmpOld;
	RECT rectBmp = {0, 0, (m_rectPreview.right - m_rectPreview.left) * 4, (m_rectPreview.bottom - m_rectPreview.top) * 4};

	if (dcTemp.CreateCompatibleDC(NULL) == FALSE) {
		return;
	}
	if (bmpTemp.CreateCompatibleBitmap(pDC, rectBmp.right, rectBmp.bottom) == FALSE) {
		return;
	}
	pbmpOld = dcTemp.SelectObject(&bmpTemp);
	if (pbmpOld == NULL) {
		return;
	}

	holdBrush = (CBrush *) GetStockObject(HOLLOW_BRUSH);
	if (holdBrush == NULL) {
		return;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) dcTemp.SelectStockObject(NULL_PEN);

	dcTemp.SelectStockObject(WHITE_BRUSH);
	dcTemp.Rectangle(&rectBmp);
	dcTemp.SelectObject(oldpen);		// Restore pen

	// Get the DC ready.
	PrepareDC(&dcTemp);

	m_pSpecialCharsItem->Draw(&dcTemp, &status);

	// Build the grid cell coordinates
	int nStartYText = abs(m_pSpecialCharsItem->rectChar[0].top);
	int nStartXText = m_pSpecialCharsItem->rectChar[0].left;
	int nStartYImage = m_nFontIndex < beginMathFonts ? 15 : 20;// Current SW fonts seem drawn higher above lines than other fonts.  Adjust here if that changes.
	int nStartXImage = 15;
	for (int i=0; i<SHAPES_MAX; i++) {
		if (m_pSpecialCharsItem->nCharValue[i] > 0) {
			m_rectChar[i].top = nStartYImage + ((abs(m_pSpecialCharsItem->rectChar[i].top) - nStartYText) / 15);
			m_rectChar[i].left = nStartXImage + ((m_pSpecialCharsItem->rectChar[i].left - nStartXText) / 15);
			m_rectChar[i].bottom = 1 + nStartYImage + ((abs(m_pSpecialCharsItem->rectChar[i].bottom) - nStartYText) / 15);
			m_rectChar[i].right = 1 + nStartXImage + ((m_pSpecialCharsItem->rectChar[i].right - nStartXText) / 15);
		}
		else {
			m_rectChar[i].top = 0;
			m_rectChar[i].left = 0;
			m_rectChar[i].bottom = 0;
			m_rectChar[i].right = 0;
		}
	}
	m_pSpecialCharsItem->bIsSetupDone = TRUE;
	m_pSpecialCharsItem->nCharIndexMax = m_pSpecialCharsItem->nCharIndexCurrent;
	m_nGridRows = min(GRID_ROWS_MAX, m_pSpecialCharsItem->nCharIndexMax / m_nGridCols + ((m_pSpecialCharsItem->nCharIndexMax - 1) % m_nGridCols > 0 ? 1 : 0));

	CWnd *pPreview = GetDlgItem(IDS_PREVIEW);
	CWnd *pBtnClose = GetDlgItem(IDCANCEL);
	if (m_nGridRows < GRID_ROWS_MAX) {
		int nDecreaseHeight = (GRID_ROWS_MAX - m_nGridRows) * -28;
		CRect rectGridArea(0, 0, 0, 0);
		pPreview->GetClientRect(&rectGridArea);
		rectGridArea.InflateRect(0, 0, 0, nDecreaseHeight);
		rectGridArea.OffsetRect(10, 10);
		pPreview->MoveWindow(rectGridArea);
		m_rectPreview = rectGridArea;

		CRect rectBtnInsert(0, 0, 0, 0);
		CRect rectBtnClose(0, 0, 0, 0);
		m_buttonInsert.GetClientRect(&rectBtnInsert);
		rectBtnInsert.OffsetRect(10 + rectGridArea.Width() / 2 - rectBtnInsert.Width() - 10, rectGridArea.bottom + 10);
		m_buttonInsert.MoveWindow(&rectBtnInsert);
		pBtnClose->GetClientRect(&rectBtnClose);
		rectBtnClose.OffsetRect(10 + rectGridArea.Width() / 2 + 20, rectGridArea.bottom + 10);
		pBtnClose->MoveWindow(&rectBtnClose);

		CRect rectThisDlg(0, 0, 0, 0);
		this->GetWindowRect(&rectThisDlg);
		rectThisDlg.InflateRect(0, 0, 0, nDecreaseHeight + 20);
		this->MoveWindow(&rectThisDlg);
	}

	// If there are no special characters for the current font, show message and don't show grid
	if (m_nGridRows < 1) {
		m_buttonInsert.EnableWindow(FALSE);
		((CWnd *)GetDlgItem(IDC_STATIC_NOSPECIALCHARS))->ShowWindow(SW_SHOW);
		dcTemp.DeleteDC();
		bmpTemp.DeleteObject();
		return;
	}
   // Now blt the SpecialCharsItem display onto the preview area.
	dcTemp.SelectObject(pbmpOld);

	DrawBitmap(pDC->m_hDC, (HBITMAP) bmpTemp.m_hObject, 
		m_rectPreview.left + 2, m_rectPreview.top + 2, SRCCOPY,
		m_rectPreview.right - m_rectPreview.left - 4,
		m_rectPreview.bottom - m_rectPreview.top - 4
		);

	dcTemp.DeleteDC();
	bmpTemp.DeleteObject();

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	// Draw the 3D look stuff
	CPen 	*ppenOld,
			pen;

	m_pBox->Message(BBOX_POSITION_SET, CPoint(m_rectBox.left, m_rectBox.top), &status);

	// Dk gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNSHADOW));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.left, m_rectPreview.top);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Black
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNTEXT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.left + 1, m_rectPreview.top + 1);
	pDC->LineTo(m_rectPreview.right - 2, m_rectPreview.top + 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Lt gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNFACE));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// White
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNHIGHLIGHT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	if (bDelete)
		delete pDC;
}

void CSpecialCharsDlg::DrawSpecialCharsGrid(CDC *pDC)
{
	BOOL		bDelete;

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	pDC->SelectStockObject(BLACK_PEN);
	CBrush *pOldBrush = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);
	for (int i=0; i<SHAPES_MAX; i++) {
		if (m_pSpecialCharsItem->nCharValue[i] > 0) {
			pDC->Rectangle(m_rectChar[i].left, m_rectChar[i].top, m_rectChar[i].right, m_rectChar[i].bottom);
		}
	}

	if (m_nCharIndexPrevious > -1 && m_pSpecialCharsItem->nCharValue[m_nCharIndexPrevious] > 0) {
		pDC->SelectStockObject(WHITE_PEN);
		pDC->Rectangle(m_rectChar[m_nCharIndexPrevious].left + 1,
		m_rectChar[m_nCharIndexPrevious].top + 1,
		m_rectChar[m_nCharIndexPrevious].right - 1,
		m_rectChar[m_nCharIndexPrevious].bottom - 1);
		pDC->SelectStockObject(BLACK_PEN);
	}

	if (m_nCharIndexCurrent > -1 && m_pSpecialCharsItem->nCharValue[m_nCharIndexCurrent] > 0) {
		pDC->Rectangle(m_rectChar[m_nCharIndexCurrent].left + 1,
		m_rectChar[m_nCharIndexCurrent].top + 1,
		m_rectChar[m_nCharIndexCurrent].right - 1,
		m_rectChar[m_nCharIndexCurrent].bottom - 1);
	}

	pDC->SelectObject(pOldBrush);
	if (bDelete)
		delete pDC;
}

void CSpecialCharsDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	nFlags;
	m_nCharIndexPrevious = m_nCharIndexCurrent;
	m_nCharIndexCurrent = -1;
	m_buttonInsert.EnableWindow(FALSE);
	for (int i=0; i<SHAPES_MAX; i++) {
		if (point.y > m_rectChar[i].top
			&& point.x > m_rectChar[i].left
			&& point.y < m_rectChar[i].bottom
			&& point.x < m_rectChar[i].right) {
				m_nCharIndexCurrent = i;
				m_buttonInsert.EnableWindow(TRUE);
				break;
		}
	}
	//CDialog::OnLButtonDown(nFlags, point);
	Invalidate(0);
}

void CSpecialCharsDlg::OnBnClickedButtonInsert()
{
	if (m_nCharIndexCurrent > -1 && m_pSpecialCharsItem->nCharValue[m_nCharIndexCurrent] > 0) {
		m_pTextItem->IsFromSpecialCharDlg = TRUE;
		m_pView->SendMessage(WM_KEYDOWN, m_pSpecialCharsItem->nCharValue[m_nCharIndexCurrent], SHAPES_KEY_SENT);
		m_pTextItem->IsFromSpecialCharDlg = FALSE;
	}
}


void CSpecialCharsDlg::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	OnBnClickedButtonInsert();
}

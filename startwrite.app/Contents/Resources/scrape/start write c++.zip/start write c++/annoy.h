#if !defined(AFX_ANNOY_H__9E111F45_01CE_11D4_B60B_F1D6C4E2640B__INCLUDED_)
#define AFX_ANNOY_H__9E111F45_01CE_11D4_B60B_F1D6C4E2640B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Annoy.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAnnoy dialog

class CAnnoy : public CDialog
{
// Construction
public:
	CAnnoy(CWnd* pParent = NULL);   // standard constructor
	int Counter;
// Dialog Data
	//{{AFX_DATA(CAnnoy)
	enum { IDD = IDD_ANNOY };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnnoy)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAnnoy)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANNOY_H__9E111F45_01CE_11D4_B60B_F1D6C4E2640B__INCLUDED_)

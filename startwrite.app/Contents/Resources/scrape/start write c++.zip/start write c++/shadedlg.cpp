// shadedlg.cpp : implementation file
//
#include "stdafx.h"
#include "sw.h"
#include "shadedlg.h"

#include "miscutil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShadeDlg dialog


CShadeDlg::CShadeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShadeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShadeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

int iShadeIDs[] = {IDC_SHADING_NORMAL, IDC_SHADING_FIRST_LINE, 
							IDC_SHADING_FIRST_WORD, IDC_SHADING_ALTER_WORD,IDC_SHADING_ALLFIRST_WORD};

void CShadeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShadeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
		GetRadioRowValue(m_hWnd, &m_iShading, iShadeIDs, sizeof(iShadeIDs)/sizeof(int));
	else
		SetRadioRowValue(m_hWnd, m_iShading, iShadeIDs, sizeof(iShadeIDs)/sizeof(int));
}

BEGIN_MESSAGE_MAP(CShadeDlg, CDialog)
	//{{AFX_MSG_MAP(CShadeDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CShadeDlg message handlers


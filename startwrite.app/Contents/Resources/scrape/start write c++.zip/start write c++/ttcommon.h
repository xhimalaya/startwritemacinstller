// TrueType Common Header

#ifndef _TTCOMMON_H_
#define _TTCOMMON_H_

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include "common.h"
#include "reporter.h"

// Level 1 debug is entry and exit info
//#define DEBUG_ENTER
//#define DEBUG_EXIT

//#define OK		1
//#define ERROR	0

// for string compares
#define S1_EQUALS_S2 0

/*
// for info/error/debug reporting
#define TO_SCREEN	0x0001
#define TO_FILE		0x0010
#define TO_ALL		0x0011
#define TO_LIST		TO_FILE

int Report( int where, char *string);
int Report( int where, char *format, char *arg1);
int Report( int where, char *format, int *arg1);

void myswab( char *ptr, int bytes);

char *copy_short( char *src, short *dest);
char *copy_ushort( char *src, unsigned short *dest);
char *copy_byte2short( char *src, short *dest);
char *copy_byte2ushort( char *src, unsigned short *dest);
*/
#endif // _TTCOMMON_H_
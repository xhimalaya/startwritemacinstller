// Bounding Box Item Abstract Base Class

#ifndef _MODULE_H_
#define _MODULE_H_

#include "stdafx.h"

#include "reporter.h"

#include "bbox.h"

class Module 
{
	public:

		virtual BBox* GetParent();
		virtual Module* SetParent(Module *);
		
		virtual int Event(int event, CPoint point) = 0;
		virtual int Draw(CDC* pDC) = 0;
};

#endif // _MODULE_H_ 
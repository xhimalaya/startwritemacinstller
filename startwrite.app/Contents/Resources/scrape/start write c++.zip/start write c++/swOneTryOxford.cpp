// swOneTryOxford.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swOneTryOxford.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CswOneTryOxford dialog


CswOneTryOxford::CswOneTryOxford(CWnd* pParent /*=NULL*/)
	: CDialog(CswOneTryOxford::IDD, pParent)
{
	//{{AFX_DATA_INIT(CswOneTryOxford)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CswOneTryOxford::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CswOneTryOxford)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CswOneTryOxford, CDialog)
	//{{AFX_MSG_MAP(CswOneTryOxford)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CswOneTryOxford message handlers

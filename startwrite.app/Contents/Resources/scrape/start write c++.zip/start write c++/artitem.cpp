// Art Item Class Implementation

#include "stdafx.h"
#include "ArtItem.h"
#include "artdisp.h"	// 
#include "stdlib.h"
#include "miscutil.h"
#include "sw.h"

extern int inPrintPreview;

ArtItem::ArtItem()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::ArtItem()"); 
	#endif
		
	pParentBBox = NULL;

	BasePath = theApp.m_strArtPath;		// Get the system art path
	ImagePath.Empty();
	saveImagePath.Empty();
	saveBasePath.Empty();
	artBufId = artIdValue++;
	artViewId = artIdValue++;

	PictureLoaded = FALSE;
	ReloadImage = TRUE;			// Need to set to load first time
	IsOverlappedByABox = FALSE;
	SizeFormat = SIZE_NORMAL;
	lastPos = CPoint(0,0);
	lastSize = CPoint(0,0);
	lastFlag = -1;
	lastScrollPos = CPoint(0,0);
	currScrollPos = CPoint(0,0);

	m_iType = ITEM_ART_TYPE;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::ArtItem"); 
	#endif
}

ArtItem::~ArtItem()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::~ArtItem()"); 
	#endif
	
	artFreeBuffer(&artBufId);

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::~ArtItem"); 
	#endif
}

void
ArtItem::Delete()
{
	delete this;	// BAD code ->~ArtItem();
}

void 
ArtItem::Read(fstream *fin, Module *pmodule, int *status)
{
	char line[128];
	pmodule;	/* get rid of compiler warning */

	while( ! fin->eof())
	{
		fin->getline( line, 128, SWD_EQ);

		if( strcmp(line,SWD_IMAGE) == S1_EQUALS_S2)
		{
			ImagePath.Empty();
			fin->getline( line, 128, SWD_NL);
			ImagePath = line;
		}
		else if( strcmp(line,SWD_BASEPATH) == S1_EQUALS_S2)
		{
			BasePath.Empty();
			fin->getline( line, 128, SWD_NL);
			BasePath = line;
		}
		else if( strcmp(line,SWD_SIZEFORMAT) == S1_EQUALS_S2)
		{            
			fin->getline( line, 128, SWD_NL);
			SizeFormat = line[0];
		}
		else if( strcmp(line,SWD_SIZEPERCENT) == S1_EQUALS_S2)
		{          
			int temp;
			  
			*fin >> temp;	//SizePercent;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_ENDARTITEM) == S1_EQUALS_S2)
		{            
			fin->getline( line, 128, SWD_NL);

			if((PictureLoaded = LoadArt(NULL)) == FALSE) {
				if (!ImagePath.IsEmpty()) {
					char string[256];
					wsprintf(string,"Unable to load image: %s\n", ImagePath);
					AfxMessageBox(string);
				}
			}

			*status = OK;
			return;
		}
		else
		{
			fin->getline( line, 128, SWD_NL);
		}
	}

	*status = ERROR;
}

void
ArtItem::Write(fstream *fout, Module *pmodule, int *status)
{
	status;	/* get rid of compiler warning */
	pmodule;	/* get rid of compiler warning */

	*fout << SWD_BEGINARTITEM 	<< SWD_EQ	<< "*" 			<< SWD_NL;
	*fout << SWD_BASEPATH		<< SWD_EQ	<< BasePath		<< SWD_NL;
    *fout << SWD_IMAGE			<< SWD_EQ 	<< ImagePath	<< SWD_NL;
    *fout << SWD_SIZEFORMAT		<< SWD_EQ	<< SizeFormat	<< SWD_NL;
    *fout << SWD_SIZEPERCENT		<< SWD_EQ	<< 100 /* SizePerfect */	<< SWD_NL;    
	*fout << SWD_ENDARTITEM		<< SWD_EQ	<< "*" 			<< SWD_NL;
}

float ArtItem::Message(int message, float number, int *status)
{
	message;	/* get rid of compiler warning */
	number;		/* get rid of compiler warning */
	*status = 0;
	return((float)0.0);
}

int 
ArtItem::Message( int message, int number, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::Message(int,int,int*)"); 
	#endif

	// Return Integer
	int RI = 0;

	switch(message)
	{

		case ITEM_NONE:
			*status = ERROR;
		break;

		case ITEM_DIALOG_EDIT:
			// if we are editing a graph, remember the current path/name
			if (number == NOT_EMPTY) {
				saveImagePath = ImagePath;
				saveBasePath = BasePath;
			}
			else {
				saveImagePath.Empty();
				saveBasePath.Empty();
			}
			RI = ImagePathDialog();
			if (RI == OK) {
				artFreeBuffer(&artBufId);
	    		ReloadImage = TRUE;
				if((PictureLoaded = LoadArt(NULL)) == FALSE){
					if (!ImagePath.IsEmpty()) {
						char string[256];
						wsprintf(string,"Unable to load image: %s\n", ImagePath);
						AfxMessageBox(string);
					}
				}
				*status = OK;
			}
			else {
				*status = ERROR;
			}
		break;

		case BBOX_ITEM_WHATAMI:
			RI = ITEM_ART_TYPE;
			*status = OK;
			break;

		case ART_GET_PROPORTIONAL_SET:
			RI = (SizeFormat == SIZE_NORMAL);
			*status = OK;
			break;

		case ART_SET_PROPORTIONAL:
			SizeFormat = (unsigned char) ((SizeFormat == SIZE_NORMAL) ? SIZE_FILL : SIZE_NORMAL);
			ReloadImage = TRUE;	// They changed the type
			*status = OK;
			break;

		case ART_SET_RELOAD:
			ReloadImage = (WBOOL)number;
			*status = OK;
			break;

		case ART_CLEAR_IMAGE:
			artFreeView(&artViewId);	// remove the view so it won't display
			lastPos.x = 0;
			lastPos.y = 0;
			ReloadImage = TRUE;
			*status = OK;
			break;

		case ART_SET_OVERLAPPED:
			IsOverlappedByABox = (WBOOL)number;
			if (IsOverlappedByABox) {
				artFreeView(&artViewId);	// remove the view so it won't display
				lastPos.x = 0;
				lastPos.y = 0;
			}
			*status = OK;
			break;

		case ART_GET_OVERLAPPED:
			RI = IsOverlappedByABox;
			*status = OK;
			break;

		default:
			//RI = pBBoxes[nCurrentBBox]->Message( message, number, status);
			*status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::Message: %d", status); 
	#endif

	return RI;
}

CPoint
ArtItem::Message( int message, CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::Message(int,CPoint,int*)"); 
	#endif

	// Return CPoint
	CPoint RCP;
	RCP.x = 0;
	RCP.y = 0;    

	switch(message)
	{
		case ITEM_NONE:
			*status = ERROR;
		break;	    
		
		case ART_SET_SCROLL:
			currScrollPos = point;
			*status = OK;
			break;

		default:
			//RCP = pBBoxes[nCurrentBBox]->Message( message, point, status);
			*status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::Message: %d", status); 
	#endif

	return RCP;
}

Module*
ArtItem::Message( int message, Module *pmodule, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::Message(int,Module*,int*)"); 
	#endif

	// Return Module
	Module *RM = NULL;
	ArtItem *pnart;

	switch(message)
	{

		case ITEM_NONE:
			*status = ERROR;
		break;

		case ITEM_PARENT_SET:
			RM = pParentBBox;
			pParentBBox = pmodule;
			*status = OK;
		break;

		case ITEM_RETURN_COPY:
			pnart = new ArtItem();
			pnart->ImagePath = ImagePath;
			pnart->BasePath = BasePath;
			pnart->PictureLoaded = FALSE;
			pnart->SizeFormat = SizeFormat;
			pnart->ReloadImage = TRUE;
			pnart->IsOverlappedByABox = FALSE;
			RM = pnart;
		break;
	    
		default:
			//RM = pBBoxes[nCurrentBBox]->Message( message, pmodule, status);
			*status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::Message: %d", status); 
	#endif

	return RM;
}

void
ArtItem::Draw(CDC *pDC, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER ArtItem::Draw(CDC,int*)"); 
	#endif
	status;	/* get rid of compiler warning */

	if( pParentBBox != NULL)
	{
		// If we have scrolled, we need to update the graphic
		if (currScrollPos != lastScrollPos) {
			ReloadImage = TRUE;
			if (IsOverlappedByABox == FALSE ) {
				lastScrollPos = currScrollPos;
			}
		}

		if( ReloadImage == TRUE && IsOverlappedByABox == FALSE) {
			ReloadImage = FALSE;
			PictureLoaded = LoadArt(pDC);
		}
		else if (pDC->IsPrinting()) {	//When Printing we always need to load the art
			LoadArt(pDC);
		}

	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT ArtItem::Draw: void"); 
	#endif
}

void ConvertXYtoTwips(CDC *pDC, long *x, long *y, long *xPix, long *yPix)
{
	HDC hdc = GetDC(NULL);
	pDC;	/* get rid of compiler warning */

	// Determine how many Twips are in one pixel.
	CPoint pOne(1, 1);
	SetMapMode(hdc, MM_TWIPS);

	DPtoLP(hdc, &pOne, 1);

	// Convert *x and *y to Twips units.
	*x = pOne.x;
	*y = pOne.y;//NOTE: both *y and pOne.y are negative values.

	
	*xPix = GetDeviceCaps(hdc, LOGPIXELSX);
	*yPix = GetDeviceCaps(hdc, LOGPIXELSY);

	// Release the device context.
	ReleaseDC(NULL, hdc);
}


// use this to find the file we are looking for
// could return more than one
BOOL Recurse(LPCTSTR basePath, CString aName, CString &newPath, int &canceled) 
{    
	BOOL foundFile = false;
	CFileFind finder;     	// build a string with wildcards    
	CString strWildcard(basePath);
	
	strWildcard += _T("\\*.*");     // start working for files    
	
	BOOL bWorking = finder.FindFile(strWildcard);     
	
	while (bWorking)    {       
		bWorking = finder.FindNextFile();        // skip . and .. files; otherwise, we'd       
		if (bWorking == false) {
			break;
		}
		// recur infinitely!        
		if (finder.IsDots())          
			continue;        
		// if it's a directory, recursively search it        
		if (finder.IsDirectory())       
		{          
			CString str = finder.GetFilePath();          
			//AfxMessageBox(str); //show new folder
			bWorking = Recurse(str,aName,newPath, canceled);       
			if (canceled) {
				break;
			}
		}
		else if(aName == finder.GetFileName()) {
			CString newName;
			CString tmpPath;
			int retv;
			tmpPath = finder.GetFilePath();
			newName = "Original Path not found, Use " + tmpPath + "?";
			retv = AfxMessageBox(newName, MB_YESNOCANCEL);
			if (retv == IDYES) {
				bWorking = false;
				foundFile = true;
				newPath = finder.GetFilePath();	// use this path
			}
			else if (retv == IDCANCEL) {
				bWorking = false;
				foundFile = false;
				canceled = 1;
			}
		}
		else {
			CString at;
			at = "Keep Looking: " + finder.GetFileName();
//			AfxMessageBox(at);
		}
	}     
	finder.Close(); 
	return(!foundFile);
} 


WBOOL ArtItem::LoadArt(CDC *pDC)
{
	char string[256], curDir[256];
	char *sptr = NULL;
    CFile art_file;
    CString tstr;
	CString defaultPath;
	int index=0;
	int tryCount=0;
	bool isOpen=false;
	tstr.Empty();
	defaultPath.Empty();
	int canceled=0;

	/* Change to the art directory */
	if( _chdir(BasePath) == -1) {
		if( _chdir(theApp.m_strArtPath) == -1) {
		}		
	}

	sptr = _getcwd(curDir, sizeof(curDir));
	if (sptr != NULL) {
#ifdef _CRT_SECURE_NO_DEPRECATE
		strcat(sptr, "\\");
#else
		strcat_s(sptr, sizeof("\\"),"\\");
#endif
	}

	if (pDC == NULL) {
		if (ImagePath.IsEmpty()) {		// If there is no art name, just return
			return FALSE;
		}
		for(;;) {
			if (art_file.Open(ImagePath, CFile::modeRead)) {
				if (strncmp(sptr, ImagePath, strlen(sptr))) {
					ImagePath = sptr + ImagePath;
				}
				BasePath = sptr;
				isOpen=true;
				break;
			}
			if (art_file.Open(BasePath+ImagePath, CFile::modeRead)) {
				ImagePath = BasePath+ImagePath;
				isOpen=true;
				break;		/* Found it */
			}
			defaultPath = theApp.m_strArtPath;

			if (art_file.Open(defaultPath+ImagePath, CFile::modeRead)) {
				/* The base path has changed */
				BasePath = theApp.m_strArtPath;
				isOpen=true;
				break;
			}
			
			index = ImagePath.ReverseFind('\\');
			if (index > 0) {
				// new test	
				CString artFileName = ImagePath.Right(ImagePath.GetLength() - (index+1));
				CString newPath;
				Recurse(defaultPath, artFileName, newPath, canceled);
				if (canceled) {
					break;
				}
				if (newPath.IsEmpty() == false) {
					if (art_file.Open(newPath, CFile::modeRead)) {
						ImagePath = newPath;
						//theApp.TempBasePath = newPath;
						//BasePath = newPath;
						//index = BasePath.ReverseFind('\\');
						//if (index > 0) {
						//	BasePath = BasePath.Left(index+1);
						//}
						BasePath.Empty();
						isOpen=true;
		  				break;
					}
				}
		 	}
			// show what we tried to open
		 	wsprintf(string,"Unable to open file: %s", ImagePath);
	
			// But fixed the paths first
			if (!saveImagePath.IsEmpty()) {
		    	BasePath = saveBasePath;
	    		ImagePath = saveImagePath;
	    		ReloadImage = TRUE;
				// make sure this is reset
				artFreeBuffer(&artBufId);
	    	}
	    	// perhaps - restore original if there
	    	// and do reload
			AfxMessageBox(string);
//			if( ImagePathDialog() == ERROR) {
//				return FALSE;
//			}
			break;
	    }
		if (isOpen) {
		    art_file.Close();
		}
	}

	if( (pParentBBox != NULL) && pDC)
	{
		int tstatus=OK;
//    	int retval = FALSE;
		long artval=-1;
		int dispFlag=0;
		CPoint cpTemp(0, 0);

		tstatus = -5;
		CPoint pos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &tstatus);
		CPoint size = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &tstatus);

		CPoint dibpos = pos;
		CPoint dibsize = size;

		dispFlag = (SizeFormat == SIZE_NORMAL) ? SWA_NORMAL : SWA_FILL;

		if (!pDC->IsPrinting() && (theApp.m_showGraphics == true)) {
			HWND hptr = (pDC->GetWindow())->m_hWnd;

			dibsize.y += (2 * BORDER_WIDTH);
			dibsize.x -= (2 * BORDER_WIDTH);
			dibpos.y -= BORDER_WIDTH;
			dibpos.x += BORDER_WIDTH;

			// display stuff does not use the negatives
			dibpos.y = -dibpos.y;
			dibsize.y = -dibsize.y;

			dibpos.y += currScrollPos.y;
			dibpos.x -= currScrollPos.x;

			/* On windows 2000/NT etc */
			/* Convert to regular units for art display because of TWIPS problem */
			/* Then get the real twips value back for art */
			/* if the bug gets fixed, then this should have no affect */
			OSVERSIONINFOEX os_version_info;
			ZeroMemory(&os_version_info, sizeof(OSVERSIONINFOEX));
			os_version_info.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
			GetVersionEx((OSVERSIONINFO *) &os_version_info);

			if(os_version_info.dwPlatformId >= VER_PLATFORM_WIN32_NT){ // is this version XP or greater
				static long newX=1, newY=1, xVal, yVal;

				if (newX == 1) {
					ConvertXYtoTwips(pDC, &newX, &newY, &xVal, &yVal);

					if (xVal) 
						xVal = 1440 / xVal;
					if (yVal)
						yVal = 1440 / yVal;
					
					if (newY < 0) {
						newY *= -1;
					}
					
					if (newX < 0) {
						newX *= -1;
					}
				}
				dibpos.y =(long) (dibpos.y * yVal / (long)newY);
				dibpos.x =(long) (dibpos.x * xVal / (long)newX);
				dibsize.y =(long) (dibsize.y * yVal / (long)newY);
				dibsize.x =(long) (dibsize.x * xVal / (long)newX);
			}
			artval = artDisplay(hptr, artViewId, artBufId, dibpos, dibsize, dispFlag, /*BasePath+*/ImagePath, 0);
			if (artval) {
				ReloadImage = TRUE;	// couldn't draw it, try again
			}
			else {
				lastPos = dibpos;
				lastSize = dibsize;
				lastFlag = dispFlag;
			}
		}
		else if (pDC->IsPrinting()) {

			// convert to printer units
			if (!inPrintPreview) {
				pDC->LPtoDP(&dibpos);
				pDC->LPtoDP(&dibsize);
			}
			artval = artPrint(pDC, artBufId, dibpos, dibsize, dispFlag, /*BasePath+*/ImagePath );

// Removing this since it gives some bad information if the graphic displays passed
// the end of the page and can't be seen.
//			if (artval) {
//				char string[128];
//				wsprintf(string,"<%ud> Unable to print image: %s\n", artval, ImagePath);
//				AfxMessageBox(string);
//			}
		}
		if (!artval) {
			artBufId |= SWA_LOADED;	// remember that this was loaded
		}
   	}

	// Make sure we go back to the document directry after doing art
	if (theApp.m_strDocPath.GetLength() > 0) {
		_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
		_chdir(theApp.m_strDocPath);
	}
	
	return TRUE;
}

typedef UINT (CALLBACK *OPENHOOK)(HWND, UINT, WPARAM, LPARAM);

OPENFILENAME ofn;

int
ArtItem::ImagePathDialog()
{      
	// Change 'working' directory to the document directory...
	if( _chdir(BasePath) == -1) {
		 _chdir(theApp.m_strArtPath);
	}

	TCHAR szFileName[256] = "",
			szFileTitle[256] = "",
			szDir[256];

	memset(&ofn, 0, sizeof(ofn)); // initialize structure to 0/NULL
	if (!BasePath.IsEmpty())
	{
		lstrcpy(szDir, BasePath);
		ofn.lpstrInitialDir = szDir;
	}

	if (!ImagePath.IsEmpty()) {
		
		// Get Index of end of path
		int index = ImagePath.ReverseFind('\\');
		
		// copy the whole path and filename
		lstrcpy(szFileName, ImagePath);

		// Use current graphics directory
		if (index > 0) {
			lstrcpyn(szDir, ImagePath, index+1);
			ofn.lpstrInitialDir = szDir;
		}
	}

	ofn.hInstance = AfxGetInstanceHandle();
	ofn.hwndOwner = AfxGetMainWnd()->m_hWnd;
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = (LPSTR)"Art Files (*.*)\0*.*\0\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = sizeof(szFileName);
	ofn.lpstrDefExt = "bmp";
	ofn.lpstrTitle = "Select Art";
	ofn.lpstrFileTitle = (LPSTR) szFileTitle;
	ofn.nMaxFileTitle = sizeof(szFileTitle);
	ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST ;

	if (::GetOpenFileName(&ofn) == 0) {
		int ret = ERROR;
		if (!saveImagePath.IsEmpty()) {
			ImagePath = saveImagePath;
			BasePath = saveBasePath;
			// Rebuild the original bitmap
			artFreeBuffer(&artBufId);
    		ReloadImage = TRUE;
			ret = OK;
		} 
		return ret;		// The user closed with out selection
	}

	ImagePath = szFileName;
    
	// Make sure they have the same case
	BasePath.MakeLower();
	ImagePath.MakeLower();

	if(ImagePath.Find(BasePath) == 0)
	{
		ImagePath = ImagePath.Mid(BasePath.GetLength());
	}
	else {
		// Reset BasePath to match the used directory
		int index = ImagePath.ReverseFind('\\');
    	if (index > -1) {
    		BasePath = ImagePath.Left(index+1);	// include the slash here
			ImagePath = ImagePath.Mid(BasePath.GetLength());
		}
	}
	
	/* Change back to the document directory */
	_chdir(theApp.m_strDocPath);

	return OK;
}

  

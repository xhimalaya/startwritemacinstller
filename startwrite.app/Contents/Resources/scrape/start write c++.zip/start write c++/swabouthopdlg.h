#if !defined(AFX_ABOUTHOPDLG_H__6EACC281_A842_11D3_B60A_444553540000__INCLUDED_)
#define AFX_ABOUTHOPDLG_H__6EACC281_A842_11D3_B60A_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AboutHOPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHOPAboutDlg dialog

class CHOPAboutDlg : public CDialog
{
// Construction
public:
	int doUpgrade;
	CHOPAboutDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHOPAboutDlg)
	enum { IDD = IDD_ABOUT_HOP };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHOPAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	RECT		m_rectSplash;

protected:

	// Generated message map functions
	//{{AFX_MSG(CHOPAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnHelpOrder();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABOUTHOPDLG_H__6EACC281_A842_11D3_B60A_444553540000__INCLUDED_)

#pragma once
#include "textitem.h"

class SpecialCharsItem :
	public TextItem
{
public:
	SpecialCharsItem(void);
	~SpecialCharsItem(void);
	int DrawLedgerLines( CDC *pDC, CPoint pos, CPoint size, int MarginVal, int startX, int ly);		
	int GetCharacterWidth( CDC* pDC, unsigned short *c, unsigned short *nc, int lx, int ly, int *status);

	int nGridCellWidth;
	int nGridCellHeight;
	int nGridWidth;
	int nGridHeight;
	int nGridCols;
	int nGridRows;

	int nCharIndexCurrent;
	int nCharStored;
	int nCharIndexMax;

	RECT rectChar[SHAPES_MAX];
	int nCharValue[SHAPES_MAX];
	BOOL bIsSetupDone;
};

#include "specialcharsitem.h"

SpecialCharsItem::SpecialCharsItem(void)
{
	bIsSetupDone = FALSE;

	nGridCellWidth = SHAPES_CELL_WIDTH;
	nGridCellHeight = 0;
	nGridWidth = SHAPES_GRID_WIDTH;
	nGridHeight = 0;
	nGridCols = SHAPES_GRID_COLS;
	nGridRows = 0;

	nCharIndexCurrent = -1;
	nCharStored = 0;
	nCharIndexMax = 0;

	for (int i=0; i<SHAPES_MAX; i++) {
		rectChar[i].bottom = 0;
		rectChar[i].top = 0;
		rectChar[i].left = 0;
		rectChar[i].right = 0;
		nCharValue[i] = 0;
	}
}

SpecialCharsItem::~SpecialCharsItem(void)
{
}

int SpecialCharsItem::DrawLedgerLines( CDC *pDC, CPoint zPos, CPoint zSize, int MarginVal, int startX, int ly)
{
	if (bIsSetupDone) {
		return 0;
	}
	// No lines are drawn for SpecialCharsItem.  Just clear area and set up for grid
	nGridCellHeight = TextLineYs;
	int ht = zPos.y + nGridCellHeight;
	int wd = zPos.x - 100 + nGridWidth;

	if ((ht > 32000) || (wd > 32000)) {
		return TRUE;
	}
	if (ly + 1 > nGridRows) {
		nGridRows = ly + 1;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) pDC->SelectStockObject(NULL_PEN);
	pDC->SelectStockObject(WHITE_BRUSH);

	pDC->Rectangle(CRect( 
		zPos.x - MarginVal,
		zPos.y + zMargin + (ly > 0 || BorderArtType == 0 ? (2*(int)zPointSize) : 0),
		wd + MarginVal,
		ht + (zMargin)+(2*(int)zPointSize) - 10));

	float upem = 2048.00;
	float points = zPointSize;

	float points_per_inch = 72.00;
	// Equation from page 4 of 40 in the Apple's Font Engine reference
	float scale = ( points * (float)PIXELS_PER_INCH ) 
		/ ( points_per_inch * upem );

	float maxy_em = 1836 - 336;
	int maxy = (int)(maxy_em * scale);

	// We do not draw ledger lines.  We only set up the grid rectangles based upon text lines and chars
	int doY, doX;
	doY = zPos.y + 100;
	doX = zPos.x - 100;
	int nGridCol = 0;
	int nGridCell = ly * nGridCols;
	for (doX=zPos.x - 100; doX <= wd; doX += nGridCellWidth) {
		if (nGridCol < nGridCols) {
			rectChar[nGridCell].top = doY;
			rectChar[nGridCell].left = doX;
			rectChar[nGridCell].bottom = max(ht, doY + nGridCellHeight);
			rectChar[nGridCell].right = min(doX + nGridCellWidth, wd);
			++nGridCell;
			++nGridCol;
		}
	}
	pDC->SelectObject(oldpen);

	return TRUE;
}

int SpecialCharsItem::GetCharacterWidth( CDC *pDC, unsigned short *c, unsigned short *nc, int lx, int ly, int *status)
{
	int nWidth = TextItem::GetCharacterWidth(pDC, c, nc, lx, ly, status);
	if (!bIsSetupDone && TxtShapes[ly][lx] > SHAPE_NONE) {
		if (nWidth > 0) {
			unsigned short cTemp = 0;
			cTemp = *c;
			if (*c != nCharStored) {
				++nCharIndexCurrent;
			}
			nCharValue[nCharIndexCurrent] = cTemp;
			nCharStored = *c;
			return nGridCellWidth;
		}
		else {
			int xLeft = max(0, lx);
			int xMid = min(lx + 1, TxtLines[ly].GetLength() - 1);
			int xMax = TxtLines[ly].GetLength();
			int x;
			for (x=xLeft; x>=0; x--) {
				if (TxtLines[ly][x] != 32) {
					xLeft = x + 1;
					break;
				}
			}
			for (x=xMid; x<xMax; x++) {
				if (TxtLines[ly][x] != 32) {
					xMid = x - 1;
					break;
				}
			}

			TxtLines[ly] = TxtLines[ly].Left(xLeft) + TxtLines[ly].Mid(xMid);
			TxtShapes[ly] = TxtShapes[ly].Left(xLeft) + TxtShapes[ly].Mid(xMid);
			TxtAttrs[ly] = TxtAttrs[ly].Left(xLeft) + TxtAttrs[ly].Mid(xMid);
			return 0;
		}
	}
	else {
		return 0;
	}
}

#pragma once


// CBorderArtDlg dialog
#include "mainfrm.h"

class CBorderArtDlg : public CDialog
{
	DECLARE_DYNAMIC(CBorderArtDlg)

public:
	CBorderArtDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBorderArtDlg();

	int m_nBorderArtSize;
	CString m_strBorderArtName;
	int m_nBorderArtSource;
	int m_nBorderArtShrink;
	int m_nSize;//Font related--just so they see how the line size looks with the border
	afx_msg void OnLbnSelchangeListswborderart();
	afx_msg void OnLbnSelchangeListborderartsize();
	afx_msg void OnBnClickedRadioborderart0();
	afx_msg void OnBnClickedRadioborderart1();
	afx_msg void OnBnClickedRadioborderart2();

	// Dialog Data
	enum { IDD = IDD_BORDERART };

	BBox 		*m_pBox;
	TextItem	*m_pTextItem;
	CRect		m_rectPreview,
				m_rectBox;
	CListBox	m_ctlListSWBorderArt;
	CListBox	m_ctlListBorderArtSize;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnPaint();
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);

	DECLARE_MESSAGE_MAP()
private:
	void InitControls();
	void FillArtList();
	void FillSizeList();
	void SetSWBorderArtSelection();
	void SetBorderArtSizeSelection();
	void LoadFileLists();
	bool IsFileForList(CString name);
	CString MakeDisplayName(CString name);
	bool GetCurrentSelections();
	CString BasePath;
	bool doInitialization;
	CStringArray filesBW;
	CStringArray filesColor;
	CStringArray displayBW;
	CStringArray displayColor;

public:
	afx_msg void OnBnClickedChkborderartshrink();
};

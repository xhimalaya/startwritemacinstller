// Reporter Header

#ifndef _REPORTER_H_
#define _REPORTER_H_

#include "common.h"

// for info/error/debug reporting
#define TO_SCREEN	0x0001
#define TO_FILE		0x0010
#define TO_ALL		0x0011
#define TO_LIST		TO_FILE

int Report( int where, char *string);
int Report( int where, char *format, char *arg1);
int Report( int where, char *format, int *arg1);

#endif // _REPORTER_H_
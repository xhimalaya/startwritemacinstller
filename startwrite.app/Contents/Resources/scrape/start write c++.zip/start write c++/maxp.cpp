// Font Header Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Maxp.h"
 
#include <stdio.h>
 
MaxPTable::MaxPTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER MaxPTable::MaxPTable()"); 
	#endif

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT MaxPTable::MaxPTable: void"); 
	#endif
}

MaxPTable::~MaxPTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER MaxPTable::~MaxPTable()"); 
	#endif

	// NO malloc

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT MaxPTable::~MaxPTable: void"); 
	#endif
}

int
MaxPTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER MaxPTable::Read(ifstream,DirectoryTable*)"); 
	#endif

	// Read maxp table
	
	// Check for existence of maxp table
	if( !dir->GetTag("maxp"))
	{
		Report( TO_LIST, "ERROR MaxPTable::Read: Unable to GetTag(maxp)"); 
		return ERROR;
	}
	
	// Head table begins at offset specified in directory table		 
	fin->seekg(dir->GetOffset());	 
	fin->read( (char *)&Table, sizeof(Table));	
 	
 	// Swab the shorts...
    myswab( (unsigned char *)&Table, sizeof(Table));

	// NO malloc
		                                               
	return OK;
}

UShort
MaxPTable::GetNumGlyphs()
{
	return Table.NumGlyphs;
}

int
MaxPTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER MaxPTable::Print()"); 
	#endif

	cout << "** Maxp **" << endl;
	cout << dec;
	cout << "Version:\t" << Table.Version << endl;
	cout << "NumGlyphs:\t" << Table.NumGlyphs << endl;
	cout << "MaxPoints:\t" << Table.MaxPoints << endl;
	cout << "MaxContours:\t" << Table.MaxContours << endl;
	cout << "MaxCompositePoints:\t" << Table.MaxCompositePoints << endl;
	cout << "MaxCompositeContours:\t" << Table.MaxCompositeContours << endl;
	cout << "MaxZones:\t" << Table.MaxZones << endl;
	cout << "MaxTwilightPoints:\t" << Table.MaxTwilightPoints << endl;
	cout << "MaxStorage:\t" << Table.MaxStorage << endl;
	cout << "MaxFunctionDefs:\t" << Table.MaxFunctionDefs << endl;
	cout << "MaxInstructionDefs:\t" << Table.MaxInstructionDefs << endl;
	cout << "MaxStackElements:\t" << Table.MaxStackElements << endl;
	cout << "MaxSizeOfInstructions:\t" << Table.MaxSizeOfInstructions << endl;
	cout << "MaxComponentElements:\t" << Table.MaxComponentElements << endl;
	cout << "MaxComponentDepth:\t" << Table.MaxComponentDepth << endl;
	cout << dec;

	return OK;
}
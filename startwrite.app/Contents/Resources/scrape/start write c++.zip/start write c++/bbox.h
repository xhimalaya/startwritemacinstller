// Document Class Header

#ifndef _BBOX_H_
#define _BBOX_H_

#include "module.h"
#include "docunits.h"
#include "messages.h"
#include "filefmt.h"

#include "textitem.h"
#include "artitem.h"

class BBox : public Module
{
	private:

        int nVisible;
        
		int nState;
		int PosHasScroll;
        
        int nWarning;
		BOOL m_bAllowGrow;
	    CPoint Position;
	    CPoint Size;
	    CPoint MaxXY;
	    
	    CPoint ScrollOffset;
	    CPoint OldPosition;
	    CPoint OldSize;
	    
	    CPoint TmpPos;
	    
		int HandleRadius;
		CPoint HandleOffsets[8];

	public:
	
	    Module *Item;
	    float dCurrentZoom;
		int FrameInfo;

		BBox();
		~BBox();

		void Read(fstream *fin, Module *pmodule, int *status);
		void Write(fstream *fout, Module *pmodule, int *status);
		
		void Delete();

		float Message(int message, float number, int *status);
		int Message( int message, int number, int *status);
		CPoint Message( int message, CPoint point, int *status);
		Module* Message( int message, Module *pmodule, int *status);
		
		void Draw(CDC* pDC, int *status);

		int IsAtPoint(CPoint point, int *status);
		CPoint WhatIsAtPoint(CPoint point, int *status);
#ifdef DO_OVERLAP
		int IsOverlapping(BBox *pbbox, int *status);
#endif
		CPoint GetCornerPoint(int corner, int *status);
		CPoint GetHandlePoint(int adjust, int handle, int *status);
	private:
		void resetFontInfo(void);
};

#endif // _BBOX_H_
// Document Class Header

#ifndef _DOCUMENT_H_
#define _DOCUMENT_H_

#include "resource.h"

#include "module.h"
#include "messages.h"
#include "docunits.h"
#include "filefmt.h"

#include "page.h"

//#include "bbox.h"
//#include "textitem.h"

// dialogs
//include "edittext.h"

class Document : public Module
{
	private:
/*
		int CurrentTool;
		
		int HoldingLButton;
		CPoint HoldingPos;
		
		BBox TmpBBox, *pTmpBBox;
		
		// Page start at 1, so must MAX_PAGES+1
		Page* Pages[MAX_PAGES+1];
	    int CurrentPage;
	    int LastPage;
	    float ZoomFactor;
*/
		// Zoom is in %... 130% == 1.3 times document size
		int Zoom;

		// Paper = letter, legal, A4, etc...
		int nPaper;

		// Orientation is portrait or landscape
		int nOrientation;

		// Pages are numbered 1 - MAX_PAGES
		Page* pPages[MAX_PAGES+1];

		// Keep track of the total pages (and last page)
		int nTotalPages;
        
        // Pages[1] is the 'first' page
		int nCurrentPage;
		Page *pCurrentPage;

		bool bRestoreBorderArt;

		int nTotalStoryBoxes;//The number of story boxes in the entire document

	public:
	
		Document();
		~Document();

		void Read(fstream *fin, Module *pmodule, int *status);
		void Write(fstream *fout, Module *pmodule, int *status);

		void Delete();

		float Message(int message, float number, int *status);
		int Message( int message, int number, int *status);
		CPoint Message( int message, CPoint point, int *status);
		Module* Message( int message, Module *pmodule, int *status);

		void Draw(CDC* pDC, int *status);
		
		BOOL IsPageLandscape(int iPage) {return pPages[iPage]->IsLandscape();}
		int WhatIsAtPoint(POINT pt);
		float dCurrentZoom;
		// The CustomColors that the user has created
		// (they may not have chosen them for any specific usage yet, but they added to custom colors)
		COLORREF CustomPalette[16];
	   
		BBox *GetCurrentBox();
		TextItem *GetStoryItem(int orderNumber, int *onCurrentPage, int *onPageNumber);

		void DrawAllPages(CDC* pDC, int *status);
		void SetStoryItemsOrder();
		int NeedsOverlapCheck;
	   
	private:
	
		int DocPageNew( int where, int doInitBox, int *status);		
		int DocPageDelete( int where, int *status);		
		
/*        
        int SetTool(int tool);
        int GetTool();
        
		int AddPage(Page* ppage);
		int AddToPage(BBox* pbbox);
		int GetCurrentPage();
		int GetLastPage();
		int SetCurrentPage(int newpage);

		float GetZoomFactor();
		int SetZoomFactor(float zf);
		int IncZoomFactor(float inc);
		int DecZoomFactor(float dec);
		
		// Required by the Module class
		//Module* GetParent();
		//Module* SetParent(Module *);
		int Event(int event, CPoint point);     
		int Draw(CDC* pDC);
*/

};

#endif // _DOCUMENT_H_
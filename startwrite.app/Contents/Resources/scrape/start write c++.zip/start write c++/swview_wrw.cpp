// swview.cpp : implementation of the CSwView class
//
#include "stdafx.h"
#include "sw.h"
#include <string.h>
//#include "windows.h"
#include "swdoc.h"
#include "swview.h"

#include "miscutil.h"
#include "mainfrm.h"

#include "GotoDlg.h"
#include "ZoomDlg.h"
#include "swspace.h"
#include "ShadeDlg.h"
#include "DnstyDlg.h"
#include "ArrowDlg.h"
#include "FontDlg.h"
#include "swregister.h"
#include "textitem.h"
#include "swAboutHOPDlg.h"
#include "numcopies.h"
#include "insertPage.h"

#define GUIDELINE_TOP	1
#define GUIDELINE_MID	2
#define GUIDELINE_BOT	4
#define GUIDELINE_DES	8

#define LINEDENSITY100	4
#define LINEDENSITY75	3
#define LINEDENSITY50	2
#define LINEDENSITY25	1
#define LINEDENSITYNONE	0

#define TEXTSHADING25	1
#define TEXTSHADING50	2
#define TEXTSHADING75	3
#define TEXTSHADING100	4

#define GUIDELINETHICKNESS_THIN		LINE_THICK_NORMAL
#define GUIDELINETHICKNESS_50		LINE_THICK_THICK
#define GUIDELINETHICKNESS_75		LINE_THICK_THICKER
#define GUIDELINETHICKNESS_HEAVY	LINE_THICK_THICKEST

#define YELLOWGUIDE_OFF	0
#define YELLOWGUIDE_MID	1
#define YELLOWGUIDE_DES	2

extern unsigned int defaultFont;
extern int checkPrinterMultiple();

#ifndef IDC_SIZEALL		// Win 3.1 does not have sizeall
#define IDC_SIZEALL	IDC_SIZE
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

int GlobalDisplay;

int inPrintPreview=0;

extern int doDrawCursor, doSetCursor;
extern int SelectionIsReal;

CString TxtCopy[MAX_TEXT_LINES+1];
CString TxtCopyAttrs[MAX_TEXT_LINES+1];

#ifdef WRWDEBUG
extern int doDump;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSwView

IMPLEMENT_DYNCREATE(CSwView, CScrollView)

BEGIN_MESSAGE_MAP(CSwView, CScrollView)
	ON_UPDATE_COMMAND_UI(ID_PAGE_NUMBER, OnUpdateStatusPageOfPage)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_SELECT, OnUpdateSelect)
	ON_UPDATE_COMMAND_UI(ID_PAGE_ZOOM, OnUpdateStatusZoom)
	ON_UPDATE_COMMAND_UI(IDC_PAGE_PREV, OnUpdatePagePrev)
	ON_UPDATE_COMMAND_UI(IDC_PAGE_NEXT, OnUpdatePageNext)
	ON_UPDATE_COMMAND_UI(IDC_ZOOM_DEC, OnUpdateZoomDec)
	ON_UPDATE_COMMAND_UI(IDC_ZOOM_INC, OnUpdateZoomInc)
	ON_COMMAND(IDC_PAGE_PREV, OnPagePrev)
	ON_COMMAND(IDC_PAGE_NEXT, OnPageNext)
	ON_COMMAND(IDC_ZOOM_DEC, OnZoomDec)
	ON_COMMAND(IDC_ZOOM_INC, OnZoomInc)
	//{{AFX_MSG_MAP(CSwView)
	ON_COMMAND(ID_NEW_TEXT_ITEM, OnNewTextItem)
	ON_COMMAND(ID_NEW_ART_ITEM, OnNewArtItem)
	ON_COMMAND(ID_ITEM_TOOL, OnItemTool)
	ON_COMMAND(ID_DOC_ORIENTATION, OnDocOrientation)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_DOC_SPELL, OnDocSpell)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_NEW_PAGE, OnNewPage)
	ON_COMMAND(ID_DELETE_PAGE, OnDeletePage)
	ON_COMMAND(ID_DOCUMENT_LANDSCAPE, OnDocumentLandscape)
	ON_UPDATE_COMMAND_UI(ID_DOCUMENT_LANDSCAPE, OnUpdateDocumentLandscape)
	ON_COMMAND(ID_DOCUMENT_PORTRAIT, OnDocumentPortrait)
	ON_UPDATE_COMMAND_UI(ID_DOCUMENT_PORTRAIT, OnUpdateDocumentPortrait)
	ON_WM_SETCURSOR()
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_FORMAT_LINEDENSITY_100, OnFormatLinedensity100)
	ON_COMMAND(ID_FORMAT_LINEDENSITY, OnFormatLinedensity)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY, OnUpdateFormatLinedensity)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY_100, OnUpdateFormatLinedensity100)
	ON_COMMAND(ID_CONNECTTHEDOTS, OnFormatConnectTheDots)
	ON_UPDATE_COMMAND_UI(ID_CONNECTTHEDOTS, OnUpdateFormatConnectTheDots)
	ON_COMMAND(ID_FORMAT_LINEDENSITY_NONE, OnFormatLinedensityNone)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY_NONE, OnUpdateFormatLinedensityNone)
	ON_COMMAND(ID_FORMAT_LINEDENSITY_25, OnFormatLinedensity25)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY_25, OnUpdateFormatLinedensity25)
	ON_COMMAND(ID_FORMAT_LINEDENSITY_50, OnFormatLinedensity50)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY_50, OnUpdateFormatLinedensity50)
	ON_COMMAND(ID_FORMAT_LINEDENSITY_75, OnFormatLinedensity75)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LINEDENSITY_75, OnUpdateFormatLinedensity75)
	ON_COMMAND(ID_FORMAT_TEXTARROWS_OFF, OnFormatTextarrowsToggle)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTARROWS_OFF, OnUpdateFormatTextarrowsToggle)
	ON_COMMAND(ID_FORMAT_TEXTARROWS, OnFormatTextarrows)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTARROWS, OnUpdateFormatTextarrows)
	ON_COMMAND(ID_FORMAT_TEXTSTARTDOT_ON, OnFormatTextDotToggle)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSTARTDOT_ON, OnUpdateFormatTextDotToggle)
	ON_COMMAND(ID_FORMAT_OVERLAY, OnFormatOverlayToggle)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_OVERLAY, OnUpdateFormatOverlayToggle)
	ON_COMMAND(ID_FORMAT_TEXTLINES_BOTTOM, OnFormatTextlinesBottom)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTLINES_BOTTOM, OnUpdateFormatTextlinesBottom)
	ON_COMMAND(ID_FORMAT_TEXTLINES_MIDBOTTOM, OnFormatTextlinesMidbottom)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTLINES_MIDBOTTOM, OnUpdateFormatTextlinesMidbottom)
	ON_COMMAND(ID_FORMAT_TEXTLINES_NONE, OnFormatTextlinesNone)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTLINES_NONE, OnUpdateFormatTextlinesNone)
	ON_COMMAND(ID_FORMAT_TEXTLINES_TOPMIDBOTTOM, OnFormatTextlinesTopmidbottom)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTLINES_TOPMIDBOTTOM, OnUpdateFormatTextlinesTopmidbottom)
	ON_COMMAND(ID_FORMAT_TEXTSHADING, OnFormatTextshading)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSHADING, OnUpdateFormatTextshading)
	ON_COMMAND(ID_FORMAT_TEXTSHADING_100, OnFormatTextshading100)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSHADING_100, OnUpdateFormatTextshading100)
	ON_COMMAND(ID_FORMAT_TEXTSHADING_25, OnFormatTextshading25)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSHADING_25, OnUpdateFormatTextshading25)
	ON_COMMAND(ID_FORMAT_TEXTSHADING_50, OnFormatTextshading50)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSHADING_50, OnUpdateFormatTextshading50)
	ON_COMMAND(ID_FORMAT_TEXTSHADING_75, OnFormatTextshading75)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_TEXTSHADING_75, OnUpdateFormatTextshading75)
	ON_COMMAND(ID_EDIT_GOTO, OnEditGoto)
	ON_COMMAND(ID_VIEW_ZOOM, OnViewZoom)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, OnUpdateEditDelete)
	ON_COMMAND(ID_FORMAT_ART, OnFormatArt)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_ART, OnUpdateFormatArt)
	ON_COMMAND(ID_ART_PROPORTIONAL, OnMaintainProportions)
	ON_UPDATE_COMMAND_UI(ID_ART_PROPORTIONAL, OnUpdateMaintainProportions)
	ON_COMMAND(ID_FORMAT_FONT, OnFormatFont)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_FONT, OnUpdateFormatFont)
	ON_WM_KILLFOCUS()
	ON_UPDATE_COMMAND_UI(ID_DOC_SPELL, OnUpdateDocSpell)
	ON_COMMAND(ID_FORMAT_LETTERDOTDENSITY, OnFormatLetterdotdensity)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LETTERDOTDENSITY, OnUpdateFormatLetterdotdensity)
	ON_COMMAND(ID_FORMAT_LETTERSHADING, OnFormatLettershading)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LETTERSHADING, OnUpdateFormatLettershading)
	ON_COMMAND(ID_FORMAT_LETTERSTROKEARROWS, OnFormatLetterstrokearrows)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_LETTERSTROKEARROWS, OnUpdateFormatLetterstrokearrows)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT_PREVIEW, OnUpdateFilePrintPreview)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT_SETUP, OnUpdateFilePrintSetup)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_COMMAND(ID_OPEN_TEMPLATE, OnOpenTemplate)
	ON_UPDATE_COMMAND_UI(ID_OPEN_TEMPLATE, OnUpdateOpenTemplate)
	ON_UPDATE_COMMAND_UI(ID_NEW_PAGE, OnUpdateNewPage)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOM, OnUpdateViewZoom)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_SETTINGS, OnUpdateToolsSettings)
	ON_UPDATE_COMMAND_UI(ID_NEW_ART_ITEM, OnUpdateNewArtItem)
	ON_UPDATE_COMMAND_UI(ID_NEW_TEXT_ITEM, OnUpdateNewTextItem)
	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_CLOSE, OnUpdateFileClose)
	ON_UPDATE_COMMAND_UI(ID_DELETE_PAGE, OnUpdateDeletePage)
	ON_UPDATE_COMMAND_UI(ID_EDIT_GOTO, OnUpdateEditGoto)
	ON_COMMAND(ID_KERNING_ON, OnKerningOn)
	ON_UPDATE_COMMAND_UI(ID_KERNING_ON, OnUpdateKerningOn)
	ON_COMMAND(ID_KERNING_OFF, OnKerningOff)
	ON_UPDATE_COMMAND_UI(ID_KERNING_OFF, OnUpdateKerningOff)
	ON_COMMAND(ID_REDRAW_ALL, OnRedrawAll)
	ON_COMMAND(IDD_REGISTER, OnRegister)
	ON_UPDATE_COMMAND_UI(IDD_REGISTER, OnUpdateRegister)
	ON_COMMAND(ID_HOP_UPGRADE, OnHopUpgrade)
	ON_UPDATE_COMMAND_UI(ID_HOP_UPGRADE, OnUpdateHopUpgrade)
	ON_COMMAND(ID_SPACE_NORMAL, OnSpaceNormal)
	ON_COMMAND(ID_SPACE_WIDE, OnSpaceWide)
	ON_UPDATE_COMMAND_UI(ID_SPACE_NORMAL, OnUpdateSpaceNormal)
	ON_UPDATE_COMMAND_UI(ID_SPACE_WIDE, OnUpdateSpaceWide)
	ON_COMMAND(ID_TOOLS_SETSPACE, OnToolsSetspace)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_SETSPACE, OnUpdateToolsSetspace)
	ON_COMMAND(ID_FORMAT_YELLOWGUIDE, OnFormatYellowguide)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_YELLOWGUIDE, OnUpdateFormatYellowguide)
	ON_COMMAND(ID_TOOLS_DEFAULTSETTINGS_FONTS, OnToolsDefaultsettingsFonts)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_DEFAULTSETTINGS_FONTS, OnUpdateToolsDefaultsettingsFonts)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_ALLOWWINDOWSFONTS, OnUpdateFormatAllowwindowsfonts)
	ON_COMMAND(ID_FORMAT_ALLOWWINDOWSFONTS, OnFormatAllowwindowsfonts)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_WM_MOUSEWHEEL()
	ON_COMMAND(ID_FORMAT_YELLOWHIGHLIGHT_GENERAL, OnFormatYellowhighlightGeneral)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_YELLOWHIGHLIGHT_GENERAL, OnUpdateFormatYellowhighlightGeneral)
	ON_COMMAND(ID_FORMAT_YELLOWHIGHLIGHT_DESCENDER, OnFormatYellowhighlightDescender)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_YELLOWHIGHLIGHT_DESCENDER, OnUpdateFormatYellowhighlightDescender)
	ON_COMMAND(ID_FORMAT_YELLOWHIGHLIGHT_OFF, OnFormatYellowhighlightOff)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_YELLOWHIGHLIGHT_OFF, OnUpdateFormatYellowhighlightOff)
	ON_COMMAND(ID_EDIT_SELECTALL, OnEditSelectall)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SELECTALL, OnUpdateEditSelectall)
	ON_COMMAND(ID__GUIDELINETHICKNESS_THIN, OnFormatThicknessNormal)
	ON_UPDATE_COMMAND_UI(ID__GUIDELINETHICKNESS_THIN, OnUpdateFormatThicknessNormal)
	ON_COMMAND(ID__GUIDELINETHICKNESS_50, OnFormatThicknessThin)
	ON_UPDATE_COMMAND_UI(ID__GUIDELINETHICKNESS_50, OnUpdateFormatThicknessThin)
	ON_COMMAND(ID__GUIDELINETHICKNESS_75, OnFormatThicknessMedium)
	ON_UPDATE_COMMAND_UI(ID__GUIDELINETHICKNESS_75, OnUpdateFormatThicknessMedium)
	ON_COMMAND(ID__GUIDELINETHICKNESS_HEAVY, OnFormatThicknessThick)
	ON_UPDATE_COMMAND_UI(ID__GUIDELINETHICKNESS_HEAVY, OnUpdateFormatThicknessThick)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_COMMAND(ID_BOXFRAME_NONE, &CSwView::OnBoxframeNone)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_NONE, &CSwView::OnUpdateBoxframeNone)
	ON_COMMAND(ID_BOXFRAME_SINGLE_1, &CSwView::OnBoxframeSingle1)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_SINGLE_1, &CSwView::OnUpdateBoxframeSingle1)
	ON_COMMAND(ID_BOXFRAME_SINGLE_2, &CSwView::OnBoxframeSingle2)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_SINGLE_2, &CSwView::OnUpdateBoxframeSingle2)
	ON_COMMAND(ID_BOXFRAME_SINGLE_3, &CSwView::OnBoxframeSingle3)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_SINGLE_3, &CSwView::OnUpdateBoxframeSingle3)
	ON_COMMAND(ID_BOXFRAME_SINGLE_6, &CSwView::OnBoxframeSingle6)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_SINGLE_6, &CSwView::OnUpdateBoxframeSingle6)
	ON_COMMAND(ID_BOXFRAME_DOUBLE_1, &CSwView::OnBoxframeDouble1)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_DOUBLE_1, &CSwView::OnUpdateBoxframeDouble1)
	ON_COMMAND(ID_BOXFRAME_DOUBLE_2, &CSwView::OnBoxframeDouble2)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_DOUBLE_2, &CSwView::OnUpdateBoxframeDouble2)
	ON_COMMAND(ID_BOXFRAME_DOUBLE_3, &CSwView::OnBoxframeDouble3)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_DOUBLE_3, &CSwView::OnUpdateBoxframeDouble3)
	ON_COMMAND(ID_BOXFRAME_DOUBLE_6, &CSwView::OnBoxframeDouble6)
	ON_UPDATE_COMMAND_UI(ID_BOXFRAME_DOUBLE_6, &CSwView::OnUpdateBoxframeDouble6)

	ON_NOTIFY(TBN_DROPDOWN,	 ID_VIEW_POWERBAR, &CSwView::OnToolBarBtnDropDown)

	ON_COMMAND(ID__COLOREDSTROKES, &CSwView::OnDoColoredStrokes)
	ON_UPDATE_COMMAND_UI(ID__COLOREDSTROKES, &CSwView::OnUpdateDoColoredStrokes)

	ON_COMMAND(ID__DECISIONDOTS, &CSwView::OnDoDecisionDots)
	ON_UPDATE_COMMAND_UI(ID__DECISIONDOTS, &CSwView::OnUpdateDoDecisionDots)

	ON_COMMAND(ID_FORMAT_STARTDOT, &CSwView::OnFormatStartDot)
	ON_UPDATE_COMMAND_UI(ID_FORMAT_STARTDOT, &CSwView::OnUpdateStartDot)

	ON_COMMAND(ID_GUIDELINES, &CSwView::OnFormatGuidelines)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES, &CSwView::OnUpdateGuidelines)

	ON_COMMAND(ID_GUIDELINES_TMD, OnFormatTextlinesTMD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TMD, OnUpdateFormatTextlinesTMD)
	
	ON_COMMAND(ID_GUIDELINES_TBD, OnFormatTextlinesTBD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TBD, OnUpdateFormatTextlinesTBD)
	
	ON_COMMAND(ID_GUIDELINES_MBD, OnFormatTextlinesMBD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_MBD, OnUpdateFormatTextlinesMBD)
	
	ON_COMMAND(ID_GUIDELINES_T, OnFormatTextlinesT)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_T, OnUpdateFormatTextlinesT)
	
	ON_COMMAND(ID_GUIDELINES_M, OnFormatTextlinesM)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_M, OnUpdateFormatTextlinesT)
	
	ON_COMMAND(ID_GUIDELINES_B, OnFormatTextlinesB)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_B, OnUpdateFormatTextlinesB)
	
	ON_COMMAND(ID_GUIDELINES_D, OnFormatTextlinesD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_D, OnUpdateFormatTextlinesD)
	
	ON_COMMAND(ID_GUIDELINES_TM, OnFormatTextlinesTM)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TM, OnUpdateFormatTextlinesTM)
	
	ON_COMMAND(ID_GUIDELINES_TB, OnFormatTextlinesTB)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TB, OnUpdateFormatTextlinesTB)
	
	ON_COMMAND(ID_GUIDELINES_TD, OnFormatTextlinesTD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TD, OnUpdateFormatTextlinesTD)
	
	ON_COMMAND(ID_GUIDELINES_MB, OnFormatTextlinesMB)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_MB, OnUpdateFormatTextlinesMB)
	
	ON_COMMAND(ID_GUIDELINES_MD, OnFormatTextlinesMD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_MD, OnUpdateFormatTextlinesMD)
	
	ON_COMMAND(ID_GUIDELINES_BD, OnFormatTextlinesBD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_BD, OnUpdateFormatTextlinesBD)
	
	ON_COMMAND(ID_GUIDELINES_NONE, OnFormatTextlinesAllOff)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_NONE, OnUpdateFormatTextlinesAllOff)
	
	ON_COMMAND(ID_GUIDELINES_TMBD, OnFormatTextlinesTMBD)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TMBD, OnUpdateFormatTextlinesTMBD)

	ON_COMMAND(ID_GUIDELINES_TMB, OnFormatTextlinesTMB)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_TMB, OnUpdateFormatTextlinesTMB)

	ON_COMMAND(ID_GUIDELINES_THICKNESS, OnFormatGuidelineThickness)
	ON_UPDATE_COMMAND_UI(ID_GUIDELINES_THICKNESS, OnUpdateFormatGuidelineThickness)

	ON_COMMAND(ID_BIGSPACING, OnFormatBigSpace)
	ON_UPDATE_COMMAND_UI(ID_BIGSPACING, OnUpdateFormatBigSpace)

	END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSwView construction/destruction


CSwView::CSwView()
{
	// TODO: add construction code here
	MouseCaptured = FALSE;
	MousePending = FALSE;
	//nNewBBoxTakesKeys = FALSE;
	//nBBoxTakesKeys = FALSE;
	TBasePath = theApp.m_BasePath;
	TBasePath += "\\Lessons";
	TemplatePath = "";

	m_ptLastMove = CPoint(0,0);
	lastPoint = CPoint(0,0);
	m_doFontDefault=0;
	nButtonDensity = LINEDENSITY50;
	nButtonShading = TEXTSHADING100;
	nButtonGuidelines = (GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_BOT);
	nButtonGuidelineThickness = GUIDELINETHICKNESS_THIN;
	nButtonYellowGuide = YELLOWGUIDE_OFF;
}

CSwView::~CSwView()
{
	if (pCopyBBox) {
		delete pCopyBBox;
		pCopyBBox = NULL;
	}
	if (pUndoBBox) {
		delete pUndoBBox;
		pUndoBBox = NULL;
	}
}

BOOL CSwView::CheckSelection()
{
	TextItem *pItem = GetCurrentTextItem();

	return((pItem && (pItem->SelectionOn)) ? TRUE : FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CSwView drawing

void CSwView::OnDraw(CDC* pDC)
{
	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	
	//Trace("Preparing DC...");
	pDoc->PrepareDC(pDC);
	//Trace("Preparing ScrollView...");
	pDoc->PrepareScrollView(this);
	//Trace("DrawingThisDoc");
	GlobalDisplay = 1;

	doDrawCursor++;				// Allow cursor draw if this sets it to one

	pDoc->DrawThisDocument(pDC);
	doDrawCursor--;				// restore
	GlobalDisplay = 0;
}

void CSwView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();
	int status;
	CPoint paper_pixels = pThisDocument->Message( PAGE_PIXELS_MAX_GET, EMPTY_CPOINT, &status);

	CSize totalSize = CSize(
		(long)(paper_pixels.x + (paper_pixels.x/4)),
		(long)(paper_pixels.y + (paper_pixels.y/4)));

//	totalSize = CSize(GetSystemMetrics(SM_CXSCREEN) * 2, GetSystemMetrics(SM_CYSCREEN) * 2);

	// Program can't handle largner than 32K size (TWIPS does that)
	if (totalSize.cx > (32*1024))
		totalSize.cx = (32*1024)-1;

	if (totalSize.cy > (32*1024))
		totalSize.cy = (32*1024)-1;

	pageSize = CSize( totalSize.cx / 2, totalSize.cy / 2);

	lineSize = CSize( totalSize.cx / 5, totalSize.cy / 50);


	SetScrollSizes( MM_TWIPS, totalSize, pageSize, lineSize);


	// Make sure the initial window comes up maximized
	CMDIChildWnd *pFrame = (CMDIChildWnd *) GetParentFrame();
        
	pFrame->MDIMaximize();

}

/////////////////////////////////////////////////////////////////////////////
// CSwView printing


BOOL CSwView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	int status = ERROR;
	int retv;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	inPrintPreview = pInfo->m_bPreview;	

	int ntpage = pThisDocument->Message( DOC_PAGE_TOTAL_GET, EMPTY_INT, &status);

	CurrPage = pThisDocument->Message( DOC_PAGE_CURRENT_GET, EMPTY_INT, &status);

	pInfo->SetMaxPage(ntpage);

	pThisDocument->Message( PAGE_ORIENTATION_ROTATE, 1, &status);

	if (m_showPrintDialog == 0) {
		pInfo->m_bPreview = 1;
	}
	retv = DoPreparePrinting(pInfo);
	pInfo->m_bPreview = inPrintPreview;

	return retv;
}

void CSwView::OnBeginPrinting(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	pDC;	/* not needed */

	CEditBar *ptoolbar;

	int status=OK;
	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	// save the current Zoom to restore after printing
	saveZoom = pThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);
	// Make sure the zoom is set to 100% before printing
	pThisDocument->Message(DOC_ZOOM_SET, 100, &status);
    
	BarsVisible = 0;
	ptoolbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_POWERBAR);
	if (ptoolbar) {
		if (ptoolbar->IsVisible()) {
			BarsVisible |= POWERBAR_ON;
			ptoolbar->ShowWindow(SW_HIDE);
		}
	}

	ptoolbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_STATUS_BAR);
	if (ptoolbar) {
		if (ptoolbar->IsVisible()) {
			BarsVisible |= STATUSBAR_ON;
			ptoolbar->ShowWindow(SW_HIDE);
		}
	}


	BBox  *pBoxCurrent;
//    int status;
//	CSwDoc* pDoc = GetDocument();
//	ASSERT_VALID(pDoc);
//	Document *pThisDocument = pDoc->GetThisDocument();

	pThisDocument->Message( DOC_SET_DONTDRAW, TRUE, &status);

	pBoxCurrent = pThisDocument->GetCurrentBox();

	if (pBoxCurrent) {
		pThisDocument->Message(MOUSE_LBUTTON_DOWN, CPoint(-1,-1), &status);
		pThisDocument->Message(MOUSE_LBUTTON_UP, CPoint(-1,-1), &status);
	}
}

void CSwView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	CEditBar *ptoolbar;
	int status;
	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	inPrintPreview = 0;	

	Document* pThisDocument = pDoc->GetThisDocument();

	status = -1;	// Force reset of graphics

	pThisDocument->Message( DOC_PAGE_CURRENT_SET, CurrPage, &status);

	pThisDocument->Message(DOC_ZOOM_SET, saveZoom, &status);

	ptoolbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_POWERBAR);
	if ((BarsVisible & POWERBAR_ON) && ptoolbar) {
		ptoolbar->ShowWindow(SW_SHOW);
	}

	ptoolbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_STATUS_BAR);
	if ((BarsVisible & STATUSBAR_ON) && ptoolbar) {
		ptoolbar->ShowWindow(SW_SHOW);
	}

	pThisDocument->Message( DOC_SET_DONTDRAW, FALSE, &status);

	Invalidate(TRUE);	// wrw-OK
}

void CSwView::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo)
{
	CScrollView::OnPrepareDC(pDC, pInfo);
}

void CSwView::OnUpdateFilePrint(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFilePrintPreview(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection());
}
void CSwView::OnUpdateFilePrintSetup(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection());
}
extern int doingPrinting;
void CSwView::OnPrint( CDC* pDC, CPrintInfo* pInfo)
{
	int 			status = ERROR;  

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	pThisDocument->Message( DOC_PAGE_CURRENT_SET, (int)pInfo->m_nCurPage, &status);

	doingPrinting=1;
	OnDraw(pDC);
	doingPrinting=0;

	if ((*swType == swHOP) || (*swType == swHPD) || (*swType == swDEM) || (*swType == swOXD)) {
		/* Print the Copyright notice on each page for HOP only **/
		CFont FooterFont, *pOldFont;

		BOOL retval = FooterFont.CreateFont( ((int)8 * 20) * -1, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
					ANSI_CHARSET, OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
					DEFAULT_PITCH, "Arial");

		if (retval) {
			CString tStr;
			int pos;
			pOldFont = (CFont*)pDC->SelectObject(&FooterFont);

			if (*swType == swDEM) {
				tStr.LoadString(IDS_FOOTER_SW);	// on DEMO print this message
			}
			else if (*swType == swOXD) {
				tStr.LoadString(IDS_FOOTER_OXFD);	// Always on Oxford
			}
			else {
				tStr.LoadString(IDS_FOOTER_HOOKED);	// Always on HOP
			}
			pos = (int) (IsLandscape() ? -PAGE_US_X_PIXELS : -(PAGE_US_Y_PIXELS)) + 50;
			pDC->TextOut( DOC_X_BORDER_PIXELS, pos, tStr);

			pDC->SelectObject(pOldFont);
			FooterFont.DeleteObject();
		}
	}
}

static unsigned char A_1[] = {192, '`', '\'','^','~','\"','O','E',0};
static unsigned char a_1[] = {224, '`', '\'','^','~','\"','O','E',0};
static unsigned char N_1[] = {209, '~', '\0'};
static unsigned char n_1[] = {241, '~', '\0'};
static unsigned char O_1[] = {210, '`', '\'','^','~','\"',0};
static unsigned char o_1[] = {242, '`', '\'','^','~','\"',0};
static unsigned char E_1[] = {200, '`', '\'','^','\"',0};
static unsigned char e_1[] = {232, '`', '\'','^','\"',0};
static unsigned char C_1[] = {231, ',', '\0'};		// was 199 for Capital which is not used
static unsigned char c_1[] = {231, ',', '\0'};
static unsigned char I_1[] = {204, '`', '\'','^','\"',0};
static unsigned char i_1[] = {236, '`', '\'','^','\"',0};
static unsigned char U_1[] = {217, '`', '\'','^','\"',0};
static unsigned char u_1[] = {249, '`', '\'','^','\"',0};

// shapes
static unsigned char w_1[] = {130, '1','2','3',0};


static int makeNewChar(UINT c1, UINT c2)
{
	unsigned char *ptr=NULL, *ptr1, i;
	int tVal=0;

	if ((c2 == 'o') || (c2 == 'e')) {
		c2 &= ~0x20;
	}

	switch(c1) {
	case 'A':
		ptr = A_1;
		break;
	case 'a':
		ptr = a_1;
		break;
	case 'O':
		ptr = O_1;
		break;
	case 'o':
		ptr = o_1;
		break;
	case 'N':
		ptr = N_1;
		break;
	case 'n':
		ptr = n_1;
		break;
	case 'E':
		ptr = E_1;
		break;
	case 'e':
		ptr = e_1;
		break;
	case 'I':
		ptr = I_1;
		break;
	case 'i':
		ptr = i_1;
		break;
	case 'U':
		ptr = U_1;
		break;
	case 'u':
		ptr = u_1;
		break;
	case 'C':
		ptr = C_1;
		break;
	case 'c':
		ptr = c_1;
		break;

	case 'w':
		ptr = w_1;
		return(131);
		break;

	default:
		return(0);
	}
	if (!tVal)
		tVal = *ptr;
	ptr1 = ptr+1;

	for(i=0; *ptr1 != '\0'; i++, ptr1++) {
		if (c2 == *ptr1) {
			return(tVal + i);
		}
	}
	return(0);
}

/////////////////////////////////////////////////////////////////////////////
// CSwView diagnostics

#ifdef _DEBUG
void CSwView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CSwView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CSwDoc* CSwView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSwDoc)));
	return (CSwDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSwView message handlers

// TWO things caused this optimization to be a problem.
//  1 - the prior next code caused a crash in the routine
//	2 - the peek message would not work properly

#pragma optimize( "", off )

void CSwView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	static UINT charKeep1=0;
	RECT winrect;
	Module *pmodule = NULL;	
	Module *null_module = NULL;
	int shiftStatus = 1;

	nRepCnt;	/* not used */
    
   	nNewBBoxTakesKeys = FALSE;
    
	int newChar;
	int status = ERROR;
	int iWhichDraw = ERROR;
	int didSend=0;
    int doScroll = 0;
	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();
	TextItem *pItem = GetCurrentTextItem();
	CPoint scroll_position;

	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	pDC->SetMapMode(MM_TWIPS);
	scroll_position = GetDeviceScrollPosition();
	pDC->DPtoLP(&scroll_position);

	if (pItem) {
		pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pItem->DrawCursor(pDC,0);
		pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
	}
	shiftStatus  = GetKeyState(VK_SHIFT);
	if (shiftStatus & 0x1000) {
		shiftStatus = TEXT_EXTEND_SELECTION;
	}
	else {
		shiftStatus = 0;
	}

	switch (nChar) {
		case VK_HOME:
			status = GetKeyState(VK_CONTROL);
			if (status & 0x1000)
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_GOTO_BEGIN, &shiftStatus);
			else
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_HOME, &shiftStatus);
			break;
		case VK_END:
			status = GetKeyState(VK_CONTROL);
			if (status & 0x1000)
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_GOTO_END, &shiftStatus);
			else
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_END, &shiftStatus);
			status = shiftStatus;
			break;
		case VK_DELETE:
			pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_DELETE, &status);
			pDoc->SetModifiedFlag(TRUE);
			break;
		case VK_UP:
			pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_UP, &shiftStatus);
			status = shiftStatus;
			break;
		case VK_DOWN:
			pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_DOWN, &shiftStatus);
			status = shiftStatus;
			break;

		case VK_PRIOR:   
			if (IsCurrentText() == FALSE) {
   				OnVScroll( SB_PAGEUP, 0, NULL);
				OnVScroll( SB_ENDSCROLL, 0, NULL);
   			}
			goto GetOut;
			break;
		case VK_NEXT:
			if (IsCurrentText() == FALSE) {
				OnVScroll( SB_PAGEDOWN, 0, NULL);
				OnVScroll( SB_ENDSCROLL, 0, NULL);
			}
			goto GetOut;
			break;

		case VK_LEFT:
			status = GetKeyState(VK_CONTROL);
			if (status & 0x1000)
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_WORDLEFT, &shiftStatus);
			else 
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_LEFT, &shiftStatus);
			status = shiftStatus;
			break;
		case VK_RIGHT:
			status = GetKeyState(VK_CONTROL);
			if (status & 0x1000)
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_WORDRIGHT, &shiftStatus);
			else 
				pThisDocument->Message( KEY_DOWN, TEXT_CURSOR_RIGHT, &shiftStatus);
			status = shiftStatus;
			break;
		case VK_TAB:
			pThisDocument->Message( KEY_DOWN, 0x09, &status);
			pDoc->SetModifiedFlag(TRUE);
			break;
		// These are things we don't want processed!!!
		case VK_F3:
			status = GetKeyState(VK_CONTROL);
			if (status & 0x1000) {

#ifdef WRWDEBUG
				doDump=1;	// force a dump of the character in cursive
#endif
				if (pItem != NULL) {
					pItem->ReformatText();	/* Make sure text is formatted correctly */
				}
				OnRedrawAll();			// control-f3 does re-draw of whole screen
				break;
			}

		case VK_CONTROL:
		case VK_CAPITAL:
		case VK_SHIFT:
			goto GetOut;
		case VK_MENU:
		case VK_ESCAPE:
		case VK_F1:
		case VK_F2:
			
		case VK_F4:
		case VK_F5:
		case VK_F6:
		case VK_F7:
		case VK_F8:
		case VK_F9:
		case VK_F10:
		case VK_F11:
		case VK_F12:
		case VK_F13:
		case VK_F14:
		case VK_F15:
		case VK_F16:
		case VK_F17:
		case VK_F18:
		case VK_F19:
		case VK_F20:
		case VK_F21:
		case VK_F22:
		case VK_F23:
		case VK_F24:
		case VK_NUMLOCK:
		case VK_SCROLL:
			goto GetOut;
			break;
		default:
			BYTE pbKeyState[256];
#if (WINVER < 0x400)
		    DWORD pdwTransKey;		// 32 bit is dword in win3.1
#else 
		    WORD pdwTransKey;		// This is a word in win32
#endif		    
    
			// This gets the stake of the cntrol - shift - alt keys and others
    		GetKeyboardState((LPBYTE) &pbKeyState);
    		ToAscii(nChar, nFlags, pbKeyState, &pdwTransKey, 0);

			// SW16_BIT???Th	This was added for Windows 3.1...
    		char asciichar[2];

// Underline
			status = pbKeyState[VK_CONTROL];	//GetKeyState(VK_CONTROL);
//			if ((status & 0x80) && (nChar == 'U')) {
//				asciichar[0] = 'U';
//				pThisDocument->Message( KEY_DOWN, asciichar[0], &status);
//				break;
//			}
// End Underline

			/* We need to get the Sterling pound into the system somehow */
			if ((*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {
				if ((status & 0x80) && (nChar == 'L')) {
					pThisDocument->Message( KEY_DOWN, (int)163, &status);
					didSend++;
				}
				else {
					status = pbKeyState[VK_SHIFT];	//GetKeyState(VK_SHIFT);
					if ((status & 0x80) && (nChar == '3')) {
						pThisDocument->Message( KEY_DOWN, (int)163, &status);
						didSend++;
					}
				}
				/* Get the control-key status again */
				status = pbKeyState[VK_CONTROL];	//GetKeyState(VK_CONTROL);
			}
			pDoc->SetModifiedFlag(TRUE);

			if (!(status & 0x80)) {
				wsprintf( asciichar, "%c", pdwTransKey);
				nChar = (UINT) asciichar[0];
			}

			if (status & 0x80) {		// If the control key is pressed

				if (charKeep1 == 0) {
					int shiftStat = pbKeyState[VK_SHIFT];
					int testNum=0;

					switch(nChar) {
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
					case '0':
						testNum=1;
						nChar = nChar - '0' + 0xb0;	
						break;
					case 'A':
					case 'O':
					case 'N':
					case 'E':
					case 'I':
					case 'U':
					case 'C':
					case 'W':
						if (!(shiftStat & 0x80)) {
							nChar |= 0x20;
						}
						else {
							nChar &= ~0x20;
						}
						charKeep1 = nChar;
						didSend++;	/* don't send it through */
						goto GetOut;
						break;
					case 191:
						nChar = 191;	/* control ? is the upsidedown questionmark */
						break;
					case 49:	/* control 1 is the upsidedown exclaimation */
						nChar = 161;
						break;
					default:
						charKeep1 = 0;
						break;
					case 'Z':
					case 'z':
						pThisDocument->Message( TEXT_UNDO, (int)0, &status);
						didSend++;
						break;
					}
				}
			}
			else if (charKeep1) {
				if (charKeep1 == 'w') {
					if (nChar >= 'a' && nChar <= 'z') {
						nChar = 129 + nChar - 'a';
					}
					else if ((nChar >= '1') && (nChar <= '9')) {
						nChar = 171 + nChar - '1';
					}
					else {
						switch(nChar) {
							case '0': nChar = 180; break;	//10
							case '-': nChar = 181; break;	//11
							case '=': nChar = 182; break;	//12

							case ',': nChar = 156; break;
							case '.': nChar = 157; break;
							case '/': nChar = 158; break;
							case ';': nChar = 159; break;
							case '\'': nChar = 160; break;
							case '[': nChar = 161; break;
							case ']': nChar = 162; break;
							case '\\': nChar = 163; break;
							default:
								break;
						}
					}
					charKeep1 = 0;

				}
				else {
					switch(nChar) {
					case '\'':
					case '`':
					case 'o':
					case 'O':
					case '^':
					case '~':
					case ',':
					case '\"':	/* was ':' */
					case 'e':
					case 'E':

						newChar = makeNewChar(charKeep1, nChar);
						if (newChar != 0) {
							pThisDocument->Message( KEY_DOWN, newChar, &status);
							didSend++;
						}
					default:
						charKeep1 =0;
						break;
					}
				}
			}

			if (!didSend) {	/* if sherston didn't send the key */
				pThisDocument->Message( KEY_DOWN, (int)nChar, &status);
			}

		break;
	}    
	
	iWhichDraw = status;	/* Remember the display command */
	pmodule = pThisDocument->Message( GET_ITEM_FOR_REDRAW, null_module, &status);
	if( pmodule != NULL) {
		MSG stmsg = {0,0,0,0,0,0};
		int sYtype=-1, sXtype=-1;

		pmodule->Message( BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
		pmodule->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pmodule->Draw( pDC, &iWhichDraw);
		pmodule->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pmodule->Message( BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);

		if (PeekMessage(&stmsg, NULL, WM_KEYDOWN, WM_KEYDOWN, PM_NOYIELD|PM_NOREMOVE) != FALSE) {
			goto GetOut;
		}

		/// Get the current cursor position, and get it onto the screen!
		int lheight, topos;
		CPoint newpos;
		CPoint curpos =  pThisDocument->Message( TEXT_GET_CURSOR_POS, CPoint(0,0), &lheight);
		lheight = (int)((float)lheight / pThisDocument->dCurrentZoom);

		curpos.y -= scroll_position.y;
		curpos.x += scroll_position.x;

		GetClientRect(&winrect);

		pDC->SetMapMode(MM_TWIPS);
		pDC->DPtoLP(&winrect);

		topos = curpos.y + lheight;

		if (topos < winrect.bottom) {     
			int diff = topos - winrect.bottom;
			doScroll = -diff;
			sYtype = SB_LINEDOWN;
		}
		else if (curpos.y > 0) {		// if we went off the top
			doScroll = curpos.y;
			sYtype = SB_LINEUP;
		}

		if (curpos.x > winrect.right) {
			if (curpos.x > (winrect.right + DOC_X_EXTENT)) {
				sXtype = SB_RIGHT;
			}
			else {
				sXtype = SB_PAGERIGHT;
			}
		}
		else if (curpos.x < 0) {
			if (-curpos.x > DOC_X_EXTENT) { 
				sXtype = SB_LEFT;
			}
			else {
				sXtype = SB_PAGELEFT;
			}   
		}

		if (doScroll || (sXtype > -1)) {
			doSetCursor = 0;
			if (doScroll) {
				int pmode;
				SIZE totalSize, sizePage, sizeLine, newLine;
				GetDeviceScrollSizes(pmode, totalSize, sizePage, sizeLine);
				// Convert these all to logical units
				pDC->SetMapMode(MM_TWIPS);
				pDC->DPtoLP(&sizeLine);		// change to logical
				newLine.cx = sizeLine.cx;
				newLine.cy = doScroll+100;	// to handle this value
				pDC->LPtoDP(&newLine);		// convert to device
				pDC->SetMapMode(MM_TEXT);	// and reset the mode
				doDrawCursor = -1;			// don't let update draw the cursor this round
				SetScrollSizes(MM_TEXT, totalSize, sizePage, newLine);
				OnVScroll( sYtype, 0, NULL);
				OnVScroll( SB_ENDSCROLL, 0, NULL);
			}

			if (sXtype > -1) {
				doDrawCursor = -1;			// don't let the update draw the cursor
				OnHScroll(sXtype, 0, NULL);	// this one scrolls and displays
				OnHScroll( SB_ENDSCROLL, 0, NULL);
			}

			doSetCursor = 1;
			scroll_position = GetDeviceScrollPosition();
			pDC->SetMapMode(MM_TWIPS);
			pDC->DPtoLP(&scroll_position);
			doScroll = -2;

		}
	}                                            
GetOut:
	// Draw the new cursor 
	if (pItem) {
		pDC->SetMapMode(MM_TWIPS);
		pThisDocument->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pItem->DrawCursor(pDC,1);
		pThisDocument->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
	}
	doDrawCursor = 0;	// make sure this is set to cleared
	delete(pDC);
	return;
}
#pragma optimize( "", on ) 

void CSwView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	CPoint iRet;
	lastPoint = point;
	bool selWasOn=false;

	SelectionIsReal = 0;		// could not be on yet
	CScrollView::OnLButtonDown(nFlags, point);

	int 	status = ERROR,
			iWhichDraw;

	SetFocus();

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	m_ptLastMove = point;		// Set the beginning of a possible move

	TextItem *pItem = GetCurrentTextItem();
	int cursorOn=0;
	if (pItem) {
		CPoint scroll_position;
		scroll_position = GetDeviceScrollPosition();
		pDC->SetMapMode(MM_TWIPS);
		pDC->DPtoLP(&scroll_position);

		pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pItem->DrawCursor(pDC, 0);	// turn off the cursor
		if (pItem->SelectionOn) {
			selWasOn=true;
			pItem->Message(TEXT_SELECTION_OFF, CPoint(0,0), &status);
		}
		pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
	}

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
    
	point.x += scroll_position.x;
	point.y += scroll_position.y;
    
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&point);
    
	pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);

	iRet = pThisDocument->Message( MOUSE_LBUTTON_DOWN, point, &status);

	if (status == STATUS_CAPTURE_MOUSE) {
//		SetCapture();
		MouseCaptured = TRUE;
		iWhichDraw = TEXT_DRAW_ALL;
		if (iRet.x == TEXT_DRAW_OLD_NEW) {		// Special case
			DoItemRedraw(0);
		}
	}
	else {
		// Will either be TEXT_DRAW_ALL if we selected another box,
		// or TEXT_DRAW_CURSOR if we're still in the same box and
		// we just need to move the cursor.
		iWhichDraw = selWasOn ? TEXT_DRAW_ALL : status;
		if (iWhichDraw == TEXT_DRAW_CURSOR) {
			// We still have the potential of getting text selection
			MouseCaptured = SEL_MAYBE;	// Just put this on alert
		}
		else if (iWhichDraw == TEXT_DRAW_OLD_NEW) {
			DoItemRedraw(iWhichDraw);
			cursorOn=1;
		}
		else if (iWhichDraw == TEXT_DRAW_CURRENT) {
			DoItemRedraw(iWhichDraw);
			delete(pDC);
			return;
		}
		else if (iWhichDraw == TEXT_DRAW_ALL) {
			Invalidate(TRUE);	// wrw-ok
			delete(pDC);
			return;
		}
	}

	delete(pDC);		// Clear memory 

	CSwDoc* pDoc1 = GetDocument();
	ASSERT_VALID(pDoc1);

	Document* pThisDocument1 = pDoc1->GetThisDocument();

	CClientDC *pDC1 = new CClientDC(this);
	pDoc1->PrepareDC(pDC1);
	pDoc1->PrepareScrollView(this);

	Module *pmodule = pThisDocument1->Message( GET_ITEM_FOR_REDRAW, 
								(Module *) NULL, &status);
	if (pmodule) {
		TextItem *pItem = GetCurrentTextItem();

		pmodule->Message(BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
		pmodule->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		iWhichDraw = TEXT_DRAW_CURSOR;	// find the correct location

		pmodule->Draw(pDC1, &iWhichDraw);

		if (pItem && !cursorOn) {
			pItem->DrawCursor(pDC1, 1);	// Then draw the cursor
		}

		pmodule->Message(BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);
		pmodule->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
	}
	delete(pDC1);
}

void CSwView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	point;	/* not used */
	nFlags;	/* not used */

    OnFormatArt();		// We just want to edit the art box
}



void CSwView::OnLButtonUp(UINT nFlags, CPoint point)
{
	int status = ERROR;
	nFlags;	/* not used */

	if (!MouseCaptured)
		return;

	if (MouseCaptured == SEL_MAYBE) {
		MouseCaptured = FALSE;
		return;
	}

	if (MouseCaptured == SEL_ON) {
		MouseCaptured = FALSE;
		MousePending = FALSE;
		if (SelectionIsReal == 0) {
			CSwDoc* pDoc = GetDocument();
			Document* pThisDocument = pDoc->GetThisDocument();
			pThisDocument->Message(TEXT_SELECTION_OFF, CPoint(-1, -1), &status);
		}
		else {
			DoItemRedraw(0);
		}
		return;
	}

	//ReleaseCapture();
	MousePending = FALSE;
	MouseCaptured = FALSE;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
	int flag = 0;
    
	if ((point.x != lastPoint.x) || (point.y != lastPoint.y)) {
		flag++;
	}
    point.x += scroll_position.x;
   	point.y += scroll_position.y;

	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&point);


	pThisDocument->Message( MOUSE_LBUTTON_UP, point, &status);
	pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);

	if (flag) {
		Invalidate(TRUE);		// wrw-OK here at end of move box or drag to create
		/* We need to here allow the text item to refit to the new size of the box */
		TextItem *pItem = GetCurrentTextItem();
		if (pItem != NULL) {
			pItem->allowAdjustBox = TRUE;
			pItem->allowFixWrap = TRUE;
		}
	}
	else {
		DoItemRedraw(0);
	}
	delete(pDC);
}


void CSwView::OnRButtonDown(UINT nFlags, CPoint cp)
{
	CMenu menu;     
	int menuNum;

	nFlags;	/* not used */

	TextItem *pItem = GetCurrentTextItem();

	menuNum = (pItem != NULL) ? (((*swType == swOXF) || (*swType == swOXD)) ? IDR_TEXTFORMAT_OXF : IDR_TEXTFORMAT) : IDR_MENUPOPUP;

	if (menu.LoadMenu(menuNum)) {

		CMenu* pPopup = menu.GetSubMenu(0);

		if (pPopup != NULL) {
                               
			ClientToScreen(&cp);
			pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, cp.x, cp.y, AfxGetMainWnd());
		}
#ifndef FREEZ
		else {
			ASSERT(pPopup != NULL);
		}    
#endif

	}
}


void CSwView::OnMouseMove(UINT nFlags, CPoint point)
{
	int status = ERROR;
	int save_status;
	nFlags;	/* not used */

	if (m_ptLastMove == point) {
		return;	// no use if no movement
	}

	if ((MouseCaptured == SEL_MAYBE) && (m_ptLastMove != point)){
		MouseCaptured = SEL_ON;
	}
	
	m_ptLastMove = point;

	if(MouseCaptured)
	{
		CSwDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);

		Document* pThisDocument = pDoc->GetThisDocument();

		CClientDC *pDC = new CClientDC(this);
		pDoc->PrepareDC(pDC);
		pDoc->PrepareScrollView(this);

		CPoint scroll_position;
		scroll_position = GetDeviceScrollPosition();
    
    	// Unsure on this one right now.
    	// Invalidate() seems to require it but just redrawint doesn't
    	// Does invalidate change the view?
	    point.x += scroll_position.x;
	    point.y += scroll_position.y;

		pDC->SetMapMode(MM_TWIPS);
		pDC->DPtoLP(&scroll_position);
		pDC->SetMapMode(MM_TWIPS);
		pDC->DPtoLP(&point);

		pDoc->SetModifiedFlag(TRUE);
		pThisDocument->Message( MOUSE_MOVE, point, &status);
		
		save_status = status;	// save this status
		
		Module *null_module = NULL;
		Module *pmodule = pThisDocument->Message( GET_ITEM_FOR_REDRAW, null_module, &status);
		if( pmodule != NULL)
		{
			int tempStatus;
			pmodule->Message( BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
			// If we are doing selection and cursor is set, make sure we do that
			if (save_status == TEXT_DRAW_SELECTION) {
				status = TEXT_DRAW_SELECTION;
			}
			doDrawCursor++;				// Allow cursor draw if this sets it to one
			TextItem *pItem = GetCurrentTextItem();
			if (pItem) {
				pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &tempStatus);
			}
			pmodule->Draw( pDC, &status);
			if (pItem) {
				pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &tempStatus);
			}
			doDrawCursor--;
			
			pmodule->Message( BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);
		}
		
		delete(pDC);
	}  
}

/////////////////////////////////////////////////////////////////////////////
// CSwView message handlers for power bar

void CSwView::OnDocOrientation()
{
	SetLandscape(!IsLandscape());
}


void CSwView::OnNewTextItem()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

// Some how turn off any current boxes
	BBox *pBoxCurrent = pThisDocument->GetCurrentBox();
	if (pBoxCurrent != NULL) {
		pBoxCurrent->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);
		DoItemRedraw(0);
	}

	// Do this just to get the scroll pos to create the box appropriately
	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
    
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);
	delete(pDC);

	// Two lines of new code.  Just create a box
	pThisDocument->Message(PAGE_NEW_TEXTBOX, scroll_position.y, &status);
	DoItemRedraw(0);

#ifdef OLDWAY		
//		pThisDocument->Message( TOOL_SET, TOOL_TEXT_NEW, &status);
//		MousePending = TRUE;
//		SetCursor(LoadCursor(NULL, IDC_CROSS));
#endif
}

void CSwView::OnNewArtItem()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
    
	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

// Some how turn off any current boxes
	BBox *pBoxCurrent = pThisDocument->GetCurrentBox();
	if (pBoxCurrent != NULL) {
		pBoxCurrent->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);
		DoItemRedraw(0);
	}

	// Do this just to get the scroll pos to create the box appropriately
	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
    
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);
	delete(pDC);

	
// NEW WAY
	pThisDocument->Message(PAGE_NEW_ARTBOX, scroll_position.y, &status);
	if (status == ERROR) {
		pThisDocument->Message(DELETE_SELECTED_ITEM, EMPTY_INT, &status);
	}
	DoItemRedraw(0);

#ifdef OLDWAY
//	pThisDocument->Message( TOOL_SET, TOOL_ART_NEW, &status);
//	MousePending = TRUE;
//	SetCursor(LoadCursor(NULL, IDC_CROSS));
#endif
}

void CSwView::OnItemTool()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
    
	Document* pThisDocument = pDoc->GetThisDocument();


	pThisDocument->Message( ITEM_USE_TOOLS, EMPTY_INT, &status);


	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
    
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);

	Module *null_module = NULL;
	Module *pmodule = pThisDocument->Message( GET_ITEM_FOR_REDRAW, null_module, &status);
	if( pmodule != NULL)
	{
		pmodule->Message( BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
		pmodule->Draw( pDC, &status);
		pmodule->Message( BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);
	}

	pDoc->SetModifiedFlag(TRUE);
	delete(pDC);
}

void CSwView::DoItemRedraw(int flag)
{
	int status;
	
	CClientDC *pDC = new CClientDC(this);

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);

	CPoint scroll_position;
	scroll_position = GetDeviceScrollPosition();
    
	pDC->SetMapMode(MM_TWIPS);
	pDC->DPtoLP(&scroll_position);

	// If we are redrawing a text box
	// then turn off the cursor first
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
		pItem->DrawCursor(pDC, 0);	// turn off the cursor
	}

	Document* pThisDocument = pDoc->GetThisDocument();
	Module *null_module = NULL;
	Module *pmodule = pThisDocument->Message( GET_ITEM_FOR_REDRAW, null_module, &status);
	if( pmodule != NULL) {
		pmodule->Message( BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
		pmodule->Message(ART_SET_RELOAD, TRUE, &status);
		status = TEXT_DRAW_ALL;	// make sure we redraw the whole thing
		pmodule->Draw( pDC, &status);
		if ((pItem != NULL) && (pItem->inPasteMode == true)) {
			while (status == TEXT_DRAW_ALL_AGAIN) {
				pmodule->Draw( pDC, &status);
			}
		}
		pmodule->Message( BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);
	}
	if (flag == TEXT_DRAW_OLD_NEW) {
		Module *pmodule = pThisDocument->Message( GET_ITEM_FOR_REDRAW, null_module, &status);
		if( pmodule != NULL) {
			pmodule->Message( BBOX_SCROLL_OFFSET_SET, scroll_position, &status);
			status = TEXT_DRAW_ALL;	// make sure we redraw the whole thing
			pmodule->Draw( pDC, &status);
			pmodule->Message( BBOX_SCROLL_OFFSET_SET, CPoint(0,0), &status);
		}
	}
	if (pItem != NULL) {
		pItem->DrawCursor(pDC, 1);	// turn on the cursor
		pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
	}
	pDoc->SetModifiedFlag(TRUE);
	delete(pDC);

}

/////////////////////////////////////////////////////////////////////////////
// CSwView message handlers for power bar

void CSwView::SharedCutCopy(int cVal)
{
	int 	status = ERROR;
	BBox  *pBoxCurrent;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	Module *null_module = NULL;
	if (pCopyBBox) {
		delete pCopyBBox;
		pCopyBBox = NULL;
	}
	if (pUndoBBox) {
		delete pUndoBBox;
		pUndoBBox = NULL;
	}
	pBoxCurrent = pThisDocument->GetCurrentBox();

	if (!pBoxCurrent)
		return;

	if (CheckSelection()) {
		// Do copy of text
		pBoxCurrent->Message( cVal, 0, &status);

		if (*swType != swHPD) {
			HANDLE hData;                            /* handles to clip data  */
			LPSTR lpData;                           /* pointers to clip data */
			int tSize, cnt;

			char lpszText[1024];
			cnt = 0;
			tSize = 0;
			lpszText[0] = 0;
			while(TxtCopy[cnt].IsEmpty() == FALSE) {
				tSize += TxtCopy[cnt].GetLength();
				if (tSize > sizeof(lpszText)) {
					break;
				}
				if (cnt) {		/* put end of lines on previous lines */
#ifdef _CRT_SECURE_NO_DEPRECATE
					strncat(lpszText, "\r\n",sizeof(lpszText));
#else
					strncat_s(lpszText,sizeof(lpszText), "\r\n",sizeof(lpszText));
#endif
				}
#ifdef _CRT_SECURE_NO_DEPRECATE
				strncat(lpszText, (char *)(LPCSTR)TxtCopy[cnt], sizeof(lpszText));
#else
				strncat_s(lpszText, sizeof(lpszText),(char *)(LPCSTR)TxtCopy[cnt], sizeof(lpszText));
#endif
				cnt++;
			}
			tSize= strlen(lpszText);

			hData = GlobalAlloc(GMEM_DDESHARE, tSize+1);
			if (!hData) {
				return;
			}
			lpData = (char *)GlobalLock(hData);
			if (!lpData) {
				return;
			}
#ifdef _CRT_SECURE_NO_DEPRECATE
			strcpy(lpData, lpszText);
#else
			strcpy_s(lpData, sizeof(lpData),lpszText);
#endif
			GlobalUnlock(hData);

			/* Clear the current contents of the clipboard, and set
			 * the data handle to the new string.
			 */

			if (OpenClipboard()) {
				EmptyClipboard();
				SetClipboardData(CF_TEXT, hData);
				CloseClipboard();
			}
		}
	}
	else {	/* Copy the item */
		pCopyBBox = (BBox *) pBoxCurrent->Message( ITEM_RETURN_COPY, null_module, &status);
		pUndoBBox = (BBox *) pBoxCurrent->Message( ITEM_RETURN_COPY, null_module, &status);
		if (cVal == TEXT_DOCUT) {
			pThisDocument->Message( DELETE_SELECTED_ITEM, EMPTY_INT, &status);
		}
	}
	if (cVal == TEXT_DOCUT) {
		Invalidate(TRUE);	// wrw-OK we just deleted a box
	}

}

void CSwView::OnEditCut()
{
	SharedCutCopy(TEXT_DOCUT);
}

void CSwView::OnEditCopy()
{
	SharedCutCopy(TEXT_DOCOPY);
}

void CSwView::OnEditPaste()
{
	int status = ERROR;
	HANDLE hClipData;                            /* handles to clip data  */
	LPSTR lpClipData;                           /* pointers to clip data */
	char lpszText[1024]={0};

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();
	TextItem *pItem = GetCurrentTextItem();

	/* if a box is copies, paste it first */
	/* We only do this paste of a box if a box is not selected and there is a copied box */
	if( (!pItem) && (pCopyBBox != NULL)) {
		pThisDocument->Message( COPY_AND_PASTE_THIS_BOX, pCopyBBox, &status);
		Invalidate(TRUE);	// wrw- temp, until display is better (smarter)
	}
	else if (pItem) {
		/* Get stuff off the clipboard */
		if (*swType != swHPD) {
			if (IsClipboardFormatAvailable(CF_TEXT) && OpenClipboard()) {
				hClipData = GetClipboardData(CF_TEXT);

				if (hClipData != NULL) {
					lpClipData = (char *)GlobalLock(hClipData);
					if (lpClipData != NULL) {
						if (GlobalSize(hClipData) > sizeof(lpszText)) {
							AfxMessageBox("Too Much Text.");
						}
#ifdef _CRT_SECURE_NO_DEPRECATE
						strncpy(lpszText, lpClipData, sizeof(lpszText));
#else
						strncpy_s(lpszText, sizeof(lpszText),lpClipData, sizeof(lpszText));
#endif
						GlobalUnlock(hClipData);
					}
				}
				CloseClipboard();
			}
			
			/* This flag set to handle the big paste. */
			/* The redraw code will make the point size smaller to fit the page */
			pItem->inPasteMode = true;
			if (lpszText[0]) {
				for(char *pptr = lpszText; *pptr; pptr++) {
					if (*pptr == '\r') {
						continue;	/* ignore the carriage return char */
					}
					else if (*pptr == '\n') {
						if (pItem->KeyDown(13, &status) == 0) {
							break;
						}
					}
					else if (pItem->KeyDown(*pptr, &status) == 0) {
						break;	/* box is full */
					}
				}
				DoItemRedraw(0);
			}
			pItem->inPasteMode = false;
			return;	
		}
		if (TxtCopy[0].IsEmpty() == FALSE) {
			// Do copy of text
			pThisDocument->Message( TEXT_DOPASTE, 0, &status);
			DoItemRedraw(0);
		}
	}
}


void CSwView::OnDocSpell()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	pThisDocument->Message( SPELL_SELECTED_ITEM, EMPTY_INT, &status);

	DoItemRedraw(0);	// wrw-OK 
}

/////////////////////////////////////////////////////////////////////////////
// CSwView message handlers for navigation bar

void CSwView::OnPagePrev()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	int ncpage = pThisDocument->Message( DOC_PAGE_CURRENT_GET, EMPTY_INT, &status);

	status = -1;	// force art clear for all pages
	pThisDocument->Message( DOC_PAGE_CURRENT_SET, ncpage - 1, &status);

	ScrollToPosition(CPoint(0,0));

	Invalidate(TRUE);	// wrw-OK
    SetFocus();
}

void CSwView::OnPageSelect()
{
    SetFocus();
}

void CSwView::OnPageNext()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	int ncpage = pThisDocument->Message( DOC_PAGE_CURRENT_GET, EMPTY_INT, &status);

	status = -1;	// force art clear for all pages

	pThisDocument->Message( DOC_PAGE_CURRENT_SET, ncpage + 1, &status);

	// Make sure we start at the top
	ScrollToPosition(CPoint(0,0));

	Invalidate(TRUE);	// wrw-OK
    SetFocus();
}

void CSwView::OnZoomDec()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	int nzoom = pThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);

	if (pThisDocument->Message( DOC_ZOOM_SET, nzoom - 10, &status) != 0) {
		// we actually changed the zoom
		pDoc->PrepareScrollView(this);
		Invalidate(TRUE);	// wrw-OK
	}
    SetFocus();
}

void CSwView::OnZoomSelect()
{
	// TODO: Add your command handler code here
	//AfxMessageBox("This has not been implemented yet.");
    SetFocus();
}

void CSwView::OnZoomInc()
{
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	int nzoom = pThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);

	if (pThisDocument->Message( DOC_ZOOM_SET, nzoom + 10, &status) != 0) {

		pDoc->PrepareScrollView(this);
		Invalidate(TRUE);	// wrw-OK/
	}
    SetFocus();
}


/////////////////////////////////////////////////////////////////////////////
// CSwView messages that are in menu, but not bars

void CSwView::OnNewPage()
{
	CInsertPage cDlg;
	int status = ERROR, retv;
	static int lastTime=0;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	cDlg.m_which = lastTime;
	retv = cDlg.DoModal();
	if (retv == IDOK) {
		switch(cDlg.m_which) {
		default:
			cDlg.m_which = 0;
			/* fall through */
		case 0:
			retv = DOC_PAGE_NEXT;
			break;

		case 1:
			retv = DOC_PAGE_PREVIOUS;
			break;
		
		case 2:
			retv = DOC_PAGE_FIRST;
			break;
		
		case 3:
			retv = DOC_PAGE_LAST;
			break;
		}
		lastTime = cDlg.m_which;
	
		if (pThisDocument->Message( DOC_PAGE_NEW, retv, &status) != 0) {

			HDC 	hdc = ::GetDC(m_hWnd);
			POINT pt = {0, 0};

			DPtoLP(hdc, &pt, 1);
			ScrollToPosition(pt);

			Invalidate(TRUE);	// wrw-OK
		}
	}
}


void CSwView::OnDeletePage()
{
	// TODO: Add your command handler code here
	int status = ERROR;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	pDoc->SetModifiedFlag(TRUE);
	Document* pThisDocument = pDoc->GetThisDocument();

	if (pThisDocument->Message( DOC_PAGE_DELETE, DOC_PAGE_CURRENT, &status) != 0) {

		// Update the page select button
		Invalidate(TRUE);	// wrw-OK
	}
}

void CSwView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
	CScrollView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

void CSwView::OnDocumentLandscape()
{
	SetLandscape(TRUE);
	setPrintOrientation(DMORIENT_LANDSCAPE);
}

void CSwView::OnUpdateDocumentLandscape(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection());

	pCmdUI->SetCheck(IsLandscape());
}

void CSwView::OnDocumentPortrait()
{
	SetLandscape(FALSE);
	setPrintOrientation(DMORIENT_PORTRAIT);
}


void CSwView::OnUpdateDocumentPortrait(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection());

	pCmdUI->SetCheck(!IsLandscape());
}

BOOL CSwView::IsLandscape()
{
	CSwDoc 	*pDoc = GetDocument();
	Document	*pThisDocument;

	ASSERT_VALID(pDoc);

	pThisDocument = pDoc->GetThisDocument();

	return pThisDocument->IsPageLandscape(1);
}

void CSwView::SetLandscape(BOOL bValue)
{
	if (bValue == IsLandscape())
		return;

	CSwDoc 	*pDoc = GetDocument();
	Document	*pThisDocument;               
	int		status;

	ASSERT_VALID(pDoc);

	pThisDocument = pDoc->GetThisDocument();
	pThisDocument->Message( PAGE_ORIENTATION_ROTATE, EMPTY_INT, &status);
	TextItem *pItem = GetCurrentTextItem();
	if (pItem) {
		pItem->Message(TEXT_SET_ORIENTATION, bValue, &status);
	}

	Invalidate(TRUE);	// wrw-OK
}


BOOL CSwView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if (nHitTest != HTCLIENT) {
		return CScrollView::OnSetCursor(pWnd, nHitTest, message);
	}
	if (MousePending) {	// If we are still in the right area -- leave it a cross
		SetCursor(LoadCursor(NULL, IDC_CROSS));
		return 1;
		//return CScrollView::OnSetCursor(pWnd, nHitTest, message);
	}

	CSwDoc 	*pDoc = GetDocument();
	Document	*pThisDocument;               
	int		iAtPoint;
	POINT		ptMove = m_ptLastMove,
				ptScroll;
	HCURSOR testCur;

	pThisDocument = pDoc->GetThisDocument();

	CClientDC *pDC = new CClientDC(this);
	pDoc->PrepareDC(pDC);
	pDoc->PrepareScrollView(this);
	ptScroll = GetDeviceScrollPosition();
	ptMove.x += ptScroll.x;
	ptMove.y += ptScroll.y;

	pDC->SetMapMode(MM_TWIPS);
	DPtoLP(pDC->m_hDC, &ptScroll, 1);
	pDC->SetMapMode(MM_TWIPS);
	DPtoLP(pDC->m_hDC, &ptMove, 1);
	iAtPoint = pThisDocument->WhatIsAtPoint(ptMove);

	LPCSTR szIcon;

	switch(iAtPoint)
	{
		case BBOX_CORNER_TOP_RIGHT:
		case BBOX_CORNER_BOTTOM_LEFT:
			szIcon = IDC_SIZENESW;
			break;
		case BBOX_CORNER_TOP_LEFT:
		case BBOX_CORNER_BOTTOM_RIGHT:
			szIcon = IDC_SIZENWSE;
			break;
		case BBOX_CENTER_TOP:
		case BBOX_CENTER_BOTTOM:
			szIcon = IDC_SIZENS;
			break;
		case BBOX_CENTER_RIGHT:
		case BBOX_CENTER_LEFT:
			szIcon = IDC_SIZEWE;
			break;
		case BBOX_HANDLE_TEXTMODE:
			szIcon = IDC_IBEAM;
			break;
		case BBOX_HANDLE_BBOX:
			szIcon = IDC_SIZEALL;
			break;
		default:
			szIcon = IDC_ARROW;
			break;
	}

	testCur = LoadCursor(NULL, szIcon);
	if (testCur != NULL) {
		SetCursor(testCur);
	}
	else {
		SetCursor(LoadCursor(NULL, IDC_IBEAM));	// default if the other fails
	}
	delete(pDC);
	return 1;
}

void CSwView::OnUpdateEditCopy(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(CanCopy());
	// If box is selected, then this is true, whether text selection or not
}

void CSwView::OnUpdateEditCut(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(CanCopy());
	// If box is selected, then this is true, whether text selection or not
}

void CSwView::OnUpdateEditPaste(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();

	pCmdUI->Enable(CanPaste() || (pItem && (IsClipboardFormatAvailable(CF_TEXT) || (TxtCopy[0].IsEmpty() == FALSE))));
	// If box is selected, then this is true, whether text selection or not
}

BOOL CSwView::CanCopy()
{
	BBox  *pBoxCurrent;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();

	pBoxCurrent = pThisDocument->GetCurrentBox();

	return pBoxCurrent != NULL;
}

BOOL CSwView::CanPaste()
{
	return pCopyBBox != NULL;
}

void CSwView::OnFormatConnectTheDots()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->doDrawConnectTheDots = pItem->doDrawConnectTheDots ? false : true;
	pItem->ReadTextBar();
	DoItemRedraw(0);

}

void CSwView::OnUpdateFormatConnectTheDots(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pCmdUI->SetCheck(pItem->doDrawConnectTheDots ? 1 : 0);
}

void CSwView::OnFormatLinedensity()
{
	SetCurrentDensity(GetButtonDensitySetting());
}
void CSwView::OnUpdateFormatLinedensity(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() ? true : false);
}

void CSwView::OnFormatLinedensity100()
{
	SetCurrentDensity(LINEDENSITY100);
	SetButtonDensitySetting(LINEDENSITY100);
}

void CSwView::OnUpdateFormatLinedensity100(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() == 4);
}

void CSwView::OnFormatLinedensity25()
{
	SetCurrentDensity(LINEDENSITY25);
	SetButtonDensitySetting(LINEDENSITY25);
}

void CSwView::OnUpdateFormatLinedensity25(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() == 1);
}
void CSwView::OnFormatLinedensityNone()
{
	SetCurrentDensity(LINEDENSITYNONE);
	SetButtonDensitySetting(LINEDENSITYNONE);
}

void CSwView::OnUpdateFormatLinedensityNone(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() == 0);
}


void CSwView::OnFormatLinedensity50()
{
	SetCurrentDensity(LINEDENSITY50);
	SetButtonDensitySetting(LINEDENSITY50);
}

void CSwView::OnUpdateFormatLinedensity50(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() == 2);
}

void CSwView::OnFormatLinedensity75()
{
	SetCurrentDensity(LINEDENSITY75);
	SetButtonDensitySetting(LINEDENSITY75);
}

void CSwView::OnUpdateFormatLinedensity75(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentDensity() == 3);
}

void CSwView::OnFormatTextarrowsToggle()
{
	if (GetCurrentArrows() == 1) {
		SetCurrentArrows(2);
	}
	else {
		SetCurrentArrows(1);
	}
}

void CSwView::OnUpdateFormatTextarrowsToggle(CCmdUI* pCmdUI)
{
	if (IsCurrentDotToDot()) {
		pCmdUI->Enable(TRUE);
		if(IsArrowedFont()) {
			pCmdUI->SetCheck(GetCurrentArrows() == 2);
		}
		else {
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::OnFormatTextarrows()
{
	if (GetCurrentArrows() == 1) {
		SetCurrentArrows(2);
	}
	else {
		SetCurrentArrows(1);
	}
}

void CSwView::OnUpdateFormatTextarrows(CCmdUI* pCmdUI)
{
	if (IsCurrentDotToDot()) {
		pCmdUI->Enable(TRUE);
		if(IsArrowedFont()) {
			pCmdUI->SetCheck(GetCurrentArrows() == 2);
		}
		else {
			pCmdUI->Enable(FALSE);
			pCmdUI->SetCheck(FALSE);
		}
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::OnFormatTextDotToggle()
{
	if (GetCurrentStartDot() == 1) {
		SetCurrentStartDot(0);
	}
	else {
		SetCurrentStartDot(1);
	}
}

void CSwView::OnUpdateFormatTextDotToggle(CCmdUI* pCmdUI)
{
	if (IsCurrentDotToDot()) {
		if(IsStartDotFont()) {
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(GetCurrentStartDot() == 1);
		}
		else {
			pCmdUI->Enable(false);
			pCmdUI->SetCheck(FALSE);
		}
	}
	else {
		pCmdUI->Enable(false);
	}
}

void CSwView::OnFormatOverlayToggle()
{
	if (GetCurrentOverlay() != 2) {
		SetCurrentOverlay(2);
	}
	else {
		SetCurrentOverlay(1);
	}
}

void CSwView::OnUpdateFormatOverlayToggle(CCmdUI* pCmdUI)
{
	if (IsCurrentDotToDot()) {
		if(IsOverlayFont()) {
			pCmdUI->Enable(TRUE);
			pCmdUI->SetCheck(GetCurrentOverlay() == 2);
		}
		else {
			pCmdUI->Enable(false);
			pCmdUI->SetCheck(FALSE);
		}
	}
	else {
		pCmdUI->Enable(false);
	}
}

void CSwView::OnFormatTextlinesBottom()
{
	SetCurrentLines(4);
}

void CSwView::OnUpdateFormatTextlinesBottom(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	
	pCmdUI->SetCheck((GetCurrentLines() & 4) ? 1 : 0);
}

void CSwView::OnFormatTextlinesMidbottom()
{
	SetCurrentLines(2);
}

void CSwView::OnUpdateFormatTextlinesMidbottom(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() & 2) ? 1 : 0);
}

void CSwView::OnFormatTextlinesNone()
{
	SetCurrentLines(8);
}

void CSwView::OnUpdateFormatTextlinesNone(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() & 8) ? 1 : 0);
}

void CSwView::OnFormatTextlinesTopmidbottom()
{
	SetCurrentLines(1);
}

void CSwView::OnUpdateFormatTextlinesTopmidbottom(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() & 1) ? 1 : 0);
}

void CSwView::OnFormatTextshading()
{
	SetCurrentShading(GetButtonShadingSetting());
}
void CSwView::OnUpdateFormatTextshading(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(0);	// KSL GetCurrentShading() ? true : false);
}

void CSwView::OnFormatTextshading100()
{
	SetCurrentShading(TEXTSHADING100);
	SetButtonShadingSetting(TEXTSHADING100);
}

void CSwView::OnUpdateFormatTextshading100(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentShading() == 4);
}

void CSwView::OnFormatTextshading25()
{
	SetCurrentShading(TEXTSHADING25);
	SetButtonShadingSetting(TEXTSHADING25);
}

void CSwView::OnUpdateFormatTextshading25(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentShading() == 1);
}

void CSwView::OnFormatTextshading50()
{
	SetCurrentShading(TEXTSHADING50);
	SetButtonShadingSetting(TEXTSHADING50);
}

void CSwView::OnUpdateFormatTextshading50(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentShading() == 2);
}

void CSwView::OnFormatTextshading75()
{
	SetCurrentShading(TEXTSHADING75);
	SetButtonShadingSetting(TEXTSHADING75);
}

void CSwView::OnUpdateFormatTextshading75(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
	pCmdUI->SetCheck(GetCurrentShading() == 3);
}


BOOL CSwView::IsCurrentText()
{
	TextItem *pItem = GetCurrentTextItem();

	return (pItem ? TRUE : FALSE); 
}

BOOL CSwView::IsArrowedFont()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return FALSE;

	return ((pItem->m_iType == ITEM_TEXT_TYPE) && !(pItem->ArrowFile.IsEmpty()));
}

BOOL CSwView::IsStartDotFont()
{
#ifdef SW50
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return FALSE;

	return ((pItem->m_iType == ITEM_TEXT_TYPE) && !(pItem->StartDotFile.IsEmpty()));
#else
	return(FALSE);
#endif
}

BOOL CSwView::IsCurrentDotToDot()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return FALSE;

	return (pItem->m_iType == ITEM_TEXT_TYPE && pItem->nDot2Dot);
}

TextItem *CSwView::GetCurrentTextItem()
{
	BBox		*pBoxCurrent;
	CSwDoc 	*pDoc = GetDocument();

	ASSERT_VALID(pDoc);

	Document *pThisDocument = pDoc->GetThisDocument();

	pBoxCurrent = pThisDocument->GetCurrentBox();

	if (!pBoxCurrent)
		return FALSE;

	if (pBoxCurrent->Item->m_iType == ITEM_TEXT_TYPE)
		return (TextItem *) pBoxCurrent->Item;
	else
		return NULL;
}

ArtItem *CSwView::GetCurrentArtItem()
{
	BBox		*pBoxCurrent;
	CSwDoc 	*pDoc = GetDocument();

	ASSERT_VALID(pDoc);

	Document *pThisDocument = pDoc->GetThisDocument();

	pBoxCurrent = pThisDocument->GetCurrentBox();

	if (!pBoxCurrent)
		return FALSE;

	if (pBoxCurrent->Item->m_iType == ITEM_ART_TYPE)
		return (ArtItem *) pBoxCurrent->Item;
	else
		return NULL;
}

int CSwView::GetCurrentShading()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem || !pItem->nDot2Dot)
		return 0;

	return pItem->nDot2DotShadeButton;
}

void CSwView::SetCurrentShading(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->nDot2DotShadeButton = i;
	pItem->ReadTextBar();
	DoItemRedraw(0);
}

int CSwView::GetCurrentLines()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem || !pItem->nDot2Dot)
		return 0;

	return pItem->nDot2DotLinesButton;
}

void CSwView::SetCurrentLines(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->nDot2DotLinesButton & i) {
		pItem->nDot2DotLinesButton &= ~i;
	}
	else {
		pItem->nDot2DotLinesButton |= i;
	}
	pItem->ReadTextBar();
	DoItemRedraw(0);
}

void CSwView::SetAllCurrentLines(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->nDot2DotLinesButton = i;
	SetButtonGuidelinesSetting(i);

	pItem->ReadTextBar();
	DoItemRedraw(0);
}

int CSwView::GetCurrentArrows()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem || !pItem->nDot2Dot)
		return 0;

	return (pItem->nDot2DotArrowsButton);
}

void CSwView::SetCurrentArrows(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->nDot2DotArrowsButton != i) {
		pItem->nDot2DotArrowsButton = i;
		pItem->ReadTextBar();
		DoItemRedraw(0);
	}
}
int CSwView::GetCurrentOverlay()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem || !pItem->nDot2Dot)
		return 0;

	return (pItem->nDot2DotOverlayButton);
}

void CSwView::SetCurrentOverlay(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->nDot2DotOverlayButton != i) {
		pItem->nDot2DotOverlayButton = i;
		pItem->ReadTextBar();
		DoItemRedraw(0);
	}
}
BOOL CSwView::IsOverlayFont()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return FALSE;

	return ((pItem->m_iType == ITEM_TEXT_TYPE) && !(pItem->OverlayFile.IsEmpty()));
}

int CSwView::GetCurrentStartDot()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem) // || !pItem->nStartDot)
		return 0;
	
	return(pItem->nStartDot);
}

void CSwView::SetCurrentStartDot(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->nStartDot != i) {
		pItem->nStartDot = (i ? true : false);
		pItem->ReadTextBar();
		DoItemRedraw(0);
	}
}

int CSwView::GetCurrentDensity()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem || !pItem->nDot2Dot)
		return 0;

	return pItem->nDot2DotDensityButton;
}

void CSwView::SetCurrentDensity(int i)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->nDot2DotDensityButton = i;
	pItem->doDrawGlyf = i ? true : false;
	pItem->ReadTextBar();
	DoItemRedraw(0);
}


void CSwView::OnEditGoto()
{
	CGotoDlg dlg;
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();

	dlg.m_iPage = pThisDocument->Message(DOC_PAGE_CURRENT_GET, EMPTY_INT, &status);
	dlg.m_nPages = pThisDocument->Message(DOC_PAGE_TOTAL_GET, EMPTY_INT, &status);

	if (dlg.DoModal() == IDCANCEL)
		return;

	status = -1;
	pThisDocument->Message(DOC_PAGE_CURRENT_SET, dlg.m_iPage, &status);
	Invalidate(TRUE);	// wrw-OK
	SetFocus();
}

void CSwView::OnUpdateStatusPageOfPage(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;

	str.Format("Page %d of %d",
		pThisDocument->Message(DOC_PAGE_CURRENT_GET, EMPTY_INT, &status),
		pThisDocument->Message(DOC_PAGE_TOTAL_GET, EMPTY_INT, &status));

	pCmdUI->Enable(TRUE);
	pCmdUI->SetText(str);
}

void CSwView::OnUpdateStatusZoom(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;

	str.Format("%d%%",
		pThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status));

	pCmdUI->Enable(!CheckSelection());
	pCmdUI->SetText(str);
}


void CSwView::OnViewZoom()
{
	CZoomDlg dlg;
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();

	dlg.m_iZoom = pThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);

	if (dlg.DoModal() == IDCANCEL)
		return;

	if (dlg.m_DoDefZoom) {
		theApp.WriteProfileInt("Settings", "ZoomSetting", dlg.m_iZoom);
	}

	pThisDocument->Message(DOC_ZOOM_SET, dlg.m_iZoom, &status);
	Invalidate(TRUE);	// wrw-OK
	SetFocus();
}

void CSwView::OnFormatLetterdotdensity()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	CDnstyDlg dlg;

	dlg.m_iDensity = pItem->DensityFormat - DENSITY_NORMAL + 1;

	if (dlg.DoModal() == IDCANCEL)
		return;

	// The '- 1' because m_iDenisty will be 1 based instead of 0 based.
	pItem->UseTools(dlg.m_iDensity + DENSITY_NORMAL - 1, -1, -1);
	DoItemRedraw(0);
}

void CSwView::OnUpdateFormatLetterdotdensity(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
}

void CSwView::OnFormatLettershading()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	CShadeDlg dlg;

	dlg.m_iShading = pItem->ShadeFormat - SHADING_NORMAL + 1;

	if (dlg.DoModal() == IDCANCEL)
		return;

	// The '- 1' because m_iShading will be 1 based instead of 0 based.
	pItem->UseTools(-1, dlg.m_iShading + SHADING_NORMAL - 1, -1);
	DoItemRedraw(0);
}

void CSwView::OnUpdateFormatLettershading(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot());
}

void CSwView::OnFormatLetterstrokearrows()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	CArrowDlg dlg;

	dlg.m_iArrows = pItem->ArrowsFormat - ARROWS_NORMAL + 1;

	if (dlg.DoModal() == IDCANCEL)
		return;

	// The '- 1' because m_iArrows will be 1 based instead of 0 based.
	pItem->UseTools(-1, -1, dlg.m_iArrows + ARROWS_NORMAL - 1);
	DoItemRedraw(0);
}

void CSwView::OnUpdateFormatLetterstrokearrows(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsArrowedFont());
}

void CSwView::OnEditDelete()
{
	int 		status = ERROR;
	CSwDoc* 	pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	Document* pThisDocument = pDoc->GetThisDocument();
	pDoc->SetModifiedFlag(TRUE);

	// Save the current copy, since the delete goes through the copy code
	BBox  *pBoxPrevCopy = pCopyBBox;  
	pCopyBBox = NULL;

	if (pUndoBBox) {
		delete pUndoBBox;
		pUndoBBox=NULL;
	}
	BBox *pBoxCurrent = pThisDocument->GetCurrentBox();

	if (pBoxCurrent != NULL) {
		Module *null_module = NULL;
		pUndoBBox = (BBox *) pBoxCurrent->Message( ITEM_RETURN_COPY, null_module, &status);
	}

	pThisDocument->Message( DELETE_SELECTED_ITEM, EMPTY_INT, &status);
	Invalidate(TRUE);	// wrw-OK really should only invalidate the rect
	if (pCopyBBox) {
		delete pCopyBBox;
	}
	pCopyBBox = pBoxPrevCopy;
}

void CSwView::OnUpdateEditDelete(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!CheckSelection() && CanCopy());
}

void CSwView::OnUpdatePagePrev(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;
	int		iCurrent = pThisDocument->Message(DOC_PAGE_CURRENT_GET, EMPTY_INT, &status);

	pCmdUI->Enable(iCurrent > 1);
}

void CSwView::OnUpdatePageNext(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;
	int		iCurrent = pThisDocument->Message(DOC_PAGE_CURRENT_GET, EMPTY_INT, &status),
				iTotal = pThisDocument->Message( DOC_PAGE_TOTAL_GET, EMPTY_INT, &status);

	pCmdUI->Enable(iCurrent < iTotal);
}

void CSwView::OnUpdateZoomDec(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;
	int		iCurrent = pThisDocument->Message(DOC_ZOOM_GET, EMPTY_INT, &status);

	pCmdUI->Enable(!CheckSelection() && (iCurrent > MIN_ZOOM));
}

void CSwView::OnUpdateZoomInc(CCmdUI* pCmdUI)
{
	int 		status = ERROR;
	CSwDoc	*pDoc = GetDocument();
	Document	*pThisDocument = pDoc->GetThisDocument();
	CString	str;
	int		iCurrent = pThisDocument->Message(DOC_ZOOM_GET, EMPTY_INT, &status);

	pCmdUI->Enable(!CheckSelection() && (iCurrent < MAX_ZOOM));
}

void CSwView::OnFormatArt()
{
	ArtItem *pItem = GetCurrentArtItem();

	if (!pItem)
		return;

	int status;

	pItem->Message(ITEM_DIALOG_EDIT, NOT_EMPTY, &status);
	DoItemRedraw(0);
}

void CSwView::OnUpdateFormatArt(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(GetCurrentArtItem() != NULL);
}

void CSwView::OnMaintainProportions()
{
	ArtItem *pItem = GetCurrentArtItem();

	if (!pItem)
		return;

	int status;

	pItem->Message(ART_SET_PROPORTIONAL, 1, &status);
	DoItemRedraw(0);

}

void CSwView::OnUpdateMaintainProportions(CCmdUI* pCmdUI)
{
	int status;
	ArtItem *pItem = GetCurrentArtItem();

 	pCmdUI->Enable(pItem != NULL);
 	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->Message(ART_GET_PROPORTIONAL_SET, 0, &status));
	}

}


void CSwView::OnFormatFont()
{
	int status;
	TextItem *pItem = GetCurrentTextItem();

	if (pItem) {
		/* This actually calls the font dialog for the text item */
		if (pItem->Message(ITEM_DIALOG_EDIT, m_doFontDefault, &status) != 0) {
			CSwDoc 	*pDoc = GetDocument();
			if (pDoc) {
				pDoc->SetModifiedFlag(TRUE);
			}
			DoItemRedraw(0);	// redraw the box
		}
	}
	else {
		CFontDlg dlg;

		dlg.m_strFont = theApp.m_defFont;
		dlg.m_nFontIndex = defaultFont;
		dlg.m_nSize = theApp.m_defPoint;
		
		dlg.m_setAsDefault = m_doFontDefault;	/* Set as the default for everything */

		if (dlg.DoModal() != IDCANCEL) {
			char string[32];
			CComboBox *pcombobox = NULL;

			pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_POINT_COMBO);
			wsprintf(string,"%d", theApp.m_defPoint);

			if (pcombobox->FindString(0, string) == CB_ERR)
				pcombobox->SetWindowText(string);
			else
				pcombobox->SelectString(-1, string);

			pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_FONT_COMBO);
			wsprintf(string,"%s", theApp.m_defFont);
			pcombobox->SelectString(-1, string);

		}
	}
}

void CSwView::OnUpdateFormatFont(CCmdUI* pCmdUI)
{
	//pCmdUI->Enable(!CheckSelection() && (GetCurrentTextItem() != NULL));
	//let's leave the font dialog always valid so they can set the default font
	pCmdUI->Enable(TRUE);

}

void CSwView::OnUpdateDocSpell(CCmdUI* pCmdUI)
{
	if (theApp.m_isDemo != DEMO_ON) {
		pCmdUI->Enable(!CheckSelection() && (GetCurrentTextItem() != NULL));
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::OnKillFocus(CWnd* pNewWnd)
{
	CScrollView::OnKillFocus(pNewWnd);

	//ReleaseCapture();
	MousePending = FALSE;

#ifdef LATER_WRW_KILL	// Do we really want to do this on kill focus??? always???
	BBox		*pBoxCurrent;
	CSwDoc 	*pDoc = GetDocument();
	int		status;

	ASSERT_VALID(pDoc);

	Document *pThisDocument = pDoc->GetThisDocument();

	pBoxCurrent = pThisDocument->GetCurrentBox();

	if (!pBoxCurrent)
		return;

	pBoxCurrent->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);
#endif
}

void CSwView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// Turn off the cursor before the scroll
	int status;
	int flag = 0;
	int newVal=0;
	static int saveShow=-1;
	static int firstTime=-1;
	bool atEnd=false;
	
	if (saveShow == -1) {
		saveShow = theApp.m_showGraphics;
		theApp.m_showGraphics=false;
	}

	switch(nSBCode) {
		case SB_BOTTOM:  //Scroll to bottom.
			newVal = totalSize.cx-pageSize.cx;
			break;
		case SB_ENDSCROLL: //   End scroll.	This means they stopped scrolling
			theApp.m_showGraphics=saveShow ? true : false;
			saveShow=-1;
			firstTime=-1;
			atEnd=true;
			break;
		case SB_LINEDOWN:	//   Scroll one line down.
			newVal = lineSize.cx;
			break;
		case SB_LINEUP:	   //Scroll one line up.
			newVal = -lineSize.cx;
			break;
		case SB_PAGEDOWN:   //Scroll one page down.
			newVal = pageSize.cx;
			break;
		case SB_PAGEUP:		//  Scroll one page up.
			newVal = -pageSize.cx;
			break;
		case SB_THUMBPOSITION: //   Scroll to the absolute position. The current position is provided in nPos.
			newVal = nPos;
			flag++;
			break;
		case SB_THUMBTRACK:		// Drag scroll box to specified position. The current position is provided in nPos.
			newVal = nPos;
			flag++;
			break; 
		case SB_TOP:
			newVal = 0;
			break;
	}
	
	CPoint scroll_position, saveS;

	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	Document* pThisDocument = pDoc->GetThisDocument();

	if (!atEnd) {

		if ((firstTime == -1) && (pThisDocument != NULL)) {
			pThisDocument->Message( ART_CLEAR_IMAGE, 0, &status);
		}
		firstTime++;

		CClientDC *pDC = new CClientDC(this);
		pDoc->PrepareDC(pDC);
		pDoc->PrepareScrollView(this);

		pDC->SetMapMode(MM_TWIPS);
		scroll_position = GetDeviceScrollPosition();
		saveS = scroll_position;
		pDC->DPtoLP(&scroll_position);

		TextItem *pItem = GetCurrentTextItem();
		if (pItem != NULL) {
			pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
			pItem->DrawCursor(pDC, 0);	// turn off the cursor
			pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
		}

		// get original position and calc the new one
		if (flag) {
			saveS.x = newVal;
		}
		else {
			saveS.x += newVal;
		}
		scroll_position = saveS;
		pDC->DPtoLP(&scroll_position);

		// Tell any art boxes that we are scrolling
		if (pThisDocument != NULL) {
			pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);
		}

		doDrawCursor = -1;			// don't let update draw the cursor this round
		CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
		doDrawCursor = 0;

		pDC->SetMapMode(MM_TWIPS);
		scroll_position = GetDeviceScrollPosition();
		pDC->DPtoLP(&scroll_position);

		// This is just a double check to make sure we caclulated correctly
		scroll_position = GetDeviceScrollPosition();
		if (scroll_position != saveS) {
			pDC->DPtoLP(&scroll_position);
			if (pThisDocument != NULL) {
				pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);
			}
		}
		
		delete(pDC);
	}
	else {
		if (pThisDocument != NULL) {
			pThisDocument->Message( ART_SET_RELOAD, 0, &status);
		}
		Invalidate(TRUE);
	}

}

void CSwView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	// Turn off the cursor before the scroll
	int status;
	int flag = 0;
	int newVal=0;
	static int saveShow=-1;
	static int firstTime=-1;
	bool atEnd=false;

	if (saveShow == -1) {
		saveShow = theApp.m_showGraphics;
		theApp.m_showGraphics=false;
	}
	
	switch(nSBCode) {
		case SB_BOTTOM:  //Scroll to bottom.
			newVal = totalSize.cy-pageSize.cy;
			break;
		case SB_ENDSCROLL: //   End scroll.-- This means they stopped scrolling
			theApp.m_showGraphics=saveShow ? true : false;
			saveShow=-1;
			firstTime=-1;
			atEnd=true;
			//return;
			break;

		case SB_LINEDOWN:	//   Scroll one line down.
			newVal = lineSize.cy;
			break;
		case SB_LINEUP:	   //Scroll one line up.
			newVal = -lineSize.cy;
			break;
		case SB_PAGEDOWN:   //Scroll one page down.
			newVal = pageSize.cy;
			break;
		case SB_PAGEUP:		//  Scroll one page up.
			newVal = -pageSize.cy;
			break;
		case SB_THUMBPOSITION: //   Scroll to the absolute position. The current position is provided in nPos.
			newVal = nPos;
			flag++;
			break;
		case SB_THUMBTRACK:		// Drag scroll box to specified position. The current position is provided in nPos.
			newVal = nPos;
			flag++;
			break; 
		case SB_TOP:
			newVal = 0;
			break;
	}


	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// Tell any art boxes that we are scrolling
	Document* pThisDocument = pDoc->GetThisDocument();

	if (!atEnd) {

		CPoint scroll_position, saveS;

		if ((firstTime == -1) && (pThisDocument != NULL)) {
			pThisDocument->Message( ART_CLEAR_IMAGE, 0, &status);
		}
		
		firstTime++;

		CClientDC *pDC = new CClientDC(this);
		pDoc->PrepareDC(pDC);
		pDoc->PrepareScrollView(this);

		pDC->SetMapMode(MM_TWIPS);
		scroll_position = GetDeviceScrollPosition();
		saveS = scroll_position;
		pDC->DPtoLP(&scroll_position);
		
		TextItem *pItem = GetCurrentTextItem();
		if (pItem != NULL) {
			pItem->Message(TEXT_SET_SCROLL_POS, scroll_position, &status);
			pItem->DrawCursor(pDC, 0);	// turn off the cursor
			pItem->Message(TEXT_SET_SCROLL_POS, CPoint(0,0), &status);
			
		}

		// get original position and calc the new one
		if (flag) {
			saveS.y = newVal;
		}
		else {
			saveS.y += newVal;
			if (saveS.y < 0)
				saveS.y = 0;	// This can't go negative
		}

		scroll_position = saveS;
		pDC->DPtoLP(&scroll_position);


		if (pThisDocument != NULL) {
			pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);
		}

		doDrawCursor = -1;			// don't let update draw the cursor this round
		CScrollView::OnVScroll(nSBCode, nPos, pScrollBar);
		doDrawCursor = 0;

		// This is just a double check to make sure we caclulated correctly
		scroll_position = GetDeviceScrollPosition();
		if (scroll_position != saveS) {
			pDC->DPtoLP(&scroll_position);
			if (pThisDocument != NULL) {
				pThisDocument->Message( ART_SET_SCROLL, scroll_position, &status);
			}
		}
		
		delete(pDC);

	}
	else {
		if (pThisDocument != NULL) {
			pThisDocument->Message( ART_SET_RELOAD, 0, &status);
		}
		Invalidate(TRUE);
	}


}

static OPENFILENAME ofn;

void CSwView::OnOpenTemplate() 
{
	// TODO: Add your command handler code here
	// Change 'working' directory to the document directory...
	if( _chdir(TBasePath) == -1) {}
		//{ AfxMessageBox("Unable to change to 'images' directory!");}


	TCHAR szFileName[256] = "",
			szFileTitle[256] = "",
			szDir[256];


	memset(&ofn, 0, sizeof(ofn)); // initialize structure to 0/NULL
	if (!TBasePath.IsEmpty())
	{
		lstrcpy(szDir, TBasePath);
		ofn.lpstrInitialDir = szDir;
	}

	if (!TemplatePath.IsEmpty()) {
		lstrcpy(szFileName, TemplatePath);

		// Use current graphics directory
		lstrcpy(szDir, TemplatePath);
		ofn.lpstrInitialDir = szDir;
	}

	ofn.hInstance = AfxGetInstanceHandle();
	ofn.hwndOwner = AfxGetMainWnd()->m_hWnd;
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = (LPSTR)"Lesson Files (*.swl)\0*.swl\0\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = sizeof(szFileName);
	ofn.lpstrDefExt = "swl";
	ofn.lpstrTitle = "Select Lesson";
	ofn.lpstrFileTitle = (LPSTR) szFileTitle;
	ofn.nMaxFileTitle = sizeof(szFileTitle);
	ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

	if (::GetOpenFileName(&ofn) == 0) {
		if (!saveTemplatePath.IsEmpty()) {
			TemplatePath = saveTemplatePath;
			TBasePath = saveTBasePath;
		} 
		// Make sure we go back to normal document directory
		if (theApp.m_strDocPath.GetLength() > 0) {
			_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
			_chdir(theApp.m_strDocPath);
		}
		return;		// The user closed with out selection
	}

	// Send the message to open this file
	theApp.m_isTemplate = 1;	// Processing a template file
	theApp.OpenDocumentFile(szFileName); 
	theApp.m_isTemplate = 0;	// clear flag

	// Make sure we go back to normal document directory
	if (theApp.m_strDocPath.GetLength() > 0) {
		_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
		_chdir(theApp.m_strDocPath);
	}
	
	
	return;
	
}

void CSwView::OnUpdateOpenTemplate(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateNewPage(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateViewZoom(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateToolsSettings(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateNewArtItem(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateNewTextItem(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFileNew(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateFileClose(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateDeletePage(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::OnUpdateEditGoto(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable(!CheckSelection());
}

void CSwView::SetModified(void)
{
	CSwDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	pDoc->SetModifiedFlag(TRUE);
}

#ifndef IF_WE_WANT_THIS
void CSwView::OnKerningOn() 
{
	// TODO: Add your command handler code here
	int status;
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->Message(TEXT_SET_KERNING, TRUE, &status);
	if (status == OK) {
		DoItemRedraw(0);
	}
}

void CSwView::OnUpdateKerningOn(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	int status;

	TextItem *pItem = GetCurrentTextItem();

	if (!pItem) {
		pCmdUI->Enable(FALSE);
		return;
	}
	pCmdUI->Enable(TRUE);

	pCmdUI->SetCheck(pItem->Message(TEXT_GET_KERNING, 0, &status));
}


void CSwView::OnKerningOff() 
{

	// TODO: Add your command handler code here
	int status;
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	pItem->Message(TEXT_SET_KERNING, FALSE, &status);
	if (status == OK) {
		DoItemRedraw(0);
	}
}

void CSwView::OnUpdateKerningOff(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	int status;

	TextItem *pItem = GetCurrentTextItem();

	if (!pItem) {
		pCmdUI->Enable(FALSE);
		return;
	}

	pCmdUI->Enable(TRUE);

	pCmdUI->SetCheck(!pItem->Message(TEXT_GET_KERNING, 0, &status));


}
#endif

void CSwView::OnRedrawAll() 
{
	Invalidate(TRUE);
}

void CSwView::OnUpdateSelect(CCmdUI *pCmdUI) 
{
	CString strPage;
	TextItem *pItem = GetCurrentTextItem();

	if ((pItem && pItem->SelectionOn) || 
			(MouseCaptured == SEL_MAYBE) || (MouseCaptured == SEL_ON))
	   strPage.Format( "Select"); 
	else
		strPage.Format(""); 
	pCmdUI->SetText( strPage ); 
	pCmdUI->Enable(TRUE);

}
extern void doRegister(int);

void CSwView::OnRegister() 
{
	doRegister(1);
}

void CSwView::OnUpdateRegister(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((theApp.m_isDemo & (DEMO_ON|DEMO_HOPON)) ? TRUE : FALSE); 

	if (*swType == swDEM)
		pCmdUI->Enable(TRUE); 

}

void CSwView::OnHopUpgrade() 
{
	CHOPAboutDlg hopDlg;

	if (*swType == swHPD) {
		hopDlg.doUpgrade=1;
		hopDlg.DoModal();
		hopDlg.doUpgrade=0;
	}
	else if (*swType == swNAC) {
//		AfxMessageBox("Please Contact Startwrite to Get all sorts of good fonts");
		AfxMessageBox("For additional Manuscript and Cursive fonts...\n\
Please call Startwrite, Inc. \n\
1-888-WRITEABC\n\
1-888-974-8322\n\
For $9.95 + $5 S&H ($14.95)\n");

	}
}

void CSwView::OnUpdateHopUpgrade(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(((*swType == swHPD) || (*swType == swNAC)) ? TRUE : FALSE);
}

void CSwView::OnSpaceNormal() 
{
	TextItem *pItem = GetCurrentTextItem();
	int status=0;
	if (pItem == NULL)
		return;

	pItem->Message(TEXT_SET_SPACE_WIDTH, SPACENORMAL, &status);
	DoItemRedraw(0);
}

void CSwView::OnSpaceWide() 
{
	TextItem *pItem = GetCurrentTextItem();
	int status=0;
	if (pItem == NULL)
		return;

	pItem->Message(TEXT_SET_SPACE_WIDTH, SPACEWIDE, &status);
	DoItemRedraw(0);
}

void CSwView::OnUpdateSpaceNormal(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();

	pCmdUI->Enable(pItem ? TRUE : FALSE);
	if (pItem)
		pCmdUI->SetCheck((pItem->spaceWidth/BASE_SPACEWID) == SPACENORMAL);
}

void CSwView::OnUpdateSpaceWide(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();

	pCmdUI->Enable(pItem ? TRUE : FALSE);
	if (pItem)
		pCmdUI->SetCheck((pItem->spaceWidth/BASE_SPACEWID) == SPACEWIDE);
}

void CSwView::OnToolsSetspace() 
{

	swspace spaceDlg;
	int newVal;

	if (theApp.m_iDefaultSpacing == SPACEWIDE)
		spaceDlg.m_iSpace = 2;
	else if (theApp.m_iDefaultSpacing == SPACENORMAL)
		spaceDlg.m_iSpace = 1;
	else 
		spaceDlg.m_iSpace = 1;

	if (spaceDlg.DoModal() == IDCANCEL) {
		return;
	}

	if (spaceDlg.m_iSpace == 1) 
		newVal = SPACENORMAL;
	else if (spaceDlg.m_iSpace == 2) 
		newVal = SPACEWIDE;
	else 
		newVal = SPACENORMAL;


	theApp.setSpaceSettings(newVal);
}

void CSwView::OnUpdateToolsSetspace(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);
}

void CSwView::OnFormatYellowguide() 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		// pItem->setYellowGuide(!pItem->doYellowGuide);
		pItem->setYellowNextState();
		DoItemRedraw(0);
	}
}

void CSwView::OnUpdateFormatYellowguide(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->doYellowGuide ? 1 : 0);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::OnToolsDefaultsettingsFonts() 
{
	m_doFontDefault = 1;
	OnFormatFont();
	m_doFontDefault = 0;
}

void CSwView::OnUpdateToolsDefaultsettingsFonts(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(TRUE);
}

void CSwView::OnFormatAllowwindowsfonts() 
{
	theApp.m_allowWindowsFonts ^= 1;
	theApp.setWindowsFontDisplay(theApp.m_allowWindowsFonts);
	AfxMessageBox(IDS_WINDOWSFONTCHANGE);
}

void CSwView::OnUpdateFormatAllowwindowsfonts(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(theApp.m_allowWindowsFonts);	
}

void CSwView::OnFilePrint() 
{
	int ret;
	m_showPrintDialog = 1;
	CNumCopies cDlg;

	if (checkPrinterMultiple() == 0) {
		cDlg.m_numCopies = 1;
		ret = cDlg.DoModal();
		if (ret == IDOK) {
			for(unsigned int i=0; i < cDlg.m_numCopies; i++) {
				CScrollView::OnFilePrint();
				m_showPrintDialog = 0;
				Sleep(1000);	/* Sleep one second just to let the printer keep up a bit */
			}
		}
	}
	else {
		CScrollView::OnFilePrint();
	}
}

void CSwView::OnFileOpen() 
{
	TCHAR szFileName[256] = "",
			szFileTitle[256] = "",
			szDir[256],
			*sptr;

	// Change 'working' directory to the document directory...
	if (theApp.m_lastDocPath.IsEmpty()) {
		theApp.m_lastDocPath = theApp.m_strDocPath;
	}

	if( _chdir(theApp.m_lastDocPath) == -1) {}


	memset(&ofn, 0, sizeof(ofn)); // initialize structure to 0/NULL
	if (!theApp.m_lastDocPath.IsEmpty())	{
		lstrcpy(szDir, theApp.m_lastDocPath);
		ofn.lpstrInitialDir = szDir;
	}

	ofn.hInstance = AfxGetInstanceHandle();
	ofn.hwndOwner = AfxGetMainWnd()->m_hWnd;
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = (LPSTR)"Startwrite Files (*.swd)\0*.swl;*.swd\0\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = sizeof(szFileName);
	ofn.lpstrDefExt = "swd";
	ofn.lpstrTitle = "Select Startwrite Document";
	ofn.lpstrFileTitle = (LPSTR) szFileTitle;
	ofn.nMaxFileTitle = sizeof(szFileTitle);
	ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

	if (::GetOpenFileName(&ofn) == 0) {
		return;		// The user closed without selection
	}


	// Send the message to open this file
#ifdef _CRT_SECURE_NO_DEPRECATE
	strncpy(szFileTitle, szFileName, sizeof(szFileTitle));
#else
	strncpy_s(szFileTitle, sizeof(szFileTitle), szFileName, sizeof(szFileTitle));
#endif
	sptr = strrchr(szFileTitle, '\\');
	if (sptr != NULL) {
		*(sptr+1) = '\0';
		theApp.m_lastDocPath = szFileTitle;
	}

	theApp.OpenDocumentFile(szFileName); 

	return;
	
}

#ifdef LATER_wrw
void CSwView::OnFileSaveAs() 
{
	TCHAR szFileName[256] = "",
			szFileTitle[256] = "newswdoc.swd",
			szDir[256],
			*sptr;

	// Change 'working' directory to the document directory...
	if (theApp.m_lastDocPath.IsEmpty()) {
		theApp.m_lastDocPath = theApp.m_strDocPath;
	}

	if( _chdir(theApp.m_lastDocPath) == -1) {}


	memset(&ofn, 0, sizeof(ofn)); // initialize structure to 0/NULL
	if (!theApp.m_lastDocPath.IsEmpty())	{
		lstrcpy(szDir, theApp.m_lastDocPath);
		ofn.lpstrInitialDir = szDir;
	}
	ofn.hInstance = AfxGetInstanceHandle();
	ofn.hwndOwner = AfxGetMainWnd()->m_hWnd;
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = (LPSTR)"Startwrite Files (*.swd)\0*.swl;*.swd\0\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = sizeof(szFileName);
	ofn.lpstrDefExt = "swd";
	ofn.lpstrTitle = "Select Startwrite Document";
	ofn.lpstrFileTitle = (LPSTR) szFileTitle;
	ofn.nMaxFileTitle = sizeof(szFileTitle);
	ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

	if (::GetSaveFileName(&ofn) == 0) {
		return;		// The user closed without selection
	}


	// Send the message to open this file

	strncpy(szFileTitle, szFileName, sizeof(szFileTitle));
	sptr = strrchr(szFileTitle, '\\');
	if (sptr != NULL) {
		*(sptr+1) = '\0';
		theApp.m_lastDocPath = szFileTitle;
	}
	return;
}
#endif

void CSwView::OnUpdateUndo(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	
	pCmdUI->Enable(((pItem != NULL) || (pUndoBBox != NULL)));
	
}

void CSwView::OnEditUndo() 
{
	int status=0;

	TextItem *pItem = GetCurrentTextItem();
	
	if (pItem != NULL) {
		pItem->Message(TEXT_UNDO, 0, &status);
		DoItemRedraw(0);
	}
	else if (pUndoBBox != NULL) {
		CSwDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);

		Document* pThisDocument = pDoc->GetThisDocument();
		if (pThisDocument) {
			pThisDocument->Message( COPY_AND_PASTE_THIS_BOX, pUndoBBox, &status);
			delete pUndoBBox;
			pUndoBBox = NULL;
			Invalidate(TRUE);	// wrw- temp, until display is better (smarter)
		}
	}
}


BOOL CSwView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	nFlags; zDelta; pt;
	return(false);	
//	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}


void CSwView::OnFormatYellowhighlightGeneral() 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->setYellowGuide(1);
		DoItemRedraw(0);
	}
	
}

void CSwView::OnUpdateFormatYellowhighlightGeneral(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->doYellowGuide == 1);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
	
}

void CSwView::OnFormatYellowhighlightDescender() 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->setYellowGuide(2);
		DoItemRedraw(0);
	}
	
}

void CSwView::OnUpdateFormatYellowhighlightDescender(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->doYellowGuide == 2);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
	
}

void CSwView::OnFormatYellowhighlightOff() 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->setYellowGuide(0);
		DoItemRedraw(0);
	}
	
}

void CSwView::OnUpdateFormatYellowhighlightOff(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->doYellowGuide == 0);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
	
}

void CSwView::OnFormatThicknessNormal()
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		SetButtonGuideLineThicknessSetting(LINE_THICK_NORMAL);
		pItem->LedgerPenWidth = LINE_THICK_NORMAL;
		DoItemRedraw(0);
	}

}


void CSwView::OnUpdateFormatThicknessNormal(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->LedgerPenWidth == LINE_THICK_NORMAL);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}

}
void CSwView::OnFormatThicknessThin()
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		SetButtonGuideLineThicknessSetting(LINE_THICK_THICK);
		pItem->LedgerPenWidth = LINE_THICK_THICK;
		DoItemRedraw(0);
	}

}

void CSwView::OnUpdateFormatThicknessThin(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->LedgerPenWidth == LINE_THICK_THICK);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}

}
void CSwView::OnFormatThicknessMedium()
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		SetButtonGuideLineThicknessSetting(LINE_THICK_THICKER);
		pItem->LedgerPenWidth = LINE_THICK_THICKER;
		DoItemRedraw(0);
	}

}


void CSwView::OnUpdateFormatThicknessMedium(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->LedgerPenWidth == LINE_THICK_THICKER);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}

}
void CSwView::OnFormatThicknessThick()
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		SetButtonGuideLineThicknessSetting(LINE_THICK_THICKEST);
		pItem->LedgerPenWidth = LINE_THICK_THICKEST;
		DoItemRedraw(0);
	}

}


void CSwView::OnUpdateFormatThicknessThick(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->SetCheck(pItem->LedgerPenWidth == LINE_THICK_THICKEST);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}

}

void CSwView::OnEditSelectall() 
{
	int shiftStatus=0;

	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->Message( KEY_DOWN, TEXT_CURSOR_GOTO_BEGIN, &shiftStatus);
		shiftStatus = TEXT_EXTEND_SELECTION;	
		pItem->Message( KEY_DOWN, TEXT_CURSOR_GOTO_END, &shiftStatus);
		DoItemRedraw(0);
	}
}

void CSwView::OnUpdateEditSelectall(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::setFrameChecks(CCmdUI* pCmdUI, int flag)
{
	BBox		*pBoxCurrent;
	CSwDoc 	*pDoc = GetDocument();

	ASSERT_VALID(pDoc);

	Document *pThisDocument = pDoc->GetThisDocument();
	pBoxCurrent = pThisDocument->GetCurrentBox();
	if (pBoxCurrent != NULL) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck((pBoxCurrent->FrameInfo == flag) ? TRUE : FALSE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}



void CSwView::setFrameValues(int flag)
{
	BBox		*pBoxCurrent;
	CSwDoc 	*pDoc = GetDocument();
	int status;
	ASSERT_VALID(pDoc);

	Document *pThisDocument = pDoc->GetThisDocument();
	pBoxCurrent = pThisDocument->GetCurrentBox();
	if (pBoxCurrent != NULL) {
		pBoxCurrent->Message( BBOX_SET_FRAME, flag, &status);
		DoItemRedraw(0);
	}

}
void CSwView::OnBoxframeNone()
{
	setFrameValues(BBOX_FRAME_NONE);
}
void CSwView::OnUpdateBoxframeNone(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_NONE);
}
void CSwView::OnBoxframeSingle1()
{
	setFrameValues(BBOX_FRAME_SINGLE_1);
}

void CSwView::OnUpdateBoxframeSingle1(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_SINGLE_1);
}

void CSwView::OnBoxframeSingle2()
{
	setFrameValues(BBOX_FRAME_SINGLE_2);
}

void CSwView::OnUpdateBoxframeSingle2(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_SINGLE_2);
}
void CSwView::OnBoxframeSingle3()
{
	setFrameValues(BBOX_FRAME_SINGLE_3);
}

void CSwView::OnUpdateBoxframeSingle3(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_SINGLE_3);
}
void CSwView::OnBoxframeSingle6()
{
	setFrameValues(BBOX_FRAME_SINGLE_6);
}

void CSwView::OnUpdateBoxframeSingle6(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_SINGLE_6);
}




void CSwView::OnBoxframeDouble1()
{
	setFrameValues(BBOX_FRAME_DOUBLE_1);
}

void CSwView::OnUpdateBoxframeDouble1(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_DOUBLE_1);
}

void CSwView::OnBoxframeDouble2()
{
	setFrameValues(BBOX_FRAME_DOUBLE_2);
}

void CSwView::OnUpdateBoxframeDouble2(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_DOUBLE_2);
}
void CSwView::OnBoxframeDouble3()
{
	setFrameValues(BBOX_FRAME_DOUBLE_3);
}

void CSwView::OnUpdateBoxframeDouble3(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_DOUBLE_3);
}
void CSwView::OnBoxframeDouble6()
{
	setFrameValues(BBOX_FRAME_DOUBLE_6);
}

void CSwView::OnUpdateBoxframeDouble6(CCmdUI *pCmdUI)
{
	setFrameChecks(pCmdUI, BBOX_FRAME_DOUBLE_6);
}

void  CSwView::OnToolBarBtnDropDown(NMHDR* pNMHDR, LRESULT* pRes)
{
UNUSED_ALWAYS( pRes );
	if (pNMHDR->code == TBN_DROPDOWN)
	{
		CMenu menu;

		const NMTOOLBAR& nmtb = *(NMTOOLBAR*)pNMHDR;
		CEditBar *pbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_POWERBAR);														  
	// get location of button
		CRect rc;
		pbar->GetToolBarCtrl().GetRect(nmtb.iItem, rc);
		rc.bottom = 0;
		ClientToScreen(&rc);
		/*  ID_FORMAT_TEXTSHADING, 
		ID_FORMAT_LINEDENSITY,
		ID_FORMAT_TEXTARROWS,
		ID_FORMAT_STARTDOT,
		ID_FORMAT_OVERLAY,
		ID_CONNECTTHEDOTS,
		ID_SEPARATOR,
		ID_GUIDELINES,
		ID_GUIDELINES_SHADING,
		ID_GUIDELINES_THICKNESS,
		ID_FORMAT_YELLOWGUIDE,
		ID_SEPARATOR,
		ID_BIGSPACING,
		ID_SEPARATOR
	*/
		// call virtual function to display dropdown menu
		//return OnDropDownButtonInfo(nmtb, nmtb.iItem, rc);		
		switch(nmtb.iItem) {
			case ID_FORMAT_TEXTSHADING:
				VERIFY(menu.LoadMenu("IDR_TEXTSHADING"));
				break;
			case ID_FORMAT_LINEDENSITY:
				VERIFY(menu.LoadMenu("IDR_DOTDENSITY"));
				break;
			case ID_FORMAT_TEXTARROWS:
				VERIFY(menu.LoadMenu("IDR_STROKEARROWS"));
				break;
			case ID_FORMAT_STARTDOT:
				VERIFY(menu.LoadMenu("IDR_STARTDOT"));
				break;
			case ID_GUIDELINES:
				VERIFY(menu.LoadMenu("IDR_GUIDELINES"));
				break;
			case ID_GUIDELINES_THICKNESS:
				VERIFY(menu.LoadMenu("IDR_GUIDELINES_THICKNESS"));
				break;
			case ID_BIGSPACING:
				VERIFY(menu.LoadMenu("IDR_SPACE_WIDTH"));
				break;
			case ID_FORMAT_YELLOWGUIDE:
				VERIFY(menu.LoadMenu("IDR_YELLOW_HIGHLIGHT"));
				break;
			case ID__COLOREDSTROKES:
				VERIFY(menu.LoadMenu("IDR_COLOREDSTROKES"));
				break;
			case ID__DECISIONDOTS:
				VERIFY(menu.LoadMenu("IDR_DECISIONDOTS"));
				break;
			default:
				return;
		}
		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, rc.left, rc.bottom, AfxGetMainWnd(),&rc);	

     // return (FALSE);
      }
   // return FALSE;

}

void CSwView::OnUpdateGuidelines(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(GetCurrentStartDot() == 1);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}
void CSwView::OnFormatGuidelines()
{
	SetAllCurrentLines(GetButtonGuidelinesSetting());
}
void CSwView::OnFormatStartDot() 
{
	if (GetCurrentStartDot() == 1) {
		SetCurrentStartDot(0);
	}
	else {
		SetCurrentStartDot(1);
	}
}

void CSwView::OnUpdateStartDot(CCmdUI* pCmdUI) 
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(GetCurrentStartDot() == 1);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}

void CSwView::OnFormatTextlinesTMD()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_DES);
}

void CSwView::OnUpdateFormatTextlinesTMD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesTBD()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_BOT | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesTBD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_BOT | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesMBD()
{
	SetAllCurrentLines(GUIDELINE_MID | GUIDELINE_BOT | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesMBD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_MID | GUIDELINE_BOT | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesT()
{
	SetAllCurrentLines(GUIDELINE_TOP);
}
void CSwView::OnUpdateFormatTextlinesT(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP)) ? 1 : 0);
}

void CSwView::OnFormatTextlinesM()
{
	SetAllCurrentLines(GUIDELINE_MID);
}
void CSwView::OnUpdateFormatTextlinesM(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_MID)) ? 1 : 0);
}
void CSwView::OnFormatTextlinesB()
{
	SetAllCurrentLines(GUIDELINE_BOT);
}
void CSwView::OnUpdateFormatTextlinesB(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_BOT)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesD()
{
	SetAllCurrentLines(GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesTM()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_MID);
}
void CSwView::OnUpdateFormatTextlinesTM(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_MID)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesTB()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_BOT);
}
void CSwView::OnUpdateFormatTextlinesTB(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_BOT)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesTD()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesTD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesMB()
{
	SetAllCurrentLines(GUIDELINE_MID | GUIDELINE_BOT);
}
void CSwView::OnUpdateFormatTextlinesMB(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_MID | GUIDELINE_BOT)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesMD()
{
	SetAllCurrentLines(GUIDELINE_MID | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesMD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_MID | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesBD()
{
	SetAllCurrentLines(GUIDELINE_BOT | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesBD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_BOT | GUIDELINE_DES)) ? 1 : 0);
}	
void CSwView::OnFormatTextlinesAllOff()
{
	SetAllCurrentLines(0);
}
void CSwView::OnUpdateFormatTextlinesAllOff(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck(0);	
}	
void CSwView::OnFormatTextlinesTMBD()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_BOT | GUIDELINE_DES);
}
void CSwView::OnUpdateFormatTextlinesTMBD(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_BOT | GUIDELINE_DES)) ? 1 : 0);
}
void CSwView::OnFormatTextlinesTMB()
{
	SetAllCurrentLines(GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_BOT);
}
void CSwView::OnUpdateFormatTextlinesTMB(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(IsCurrentDotToDot() && !CheckSelection());
	pCmdUI->SetCheck((GetCurrentLines() == (GUIDELINE_TOP | GUIDELINE_MID | GUIDELINE_BOT)) ? 1 : 0);
}
void CSwView::OnFormatGuidelineThickness()
{
	SetButtonGuideLineThicknessSetting(GetButtonGuideLineThicknessSetting());
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
		pItem->LedgerPenWidth = GetButtonGuideLineThicknessSetting();
		DoItemRedraw(0);
	}
}
void CSwView::OnUpdateFormatGuidelineThickness(CCmdUI* pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();
	if (pItem != NULL) {
// KSL right now don't do anything		
		pCmdUI->SetCheck(0);	//pItem->LedgerPenWidth == LINE_THICK_NORMAL);
		pCmdUI->Enable(TRUE);
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}
void CSwView::OnFormatBigSpace()
{
}
void CSwView::OnUpdateFormatBigSpace(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(FALSE);
}

void CSwView::OnDoColoredStrokes()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->GetColoredStroke() == 2)
		pItem->SetColoredStroke(1);
	else 
		pItem->SetColoredStroke(2);
	pItem->ReadTextBar();
	DoItemRedraw(0);
}

void CSwView::OnUpdateDoColoredStrokes(CCmdUI *pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem) {
		pCmdUI->SetCheck(false);
		return;
	}

	pCmdUI->SetCheck((pItem->GetColoredStroke() == 2) ? true : false);

}
void CSwView::OnDoDecisionDots()
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem)
		return;

	if (pItem->GetFSFontSetting(DECISN_DOT_IND) == 2)
		pItem->SetFSFontSetting(DECISN_DOT_IND,1);
	else 
		pItem->SetFSFontSetting(DECISN_DOT_IND,2);
	pItem->ReadTextBar();
	DoItemRedraw(0);
}

void CSwView::OnUpdateDoDecisionDots(CCmdUI *pCmdUI)
{
	TextItem *pItem = GetCurrentTextItem();

	if (!pItem) {
		pCmdUI->SetCheck(false);
		return;
	}

	pCmdUI->SetCheck((pItem->GetFSFontSetting(DECISN_DOT_IND) == 2) ? true : false);

}
int CSwView::GetButtonDensitySetting()
{
	return nButtonDensity;
}
void CSwView::SetButtonDensitySetting(int i)
{
	nButtonDensity = i;
}

int CSwView::GetButtonShadingSetting()
{
	return nButtonShading;
}
void CSwView::SetButtonShadingSetting(int i)
{
	nButtonShading = i;
}

int CSwView::GetButtonGuidelinesSetting()
{
	return nButtonGuidelines;
}
void CSwView::SetButtonGuidelinesSetting(int i)
{
	nButtonGuidelines = i;
}

int CSwView::GetButtonYellowGuideSetting()
{
	return nButtonYellowGuide;
}
void CSwView::SetButtonYellowGuideSetting(int i)
{
	nButtonYellowGuide = i;
}
int CSwView::GetButtonGuideLineThicknessSetting()
{
	return nButtonGuidelineThickness;
}
void CSwView::SetButtonGuideLineThicknessSetting(int i)
{
	nButtonGuidelineThickness = i;
}
// splash.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSplash window

class CSplash : public CWnd
{
// Construction
public:
	CSplash();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CSplash();
	void StartSplash();
	void KillSplash();

protected:
	CString m_strClassName;
	time_t m_startTime;
	time_t m_endTime;
	
	void GetCenterWindowPos(RECT *lpRect);

protected:
	// Generated message map functions
	//{{AFX_MSG(CSplash)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GUIDESTYPEDLG_H__6045F41B_981A_418A_8D72_8AFF1BD8F99A__INCLUDED_)
#define AFX_GUIDESTYPEDLG_H__6045F41B_981A_418A_8D72_8AFF1BD8F99A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GuideStypeDlg.h : header file
//
#include "afxwin.h"
#include "colorcombo.h"

/////////////////////////////////////////////////////////////////////////////
// CGuideStypeDlg dialog

class CGuideStypeDlg : public CDialog
{
// Construction
public:
	CGuideStypeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGuideStypeDlg();
	COLORREF m_crGuideTop;
	COLORREF m_crGuideMiddle;
	COLORREF m_crGuideBase;
	COLORREF m_crGuideBottom;
	COLORREF * m_pCustomColors;

	BBox *m_pBox;
	TextItem *m_pTextItem;
	CRect m_rectPreview, m_rectBox;
	int m_LedgeThickness;

// Dialog Data
	//{{AFX_DATA(CGuideStypeDlg)
	enum { IDD = IDD_GUIDESTYLE };
	int		m_midType;
	int		m_topType;
	int		m_basType;
	int		m_botType;
	int		m_topThickness;
	int		m_midThickness;
	int		m_basThickness;
	int		m_botThickness;
	int		m_ThickRadio;
	int		fromMainPage;
	CString	m_fontName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGuideStypeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);
	virtual BOOL OnInitDialog();
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	afx_msg void OnLineChange();
	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()

private:
	CColorCombo m_ColorComboGuideTop;
	CColorCombo m_ColorComboGuideMiddle;
	CColorCombo m_ColorComboGuideBase;
	CColorCombo m_ColorComboGuideBottom;
public:
	afx_msg void OnBnClickedRadioThickNormal();
	int m_ThicknessRadioVal;
	afx_msg void OnBnClickedRadioThickThick();
	void doThicknessUpdate(int flag);
	afx_msg void OnBnClickedRadioThickThicker();
	afx_msg void OnBnClickedRadioThickThickest();
	bool m_setGuidelinesAsDefault;
	CButton m_SetGuidesAsDefault;
	afx_msg void OnOk();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GUIDESTYPEDLG_H__6045F41B_981A_418A_8D72_8AFF1BD8F99A__INCLUDED_)

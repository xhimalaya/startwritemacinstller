#if !defined(AFX_SWSERIAL_H__2DD7F7C4_F6A9_11D2_B60A_444553540000__INCLUDED_)
#define AFX_SWSERIAL_H__2DD7F7C4_F6A9_11D2_B60A_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// swSerial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// swSerial dialog

class swSerial : public CDialog
{
// Construction
public:
	swSerial(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(swSerial)
	enum { IDD = IDD_SERIAL };
	CString	m_SerialNumber;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(swSerial)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(swSerial)
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWSERIAL_H__2DD7F7C4_F6A9_11D2_B60A_444553540000__INCLUDED_)

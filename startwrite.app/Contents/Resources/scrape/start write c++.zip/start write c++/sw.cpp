// sw.cpp : Defines the class behaviors for the application.
//
//#define DO_TRIAL_FILE

#include "stdafx.h"
#include "commctrl.h"

#include <direct.h>
#include "resource.h"
#include "swabout.h"
#include "swAboutDemoDlg.h"
#include "swAboutHOPDlg.h"
#include "sw.h"
#include "swOneTry.h"
#include "swOneTryOxford.h"
#ifdef DO_TRIAL_FILE
#include "trialhelp.h"
#endif

#include "mainfrm.h"
#include "swdoc.h"
#include "swview.h"
#include "splash.h"
#include "RegGenerator.h"

#include "SetDlg.h"
#include "SetDlg50.h"
#include "mapi.h"
#include "artdisp.h"
#include "miscutil.h"
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>

#ifdef SW_IMAGN
#ifdef TOOL_NONE
#undef TOOL_NONE
#endif
#include "imagn.h"
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

long artIdValue = BASE_ARTID;
#ifdef DO_TRIAL_FILE
static CTrialHelp *trialDlg=NULL;
#endif

extern int CreateHashBuf(unsigned char *dest, char *ipptr, char *rnum, int versionFlag);
extern int OneTryCheck();

// swHOP, swDEM, swREL, swHPD swSHR swOXF swRL5 swOXD, swNAC, swNAU swUPG6
static unsigned char SWTypeArr[8] = {'W', 'R', 'W', 'R', 'E', swREL, 0};
unsigned char *swType = &SWTypeArr[5];
unsigned char originalType=0;
bool doRunUKVersion=false;		// Set page size and spelling dictionaries based on this

/////////////////////////////////////////////////////////////////////////////
// CSwApp

BEGIN_MESSAGE_MAP(CSwApp, CWinApp)
	//{{AFX_MSG_MAP(CSwApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_TOOLS_SETTINGS, OnToolsSettings50)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSwApp construction

extern int ValidateReg(int *flag, int *testFlag);

CSwApp::CSwApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	if ((*swType == swHOP) || (*swType == swHPD)) {	// Default for HOP and HOP Demo
		m_defFont = "HOP Manuscript";
	}
	else if (*swType == swSHR) {
		m_defFont = "Pre-cursive Upright";
	}
	else if ((*swType == swOXF) || (*swType == swOXD)) {
		m_defFont = "VIC Print";
	}
	else if ((*swType == swNAC) || (*swType == swNAU)) {
		m_defFont = "New American Cursive";
	}
	else {
		m_defFont = "Manuscript";
	}

	m_defPoint = 48;
	if ((*swType == swREL) || (*swType == swRL5) || (*swType == swHOP) || (*swType == swSHR) || (*swType == swOXF) || (*swType == swNAC) || (*swType == swNAU)) {
		m_isDemo = DEMO_OFF;
		m_wasDemo = FALSE;
	}
	else if (*swType == swHPD) {
		m_isDemo = DEMO_HOPON;
		m_wasDemo = FALSE;
	}
	else {
		m_isDemo = DEMO_ON;
		m_wasDemo = TRUE;	/* Remember this started as demo */
	}

	m_daysLeft = 0;
	m_doThick=0;
	m_allowWindowsFonts = (*swType == swSHR) ? 0 : 1;
	m_showGraphics=true;
	m_DoPowerReload = true;
	m_crDefaultCustomPalette[0] = RGB(252, 252, 0);// The legacy custom yellow default for yellow area
	m_crDefaultCustomPalette[1] = RGB(255, 165, 0); // Legacy custom orange default for Decision Dots
	for (int i = 2; i < 16; i++) {
		m_crDefaultCustomPalette[i] = RGB(255, 255, 255);
	}
	theApp.shutdownTime=-1;
	theApp.isNetwork = false;
	theApp.isLabPack = false;
	theApp.isCorporateVersion=false;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSwApp object

CSwApp theApp;

void CSwApp::SetRegistration(char *email, char *name, char *key, bool get60)
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2];
	CString tStr;
	struct tm newtime={0};
	time_t long_time;

	/* If they did moneyback guarentee */
	lstrcpyn(buf, "WrwEnd2", sizeof(buf));

	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		RegCloseKey(hkAssociate);	// Close the top key
		
		//tStr.LoadString((get50 == false) ? IDS_REGISTRATION2 : IDS_REGISTRATION4);	  // SWregKeyPostMB : SWregKeyPostMB50
		tStr.LoadString((get60 == false) ? IDS_REGISTRATION4 : IDS_REGISTRATION6);	  // SWregKeyPostMB50 : SWregKeyPostMB60
	}
	else {
		//tStr.LoadString((get50 == false) ? IDS_REGISTRATION : IDS_REGISTRATION3);	// SWregkey : SWregkey50
		tStr.LoadString((get60 == false) ? IDS_REGISTRATION3 : IDS_REGISTRATION5);	// SWregkey50 : SWregkey60
	}

	lstrcpyn(buf, tStr, sizeof(buf));

	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			
		tStr.LoadString(IDS_REG_EMAIL);

		lstrcpyn(buf, tStr, sizeof(buf));

		tStr.Empty();
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_SZ,
				(const unsigned char *)email,
    			strlen(email)+1);

		tStr.LoadString(IDS_REG_NAME);
		lstrcpyn(buf, tStr, sizeof(buf));

		tStr.Empty();
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_SZ,
				(const unsigned char *)name,
    			strlen(name)+1);

		tStr.LoadString(IDS_REG_KEY);
		lstrcpyn(buf, tStr, sizeof(buf));

		tStr.Empty();
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_SZ,
				(const unsigned char *)key,
    			strlen(key)+1);


		RegCloseKey(hkAssociate);
	}

	lstrcpyn(buf, "wrwtw_one", sizeof(buf));

	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			
		time( &long_time );					/* Get time as long integer. */
		localtime_s(&newtime, &long_time);	/* Convert to local time. */	

		_snprintf_s(buf, sizeof(buf),_TRUNCATE,"%4d%03d:%02d%02d%02d", 
			newtime.tm_year+1900, newtime.tm_yday,
			newtime.tm_hour,  newtime.tm_min, newtime.tm_sec);

		RegSetValueEx(hkAssociate,
	    		"", /*  (const char *)buf,*/
				0,
    			REG_SZ,
				(const unsigned char *)buf,
    			strlen(buf)+1);

		RegCloseKey(hkAssociate);
	}
}

int CSwApp::SetSerialNumber(char *regString)
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2];
	int retval;

	lstrcpyn(buf, "Software\\Startwrite60\\SW60SerialNumber", sizeof(buf));

	if( (retval = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition)) == ERROR_SUCCESS) {
			
		lstrcpyn(buf, regString, sizeof(buf));

		RegSetValueEx(hkAssociate,
	    		"sw60b45", /*  (const char *)buf,*/
				0,
    			REG_SZ,
				(const unsigned char *)buf,
    			strlen(buf)+1);
		
		RegCloseKey(hkAssociate);
	}
	else {
		lstrcpyn(buf, "Software\\Startwrite60\\SW60SerialNumber", sizeof(buf));

		if( (retval = RegCreateKeyEx(HKEY_CURRENT_USER,
		    		(const char *)buf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
		    		&hkAssociate,
					&disposition)) == ERROR_SUCCESS) {
				
			lstrcpyn(buf, regString, sizeof(buf));

			RegSetValueEx(hkAssociate,
	    			"sw60b45", /*  (const char *)buf,*/
					0,
    				REG_SZ,
					(const unsigned char *)buf,
    				strlen(buf)+1);
			
			RegCloseKey(hkAssociate);
		}
		else {
			_snprintf(buf, sizeof(buf), "Error Saving Serial Number %d", retval);
			AfxMessageBox(buf);
			return(-1);
		}
	}
	return(0);
}


int CSwApp::GetSerialNumber(char *regString)
{
	HKEY hkAssociate;
	char buf[128];
	DWORD dType;
	DWORD dSize;
	*regString = '\0';
	int retv=1;

	// For Safety, look in file first. in case there is registry issues
	if (theApp.m_SerialNumber[0] != '\0') {
	// CHeck the config file for registration value
		lstrcpyn(regString, theApp.m_SerialNumber, 15);
		retv = 0;
	}
	else {
		lstrcpyn(buf, "Software\\Startwrite60\\SW60SerialNumber", sizeof(buf));
		if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
			(const char *)buf,
			0,
			KEY_ALL_ACCESS,
			&hkAssociate) == ERROR_SUCCESS) {
			
			dType = REG_SZ;	// set defaults
			dSize = 128;

			if (RegQueryValueEx(hkAssociate,
					(const char *)"sw60b45",
					0,
					&dType,
					(unsigned char *)regString,
					&dSize) == ERROR_SUCCESS) {

						if (strlen(regString) == 14) {
							retv = 0;
						}
			}
			else if (RegQueryValueEx(hkAssociate,
					(const char *)"Serial",
					0,
					&dType,
					(unsigned char *)regString,
					&dSize) == ERROR_SUCCESS) {

						if (strlen(regString) == 14) {
							retv = 0;
						}
			}
			RegCloseKey(hkAssociate);
		}
		else {
			lstrcpyn(buf, "Software\\Startwrite60\\SW60SerialNumber", sizeof(buf));
			if (RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
				&hkAssociate) == ERROR_SUCCESS) {
				
				dType = REG_SZ;	// set defaults
				dSize = 128;

				if (RegQueryValueEx(hkAssociate,
						(const char *)"sw60b45",
						0,
						&dType,
						(unsigned char *)regString,
						&dSize) == ERROR_SUCCESS) {

							if (strlen(regString) == 14) {
								retv = 0;
							}
				}
				else if (RegQueryValueEx(hkAssociate,
						(const char *)"Serial",
						0,
						&dType,
						(unsigned char *)regString,
						&dSize) == ERROR_SUCCESS) {

							if (strlen(regString) == 14) {
								retv = 0;
							}
				}
				RegCloseKey(hkAssociate);
			}
//			else {
//				AfxMessageBox("Unable to find registration");
//			}
		}
	}
	return(retv);
}




void  CSwApp::CheckDemoTime()
{
	HKEY hkAssociate;
	char buf[255];
	char tbuf[32];
	CString tStr;
	struct tm newtime;
	time_t long_time;
	int yearTest, dayTest, timeTest;
	DWORD dType;
	DWORD dSize;

	lstrcpyn(buf, "wrwtw_one", sizeof(buf));

	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		// The key and time are already set -- check the time
		dType = REG_SZ;	// set defaults
		dSize = 255;
		buf[0] = 0;
		if (RegQueryValueEx(hkAssociate,
			"",
			0,
			&dType,
			(unsigned char *)buf,
			&dSize) == ERROR_SUCCESS) {

			RegCloseKey(hkAssociate);	// Close the top key
		
			time( &long_time );					/* Get time as long integer. */			
			localtime_s(&newtime, &long_time);	/* Convert to local time. */

#ifdef _CRT_SECURE_NO_DEPRECATE	
			strncpy(tbuf, buf, 4);	// get the year			
#else
			strncpy_s(tbuf, sizeof(tbuf), buf, 4);	// get the year			
#endif
			tbuf[4] = 0;
			yearTest = atoi(tbuf);
#ifdef _CRT_SECURE_NO_DEPRECATE	
			strncpy(tbuf, &buf[4], 3);	// days 
#else
			strncpy_s(tbuf, sizeof(tbuf),&buf[4], 3);	// days 
#endif
			tbuf[3] = 0;
			dayTest = atoi(tbuf);

			if (yearTest != (newtime.tm_year+1900)) {
				timeTest = 366 - dayTest;
				dayTest = 366-dayTest;
			}
			else {
				timeTest = 0;
			}

			timeTest += dayTest;
					
			if ((timeTest+30) < newtime.tm_yday) {
				m_wasDemo = FALSE;	/* this will remove the de-activate button */
			}
		}
	}
}


int OneTryCheck()
{
	HKEY hkAssociate;
	char buf[32];
	DWORD disposition;
	CString tStr;
	struct tm newtime;
	time_t long_time;

	strcpy_s(buf, sizeof(buf), "wrwtw_two");
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		RegCloseKey(hkAssociate);	// Close the top key

		return(DEMO_ON);
	}
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
	    	(const char *)buf,
			0,
			"",
			REG_OPTION_NON_VOLATILE,
			KEY_ALL_ACCESS,
			NULL,
	    	&hkAssociate,
			&disposition) == ERROR_SUCCESS) {
			
		time( &long_time );					/* Get time as long integer. */		
		localtime_s(&newtime,&long_time);	/* Convert to local time. */
#ifdef _CRT_SECURE_NO_DEPRECATE	
		_snprintf(buf, sizeof(buf), "MFC%4d%03d:%02d%02d%02dY2KComp", 
				newtime.tm_year+1900, newtime.tm_yday,
				newtime.tm_hour,  newtime.tm_min, newtime.tm_sec);
#else
		_snprintf_s(buf, sizeof(buf), sizeof(buf), "MFC%4d%03d:%02d%02d%02dY2KComp", 
				newtime.tm_year+1900, newtime.tm_yday,
				newtime.tm_hour,  newtime.tm_min, newtime.tm_sec);
#endif

		RegSetValueEx(hkAssociate,
	    		"", /*  (const char *)buf,*/
				0,
    			REG_SZ,
				(const unsigned char *)buf,
    			strlen(buf)+1);

		RegCloseKey(hkAssociate);
	}
	
	// Set Timer so this will close after 24 hours.
	theApp.shutdownTime = GetTickCount() + (60*60*72*1000);	// 24hours
	return(DEMO_OFF);	/* allow the single try */
}


void CSwApp::GetRegistration(char *email, char *name, char *key, int *flag, bool get60)
{
	HKEY hkAssociate;
	char buf[128];
	char buf2[24];
	CString tStr;
	DWORD dType;
	DWORD dSize;

	*email = '\0';
	*name = '\0';
	*key = '\0';

	strcpy_s(buf, sizeof(buf), "WrwEnd2");
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {
		RegCloseKey(hkAssociate);	// Close the top key
		
		//tStr.LoadString( (get50 == false) ? IDS_REGISTRATION2 : IDS_REGISTRATION4);
		tStr.LoadString( (get60 == false) ? IDS_REGISTRATION4 : IDS_REGISTRATION6);
		*flag = 1;
	}
	else {
		//tStr.LoadString( (get50 == false) ? IDS_REGISTRATION : IDS_REGISTRATION3);
		tStr.LoadString( (get60 == false) ? IDS_REGISTRATION3 : IDS_REGISTRATION5);
		*flag = 0;
	}

	// Open the Settings subkey
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
			(const char *)buf,
			0,
			KEY_ALL_ACCESS,
	        &hkAssociate) == ERROR_SUCCESS) {
			
		dType = REG_SZ;	// set defaults
		dSize = 128;

		tStr.LoadString(IDS_REG_EMAIL);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)email,
				&dSize) == ERROR_SUCCESS) {
		}

		dType = REG_SZ;	// set defaults
		dSize = 128;
		tStr.LoadString(IDS_REG_NAME);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)name,
				&dSize) == ERROR_SUCCESS) {
		}
	
		dType = REG_SZ;	// set defaults
		dSize = 128;
		tStr.LoadString(IDS_REG_KEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)key,
				&dSize) == ERROR_SUCCESS) {

		}
			
		RegCloseKey(hkAssociate);
	}

	if (*flag) {
		if (get60 == false) {		
			tStr.LoadString(IDS_REGISTRATION3);
		}
		else {
			tStr.LoadString(IDS_REGISTRATION5);
		}

		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (RegOpenKeyEx(HKEY_CURRENT_USER,
			(const char *)buf,
			0,
			KEY_ALL_ACCESS,
	        &hkAssociate) == ERROR_SUCCESS) {
			
			dType = REG_SZ;	// set defaults
			dSize = 128;
			tStr.LoadString(IDS_REG_KEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)buf2,
				&dSize) == ERROR_SUCCESS) {

			}

			if ((*key == '\0') && (*email == '\0')) {
				strncpy_s(key, sizeof(key), buf2, sizeof(buf2));				
			}
			else if (!strncmp(buf2, key, sizeof(buf2))) {
				*key = 0;	/* Invalidate return key */
			}
		
			RegCloseKey(hkAssociate);
		}
	}


}


void CSwApp::swSetSettings(CString strDocPath, CString strArtPath, 
							int newDensity,
							int newShading,
							int newArrows,
							int newStartDot,
							int newKerning,
							int newSpacing,
							int newShadeType,
							int allowWindowsFonts)
{
	HKEY hkAssociate;
	DWORD disposition, valSet;
	char buf[_MAX_PATH * 2];
	CString tStr;

	m_strDocPath = strDocPath;
	m_strArtPath = strArtPath;
	m_iDefaultDensity = newDensity;
	m_iDefaultShading = newShading;
	m_iDefaultArrows = newArrows;
	m_iDefaultStartDot= newStartDot;
	m_iDefaultKernMode = newKerning;
	m_iDefaultShadeType = newShadeType;
	if (newSpacing != -1) {
		m_iDefaultSpacing = newSpacing;
	}
	m_allowWindowsFonts = allowWindowsFonts;

	tStr.LoadString((*swType != swSHR) ? IDS_DOCKEY: IDS_DOCKEY_SHR);
	strcpy(buf, tStr);
	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
		strcpy_s((char *)buf, sizeof(buf), strDocPath);
		RegSetValueEx(hkAssociate,
	    		"",
				0,
    			REG_SZ,                 
    			(const unsigned char *)buf,
    			strlen((const char *)buf)+1);

		RegCloseKey(hkAssociate);
	}

	tStr.LoadString((*swType != swSHR) ? IDS_VERSION : IDS_VERSION_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			
		tStr.LoadString(IDS_VERSIONSTR);
		strcpy_s((char *)buf, sizeof(buf), tStr);
		tStr.Empty();
		RegSetValueEx(hkAssociate,
	    		"",
				0,
    			REG_SZ,                 
    			(const unsigned char *)buf,
    			strlen((const char *)buf)+1);

		RegCloseKey(hkAssociate);
	}

	
	
	tStr.LoadString((*swType != swSHR) ? IDS_ARTKEY : IDS_ARTKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
		strcpy_s((char *)buf, sizeof(buf), strArtPath);
		RegSetValueEx(hkAssociate,
	    		"",
				0,
    			REG_SZ,                 
    			(const unsigned char *)buf,
    			strlen((const char *)buf)+1);

		RegCloseKey(hkAssociate);
	}

	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			
		tStr.LoadString(IDS_DENSITYKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newDensity;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		tStr.LoadString(IDS_SHADINGKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newShading;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		tStr.LoadString(IDS_SHADETYPEKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newShadeType;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		tStr.LoadString(IDS_ARROWSKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newArrows;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

//startdot
		tStr.LoadString(IDS_STARTDOTKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newStartDot;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		tStr.LoadString(IDS_KERNINGMODEKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newKerning;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		if (newSpacing != -1) {
			tStr.LoadString(IDS_WORDSPACEKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			valSet = newSpacing;
			RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
	   			sizeof(DWORD));
		}

		tStr.LoadString(IDS_ALLOWWINDOWSFONTS);
		strcpy_s(buf, sizeof(buf), tStr);

		tStr.Empty();
		valSet = allowWindowsFonts;
		RegSetValueEx(hkAssociate,
	    	(const char *)buf,
			0,
    		REG_DWORD,
			(const unsigned char *)&valSet,
	   		sizeof(DWORD));
		
		RegCloseKey(hkAssociate);
	}
}

void CSwApp::setSpaceSettings(int newSpacing)
{
	HKEY hkAssociate;
	DWORD disposition, valSet;
	char buf[_MAX_PATH * 2];
	CString tStr;
	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();

	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

		tStr.LoadString(IDS_WORDSPACEKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newSpacing;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		RegCloseKey(hkAssociate);
	
		// Set the default for the rest of the session too
		m_iDefaultSpacing = newSpacing;
	}
}

void CSwApp::setColorSettings(int item, COLORREF newVal)
{
	HKEY hkAssociate;
	DWORD disposition, valSet;
	char buf[_MAX_PATH * 2];
	CString tStr;
	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);

	lstrcpyn(buf, tStr, sizeof(buf));
	tStr.Empty();

	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

				switch(item) {
					case ID_FORMAT_TEXTARROWS:
						tStr.LoadString(IDS_TEXTARROWCOLOR);
						m_iDefaultArrowColor = newVal;
						break;
					case ID_FORMAT_STARTDOT:
						tStr.LoadString(IDS_STARTDOTCOLOR);
						m_iDefaultStartDotColor = newVal;
						break;
					case ID_FORMAT_OVERLAY:
						tStr.LoadString(IDS_OVERLAYCOLOR);
						m_iDefaultOverlayColor = newVal;
						break;
					case ID__DECISIONDOTS:
						tStr.LoadString(IDS_DECISIONDDOTCOLOR);
						m_iDefaultDecisionDotColor = newVal;
						break;
					case ID_CONNECTTHEDOTS:
						tStr.LoadString(IDS_CONNECTDOTCOLOR);
						m_iDefaultConnectDotColor = newVal;
						break;
					case ID__COLOREDSTROKES+11:
						tStr.LoadString(IDS_STROKEONE_COLOR);
						m_iDefaultColorStrokeOne = newVal;
						break;
					case ID__COLOREDSTROKES+12:
						tStr.LoadString(IDS_STROKETWO_COLOR);
						m_iDefaultColorStrokeTwo = newVal;
						break;
					case ID__COLOREDSTROKES+13:
						tStr.LoadString(IDS_STROKETHREE_COLOR);
						m_iDefaultColorStrokeThree = newVal;
						break;
					case ID__COLOREDSTROKES+14:
						tStr.LoadString(IDS_STROKEFOUR_COLOR);
						m_iDefaultColorStrokeFour = newVal;
						break;
					case IDC_GRP_COLOR_TOPAREA:
						tStr.LoadString(IDS_COLORTOPAREA);
						m_iDefaultColorTopArea = newVal;
						break;
					case IDC_GRP_COLOR_BOTTOMAREA:
						tStr.LoadString(IDS_COLORMIDDLEAREA);
						m_iDefaultColorMiddleArea = newVal;
						break;
					case IDC_GRP_COLOR_DESCENDERAREA:
						tStr.LoadString(IDS_COLORBOTAREA);
						m_iDefaultColorBottomArea = newVal;
						break;
					case IDC_SHADINGTOP_ON_YES:
						tStr.LoadString(IDS_TOPAREA_ON);
						m_TopAreaColorOn = newVal ? TRUE : FALSE;
						break;
					case IDC_SHADINGBOTTOM_ON_YES:
						tStr.LoadString(IDS_MIDDLEAREA_ON);
						m_MidAreaColorOn = newVal ? TRUE : FALSE;
						break;
					case IDC_SHADINGDESCENDER_ON_YES:
						tStr.LoadString(IDS_BOTTOMAREA_ON);
						m_BotAreaColorOn = newVal ? TRUE : FALSE;
						break;

					default:
						tStr.Empty();
						break;
				}
				if (tStr.GetLength() != 0) {
					lstrcpyn(buf, tStr, sizeof(buf));
					tStr.Empty();
					valSet = newVal;
					RegSetValueEx(hkAssociate,
	    				(const char *)buf,
						0,
    					REG_DWORD,
						(const unsigned char *)&valSet,
    					sizeof(DWORD));
				}
	
		RegCloseKey(hkAssociate);
	}
}



void CSwApp::setWindowsFontDisplay(int newFontDisplayFlag)
{
	HKEY hkAssociate;
	DWORD disposition, valSet;
	char buf[_MAX_PATH * 2];
	CString tStr;
	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();

	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

		tStr.LoadString(IDS_ALLOWWINDOWSFONTS);
		strcpy_s(buf, sizeof(buf),tStr);
		tStr.Empty();
		valSet = newFontDisplayFlag;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		RegCloseKey(hkAssociate);
	
		// Set the default for the rest of the session too
		m_allowWindowsFonts = newFontDisplayFlag;
	}
}

void CSwApp::DoCancelProduct()
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[128];

	strcpy_s(buf, sizeof(buf), "WrwEnd2");
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		"",
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hkAssociate,
		&disposition) == ERROR_SUCCESS) {

		strncpy_s(buf, sizeof(buf), "Microsoft Windows Product Y2K Flag Verification 2 - do not remove", sizeof(buf));

		// Set the value
		RegSetValueEx(hkAssociate,
	    		(const char *)"", //set the default value
				0,
    			REG_SZ,                 
    			(const unsigned char *)buf,
    			strlen((const char *)buf));
		
		RegCloseKey(hkAssociate);	// Close the top key
	}

}

#ifdef Needed_before
int CSwApp::checkStartTime()
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2];
	char fbuf[32];
	char tbuf[48];
	char saveHash[48];
	CString tStr;
	DWORD dType;
	DWORD dSize;
	struct tm *newtime;
	time_t long_time;
	int timeTest=0;
	int yearTest=0;
	int dayTest=0;
	int retVal=DEMO_ON;

	time( &long_time );                /* Get time as long integer. */
	newtime = localtime( &long_time ); /* Convert to local time. */

	strcpy(buf, "WrwEnd");
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		RegCloseKey(hkAssociate);	// Close the top key

		return(DEMO_ON);	// If this is there, demo time is up
	}

	/* Check if the Money Back Cancel Product has happened */
	strcpy(buf, "WrwEnd2");
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		RegCloseKey(hkAssociate);	// Close the top key

		return(DEMO_ON);	// If this is there, demo time is up
	}

	strcpy(buf, "WrwBegin");
	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)buf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {

		// The key and time are already set -- check the time
		dType = REG_SZ;	// set defaults
		dSize = 255;
		buf[0] = 0;
		if (RegQueryValueEx(hkAssociate,
			"",
			0,
			&dType,
			(unsigned char *)buf,
			&dSize) == ERROR_SUCCESS) {

			// Get the hash saved from original install	
			CreateHashBuf((unsigned char *)saveHash, (char *)buf, "9797", 0);

			strncpy(tbuf, buf, 4);	// get the year
			tbuf[4] = 0;
			yearTest = atoi(tbuf);

			strncpy(tbuf, &buf[4], 3);	// days 
			tbuf[3] = 0;
			dayTest = atoi(tbuf);

			if (yearTest != (newtime->tm_year+1900)) {
				timeTest = 366 - dayTest;
				dayTest = 366-dayTest;
			}
			else {
				timeTest = 0;
			}

			timeTest += dayTest;
				
			if ((timeTest+DEMO_TIME) > newtime->tm_yday) {
				m_daysLeft = DEMO_TIME - (newtime->tm_yday - timeTest);
				retVal = DEMO_OFF;
			}
			else {
				RegCloseKey(hkAssociate);	// Close the top key
				strcpy(buf, "WrwEnd");
				if( RegCreateKeyEx(HKEY_CURRENT_USER,
					(const char *)buf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
					&hkAssociate,
					&disposition) == ERROR_SUCCESS) {

					// We created the flag that disallows setting the clock back 
					// Once this is set, it will fail.
					// The key and time are already set -- check the time
					buf[0] = 0;
					strcpy(buf, "Microsoft Windows Product Y2K Flag Verification");
				// Set the value
					RegSetValueEx(hkAssociate,
	    					(const char *)"", //set the default value
							0,
    						REG_SZ,                 
    						(const unsigned char *)buf,
    						strlen((const char *)buf)+1);
				}
			}
			RegCloseKey(hkAssociate);	// Close the top key
		}
			
		strcpy(buf, "WECoyote");

		if ((retVal == DEMO_OFF) && 
			RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
			    &hkAssociate) == ERROR_SUCCESS) {

				// The key and time are already set -- check the time
			dType = REG_SZ;	// set defaults
			dSize = 255;
			buf[0] = 0;
			if (RegQueryValueEx(hkAssociate,
					"",
					0,
					&dType,
					(unsigned char *)buf,
					&dSize) == ERROR_SUCCESS) {

				// If the hash has been messed with, just go to demo.
				retVal = strcmp(saveHash, buf) ? DEMO_ON : DEMO_OFF;
			}

			RegCloseKey(hkAssociate);	// Close the top key
		}
		else {
			retVal = DEMO_ON;
		}
	}
	else if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

		retVal = DEMO_OFF;	// We are just starting -- set to full demo
		m_daysLeft = DEMO_TIME;

		// Get the current time in this format "yyyyddd:hrmnsc"
        _snprintf(fbuf, sizeof(buf), "%4d%03d:%02d%02d%02d", 
				newtime->tm_year+1900, newtime->tm_yday,
				newtime->tm_hour,  newtime->tm_min, newtime->tm_sec);
		
		// Set the value
		RegSetValueEx(hkAssociate,
	    		(const char *)"", //set the default value
				0,
    			REG_SZ,                 
    			(const unsigned char *)fbuf,
    			strlen((const char *)fbuf)+1);
		
		RegCloseKey(hkAssociate);
		
		CreateHashBuf((unsigned char *)tbuf, (char *)fbuf, "9797", 0);

		strcpy(buf, "WECoyote");
		if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

			
			RegSetValueEx(hkAssociate,
		    	(const char *)"", //set the default value
				0,
    			REG_SZ,                 
    			(const unsigned char *)tbuf,
    			strlen((const char *)tbuf)+1);
		
			RegCloseKey(hkAssociate);
		
		}
	
	}

	return(retVal);
}
#endif

void CSwApp::setFontSettings(CString newFontStr, int newPointSize)
{
	HKEY hkAssociate;
	DWORD disposition, valSet;
	char buf[_MAX_PATH * 2];
	char fbuf[32];
	CString tStr;

	m_defPoint = newPointSize;
	m_defFont = newFontStr;

	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    	(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
		    	&hkAssociate,
				&disposition) == ERROR_SUCCESS) {

		tStr.LoadString(IDS_DEFPOINTKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		valSet = newPointSize;
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_DWORD,
				(const unsigned char *)&valSet,
    			sizeof(DWORD));

		tStr.LoadString(IDS_DEFFONTKEY);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		strcpy_s(fbuf, sizeof(fbuf), newFontStr);
		RegSetValueEx(hkAssociate,
	    		(const char *)buf,
				0,
    			REG_SZ,                 
    			(const unsigned char *)fbuf,
    			strlen((const char *)fbuf)+1);
		
		RegCloseKey(hkAssociate);
	}
	else {
		RegCloseKey(hkAssociate);	// Close the top key
	}

}

extern FONTINFO szFonts[];
void CSwApp::swSetLedgerSettings(FONTINFO *fontPtr)
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2];
	char tbuf[_MAX_PATH * 2];
	CString tStr;
	int saveValues[17];

	tStr.LoadString((*swType != swSHR) ? IDS_MAINKEY: IDS_MAINKEY_SHR);
	lstrcpyn(buf, tStr, sizeof(buf));
	tStr.Empty();
	if (strlen(buf) + 20 > sizeof(buf)) {
		AfxMessageBox("Insufficient space");
		return;
	}

	for(int i=0; szFonts[i].f_fontname[0]; i++) {
		if (szFonts[i].f_filename[0] == '\0') {
			continue;	// don't save non-dot fonts in registry
		}
		if (szFonts[i].f_MathFlag) {
			continue;	// no need to do math fonts
		}

		strcpy_s(tbuf, sizeof(tbuf),buf);
		strcat_s(tbuf, sizeof(tbuf),"\\fonts\\");
		strcat_s(tbuf, sizeof(tbuf), szFonts[i].f_fontname);
		if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    		(const char *)tbuf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
		    		&hkAssociate,
					&disposition) == ERROR_SUCCESS) {
				
						if (fontPtr != NULL) {
							szFonts[i].f_fontLine = saveValues[0] = fontPtr->f_fontLine;		/* Combination lines for this font */
							szFonts[i].f_TopLine = saveValues[1] = fontPtr->f_TopLine;		/* SWLINE_ON, SWLINESOLID, SWLINE_DOTTED */
							szFonts[i].f_MidLine = saveValues[2] = fontPtr->f_MidLine;
							szFonts[i].f_BasLine = saveValues[3] = fontPtr->f_BasLine;
							szFonts[i].f_BotLine = saveValues[4] = fontPtr->f_BotLine;
							szFonts[i].f_TopColor = saveValues[5] = fontPtr->f_TopColor;		/* 0,0,0xFF (Blue) */
							szFonts[i].f_MidColor = saveValues[6] = fontPtr->f_MidColor;		/* 0xFF,0,0  (red) */
							szFonts[i].f_BasColor = saveValues[7] = fontPtr->f_BasColor;		/* 0,0,0xFF (Blue) */
							szFonts[i].f_BotColor = saveValues[8] = fontPtr->f_BotColor;		/* -1 for no line  */
							szFonts[i].f_TopColorInd = saveValues[9] = fontPtr->f_TopColorInd;
							szFonts[i].f_MidColorInd = saveValues[10] = fontPtr->f_MidColorInd;		/* 0xFF,0,0  (red) */
							szFonts[i].f_BasColorInd = saveValues[11] = fontPtr->f_BasColorInd;		/* 0,0,0xFF (Blue) */
							szFonts[i].f_BotColorInd = saveValues[12] = fontPtr->f_BotColorInd;		/* -1 for no line  */
							szFonts[i].f_TopThickness = saveValues[13] = fontPtr->f_TopThickness;
							szFonts[i].f_MidThickness = saveValues[14] = fontPtr->f_MidThickness;
							szFonts[i].f_BasThickness = saveValues[15] = fontPtr->f_BasThickness;
							szFonts[i].f_BotThickness = saveValues[16] = fontPtr->f_BotThickness;
						}
						else {
							saveValues[0] = szFonts[i].f_fontLine;		/* Combination lines for this font */
							saveValues[1] = szFonts[i].f_TopLine;		/* SWLINE_ON, SWLINESOLID, SWLINE_DOTTED */
							saveValues[2] = szFonts[i].f_MidLine;
							saveValues[3] = szFonts[i].f_BasLine;
							saveValues[4] = szFonts[i].f_BotLine;
							saveValues[5] = szFonts[i].f_TopColor;		/* 0,0,0xFF (Blue) */
							saveValues[6] = szFonts[i].f_MidColor;		/* 0xFF,0,0  (red) */
							saveValues[7] = szFonts[i].f_BasColor;		/* 0,0,0xFF (Blue) */
							saveValues[8] = szFonts[i].f_BotColor;		/* -1 for no line  */
							saveValues[9] = szFonts[i].f_TopColorInd;
							saveValues[10] = szFonts[i].f_MidColorInd;		/* 0xFF,0,0  (red) */
							saveValues[11] = szFonts[i].f_BasColorInd;		/* 0,0,0xFF (Blue) */
							saveValues[12] = szFonts[i].f_BotColorInd;		/* -1 for no line  */
							saveValues[13] = szFonts[i].f_TopThickness;
							saveValues[14] = szFonts[i].f_MidThickness;
							saveValues[15] = szFonts[i].f_BasThickness;
							saveValues[16] = szFonts[i].f_BotThickness;
						}
			RegSetValueEx(hkAssociate,
	    			"",
					0,
    				REG_BINARY,                 
    				(const unsigned char *)saveValues,
    				sizeof(saveValues));

			RegCloseKey(hkAssociate);
		}
	}
}

void CSwApp::swGetLedgerSettings()
{
	HKEY hkAssociate;
	char buf[_MAX_PATH * 2];
	char tbuf[_MAX_PATH * 2];
	CString tStr;
	DWORD dType;
	DWORD dSize;
	int rc, i;
	int newValues[17]={0};

	tStr.LoadString((*swType != swSHR) ? IDS_MAINKEY : IDS_MAINKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();

	if ((rc=RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
		        &hkAssociate)) == ERROR_SUCCESS) {

		for(i=0; szFonts[i].f_fontname[0]; i++) {
			strcpy_s(tbuf, sizeof(tbuf),buf);
			strcat_s(tbuf, sizeof(tbuf), "\\fonts\\");
			strcat_s(tbuf, sizeof(tbuf), szFonts[i].f_fontname);

			if (RegOpenKeyEx(HKEY_CURRENT_USER,
					(const char *)tbuf,
					0,
					KEY_ALL_ACCESS,
					&hkAssociate) == ERROR_SUCCESS) {

				dType = REG_BINARY;	// set defaults
				dSize = sizeof(newValues);
				if (RegQueryValueEx(hkAssociate,
					"",
					0,
					&dType,
					(unsigned char *)newValues,
					&dSize) == ERROR_SUCCESS) {

				}
				RegCloseKey(hkAssociate);	// Close the top key

				szFonts[i].f_fontLine = newValues[0];
				szFonts[i].f_TopLine = (char)newValues[1];
				szFonts[i].f_MidLine = (char)newValues[2];
				szFonts[i].f_BasLine = (char)newValues[3];
				szFonts[i].f_BotLine = (char)newValues[4];
				szFonts[i].f_TopColor = newValues[5];
				szFonts[i].f_MidColor = newValues[6];
				szFonts[i].f_BasColor = newValues[7];
				szFonts[i].f_BotColor = newValues[8];
				szFonts[i].f_TopColorInd = newValues[9];
				szFonts[i].f_MidColorInd = newValues[10];
				szFonts[i].f_BasColorInd = newValues[11];
				szFonts[i].f_BotColorInd = newValues[12];
				szFonts[i].f_TopThickness = newValues[13];
				szFonts[i].f_MidThickness = newValues[14];
				szFonts[i].f_BasThickness = newValues[15];
				szFonts[i].f_BotThickness = newValues[16];
			}
		}
	}
}

void CSwApp::swSetDefaultCustomPalette()
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2];
	CString tStr;
	tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);

	lstrcpyn(buf, tStr, sizeof(buf));
	tStr.Empty();

	if( RegCreateKeyEx(HKEY_CURRENT_USER,
	(const char *)buf,
	0,
	"",
	REG_OPTION_NON_VOLATILE,
	KEY_ALL_ACCESS,
	NULL,
	&hkAssociate,
	&disposition) == ERROR_SUCCESS) {
		tStr.LoadString(IDS_DEFCUSTOMPALETTEKEY);
		if (tStr.GetLength() != 0) {
			lstrcpyn(buf, tStr, sizeof(buf));
			tStr.Empty();
			RegSetValueEx(hkAssociate,
				(const char *)buf,
				0,
				REG_BINARY,                 
				(const unsigned char *)&theApp.m_crDefaultCustomPalette[0],
				sizeof(theApp.m_crDefaultCustomPalette));
		}
		RegCloseKey(hkAssociate);
	}
}

void CSwApp::swGetSettings(char *szName, CString strArtPath, CString strDocPath)
{
	HKEY hkAssociate;
	DWORD disposition;
	char buf[_MAX_PATH * 2], *sptr;
	CString tStr;
	DWORD dType;
	DWORD dSize;
	DWORD CurVal;
	int buildNew = TRUE;
	int rebuildUpdate=FALSE;
	int rc;

	tStr.LoadString((*swType != swSHR) ? IDS_MAINKEY : IDS_MAINKEY_SHR);
	strcpy_s(buf, sizeof(buf), tStr);
	tStr.Empty();

	// try startwrite60 
	if ((rc=RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
				&hkAssociate)) != ERROR_SUCCESS) {
			
			// failed, try to find startwrite50
			tStr.LoadString((*swType != swSHR) ? IDS_MAINKEY_50 : IDS_MAINKEY_SHR);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			rc = 0;
			if ((rc=RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
				&hkAssociate)) == ERROR_SUCCESS) {
					buildNew = FALSE;	// just read the old stuff
					rebuildUpdate = TRUE;
					// No settings available
			}
			
	}

	if (rc == ERROR_SUCCESS) {
		RegCloseKey(hkAssociate);	// Close the top key
		tStr.LoadString((*swType != swSHR) ? IDS_VERSION : IDS_VERSION_SHR);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();

		if (rebuildUpdate) {
			sptr = strchr(buf, '6');
			if (sptr != NULL) {
				*sptr = '5';
			}
		}

		if (RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
		        &hkAssociate) == ERROR_SUCCESS) {
#ifdef FREEZ
			buildNew = FALSE;		// We must have written here, use what is here
#else
			dType = REG_SZ;	// set defaults
			dSize = 255;
			buf[0] = 0;
			if (RegQueryValueEx(hkAssociate,
				"",
				0,
				&dType,
				(unsigned char *)buf,
				&dSize) == ERROR_SUCCESS) {

				tStr.LoadString(IDS_VERSIONSTR);
				if (!strcmp(tStr, buf)) {
					buildNew = FALSE;
				}
				tStr.Empty();
			}
#endif
			RegCloseKey(hkAssociate);	// Close the top key
		}
	}

	if (buildNew == FALSE) {		// just read in what is there
		int ret;

		// Open the ArtPath Key
		tStr.LoadString((*swType != swSHR) ? IDS_ARTKEY : IDS_ARTKEY_SHR);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();

		// we can fail on the art path
		// we want them to loko at the new install
		//if (rebuildUpdate) {
		//	sptr = strchr(buf, '6');
		//	if (sptr != NULL) {
		//		*sptr = '5';
		//	}
		//}
		if (RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
		        &hkAssociate) == ERROR_SUCCESS) {


			dType = REG_SZ;	// set defaults
			dSize = 255;
			buf[0] = 0;
			if (RegQueryValueEx(hkAssociate,
				"",
				0,
				&dType,
				(unsigned char *)buf,
				&dSize) == ERROR_SUCCESS) {

				m_strArtPath = buf;

				ret = m_strArtPath.GetLength();
				if ((ret > 0) && (m_strArtPath.GetAt(ret-1) != '\\')) {
					m_strArtPath += '\\';
				}
			}
			RegCloseKey(hkAssociate);	// Close the top key
		}

		// Open the DocPath Key
		tStr.LoadString((*swType != swSHR) ? IDS_DOCKEY: IDS_DOCKEY_SHR);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (rebuildUpdate) {
			sptr = strchr(buf, '6');
			if (sptr != NULL) {
				*sptr = '5';
			}
		}
		if (RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
		        &hkAssociate) == ERROR_SUCCESS) {

			dType = REG_SZ;	// set defaults
			dSize = 255;
			buf[0] = 0;
			if (RegQueryValueEx(hkAssociate,
				"",
				0,
				&dType,
				(unsigned char *)buf,
				&dSize) == ERROR_SUCCESS) {

				m_strDocPath = buf;
				ret = m_strDocPath.GetLength();
				if ((ret > 0) && (m_strDocPath.GetAt(ret-1) != '\\')) {
					m_strDocPath += '\\';
				}
				m_lastDocPath = m_strDocPath;
			}
			RegCloseKey(hkAssociate);	// Close the top key
		}

		// Open the Settings subkey
		tStr.LoadString((*swType != swSHR) ? IDS_SETTINGSKEY: IDS_SETTINGSKEY_SHR);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if (rebuildUpdate) {
			sptr = strchr(buf, '6');
			if (sptr != NULL) {
				*sptr = '5';
			}
		}
		if (RegOpenKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				KEY_ALL_ACCESS,
		        &hkAssociate) == ERROR_SUCCESS) {
			
			dType = REG_DWORD;	// set defaults
			dSize = sizeof(DWORD);

			tStr.LoadString(IDS_DENSITYKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultDensity = CurVal;		// Set density
			}

			tStr.LoadString(IDS_SHADINGKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultShading = CurVal;		// Set Shading
			}
	
			tStr.LoadString(IDS_SHADETYPEKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultShadeType = CurVal;		// Set Shading
			}

			
			tStr.LoadString(IDS_ARROWSKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultArrows = CurVal;		// Set Arrows
			}

			tStr.LoadString(IDS_STARTDOTKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultStartDot = CurVal;		// Set StartDot
			}

			tStr.LoadString(IDS_KERNINGMODEKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_iDefaultKernMode = CurVal;		// Set kerning mode
			}

			tStr.LoadString(IDS_WORDSPACEKEY);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				if (CurVal == 2 /*SPACE_NARROW*/) {
					CurVal = SPACENORMAL;
				}
				m_iDefaultSpacing = CurVal;		// Set word spacing
			}

			tStr.LoadString(IDS_TEXTARROWCOLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultArrowColor = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultArrowColor = RGB(0,0,0);
			}

			tStr.LoadString(IDS_STARTDOTCOLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultStartDotColor = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultStartDotColor = RGB(255, 0, 0);
			}

			tStr.LoadString(IDS_OVERLAYCOLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultOverlayColor = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultOverlayColor = RGB(0,0,0);
			}

			tStr.LoadString(IDS_DECISIONDDOTCOLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultDecisionDotColor = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultDecisionDotColor = RGB(0,0,255);
			}


			tStr.LoadString(IDS_CONNECTDOTCOLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultConnectDotColor = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultConnectDotColor = RGB(0,0,0);
			}

			tStr.LoadString(IDS_STROKEONE_COLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorStrokeOne = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultColorStrokeOne = RGB(255,0,0);
			}

			tStr.LoadString(IDS_STROKETWO_COLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorStrokeTwo = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultColorStrokeTwo = RGB(0,0,255);
			}

			tStr.LoadString(IDS_STROKETHREE_COLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorStrokeThree = CurVal;		
			}
			else {
				m_iDefaultColorStrokeThree = RGB(0,190,0);
			}

			tStr.LoadString(IDS_STROKEFOUR_COLOR);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorStrokeFour = CurVal;		
			}
			else {
				m_iDefaultColorStrokeFour = RGB(128,0,128);
			}

			tStr.LoadString(IDS_COLORTOPAREA);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorTopArea = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultColorTopArea = RGB(201, 252, 201);
			}

			tStr.LoadString(IDS_COLORMIDDLEAREA);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorMiddleArea = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultColorMiddleArea = RGB(255, 255, 185);
			}

			tStr.LoadString(IDS_COLORBOTAREA);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
				m_iDefaultColorBottomArea = CurVal;		// Set word spacing
			}
			else {
				m_iDefaultColorBottomArea = RGB(255,234,255);
			}


			tStr.LoadString(IDS_TOPAREA_ON);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
					m_TopAreaColorOn = CurVal ? TRUE : FALSE;
			}
			else {
				m_TopAreaColorOn = FALSE;
			}

			tStr.LoadString(IDS_MIDDLEAREA_ON);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
					m_MidAreaColorOn = CurVal ? TRUE : FALSE;
			}
			else {
				m_MidAreaColorOn = FALSE;
			}

			tStr.LoadString(IDS_BOTTOMAREA_ON);
			strcpy_s(buf, sizeof(buf),tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {
					m_BotAreaColorOn = CurVal ? TRUE : FALSE;
			}
			else {
				m_BotAreaColorOn = FALSE;
			}

			tStr.LoadString(IDS_ALLOWWINDOWSFONTS);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_allowWindowsFonts = CurVal;		// Set density
			}

			tStr.LoadString(IDS_DEFFONTKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			dType = REG_SZ;	// set defaults
			dSize = 255;
			if (RegQueryValueEx(hkAssociate,
				buf,
				0,
				&dType,
				(unsigned char *)buf,
				&dSize) == ERROR_SUCCESS) {

				m_defFont = buf;

			}


			tStr.LoadString(IDS_DEFPOINTKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
				(const char *)buf,
				0,
				&dType,
				(unsigned char *)&CurVal,
				&dSize) == ERROR_SUCCESS) {

				m_defPoint = CurVal;		// Set Shading
			}
			
			COLORREF defCustomPalette[16];
			tStr.LoadString(IDS_DEFCUSTOMPALETTEKEY);
			strcpy_s(buf, sizeof(buf), tStr);
			dType = REG_BINARY;	// set defaults
			dSize = sizeof(defCustomPalette);
			tStr.Empty();
			if (RegQueryValueEx(hkAssociate,
			(const char *)buf,
			0,
			&dType,
			(unsigned char *)&defCustomPalette[0],
			&dSize) == ERROR_SUCCESS) {
				// Set default custom palette
				for (int i=0; i<16; i++) {
					theApp.m_crDefaultCustomPalette[i] = defCustomPalette[i];
				}
			}

			RegCloseKey(hkAssociate);
		}
		
	}
	if ((rebuildUpdate == TRUE) || (buildNew == TRUE))	{ // On Failure -build the settings
		tStr.LoadString((*swType != swSHR) ? IDS_COMMANDKEY : IDS_COMMANDKEY_SHR);
		strcpy_s(buf, sizeof(buf), tStr);
		tStr.Empty();
		if( RegCreateKeyEx(HKEY_CURRENT_USER,
				(const char *)buf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
				&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			//!!!strcat_s(szName, _MAX_PATH, " %1");		
			strcat_s(szName, _MAX_PATH, " \"%1\"");
			RegSetValueEx(hkAssociate,
	    		(const char *)"",
				0,
    			REG_SZ,                 
    			(const unsigned char *)szName,		    
    			strlen(szName)+1);

			RegCloseKey(hkAssociate);

			tStr.LoadString(IDS_EXTENSIONSTR);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    		(const char *)buf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
	    			&hkAssociate,
					&disposition) == ERROR_SUCCESS) {

				tStr.LoadString(IDS_EXECUTIBLESTR);
				strcpy_s(buf, sizeof(buf), tStr);
				tStr.Empty();
				RegSetValueEx(hkAssociate,
    				"",
					0,
    				REG_SZ,                
    				(const unsigned char *)buf,		   
    				strlen(buf)+1);

				RegCloseKey(hkAssociate);
    		}
			tStr.LoadString(IDS_LESSONEXTENSIONSTR);
			strcpy_s(buf, sizeof(buf), tStr);
			tStr.Empty();
			if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    		(const char *)buf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
	    			&hkAssociate,
					&disposition) == ERROR_SUCCESS) {

				tStr.LoadString(IDS_EXECUTIBLESTR);
				strcpy_s(buf, sizeof(buf), tStr);
				tStr.Empty();
				RegSetValueEx(hkAssociate,
    				"",
					0,
    				REG_SZ,                
    				(const unsigned char *)buf,		   
    				strlen(buf)+1);

				RegCloseKey(hkAssociate);
    		}

			// Set new 6.0 Defaults
			m_iDefaultArrowColor = RGB(0,0,0);
			m_iDefaultStartDotColor = RGB(255, 0, 0);
			m_iDefaultOverlayColor = RGB(0,0,0);
			m_iDefaultDecisionDotColor = RGB(0,0,255);
			m_iDefaultConnectDotColor = RGB(0,0,0);
			m_iDefaultColorStrokeOne = RGB(255,0,0);
			m_iDefaultColorStrokeTwo = RGB(0,0,255);
			m_iDefaultColorStrokeThree = RGB(0,190,0);
			m_iDefaultColorStrokeFour = RGB(128,0,128);
			m_iDefaultColorTopArea = RGB(201, 252, 201);
			m_iDefaultColorMiddleArea = RGB(255, 255, 185);
			m_iDefaultColorBottomArea = RGB(255,234,255);
			m_TopAreaColorOn = FALSE;
			m_MidAreaColorOn = FALSE;
			m_BotAreaColorOn = FALSE;
			
			swSetSettings(strDocPath, strArtPath, 1 , 4, 1 , (((*swType == swOXF) || (*swType == swOXD)) ? 0xF : 4), 1, 
				SPACENORMAL, 1, ((*swType == swSHR) ? 0 : 1) );
		}	
	}
}

static OPENFILENAME ofn;
int getStartWriteProgram(CString &newFilename)
{
	TCHAR szFileName[256] = "",
			szFileTitle[256] = "",
			szDir[256],
			*sptr;


	//if( _chdir(newFilename) == -1) {}

	memset(&ofn, 0, sizeof(ofn)); // initialize structure to 0/NULL
	if (!newFilename.IsEmpty())	{
		lstrcpy(szDir, newFilename);
		ofn.lpstrInitialDir = szDir;
	}

	ofn.hInstance = AfxGetInstanceHandle();
	//ofn.hwndOwner = AfxGetMainWnd()->m_hWnd;
	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = (LPSTR)"Startwrite Program \0*.swl;Startwrite50.exe\0\0";
	ofn.lpstrFile = szFileName;
	ofn.nMaxFile = sizeof(szFileName);
	ofn.lpstrDefExt = "swd";
	ofn.lpstrTitle = "Select Startwrite5.0 Progam";
	ofn.lpstrFileTitle = (LPSTR) szFileTitle;
	ofn.nMaxFileTitle = sizeof(szFileTitle);
	ofn.Flags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

	if (::GetOpenFileName(&ofn) == 0) {
		return(-1);		// The user closed without selection
	}

	strncpy_s(szFileTitle, sizeof(szFileTitle), szFileName, sizeof(szFileTitle));
	sptr = strrchr(szFileTitle, '\\');
	if (sptr != NULL) {
		*(sptr+1) = '\0';
		newFilename = szFileTitle;
	}

	return(0);
}

// return true if there was a valid 4.x version out there
//
bool CSwApp::CheckForOldVersion()
{
	char tBuf[255];
	int flag, testFlag;
	bool setConfirmation = false;
	HKEY hkAssociate;
	DWORD disposition;
	struct tm newtime={0};
	time_t long_time;
	CString tStr;
	DWORD dType;
	DWORD dSize;

	/* Check for the key that says we already found the old version */
	strcpy_s(tBuf, sizeof(tBuf), "wrwktjbsa");

	if (RegOpenKeyEx(HKEY_CURRENT_USER,
		(const char *)tBuf,
		0,
		KEY_ALL_ACCESS,
		&hkAssociate) == ERROR_SUCCESS) {
		
		RegCloseKey(hkAssociate);
		return true;

	}

	testFlag = 5;	/* Look for 5.0 validation */
	if (ValidateReg(&flag, &testFlag) == DEMO_OFF) {
		setConfirmation = true;
	}
	else {
		char *tptr;

		tStr.LoadString(IDS_COMMANDKEY);
		strcpy_s(tBuf, sizeof(tBuf), tStr);
		tStr.Empty();
		
		tptr = strstr(tBuf, "60");
		if (tptr != NULL) {
			*tptr++ = '5';
		}
		if (RegOpenKeyEx(HKEY_CURRENT_USER,
			(const char *)tBuf,
			0,
			KEY_ALL_ACCESS,
			&hkAssociate) == ERROR_SUCCESS) {

			// The key and time are already set -- check the time
			dType = REG_SZ;	// set defaults
			dSize = 255;
			tBuf[0] = 0;
			if (RegQueryValueEx(hkAssociate,
				"",
				0,
				&dType,
				(unsigned char *)tBuf,
				&dSize) == ERROR_SUCCESS) {
			
				setConfirmation = true;
	
			}
			RegCloseKey(hkAssociate);
		}
	}

	// Look for the CD version
	if (setConfirmation == false) {
		FILE *fp;
		unsigned char *ptr=NULL, *sptr, *endPtr;
		CString folder = "C:\\Program Files\\Startwrite\\Startwrite50\\";
		CString fullpath;
		int sizeRead;
		bool done=false;
		bool good=false;

		while(!done) {
			fullpath = folder + "Startwrite50.exe";
			fp = fopen(fullpath.GetString(), "rb");
			if (fp != NULL) {
				ptr = (unsigned char *)malloc(4096);
				if (ptr != NULL) {
					for(;!done;) {
						sizeRead = fread(ptr, 1, 4096, fp);
						if (sizeRead > 0) {
							endPtr = ptr + sizeRead;
							sptr = ptr;
							while(sptr < endPtr) {
								if ((*sptr == 'W') && ((sptr+5) < endPtr)) {
									if ( (*(sptr+1) == 'R') &&
										(*(sptr+2) == 'W') &&
										(*(sptr+3) == 'R') &&
										(*(sptr+4) == 'E') &&
										(*(sptr+5) == swREL)) {
											good = true;
											done = true;
											setConfirmation=true;
											break;
									}
								}
								sptr++;
							}
						}
						else {
							done = true;
						}
					}
					free(ptr);
				}
			}
			else {
				AfxMessageBox("Previous version of Startwrite not found. Enter path of startwrite50 progam.");
				getStartWriteProgram(folder);
			}
		}

	}
	
	if (setConfirmation == true) {
		strcpy_s(tBuf, sizeof(tBuf), "wrwktjbsa");
		if( RegCreateKeyEx(HKEY_CURRENT_USER,
		    		(const char *)tBuf,
					0,
					"",
					REG_OPTION_NON_VOLATILE,
					KEY_ALL_ACCESS,
					NULL,
		    		&hkAssociate,
					&disposition) == ERROR_SUCCESS) {
				
			time( &long_time );                /* Get time as long integer. */
			localtime_s(&newtime, &long_time ); /* Convert to local time. */
			_snprintf_s(tBuf, sizeof(tBuf), _TRUNCATE, "%4d%03d:%02d%02d%02d", 
					newtime.tm_year+1900, newtime.tm_yday,
					newtime.tm_hour,  newtime.tm_min, newtime.tm_sec);

			RegSetValueEx(hkAssociate,
	    			"", /*  (const char *)buf,*/
					0,
    				REG_SZ,
					(const unsigned char *)tBuf,
    				strlen(tBuf)+1);

			RegCloseKey(hkAssociate);
			AfxMessageBox("Successfully confirmed former version", MB_OK);
		}

	}


	return(setConfirmation);
}

int GetConfItemData(char *tptr, char *str1, char *str2)
{
	char *p1, *p2, ttt;
	int endofline=0;
	int inComment=0;
	int leadwhite, spacecnt=0;
		
	/* Get a line from the file, if first character is '#' get another */
	if ((str1 == NULL) || (str2 == NULL)) {
		return(-1);
	}

	if (str1) {		/* may not have a keyword on ips */
		p1 = str1;
		while ((ttt = *tptr++) != 0) {
			if (ttt == '\n') {
				endofline++;
				break;
			}
			if ((ttt == ' ') || (ttt == '\t')) {
				break;
			}
			if (ttt == '#') {
				inComment=1;
			}
			if (!inComment) {
				*p1++ = ttt;
			}
		}
		*p1 = '\0';
		if (ttt == 0) {
			/* No end of line char */
			*str2 = '\0';			
			return(0);
		}
	}
	p2 = str2;
	if (!endofline) {
		leadwhite=1;	/* mark possibility of leading whitespace */
		spacecnt=0;
		while ((ttt = *tptr++) != 0) {
			if ((ttt == '\n') || (ttt == '\r')) {
				break;
			}
			if (ttt == '#') {
				inComment=1;
			}

			if ((ttt == ' ') || (ttt == '\t')) {
				if (leadwhite) {
					continue;		/* skip leading whitespace */
				}
				if (!inComment) {
					spacecnt++;			/* count post spaces  */
				}
			}
			else if (!inComment) {
				leadwhite = 0;		/*not whitespace  */
				spacecnt = 0;		/*no spaces  */
			}
			
			if (!inComment) {
				*p2++ = ttt;
			}
		}
		if (spacecnt) {
			p2 -= spacecnt;
		}
	}			
	*p2 = '\0';
	return(0);
}


static char *confList[] = 
{
	"LOADBLACKBUTTON",
	"THICKLINES",
	"USE_UK",
	"SERIAL",
	"END"
};

void CSwApp::ProcessConfig(char *cptr)
{
	char *sptr;
	char tagPtr[128];
	char dataBuf[128];

	//!!!for(int i = 0; confList[i] != "END"; i++) {// error in Release build
	for(int i = 0; i < 4; i++) {
		sptr = strstr(cptr, confList[i]);
		if (sptr != NULL) {
			dataBuf[0] = '\0';
			tagPtr[0] = '\0';
			GetConfItemData(sptr, tagPtr, dataBuf);
		}
		else {
			continue;
		}
		switch(i) {
			case 0:
				if ((dataBuf[0] == 'Y') || (dataBuf[0] == 'y')) {
					theApp.m_DoPowerReload = true;
				}
				else {
					theApp.m_DoPowerReload = false;
				}
				break;
			case 1:
				if ((dataBuf[0] == 'Y') || (dataBuf[0] == 'y')) {
					theApp.m_doThick = 1;
				}
				else if ((dataBuf[0] == 'N') || (dataBuf[0] == 'n')) {
					theApp.m_doThick = 0;
				}
				break;
			case 2:
				if ((dataBuf[0] == 'Y') || (dataBuf[0] == 'y')) {
					doRunUKVersion = true;
				}
				else if ((dataBuf[0] == 'N') || (dataBuf[0] == 'n')) {
					doRunUKVersion = false;
				}
				break;
			case 3:
				lstrcpyn(theApp.m_SerialNumber, dataBuf, sizeof(theApp.m_SerialNumber));
				break;
			default:
				break;
		}
	}
}


void CSwApp::OpenSpecialConfig()
{
	CFile confFile;
	CString fileName = "sw.conf";
	int retv;
	ULONGLONG fileLen;
	char *fptr;
	CFileException ex;

	fileName = (CString)AfxGetApp()->m_pszHelpFilePath;
	fileName = fileName.Left(fileName.ReverseFind('\\'));
	fileName += "\\sw.conf";

	retv = confFile.Open(fileName, CFile::modeRead, &ex);
	if (retv != FALSE) {
		fileLen = confFile.GetLength();
		fptr = (char *) calloc((int)fileLen+60,1);
		if (fptr != NULL) {
			confFile.Read(fptr, (int)fileLen);
			ProcessConfig(fptr);
			free(fptr);
		}

		confFile.Close();
	}
#ifdef _DEBUG
	else {
		CString errStr;
		char tBuf[512];
		ex.GetErrorMessage(tBuf, sizeof(tBuf));
		errStr.Format("Unable to open %s [%s]", fileName, tBuf);
		AfxMessageBox(errStr);
	}
#endif
}

void CSwApp::UpdateSpecialConfig(char *key, char *data)
{
	CFile confFile;
	CString fileName = "sw.conf";
	int retv;
	int dataLen;
	ULONGLONG fileLen;
	char tBuf[64];
	char *fptr;

	if ((key == NULL) || (data == NULL)) 
		return;

	fileName = (CString)AfxGetApp()->m_pszHelpFilePath;
	fileName = fileName.Left(fileName.ReverseFind('\\'));
	fileName += "\\sw.conf";

	retv = confFile.Open(fileName, CFile::modeReadWrite);
	if (retv != FALSE) {
		dataLen = _snprintf(tBuf, sizeof(tBuf), "\r\n%s %s\r\n", key, data);
		
		fileLen = confFile.GetLength();
		fptr = (char *) calloc((int)fileLen+60+dataLen,1);
		if (fptr != NULL) {
			confFile.Read(fptr, (int)fileLen);
			if (!strstr(fptr, key)) {	// as long as its not there
				confFile.SeekToBegin();
				confFile.SetLength(0);
				confFile.Write(fptr, (UINT)fileLen);
				confFile.Write(tBuf, dataLen);
			}
			free(fptr);
		}
		confFile.Close();
	}
#ifdef _DEBUG
	else {
		AfxMessageBox(fileName);
	}
#endif
}


/////////////////////////////////////////////////////////////////////////////
// CSwApp initialization
extern void doRegister(int);
static CSplash splash;

BOOL CSwApp::InitInstance()
{
	int expSize=0;
	int menuNum, frameNum;
	int testFlag=0;
	CDemoAboutDlg demoAbout;
	int flag;
	bool doPurchaseOption=true;
	m_InSplash = true;
	bool serialNumOK=false;
#ifdef SW_IMAGN
	//IM_Init(NULL);		// Init the graphics drawing layer
//	IM_UL(136493659, 1211347712, 1340574849, 1757);
	IM_Init(0);
	IM_UL(1694697669, 650363374, 779664416, 8087);
#endif
	CString saveArt;

	SetRegistryKey("Startwrite60");

	OpenSpecialConfig();

	InitCommonControls();

	/* Remember the original value */
	originalType = *swType;
	
	// SPECIAL BUILD
	serialNumOK = true;
	
	if (serialNumOK == false) { 
	// Get the registration code for the registry / and/or check for a file
		CRegGenerator cCheck;
		char regBuf[128]={0};
		
		if ((theApp.GetSerialNumber((char *)regBuf) != 0) ||
			(cCheck.VerifyRegistration((char *)&regBuf[0]) == false)) {
		}
		else {
			// Valid Serial Number
			// no demo, run as full version
			m_isDemo = DEMO_OFF;	
			*swType = swREL;
			serialNumOK = true;
			if (regBuf[2] == 'N')
				theApp.isNetwork = true;
			else if (regBuf[2] == 'L')
				theApp.isLabPack = true;
			else if (regBuf[2] == 'C') 
				theApp.isCorporateVersion = true;
		}
	}

	if (originalType == swREL) {
#if 0
		if (serialNumOK == false) {
			AfxMessageBox("No Valid Registration Found.\nYou will have limited access to \nprogram features in Demo Mode until registered.");
			theApp.m_isDemo = DEMO_RELEASE; // force to demo mode

			CAboutDlg CDlg;

			CDlg.DoModal();	// throw up the help dialog to all ow them to enter registration
		}
#endif
	}
	else
	if (*swType == swUPG6) {	/* Upgrade from full version */
		theApp.m_isDemo = DEMO_ON;
		if (CheckForOldVersion() == true) {	/* Found old version, or we did find it once */
			/* Now validate */
			testFlag = 5;	/* we are running version 5 already find 5 upgrade or override */
			theApp.m_isDemo = ValidateReg(&flag, &testFlag);	// DEMO_OFF set if registered
			if (theApp.m_isDemo == DEMO_ON) {
				testFlag = 6;	/* Only test for override */
				theApp.m_isDemo = ValidateReg(&flag, &testFlag);	// DEMO_OFF set if registered
				if (theApp.m_isDemo == DEMO_ON) {
					*swType = swDEM;
					doPurchaseOption=false;
					AfxMessageBox("Unable to verify Upgrade.  Version will remain in DEMO mode");
				}
			}
		}
		else {	/* never found old, check for override */
			testFlag = 6;	/* Only test for override */
			theApp.m_isDemo = ValidateReg(&flag, &testFlag);	// DEMO_OFF set if registered
			if (theApp.m_isDemo == DEMO_ON) {
				*swType = swDEM;
				doPurchaseOption=false;
				AfxMessageBox("Unable to verify Upgrade.  Version will remain in DEMO mode");
			}
		}

		if (theApp.m_isDemo == DEMO_OFF) {
			*swType = swREL;		/* change to release */
			theApp.m_isDemo = DEMO_OFF;
		}
	}
	else if ((*swType == swDEM) || (*swType == swHPD) || (*swType == swOXD)) {

		CheckDemoTime();	/* set the wasDemo flag */

		testFlag = 6;
		theApp.m_isDemo = ValidateReg(&flag, &testFlag);	// DEMO_OFF set if registered
			/* Check if the Money Back Cancel Product has happened */
		if (((*swType == swDEM) || (*swType == swOXD)) && (theApp.m_isDemo == DEMO_ON)) {
			theApp.m_isDemo = OneTryCheck();	/* let them run the first time anyway */
			if (*swType == swOXD) {
				CswOneTryOxford tryDlgOxford;
				/* This is the one time only deal. */
				m_wasDemo = FALSE;	/* don't want deavtivate button yet */
				tryDlgOxford.DoModal();
			}
			else if (theApp.m_isDemo == DEMO_OFF) {
				swOneTry tryDlg;
				/* This is the one time only deal. */
				m_wasDemo = FALSE;	/* don't want deavtivate button yet */
				tryDlg.DoModal();
			}
		}

		/* This is the overriding money back cut-off */
		if (*swType == swHPD) {
			if (theApp.m_isDemo == DEMO_ON) {	// If still demo and HOP
				theApp.m_isDemo = DEMO_HOPON;	// Switch to HOP Demo
			}
			else {
				*swType = swHOP;	// Convert to HOP FULL Version
			}
		}
		else if (*swType == swOXD) {
			;
		}
		else if (theApp.m_isDemo == DEMO_OFF) {
			/* if we validated, make this a real version */
			*swType = swREL;	// Allow this to be a full version
			/* This is going to need swRL5 soon */
			if (testFlag == SW_SITELICENSE_VERSION) {
				theApp.isNetwork = true;
			}
			else if (testFlag == SW_LABPACK_VERSION) {
				theApp.isLabPack = true;
			}
			else if (testFlag == SW_CORPORATE_VERSION) {
				theApp.isCorporateVersion = true;
			}
			// TEMP TEMP TEMP
			theApp.isCorporateVersion = true;
		}
/*
		else if (*swType == swDEM) {
			if (theApp.m_isDemo == DEMO_ON) {
				theApp.m_isDemo = checkStartTime();	// Check if time is up
			}
			else {
				*swType = swREL;	// Allow this to be a full version
			}
		}
*/
	}
	else {
		theApp.m_isDemo = DEMO_OFF;	// Regular version / no demo
		*swType = swREL;	// seems extra
	}


	//SetDialogBkColor();        // Set dialog background color to gray
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	m_isTemplate = 0;			// Default is not a template
	// Load the default app settings.
	CString 	strDocPath;
	CString		strArtPath;
	int			iWhere;    
	char		szName[_MAX_PATH * 2];

	GetModuleFileName(AfxGetInstanceHandle(), szName, sizeof(szName));
	strDocPath = szName;
	strArtPath = szName;

	iWhere = strDocPath.ReverseFind('\\');		// Remove executible name
	if (iWhere != -1) {
		strDocPath = strDocPath.Left(iWhere);
		strArtPath = strDocPath;
	}
	m_BasePath = strDocPath;	// Save executible directory

	
	if (*swType == swDEM) {
		m_splashStr = theApp.m_BasePath + "\\Startwrite60Trial.jpg";
		expSize = 36450;
	}
	else if ((*swType == swHOP) || (*swType == swHPD)) {
		m_splashStr = theApp.m_BasePath + "\\swhop.jpg";
		expSize = 34250;
	}
	else if (*swType == swOXF) {
		m_splashStr = theApp.m_BasePath + "\\startwriteoxford.jpg";
	}
	else if (*swType == swOXD) {
		m_splashStr = theApp.m_BasePath + "\\startwriteoxforddemo.jpg";
	}
	else {
		m_splashStr = theApp.m_BasePath + "\\StartWrite60.jpg";
		expSize = 109825;
	}
	
	/* Just test to be sure the file is there and is the right size */
#ifdef LATER_WRW
	{
		struct _stat statbuf;
		int result;
		result = _stat( (char *)(LPCTSTR)m_splashStr, &statbuf);

		/* Check if statistics are valid: */
		if( result != 0 ) {
			AfxMessageBox("Error: Cannot run program. Contact Startwrite, Inc. (1)");
			exit(0);
		}

		else {
			/* Output some of the statistics: */
			if (expSize != statbuf.st_size) {
				/* Invalid -- quit */
				AfxMessageBox("Error: Cannot run program. Contact Startwrite, Inc. (2)");
				exit(0);
			}
		}
	}
#endif
	//strDocPath += "\\document\\";	// Set path to default document directory
	strDocPath = "C:\\My Documents\\";
	strArtPath += "\\Images\\";	// Point to default images directory

	// If we are in regular DEMO mode -- throw up the activate dialog reminder
	if ((doPurchaseOption==true) && ((*swType == swDEM) || (theApp.m_isDemo == DEMO_ON)) /* the demo_on flag is set || (*swType == swOXD)*/) {
		//OnAppAbout();
		demoAbout.DoModal();
		//AfxMessageBox("This is a DEMO version of Statwrite.\nGo to Help => Purchase Startwrite to activate");
	}
	// This causes the black buttons -- don't do splash!
	else 
	{
		// Otherwise
#ifdef DO_THE_SPLASH
		splash.StartSplash();		// throw up the splash screen
#endif
	}

	// Set Defaults
	m_strDocPath = strDocPath;
	m_lastDocPath = strDocPath;
	m_strArtPath = strArtPath;
	m_iDefaultDensity = 1;
	m_iDefaultShading = 4;
	m_iDefaultArrows = 1;
	//m_iDefaultLines = ((*swType == swOXF) || (*swType == swOXD)) ? 0x0F : 4;
	m_iDefaultStartDot = FALSE;
	m_iDefaultKernMode = TRUE;
	m_iDefaultSpacing = SPACENORMAL;
	m_allowWindowsFonts = ((*swType == swSHR) ? 0 : 1);

	// Create the registry entries with defaults or Get current settings
	swGetSettings(szName, strArtPath, strDocPath);

	if (_chdir(m_strArtPath) == -1) {
		if (_chdir(strArtPath) == -1) {	// Try the default one
			// Nothing to do -- bad art directories
		}
		else {
			AfxMessageBox("Invalid/Old Art Directory.  Resetting to new default.");
			m_strArtPath = strArtPath;		// Set new
			swSetSettings(m_strDocPath, m_strArtPath, m_iDefaultDensity, m_iDefaultShading, m_iDefaultArrows,
				m_iDefaultStartDot, m_iDefaultKernMode, m_iDefaultSpacing, 
				m_iDefaultShadeType, m_allowWindowsFonts);
		}
	}
	
	// Make sure we go back to the document directry after doing art
	if (m_strDocPath.GetLength() > 0) {
		if (_chdir(m_strDocPath) == -1) {
			// could not change to document directory
			if (m_strDocPath != strDocPath) {	// if not default, and not there
				m_strDocPath = strDocPath;		// they must have moved the program/upgraded
				AfxMessageBox("Invalid/Old Document Directory.  Resetting to new default.");
				swSetSettings(m_strDocPath, m_strArtPath, m_iDefaultDensity, m_iDefaultShading, m_iDefaultArrows,
					m_iDefaultStartDot, m_iDefaultKernMode, m_iDefaultSpacing, 
					m_iDefaultShadeType, m_allowWindowsFonts);
			}
			_mkdir(m_strDocPath);		// make the default directory if possible
			if (_chdir(m_strDocPath) == -1) {
#ifndef FREEZ
				// Could Not Get There
				AfxMessageBox("Invalid Document Directory");
#endif
			}
		}
	}
	else {
		 if (_chdir(strDocPath) == -1) {
			// could not change to document directory
			_mkdir(strDocPath);		// make the default directory if possible
			if (_chdir(strDocPath) == -1) {
#ifndef FREEZ
				// Could Not Get There
				AfxMessageBox("Invalid Document Directory");
#endif
			}
		}
	}


	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	UpdatePrinterSelection(TRUE);
	if (theApp.m_isDemo == DEMO_RELEASE) {
		menuNum = IDR_SWTYPE_FULL_RESTRICTED;
		frameNum = IDR_MAINFRAME;
	}
	else {
		switch(*swType) {
		case swDEM:
		case swHPD:
			menuNum = IDR_SWTYPE_DEMO;
			frameNum = IDR_MAINFRAME;
			break;
		case swSHR:
			menuNum = IDR_SWTYPE_SHR;
			frameNum = IDR_MAINFRAME_SHR;
			break;
		case swOXF:
		case swOXD:
			menuNum = IDR_SWTYPE_OXF;
			frameNum = IDR_MAINFRAME_OXF;
			break;
		default:
			menuNum = IDR_SWTYPE_FULL;
			frameNum = IDR_MAINFRAME;
			break;
		}
	}
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(menuNum,
		RUNTIME_CLASS(CSwDoc),
		RUNTIME_CLASS(CMDIChildWnd),        // standard MDI child frame
		RUNTIME_CLASS(CSwView));
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(frameNum))
		return FALSE;
	m_pMainWnd = pMainFrame;

#ifdef DO_TRIAL_FILE
	if ((*swType == swDEM) && (OpenDocumentFile("TrialFile.swd") != NULL)) {
	}
	else 
#endif
	if (m_lpCmdLine[0] != '\0')
	{
		// command line processing here
		//int spcpos;
		CString param1;
		param1 = m_lpCmdLine;

		//// only use first argument in string...
		//!!! This truncates after first word in path such as "My Documents"
		//if( (spcpos = param1.Find(' '))> -1) { 
		//	param1 = param1.Left(spcpos);
		//}

		// open existing document
		OpenDocumentFile(param1);
	}
	else
	{
		// create a new (empty) document
		OnFileNew();
	}

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

#ifdef DOING_REGISTRATION
	STARTUPINFO sttr = {
	    sizeof(STARTUPINFO), //DWORD   cb; 
		NULL, //LPTSTR  lpReserved; 
		NULL, //LPTSTR  lpDesktop; 
		NULL, //LPTSTR  lpTitle; 
	    CW_USEDEFAULT, //DWORD   dwX; 
		CW_USEDEFAULT, //DWORD   dwY; 
		CW_USEDEFAULT, //    DWORD   dwXSize; 
		CW_USEDEFAULT, //DWORD   dwYSize; 
		0, //DWORD   dwXCountChars; 
		0, //DWORD   dwYCountChars; 
		0, //   DWORD   dwFillAttribute; 
		0, // DWORD   dwFlags; 
		0, //   WORD    wShowWindow; 
		0, //WORD    cbReserved2; 
		0,	//  LPBYTE  lpReserved2; 
		0, //HANDLE  hStdInput; 
		0,	//HANDLE  hStdOutput; 
		0	//    HANDLE  hStdError; 
	};
 
	PROCESS_INFORMATION pinfo;

	CString regprog = m_BasePath + "\\ereg.exe";
	DWORD retval = CreateProcess( regprog, // pointer to name of executable module
			"",  // pointer to command line string
			NULL, //LPSECURITY_ATTRIBUTES lpProcessAttributes,  // process security attributes
			NULL, //LPSECURITY_ATTRIBUTES lpThreadAttributes,   // thread security attributes
			FALSE, //BOOL bInheritHandles,  // handle inheritance flag
			0,		//DWORD dwCreationFlags, // creation flags
			NULL, //  LPVOID lpEnvironment,  // pointer to new environment block
			NULL, //  LPCTSTR lpCurrentDirectory,   // pointer to current directory name
			&sttr, //  LPSTARTUPINFO lpStartupInfo,  // pointer to STARTUPINFO
			&pinfo	//  LPPROCESS_INFORMATION lpProcessInformation  // pointer to PROCESS_INFORMATION
		); 
	
	if (!retval) {
		retval = GetLastError();	// The process creation did not happen
	}
#endif
#ifdef DO_TRIAL_FILE
	if (*swType == swDEM) {
		trialDlg = new CTrialHelp();	
	}
#endif
	SetPrintDocumentName();
	return TRUE;
}

UINT32 convertData[30] = 
{'9','S','G','J','3','V','Q','L','P','6','S','R','K','F','7','8','C','2','M','Z','N','H','D','5','T','1','X','W','4','B'};


void InitConvertData(char *in, char *out)
{
	UINT32 newIndex;
	int direction=1;
	int count=1;
	while (*in) {
		newIndex = *in * 2 + (direction * count);
		newIndex %= 30;
		direction *= -1;
		count++;
		in++;
		*out++ = (char)convertData[newIndex];
	}
	*out = '\0';
}

UINT32 BaseData[30] = 
{'S','9','S','M','5','G','D','J','3','K','V','Q','L','P','6','R','F','7','8','C','2','Z','N','H','T','1','X','W','4','B'};

void CreateBaseKey(char *in, char *out)
{
	UINT32 newIndex;
	while(*in) {
		newIndex = toupper(*in) - 'A';
		*out = (char)BaseData[newIndex];
		in++;
		out++;
	}
	*out = '\0';
}

void UndoBaseKey(char *in, char *out)
{
	int i;
	while(*in) {
		for(i=0; i < (sizeof(BaseData)/sizeof(UINT32)); i++) {
			if (*in == BaseData[i]) {
				*out = 'A' + i;
				out++;
				break;
			}
		}
		in++;
	}
	*out = '\0';
}

// App command to run the dialog
void CSwApp::OnAppAbout()
{
	long junk;
	CAboutDlg aboutDlg;
	CDemoAboutDlg demoDlg;
	CHOPAboutDlg hopDlg;
	int len;
	char tBuf[48];
	char tBuf2[48];
	char tBuf3[48];
	char tBuf4[48];
	char tBuf5[256];
	char tBuf6[48];

	if ((gethostname(tBuf, sizeof(tBuf)) == 0) && (strlen(tBuf) > 0)) {
		lstrcpyn(tBuf2, tBuf, sizeof(tBuf2));
		lstrcpyn(tBuf3, tBuf, sizeof(tBuf3));
		while(1) {
			len = strlen(tBuf2);
			if (len >= 16) {
				tBuf2[16] = '\0';
				break;
			}
			lstrcat(tBuf2, tBuf3);
		}
		tBuf3[0] = '\0';
		int i,j;

		CreateBaseKey(tBuf2, tBuf3);	// create the key
		
		UndoBaseKey(tBuf3, tBuf4);		// go back to the original
		for(i=0,j=0; j < 16; i++, j++) {
			tBuf6[i] = tBuf4[j];
			if (j && ((j+1)%4 == 0) && (j != 15)) {
				tBuf6[++i] = '-';
			}
		}
		tBuf6[i] = '\0';

		_snprintf_s(tBuf5, sizeof(tBuf5), _TRUNCATE,"%s => %s => %s", tBuf2, tBuf3, tBuf6);
		AfxMessageBox(tBuf5);


		lstrcpyn(tBuf2, tBuf, sizeof(tBuf2));
		while(1) {
			len = strlen(tBuf);
			if (len >= 16) {
				tBuf[16] = '\0';
				break;
			}
			lstrcat(tBuf, tBuf2);
		}
		AfxMessageBox(tBuf);
		InitConvertData(tBuf, tBuf2);
		AfxMessageBox(tBuf2);
		for(i=0,j=0; j < 16; i++, j++) {
			tBuf[i] = tBuf2[j];
			if (j && ((j+1)%4 == 0) && (j != 15)) {
				tBuf[++i] = '-';
			}
		}
		tBuf[i] = '\0';
		AfxMessageBox(tBuf);
	}
	else {
		AfxMessageBox("No name");
	}
	return;

	if ((*swType == swHOP) || (*swType == swHPD)){
		hopDlg.DoModal();
	}
	else if (*swType == swDEM) {
		demoDlg.DoModal();
	}
	else {
		aboutDlg.DoModal();
	}
	junk = ABOUTBUF1;
	artFreeBuffer(&junk);
	junk = ABOUTVIEW1;
	artFreeView(&junk);

//	junk = ABOUTBUF2;
//	artFreeBuffer(&junk);
//	junk = ABOUTVIEW1;
//	artFreeView(&junk);
}


BOOL CSwApp::OnIdle(LONG lCount)
{
	CWinApp::OnIdle(lCount);

#ifdef DO_THE_SPLASH
	splash.KillSplash();
#endif

	// We don't want to get called anymore.
	if (theApp.shutdownTime != -1) {
		if (GetTickCount() < theApp.shutdownTime)
			return(TRUE);
		theApp.m_isDemo = DEMO_ON;
		theApp.shutdownTime = -1;
		AfxMessageBox("Full Access Expired....changing to demo mode");
	}
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CSwApp commands

BOOL CSwApp::ExitInstance()
{
	this->swSetDefaultCustomPalette();
#ifdef SW_IMAGN
	IM_DeInit();
#endif
	return CWinApp::ExitInstance();
}


void CSwApp::OnToolsSettings50()
{
	int ret = -1;
	CSetDlg50	dlg;
	CString docPath = m_strDocPath;
	CString artPath = m_strArtPath;

	dlg.m_docFolder = m_strDocPath;
	dlg.m_artFolder = m_strArtPath;
	
	dlg.m_densityRadio = m_iDefaultDensity-1;
	dlg.m_shadeRadio = m_iDefaultShading-1;
	dlg.m_arrowSetting = m_iDefaultArrows-1;

	//dlg.m_linesFlag = m_iDefaultLines;
	dlg.m_shadeTypeRadio = m_iDefaultShadeType;
	dlg.m_startDotSetting = m_iDefaultStartDot;

	for(;ret == -1;) {
		ret = dlg.DoModal();

		if (ret == IDCANCEL)
			return;

		if (dlg.m_docFolder.GetLength() <= 0) {		// Check the Document Path
			ret = 0;
		}
		else if (docPath != dlg.m_docFolder) {	// did they change the directory?
			// Yes, make sure it is valid
			if (_chdir(dlg.m_docFolder) == -1) {
				ret = AfxMessageBox("Document directory does not exist. Create?", MB_YESNOCANCEL);
				if (ret == IDCANCEL) {
					dlg.m_docFolder = m_strDocPath;	// restore the original art path
					ret = -1;
					continue;
				}
				if (ret == IDNO) {
					ret = -1;
					continue;
				}
				ret = _mkdir(dlg.m_docFolder);
				if (ret == -1) {
					AfxMessageBox("Error creating directory");
					continue;
				}
				// we will assume they could change to the newly created
				_chdir(dlg.m_docFolder);
			}
		}
		// Check the Art Path
		if (dlg.m_artFolder.GetLength() <= 0) {
			ret = 0;
		}
		else if (artPath != dlg.m_artFolder) {	// did they change the directory?
			if (_chdir(dlg.m_artFolder) == -1) {
				ret = AfxMessageBox("Art directory does not exist. Create?", MB_YESNOCANCEL);
				if (ret == IDCANCEL) {
					dlg.m_artFolder = m_strArtPath;	// restore the original art path
					ret = -1;
					continue;
				}
				if (ret == IDNO) {
					ret = -1;
					continue;
				}
				ret = _mkdir(dlg.m_artFolder);
				if (ret == -1) {
					AfxMessageBox("Error creating directory");
					continue;
				}
			}
		}
		ret = 0;	// if we get here, then we can exit
	}
	// Force to document directory
	if (dlg.m_docFolder.GetLength() > 0) {
		_chdir(dlg.m_docFolder);
	}
	m_strDocPath = dlg.m_docFolder;
	ret = m_strDocPath.GetLength();
	if ((ret > 0) && (m_strDocPath.GetAt(ret-1) != '\\')) {
		m_strDocPath += '\\';
	}
	m_lastDocPath = m_strDocPath;
	
	m_strArtPath = dlg.m_artFolder;
	ret = m_strArtPath.GetLength();
	if ((ret > 0) && (m_strArtPath.GetAt(ret-1) != '\\')) {
		m_strArtPath += '\\';
	}

	m_iDefaultDensity = dlg.m_densityRadio+1;
	m_iDefaultShading = dlg.m_shadeRadio+1;
	m_iDefaultArrows = dlg.m_arrowSetting+1;
	//m_iDefaultLines = dlg.m_linesFlag;
	m_iDefaultShadeType = dlg.m_shadeTypeRadio;
	m_iDefaultStartDot = dlg.m_startDotSetting;


	// now Update Registry
	swSetSettings(m_strDocPath, m_strArtPath, m_iDefaultDensity, 
			m_iDefaultShading, m_iDefaultArrows, m_iDefaultStartDot, 1, -1,
			m_iDefaultShadeType, m_allowWindowsFonts);

}


int checkPrinterMultiple()
{
	PRINTDLG   pd;
	int retv=0;

	pd.lStructSize = (DWORD) sizeof (PRINTDLG);
	// force CWinApp to initialize printer and setup defaults
	CWinApp *app = AfxGetApp();
	if (app->GetPrinterDeviceDefaults (&pd)) {
        // now lock down the defaults
        
		DEVMODE FAR *pMode = (DEVMODE FAR*)::GlobalLock (pd.hDevMode);
		if (pMode) {
			// Change printer settings in here.
			retv = (pMode->dmFields & DM_COPIES) ? 1 : 0;
			::GlobalUnlock (pd.hDevMode);
		}
	}
	return(retv);
}

void setPrintOrientation(short newOrient)
{
	static short lastMode = -1;

	if (newOrient != lastMode) {

		PRINTDLG   pd;
		pd.lStructSize = (DWORD) sizeof (PRINTDLG);
		// force CWinApp to initialize printer and setup defaults
		CWinApp *app = AfxGetApp();
		if (app->GetPrinterDeviceDefaults (&pd)) {
            // now lock down the defaults
            
			DEVMODE FAR *pMode = (DEVMODE FAR*)::GlobalLock (pd.hDevMode);
			if (pMode) {
				// Change printer settings in here.
				pMode->dmOrientation = newOrient; //DMORIENT_PORTRAIT;
				pMode->dmCopies = 1;

				::GlobalUnlock (pd.hDevMode);
			}
		}
		lastMode = newOrient;
	}
}

#ifdef LATER_WRW_MAPI
void TryMapiStuff()
{
	MapiMessage mms;
	MapiRecipDesc mmrec;

	mmrec.ulReserved = 0;
	mmrec.ulRecipClass = MAPI_TO;
	mmrec.lpszName = "Wayne R. Wylie";
	mmrec.lpszAddress = "wylie@deseretonline.com";
	mmrec.ulEIDSize=0; 
	mmrec.lpEntryID=NULL;

	mms.ulReserved=0;
	mms.lpszSubject = (LPTSTR) "Registration Packet";
    mms.lpszNoteText = (LPTSTR) "Registration Information";
	mms.lpszMessageType = NULL; 
    mms.lpszDateReceived = "1999/01/08 12:00";
	mms.lpszConversationID = NULL;
	mms.flFlags = 0;
	mms.lpOriginator = NULL; 
    mms.nRecipCount=1;
	mms.lpRecips = &mmrec;
    mms.nFileCount = 0;
	mms.lpFiles = NULL;


	MAPISendMail( 0, //  LHANDLE lhSession,         
				0,	//  ULONG ulUIParam,           
				&mms,
				MAPI_LOGON_UI,             
				0);

}

#endif
void CSwApp::SetPrintDocumentName()
{
	HKEY hkAssociate;
	char tBuf[1024];
	DWORD disposition;

	strcpy_s(tBuf, sizeof(tBuf), "Software\\Startwrite PDF Writer\\outputfile");
	if( RegCreateKeyEx(HKEY_CURRENT_USER,
	    		(const char *)tBuf,
				0,
				"",
				REG_OPTION_NON_VOLATILE,
				KEY_ALL_ACCESS,
				NULL,
	    		&hkAssociate,
				&disposition) == ERROR_SUCCESS) {
			
		_snprintf_s(tBuf, sizeof(tBuf), _TRUNCATE, "C:\\Temp\\StartwriteOne.pdf");
		RegSetValueEx(hkAssociate,
    			"", /*  (const char *)buf,*/
				0,
				REG_SZ,
				(const unsigned char *)tBuf,
				strlen(tBuf)+1);

		RegCloseKey(hkAssociate);
		
	}
}



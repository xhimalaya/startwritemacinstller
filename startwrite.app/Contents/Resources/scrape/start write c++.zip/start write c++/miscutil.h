#ifndef _MSCUTIL_H
#define _MSCUTIL_H

void SetRadioRowValue(HWND hwnd, int iValue, int *piIDs, int nCount);
void GetRadioRowValue(HWND hwnd, int *piValue, int *piIDs, int nCount);

void Trace(LPCSTR szFormat, ...);
void WriteSWReleaseLog(LPCSTR szFormat, ...);


typedef struct fontInfo  {
	char f_filename[15];	// font filename
	char f_fontname[48];	// name for pulldown
	char f_default;         // 1 if default font
	unsigned short f_iscursive;		// 1 if cursive
	char f_arrowname[15];	// matching arrowfont name
	char f_overlayname[15];
	char f_dotname[15];
	char f_cffont[15];
	char f_ddfont[15];
	char nCharSet;
	char nPitchAndFamily;
	char midSection;	// for copy purposes
	int  f_MathFlag;
	int f_fontLine;		/* Combination lines for this font */
	char f_TopLine;		/* SWLINE_ON, SWLINESOLID, SWLINE_DOTTED */
	char f_MidLine;
	char f_BasLine;
	char f_BotLine;
	int f_TopColor;		/* 0,0,0xFF (Blue) */
	int f_MidColor;		/* 0xFF,0,0  (red) */
	int f_BasColor;		/* 0,0,0xFF (Blue) */
	int f_BotColor;		/* -1 for no line  */
	int f_TopColorInd;
	int f_MidColorInd;		/* 0xFF,0,0  (red) */
	int f_BasColorInd;		/* 0,0,0xFF (Blue) */
	int f_BotColorInd;		/* -1 for no line  */
	int f_TopThickness;
	int f_MidThickness;
	int f_BasThickness;
	int f_BotThickness;
} FONTINFO;

#define SWLINE_ON	0x01	/* These match the offset in the radio buttons too */
#define SWLINE_DOT	0x02
#define SWLINESET (SWLINE_ON | SWLINE_DOT)

#define SWLINE_TOP	0x01
#define SWLINE_MID	0x02
#define SWLINE_BAS	0x04
#define SWLINE_BOT	0x08


#define MATH_ONE	0x01	// Math One

#define CUR_ZAN1	0x0001	// Zaner blowser
#define CUR_ITAL	0x0002	// italic cursive
#define CUR_DNEL	0x0004	// D'nealian
#define	CUR_ZAN2	0x0008	// Simple Zaner
#define CUR_UPRT	0x0010	// Cursive Upright
#define CUR_FRML	0x0020	// Cursive from the line
#define CUR_VICT	0x0040	// Victorian Cursive
#define CUR_QUEEN	0x0080	// Queensland Cursive
#define CUR_NSW		0x0100	// New South Wales Cursive
#define CUR_PALMR	0x0200	// Palmer Cursive
#define CUR_WOT		0x0400	// Without Tears Cursive
#define CUR_AMER	0x0800	// American Cursive

#define DO_KERNING	0x8000	// Font defaults to kerning

#define MAX_ALLOWED_FONTS	1000

#define	BORDER_WIDTH 125	// Border around Boxes

// Misc flags for box display
#define SAVEOLD -1
#define CLEAROLD -2
#define NO_GROWING -3
#define DRAG_TRANSPARENT -4


#endif

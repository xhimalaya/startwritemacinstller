// NumCopies.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "NumCopies.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNumCopies dialog


CNumCopies::CNumCopies(CWnd* pParent /*=NULL*/)
	: CDialog(CNumCopies::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNumCopies)
	m_numCopies = 0;
	//}}AFX_DATA_INIT
}


void CNumCopies::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNumCopies)
	DDX_Text(pDX, IDC_NUMCOPIES, m_numCopies);
	DDV_MinMaxUInt(pDX, m_numCopies, 1, 99);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNumCopies, CDialog)
	//{{AFX_MSG_MAP(CNumCopies)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, OnChangeNumCopies)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNumCopies message handlers

void CNumCopies::OnChangeNumCopies(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	m_numCopies -= pNMUpDown->iDelta;
	if (m_numCopies < 1) 
		m_numCopies = 1;
	else if (m_numCopies > 99)
		m_numCopies = 99;
	*pResult = 0;
	UpdateData(FALSE);
}

// Glyf Data Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "GlyfData.h"
#include <afxwin.h>
#include <math.h>
 
#include <stdio.h>
 
GlyfData::GlyfData()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfData::GlyfData()"); 
	#endif
    
	segPtr=NULL;
	segList=NULL;
	segFreeList=NULL;
	segCnt=0;
	segListCnt=0;
	segAvail=0;
	dotValue=0;
	ClearData();	/* Clear out all values */
	ghp = &gh;
    gdp = &gd;

	Header = &gh;
	Description = &gd;

#ifdef _DEBUG
	allocCnt=0;
	freeCnt=0;
#endif
		
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfData::GlyfData: void"); 
	#endif
}

GlyfData::GlyfData(GlyfData *source)
{
	segPtr=NULL;
	segList=NULL;
	segFreeList=NULL;
	segCnt=0;
	segListCnt=0;
	segAvail=0;
	dotValue=0;
	ClearData();	/* Clear out all values */
	ghp = &gh;
    gdp = &gd;

	Header = &gh;
	Description = &gd;	
	gh.NumberOfContours = source->gh.NumberOfContours;
	gh.XMax = source->gh.XMax;
	gh.XMin = source->gh.XMin;
	gh.YMax = source->gh.YMax;
	gh.YMin = source->gh.YMin;

	Index = source->Index;
	Offset = source->Offset;
	Size = source->Size;
	dotValue = source->dotValue;

	gd.MaxPoints = source->gd.MaxPoints;
	if (gd.MaxPoints > GLYF_ITEMSIZE) {
		gd.MaxPoints = GLYF_ITEMSIZE-1;
	}
	for(int i = 0; i < gd.MaxPoints; i++) {
		gd.EndPointsOfContours[i] = source->gd.EndPointsOfContours[i];
		gd.Flags[i] = source->gd.Flags[i];
		gd.XCoordinates[i] = source->gd.XCoordinates[i];
		gd.YCoordinates[i] = source->gd.YCoordinates[i];
	}
	gd.InstructionLength = source->gd.InstructionLength;
#ifdef _DEBUG
	allocCnt=0;
	freeCnt=0;
#endif
}


void GlyfData::FreeMemory()
{
	SEGMENT_DATA *tPtr, *tPtr1;
	
	if ( segPtr != NULL ) {
		free(segPtr);
#ifdef _DEBUG
		freeCnt++;
#endif

		segPtr=NULL;
		segCnt=0;
		segAvail=0;
		dotValue=0;
	}
	
	tPtr = segFreeList;
	while (tPtr) {
		tPtr1 = tPtr->next;
		free(tPtr);
#ifdef _DEBUG
		//freeCnt++;
#endif
		tPtr = tPtr1;
	}
	segFreeList=NULL;
	segListCnt=0;

#ifdef _DEBUG
	if (allocCnt != freeCnt) {
		allocCnt=0;
		freeCnt=0;
	}
#endif

	ClearData();

}

GlyfData::~GlyfData()
{

	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfData::~GlyfData()"); 
	#endif
	
	FreeMemory();

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT GlyfData::~GlyfData: void"); 
	#endif
}


int
GlyfData::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER GlyfData::Print()"); 
	#endif
      
	int i = 0;      
	cout << "** Glyf **" << endl;
	cout << dec;
	cout << "Index: " << Index << endl;
	cout << "Offset: " << hex << Offset << dec << endl;
	cout << "Size: " << Size << endl;

    if( Size == 0 ) return OK; 

    cout << "NumberOfContours: " << ghp->NumberOfContours << endl;
    cout << "XMin: " << ghp->XMin << endl;
    cout << "YMin: " << ghp->YMin << endl;
	cout << "XMax: " << ghp->XMax << endl;
	cout << "YMax: " << ghp->YMax << endl;
	
	cout << "MaxPoints: " << gdp->MaxPoints << endl;

	for( i = 0; i < ghp->NumberOfContours; ++i)
	{
		cout << "EndPoint " << i << ": " << gdp->EndPointsOfContours[i] << endl;
	}        

	cout << "InstructionLength: " << gdp->InstructionLength << endl;

#ifdef notnow
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{
		cout << "Flags " << i << ": " << hex << (int)gdp->Flags[i] << dec << endl;
	}
#endif	

//#ifdef notnow    
    UShort flags;            
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{
		flags = gdp->Flags[i];
		cout << "Flags ";
		if( i < 10 ) { cout << " "; }
		cout << i << ": ";
		if( flags & GLYF_YDUAL ) { cout << "YDual "; } else { cout << "      "; }
		if( flags & GLYF_XDUAL ) { cout << "XDual "; } else { cout << "      "; }
		if( flags & GLYF_REPEAT ) { cout << "Repeat "; } else { cout << "       "; }
		if( flags & GLYF_YBYTE ) { cout << "YByte "; } else { cout << "      "; }
		if( flags & GLYF_XBYTE ) { cout << "XByte "; } else { cout << "      "; }
		if( flags & GLYF_ONCURVE ) { cout << "OnCurve "; } else { cout << "OffCurve"; }
		cout << endl;
	}                
//#endif

//#ifdef notnow
	for( i = 0; i < (int)gdp->MaxPoints; ++i)
	{
		cout << "XY[" << i << "]: " << dec << gdp->XCoordinates[i] << ", " << gdp->YCoordinates[i] << dec << endl;
	}
//#endif	
		
	return OK;
}


int 
GlyfData::MakeGlyfPointsAbsolute()
{
	unsigned short i, flags;
	short LastX = 0;
	short LastY = 0;

    if( Size == 0 ) return ERROR; 

			
	for( i = 0; i < gdp->MaxPoints; ++i)
	{
		flags = gdp->Flags[i];

		if( flags & GLYF_XDUAL) {
			gdp->XCoordinates[i] = LastX;		
		}
		else {
			gdp->XCoordinates[i] = (short)(LastX + gdp->XCoordinates[i]);
			LastX = gdp->XCoordinates[i];		
		}		

		if( flags & GLYF_YDUAL)	{
			gdp->YCoordinates[i] = LastY;		
		}
		else {
			gdp->YCoordinates[i] = (short)(LastY + gdp->YCoordinates[i]);
			LastY = gdp->YCoordinates[i];
		}		
	}

	return OK;
}


//int 
//GlyfData::DivideGlyfPointsBy( int divisor)
//{
//  if( Size == 0 ) return ERROR; 

//	for( int i = 0; i < (int)gdp->MaxPoints; ++i)
//	{
//		gdp->XCoordinates[i] = (Short)(gdp->XCoordinates[i] / divisor);
//		gdp->YCoordinates[i] = (Short)(gdp->YCoordinates[i] / divisor);
//	}	
//	
//	return OK;
//}


int 
GlyfData::GetMaxPoints()
{
    if( Size == 0 ) return 0; 
#ifdef _DEBUG
	if (gdp->MaxPoints > GLYF_ITEMSIZE-1) {
		AfxMessageBox("Character Bigger than buffer");
	}
#endif
	return (int)(gdp->MaxPoints > GLYF_ITEMSIZE-1) ? GLYF_ITEMSIZE-1 : gdp->MaxPoints;
}

int 
GlyfData::GetNumberOfContours()
{
    if( Size == 0 ) return 0; 
	return (int)ghp->NumberOfContours;
}


int 
GlyfData::GetEndPoint( int ep)
{
    if( Size == 0 ) return 0; 
	return (int)gdp->EndPointsOfContours[ep];
}

int 
GlyfData::IsOnCurve( int i)	
{
    if( Size == 0 ) return FALSE; 
	if( gdp->Flags[i] & GLYF_ONCURVE ) { return TRUE; }
	return FALSE;
}

int 
GlyfData::IsOffCurve( int i)	
{
    if( Size == 0 ) return FALSE; 
	if( gdp->Flags[i] & GLYF_ONCURVE ) { return FALSE; }
	return TRUE;
}

int 
GlyfData::GetX( int i)
{
    if( Size == 0 ) return 0; 
	return (int)gdp->XCoordinates[i];
}

int 
GlyfData::GetY( int i)	
{
    if( Size == 0 ) return 0; 
	return (int)gdp->YCoordinates[i];
}

int 
GlyfData::GetXMin()
{
    if( Size == 0 ) return 0; 
	return (int)ghp->XMin;
}

int 
GlyfData::GetYMin()	
{
    if( Size == 0 ) return 0; 
	return (int)ghp->YMin;
}

int 
GlyfData::GetXMax()
{
    if( Size == 0 ) return 0; 
	if (ghp == NULL) {
		ghp =  &gh;
	}
	return (int)ghp->XMax;
}

void GlyfData::SetXMax(int newX)
{
	ghp->XMax = (short)newX;
}

int 
GlyfData::GetYMax()	
{
    if( Size == 0 ) return 0; 
	return (int)ghp->YMax;
}

int 
GlyfData::SetX( int i, int x)
{
    if( Size == 0 ) return 0; 
	gdp->XCoordinates[i] = (Short)x;
	return (int)gdp->XCoordinates[i];
}

int 
GlyfData::SetY( int i, int y)	
{
    if( Size == 0 ) return 0; 
	gdp->YCoordinates[i] = (Short)y;
	return (int)gdp->YCoordinates[i];
}

void GlyfData::CopyList(GlyfData *dest)
{
	if (segCnt == 0) {
		dest->segCnt = 0;
		return;
	}
	if ((dest->segAvail == 0) || (dest->segAvail < segCnt)) {
		if (dest->segPtr != NULL) {
			free(dest->segPtr);
#ifdef _DEBUG
			dest->freeCnt++;
#endif
		}
		dest->segPtr = (SEGMENT_DATA *)malloc(sizeof(SEGMENT_DATA)*segCnt);
		if (dest->segPtr == NULL) {
			dest->segAvail=0;
			return;
		}
		dest->segAvail = segCnt;
#ifdef _DEBUG
		dest->allocCnt++;
#endif
	}
	
	memmove(dest->segPtr, segPtr, sizeof(SEGMENT_DATA)*segCnt);
	dest->segCnt = segCnt;
}

void
GlyfData::Copy(GlyfData *dest)
{
	dest->gh.NumberOfContours = gh.NumberOfContours;
	dest->gh.XMax = gh.XMax;
	dest->gh.XMin = gh.XMin;
	dest->gh.YMax = gh.YMax;
	dest->gh.YMin = gh.YMin;

	dest->Index = Index;
	dest->Offset = Offset;
	dest->Size = Size;

	for(int i = 0; i < gd.MaxPoints; i++) {
		dest->gd.EndPointsOfContours[i] = gd.EndPointsOfContours[i];
		dest->gd.Flags[i] = gd.Flags[i];
		dest->gd.XCoordinates[i] = gd.XCoordinates[i];
		dest->gd.YCoordinates[i] = gd.YCoordinates[i];
	}
	dest->gd.MaxPoints = gd.MaxPoints;
	dest->gd.InstructionLength = gd.InstructionLength;
	CopyList(dest);
	dest->dotValue = dotValue;
	dest->recurse_count = recurse_count;
}

void GlyfData::releaseSegmentData()
{
	segCnt=0;
	dotValue=0;
}
void
GlyfData::ClearData()
{
    Index = 0;
    Offset = 0;
	Size = 0;
	releaseSegmentData();
	memset(&gh, 0, sizeof(GlyfHeader));
	memset(&gd, 0, sizeof(GlyfDescription));
}


void GlyfData::addToList(SEGMENT_DATA *ts)
{
	SEGMENT_DATA *tPtr, *t1Ptr, *lPtr=NULL;
	SEGMENT_DATA tmp;
	int done=0;

	if (segFreeList != NULL) {
		tPtr = segFreeList;
		segFreeList = segFreeList->next;
	}
	else {
		tPtr = (SEGMENT_DATA *)malloc(sizeof(SEGMENT_DATA));
		if (tPtr == NULL) {
			return;
		}
#ifdef _DEBUG
		//allocCnt++;
#endif
	}

	*tPtr = *ts;

	t1Ptr = segList;
	while (t1Ptr) {

		/* If the beginning the current one matches the end of the new */
		if ((t1Ptr->bx == tPtr->ex) && (t1Ptr->by == tPtr->ey)) {
			
			/* Attach the last one if there is one */
			if (lPtr) {
				lPtr->next = tPtr;
			}
			else {
				segList = tPtr;		/* new beginning item */
			}
			tPtr->next = t1Ptr;		/* Connect the current one after the new */
			done++;
			break;
		}
		else if ((t1Ptr->ex == tPtr->bx) && (t1Ptr->ey == tPtr->by)) {
			/* The current ending one matches the beginning of the new one */
			/* Insert into the list */
			tPtr->next = t1Ptr->next;
			t1Ptr->next = tPtr;
			done++;
			break;
		}
#ifndef LATER_WRW
		else if ((t1Ptr->ex == tPtr->ex) && (t1Ptr->ey == tPtr->ey)) {
			/* The current ending one matches the End of the new one */
			/* switch coordinates and match to end */
			/* Insert into the list */
			tmp = *tPtr;
			tPtr->bx = tPtr->ex;
			tPtr->by = tPtr->ey;
			tPtr->ex = tmp.bx;
			tPtr->ey = tmp.by;

			tPtr->next = t1Ptr->next;
			t1Ptr->next = tPtr;
			done++;
			break;

		}
#endif
		else {
			/* Move down the list */
			lPtr = t1Ptr;
			t1Ptr = t1Ptr->next;
		}
	}
	if (!done) {
		/* Just stick it on the beginning */
		tPtr->next = segList;
		segList = tPtr;
	}

	segListCnt++;
}

/* convert the linked list to an array */
/* while freeing up the pieces */
void GlyfData::closeList()
{
	SEGMENT_DATA *newPtr;
	SEGMENT_DATA *tPtr, *t1Ptr;
	int i;
	int didRemove=0;

	/* Get the new list for this one */
	if (segAvail < segListCnt) {
		if (segPtr != NULL) {
			free(segPtr);
#ifdef _DEBUG
			freeCnt++;
#endif
		}
		newPtr = (SEGMENT_DATA *)malloc(sizeof(SEGMENT_DATA)*segListCnt);
		if (newPtr == NULL) {
			return;
		}
		segAvail = segListCnt;
#ifdef _DEBUG
		allocCnt++;
#endif
	}
	else {
		newPtr = segPtr;
	}
#ifdef _DEBUG_WRW
FILE *fp;
fp = fopen("c:\\testoutput.txt", "w");
#endif
	tPtr = segList;
	for(i=0; tPtr && i < segListCnt;i++) {
		newPtr[i] = *tPtr;/* copy the contents */
		newPtr[i].next = NULL;
		didRemove=0;
		if (i) {
			t1Ptr = &newPtr[i-1];
			if (t1Ptr->bx == tPtr->bx) {
				if (t1Ptr->ex == tPtr->ex) {
					if (t1Ptr->by == tPtr->by) {
						if (t1Ptr->ey == tPtr->ey) {
							i--;
							segListCnt--;
							didRemove=1;
						}
					}
				}
			}
		}
		
#ifdef _DEBUG_WRW
		if (didRemove==0)
			fprintf(fp, "[%3.3d, %3.3d][%3.3d, %3.3d]\n", tPtr->bx, tPtr->by, tPtr->ex, tPtr->ey);
#endif
		tPtr = tPtr->next;
	}
	segPtr = newPtr;
#ifdef _DEBUG_WRW
fclose(fp);
#endif
	if (segFreeList != NULL) {
		/* Find the end of the free list and add this new one to it */
		tPtr = segFreeList;
		while (tPtr) {
			if (tPtr->next == NULL) {
				tPtr->next = segList;
				break;
			}
			tPtr = tPtr->next;
		}
	}
	else {
		segFreeList = segList;
	}

	segCnt = segListCnt;
	segListCnt=0;
	segList = NULL;

}


int GlyfData::CreateGlyf()
{
	int sign=-1;	/* temp -- remove when it works */

	recurse_count = 0;	// Init the recursing count for each character drawn
	
	int numcontours = GetNumberOfContours();
	int thiscontour = 0;
    int endpoint = 0;
    
    // Don't draw if there are no contours...
	if( numcontours > 0 ) { 
		endpoint = GetEndPoint(thiscontour); 
		++thiscontour; 
	}
	else { 
		return OK; 
	}

	int MaxPoints = GetMaxPoints();
	int startpoint = 0;
    
	// Draws filled circles at points
	int x1, x2, x3, x4;
	int y1, y2, y3, y4;


	if ((segPtr == NULL) || (segCnt == 0)) {

		for( int i = 1; i < MaxPoints; ++i)	{   
			if( i > endpoint ) {
				if( thiscontour < numcontours )	{
					startpoint = i;
					endpoint = GetEndPoint(thiscontour);
					++thiscontour;
				}
			}
			else if( IsOnCurve(i-1) && IsOnCurve(i)) {
				x1 = GetX(i-1);
				y1 = (-sign*GetY(i-1));

				x3 = GetX(i);
				y3 = (-sign*GetY(i));

				x2 = (x1+x3)/2;
				y2 = (y1+y3)/2;

               	MakeCurve( CPoint(x1,y1), CPoint(x2,y2), CPoint(x3,y3));

			}
			else if( i < startpoint + 2) {
				;
			}
			else if( IsOnCurve(i-2) && IsOffCurve(i-1) && IsOnCurve(i)){
				x1 = GetX(i-2);
				y1 = (-sign*GetY(i-2));

				x2 = GetX(i-1);
				y2 = (-sign*GetY(i-1));

				x3 = GetX(i);
				y3 = (-sign*GetY(i));

				MakeCurve( CPoint(x1,y1),CPoint(x2,y2),CPoint(x3,y3));
			}			 
			else if( IsOnCurve(i-2) && IsOffCurve(i-1) && IsOffCurve(i))	{
				x1 = GetX(i-2);
				y1 = (-sign*GetY(i-2));

				x2 = GetX(i-1);
				y2 = (-sign*GetY(i-1));

				x4 = GetX(i);
				y4 = (-sign*GetY(i));

				x3 = (x2+x4)/2;
				y3 = (y2+y4)/2;

				MakeCurve( CPoint(x1,y1), CPoint(x2,y2), CPoint(x3,y3));
			}			 
			else if( IsOffCurve(i-2) && IsOffCurve(i-1) && IsOnCurve(i))	{
				x4 = GetX(i-2);
				y4 = (-sign*GetY(i-2));

				x2 = GetX(i-1);
				y2 = (-sign*GetY(i-1));

				x3 = GetX(i);
				y3 = (-sign*GetY(i));

				x1 = (x2+x4)/2;
				y1 = (y2+y4)/2;

				MakeCurve( CPoint(x1,y1), CPoint(x2,y2), CPoint(x3,y3));
			}
		}
		closeList();
	}
	return OK;
}


int GlyfData::MakeCurve( CPoint zPt1, CPoint zPt2, CPoint zPt3)
{
	long	p1x=zPt1.x, 
			p1y=zPt1.y,
			p2x=zPt2.x,
			p2y=zPt2.y,
			p3x=zPt3.x,
			p3y=zPt3.y;

    if (recurse_count > 10)	// This at least stops the stack crash
    	return ERROR;

	SEGMENT_DATA newPos;

	double nPointSpace=20;// Distance between 2 points when lines are drawn

    ++recurse_count;

	double aDiff = p1x - p3x;
	double bDiff = p1y - p3y;
	double cDiff = sqrt(aDiff * aDiff + bDiff * bDiff);

	if (cDiff <= nPointSpace) {
		/* Save this segment */
		newPos.bx = p1x;
		newPos.by = p1y;
		newPos.ex = p3x;
		newPos.ey = p3y;
		newPos.next=NULL;
		newPos.onFlag=false;
		addToList(&newPos);

	    recurse_count--;
		return OK;
	}
	
	CPoint r1 = CPoint((p1x+p2x)/2,(p1y+p2y)/2);
	CPoint r2 = CPoint((p2x+p3x)/2,(p2y+p3y)/2);
	CPoint q1 = zPt1;
	CPoint q2 = CPoint((r1.x+r2.x)/2,(r1.y+r2.y)/2);
	CPoint q3 = zPt3;

	// MakeCurve on left half
	MakeCurve( q1, r1, q2);

	// MakeCurve on right half
	MakeCurve( q2, r2, q3);

	recurse_count--;
	return OK;
}


void GlyfData::SetDots(int newDotValue, bool makeSolid)
{

	SEGMENT_DATA *tPtr, *t1Ptr=NULL, *t2Ptr=NULL;
	SEGMENT_DATA *lastSet=NULL;
	int countSinceLast=0;
	int testDraw=0;
	int lastThing, firstThing;
	int i;

	/* Do we need to reset this */
	if (dotValue != newDotValue) {

		tPtr = segPtr;
		for(i=0; i < segCnt; i++) {
			tPtr = &segPtr[i];

			t1Ptr = i ? &segPtr[i-1] : NULL;
			lastThing=0;
			firstThing=0;
			/* First see if this is the first one in a segment */
			if ((t1Ptr == NULL) || (!((tPtr->bx == t1Ptr->ex) && (tPtr->by == t1Ptr->ey)))) {
				firstThing=1;
				testDraw=0;
			}
			else {
				/* Then check if this is the last one of a segment */
				t2Ptr = ((i+1) < segCnt) ? &segPtr[i+1] : NULL;
				if ((t2Ptr == NULL) || (!((tPtr->ex == t2Ptr->bx) && (tPtr->ey == t2Ptr->by)))) {
					lastThing=1;
					testDraw=0;

				}
			}
			if (!testDraw || !newDotValue || ((testDraw % newDotValue) == 0)) {
				tPtr->onFlag = true;
				if (!firstThing) {
					lastSet=tPtr;
				}
				if (lastThing) {
					if ((countSinceLast < (newDotValue/2)) && lastSet) {
						lastSet->onFlag= makeSolid ? true : false;
						lastSet=NULL;
					}
				}
				countSinceLast=0;
			}
			else {
				tPtr->onFlag = makeSolid ? true : false;
				countSinceLast++;
			}
			testDraw++;
		}
		dotValue = newDotValue;
	}
}




#pragma once
#include "afxwin.h"
#include "resource.h"

// CRegistration60 dialog

class CRegistration60 : public CDialog
{
	DECLARE_DYNAMIC(CRegistration60)

public:
	CRegistration60(CWnd* pParent = NULL);   // standard constructor
	virtual ~CRegistration60();

// Dialog Data
	enum { IDD = IDD_REGISTRATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CEdit m_RegistrationValue;
	CString m_RegistrationString;
};

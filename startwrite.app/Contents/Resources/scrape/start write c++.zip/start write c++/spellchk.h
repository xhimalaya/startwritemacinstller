// spellchk.h : header file
//

#if (WINVER < 0x400)
#ifndef _WIN16
#define _WIN16
#endif
#else
#ifndef _WIN32
#define _WIN32
#endif
#endif

#include "ssce.hpp"

/////////////////////////////////////////////////////////////////////////////
// SpellChk dialog

class SpellChk : public CDialog
{
private:

	int SpellCheckError;
	CString LexiconPath;
		
	SSCE_Session ssce;
	SSCE_Lexicon lexicon[3];
	bool isLocalLex;
	
	
// Construction
public:
	SpellChk(CWnd* pParent = NULL);	// standard constructor
	//~SpellChk();

	int GetError();
	int CheckWord(CString word);
	int SetOriginalWord(CString word);
	CString GetCorrectedWord();
	
// Dialog Data
	//{{AFX_DATA(SpellChk)
	enum { IDD = IDD_SPELL_CHECK };
	CString	m_OriginalWord;
	CString	m_CorrectedWord;
	CString	m_replacelist;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(SpellChk)
	afx_msg void OnSuggest();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkSuggestedWords();
	afx_msg void OnOk();
	virtual void OnCancel();
	afx_msg void OnQuit();
	afx_msg void OnAdd();
	afx_msg void OnSelchangeSuggestedWords();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

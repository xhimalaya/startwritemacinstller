// swspace.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swspace.h"
#include "textitem.h"
#include "miscutil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// swspace dialog


swspace::swspace(CWnd* pParent /*=NULL*/)
	: CDialog(swspace::IDD, pParent)
{
	//{{AFX_DATA_INIT(swspace)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void swspace::DoDataExchange(CDataExchange* pDX)
{
	int iSPACEIDs[] = {IDC_SPACE_NORMAL, IDC_SPACE_WIDE};
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(swspace)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	if (pDX->m_bSaveAndValidate)
		GetRadioRowValue(m_hWnd, &m_iSpace, iSPACEIDs, sizeof(iSPACEIDs)/sizeof(int));
	else
		SetRadioRowValue(m_hWnd, m_iSpace, iSPACEIDs, sizeof(iSPACEIDs)/sizeof(int));
}


BEGIN_MESSAGE_MAP(swspace, CDialog)
	//{{AFX_MSG_MAP(swspace)
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDC_SPACE_NORMAL, OnSpaceNormal)
	ON_BN_CLICKED(IDC_SPACE_WIDE, OnSpaceWide)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// swspace message handlers

void swspace::OnOk()
{
	CDialog::OnOK();
}


void swspace::OnSpaceNormal() 
{
}

void swspace::OnSpaceWide() 
{
}

#pragma once


// CColorCombo

class CColorCombo : public CComboBox
{
	DECLARE_DYNAMIC(CColorCombo)

public:
	CColorCombo();
	virtual ~CColorCombo();
	CEdit m_edit;
	CListBox m_listbox;
	COLORREF m_crSelectedColor;
	COLORREF * m_pCustomColors;

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnCbnSetfocus();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnCbnDropdown();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnDestroy();


private:
	HBRUSH m_brushSelectedColor;
};



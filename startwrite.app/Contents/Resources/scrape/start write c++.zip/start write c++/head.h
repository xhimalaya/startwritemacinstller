// Font Header Table Header

#ifndef _HEAD_TABLE_H_
#define _HEAD_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

class HeadTable
{
	private:

	// Note: The ULongs and dates in this header are not fixed yet....
	
	// Head Table
	typedef struct __Table
	{
		Fixed	Version;				// 0x00010000 for version 1.0
		Fixed	FontRevision;			// Set by font manufacturer
		ULong	CheckSumAdjustment;		// Sum font as ULong then store 0xB1B0AFBA - sum
		ULong	MagicNumber;			// Set to 0x5F0F3CF5
		UShort	Flags;					// SEE *
		UShort	UnitsPerEm;				// Range = 16 -> 16384
		ULong	DateTimeCreatedHi;		// International date (8-byte field)
		ULong	DateTimeCreatedLo;		//
		ULong	DateTimeModifiedHi;		// International date (8-byte field)
		ULong	DateTimeModifiedLo;		//
		FWord	XMin;					// For all glyph bounding boxes
		FWord	YMin;					//
		FWord	XMax;					//
		FWord	YMax;					//
		UShort	MacStyle;				// SEE **
		UShort	LowestRecPPEM;			// Smallest readable size in pixels
		Short	FontDirectionHint;		// SEE ***
		Short	IndexToLocFormat;		// 0 for short offsets, 1 for long
		Short	GlyphDataFormat;		// 0 for current format		
	};// Table;

	// * = Flags
	//		Bit 0 = baseline for font at y=0
	//		Bit 1 = left sidebearing at x=0
	//		Bit 2 = instructions my depend on point size
	//		Bit 3 = force ppem to interger values for all internal scaler math
	//				may use fractional ppem sizes if this bit is clear
	//		Bit 4 = instructions may alter advance width
	//				(advance widths may not scale linearly)
	//		Note: All other bits must be zero
	//
	// ** = MacStyle
	//		Bit 0 = bold if set to 1
	//		Bit 1 = italic if set to 1
	//		Bits 2-15 = reserved (set to 0)
	//
	// *** = FontDirectionHint
	//		0 = Fully mixed direction glyphs
	//		1 = Only strongly left to right
	//		2 = Like 1 but also contains neutrals
	//		-1 = Only strongly right to left
	//		-2 = Like -1 but also contains neutrals
	
	
	public:

		__Table Table;
	
		HeadTable();
		~HeadTable();
		
		Short GetIndexToLocFormat();
		
		int 	Read(fstream *fin, DirectoryTable *dir);		
		int 	Print();
};

#endif // _HEAD_TABLE_H_
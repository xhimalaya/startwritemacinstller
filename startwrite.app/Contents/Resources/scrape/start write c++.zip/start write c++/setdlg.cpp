// setdlg.cpp : implementation file
//
#include "stdafx.h"
#include "sw.h"
#include "setdlg.h"

#include "miscutil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetDlg dialog


CSetDlg::CSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetDlg)
	m_strDocPath = "";
	m_strArtPath = "";
	m_YellowGuide = 0;
	//}}AFX_DATA_INIT
}

int iDensityIDs[] = {IDC_DENSITY_25, IDC_DENSITY_50, IDC_DENSITY_75, IDC_DENSITY_100};
int iLinesIDs[] = {IDC_LINES_NONE, IDC_LINES_BOTTOM, IDC_LINES_BOT_TOP, IDC_LINES_ALL};
int iArrowsIDs[] = {IDC_ARROWS_OFF, IDC_ARROWS_ON};
int iYellowIDs[] = {IDC_YELLOW_OFF, IDC_YELLOW_ON};
int iShadingIDs[] = {IDC_SHADING_25, IDC_SHADING_50, IDC_SHADING_75, IDC_SHADING_100};
int iShadeTypeIDs[] = {IDC_SHADE_SHADE, IDC_SHADE_NARROW};

void CSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetDlg)
	DDX_Text(pDX, IDC_EDIT1, m_strDocPath);
	DDX_Text(pDX, IDC_EDIT2, m_strArtPath);
	//}}AFX_DATA_MAP

	//	DDX_Radio(pDX, IDC_YELLOW_OFF, m_YellowGuide);

	if (pDX->m_bSaveAndValidate) {
		GetRadioRowValue(m_hWnd, &m_iDensity, iDensityIDs, sizeof(iDensityIDs)/sizeof(int));
		GetRadioRowValue(m_hWnd, &m_iLines, iLinesIDs, sizeof(iLinesIDs)/sizeof(int));
		GetRadioRowValue(m_hWnd, &m_iArrows, iArrowsIDs, sizeof(iArrowsIDs)/sizeof(int));
		GetRadioRowValue(m_hWnd, &m_YellowGuide, iYellowIDs, sizeof(iYellowIDs)/sizeof(int));
		GetRadioRowValue(m_hWnd, &m_iShading, iShadingIDs, sizeof(iShadingIDs)/sizeof(int));
		GetRadioRowValue(m_hWnd, &m_iShadeType, iShadeTypeIDs, sizeof(iShadeTypeIDs)/sizeof(int));
	}
	else {
		if (m_YellowGuide == 0) {	// Valid values are 1, 2
			m_YellowGuide++;
		}
		SetRadioRowValue(m_hWnd, m_iDensity, iDensityIDs, sizeof(iDensityIDs)/sizeof(int));
		SetRadioRowValue(m_hWnd, m_iLines, iLinesIDs, sizeof(iLinesIDs)/sizeof(int));
		SetRadioRowValue(m_hWnd, m_iArrows, iArrowsIDs, sizeof(iArrowsIDs)/sizeof(int));
		SetRadioRowValue(m_hWnd, m_YellowGuide, iYellowIDs, sizeof(iYellowIDs)/sizeof(int));
		SetRadioRowValue(m_hWnd, m_iShading, iShadingIDs, sizeof(iShadingIDs)/sizeof(int));
		SetRadioRowValue(m_hWnd, m_iShadeType, iShadeTypeIDs, sizeof(iShadeTypeIDs)/sizeof(int));
	}
}

BEGIN_MESSAGE_MAP(CSetDlg, CDialog)
	//{{AFX_MSG_MAP(CSetDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CSetDlg message handlers


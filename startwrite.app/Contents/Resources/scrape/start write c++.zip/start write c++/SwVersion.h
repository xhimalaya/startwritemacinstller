// SW Version -- CHange Log

	// 6.0.49 (05/31/11)
	// Added saving serial to conf file for network version
	// switch registration to HKEY_LOCAL_MACHINE

	// 6.0.48 (05/25/11)
	// changed trial about dialog graphic to startwrite60trial.jpg
	// after trying to figure out the empty dialog

	// 6.0.47 (05/23/11)
	// Ability to read the licenses text live
	// SERIAL number support added 14 characters
	// BOX Scoot and  Scroll wheel fixes -- commented ouot for upgrade.

	// 6.0.45 (03/09/11)
	// purchase button added
	// so not to confuse activate
	// Fix number keys in font size pulldown
	// Hard EndOfLine fix

	// 6.0.44
	// Fixes for flowing txt and "cut"

	//Version 6.0.43
	// Added Flowing text between boxes
	// Stop moving boxes off off page

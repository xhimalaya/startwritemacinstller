// Location Table Header

#ifndef _LOCA_TABLE_H_
#define _LOCA_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

class LocaTable
{
	private:

	Short	Format;
	UShort	NumGlyphs;

	char 	*Offsets;
	UShort	*UShortOffsets;
	ULong	*ULongOffsets;
	
	void FreeMem();
	
	public:
	
		LocaTable();
		~LocaTable();
		                            
		int GetOffset( ULong* offset, ULong index);		                            
		                            
		ULong GetOffset( ULong index, int *status);
		
		int 	Read(fstream *fin, DirectoryTable *dir,
						Short format, UShort numglyphs);		
		int 	Print();
};

#endif // _LOCA_TABLE_H_
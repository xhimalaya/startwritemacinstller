// colorcombo.cpp : implementation file
//

#include "stdafx.h"
#include "colorcombo.h"
#include "colordlg.h"
#include "resource.h"

// CColorCombo

IMPLEMENT_DYNAMIC(CColorCombo, CComboBox)

CColorCombo::CColorCombo()
{
	m_crSelectedColor = RGB(255, 255, 255);
	m_pCustomColors = NULL;
}

CColorCombo::~CColorCombo()
{
}

BEGIN_MESSAGE_MAP(CColorCombo, CComboBox)
	ON_WM_CTLCOLOR()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_DESTROY()
END_MESSAGE_MAP()



// CColorCombo message handlers



HBRUSH CColorCombo::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CComboBox::OnCtlColor(pDC, pWnd, nCtlColor);
	if (nCtlColor == CTLCOLOR_EDIT)
	{
		if (m_edit.GetSafeHwnd() == NULL)
		{
			m_edit.SubclassWindow(pWnd->GetSafeHwnd());
		}
		m_brushSelectedColor = ::CreateSolidBrush(m_crSelectedColor);
		hbr = m_brushSelectedColor;
		pDC->SetBkColor(m_crSelectedColor);
		m_edit.EnableWindow(0);
	}
	if (nCtlColor == CTLCOLOR_STATIC)
	{
		m_brushSelectedColor = ::CreateSolidBrush(m_crSelectedColor);
		hbr = m_brushSelectedColor;
		pDC->SetBkColor(m_crSelectedColor);
	}
	else if (nCtlColor == CTLCOLOR_LISTBOX)
	{
		if (m_listbox.GetSafeHwnd() == NULL)
		{
			m_listbox.SubclassWindow(pWnd->GetSafeHwnd());
		}
	}

	// TODO:  Change any attributes of the DC here

	// TODO:  Return a different brush if the default is not desired
	return hbr;
}

void CColorCombo::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default

	CComboBox::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CColorCombo::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default

	CComboBox::OnLButtonDown(nFlags, point);

	CRect rc;
	GetClientRect(&rc);
	ClientToScreen(&rc);

	// Save the current custom colors in case the user clicks Cancel
	COLORREF crSaveCustom[16];
	int i;
	if (m_pCustomColors != NULL) {
		for (i=0; i<16; i++) {
			crSaveCustom[i] = m_pCustomColors[i];
		}
	}
	CColorDlg dlgColorChoice;
	dlgColorChoice.m_pos = CPoint(rc.left, rc.bottom/2);	// /2 to keep the bottom one from going off the screen
	if (m_pCustomColors != NULL) {
		dlgColorChoice.m_cc.lpCustColors = m_pCustomColors;
	}
	dlgColorChoice.m_cc.rgbResult = m_crSelectedColor;
	int nRet = dlgColorChoice.DoModal();
	if (nRet != IDCANCEL) {// they clicked OK, so retrieve the color. New custom colors were already returned
		m_crSelectedColor = dlgColorChoice.GetColor();
	}
	else if (m_pCustomColors != NULL) {// if they Cancelled, restore the old Custom Colors
		for (i=0; i<16; i++) {
			m_pCustomColors[i] = crSaveCustom[i];
		}
	}

	this->Invalidate(0);
    NMHDR nmh;
    nmh.code = NM_CLICK;
    nmh.idFrom = GetDlgCtrlID();
    nmh.hwndFrom = m_hWnd;
    GetParent()->SendMessage(WM_NOTIFY, GetDlgCtrlID(), (LPARAM) &nmh);
	//work here
}

BOOL CColorCombo::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: Add your message handler code here and/or call default

	return CComboBox::OnSetCursor(pWnd, nHitTest, message);
}

void CColorCombo::OnDestroy()
{
	if (m_edit.GetSafeHwnd() != NULL)
	{
		m_edit.UnsubclassWindow();
	}
	if (m_listbox.GetSafeHwnd() != NULL)
	{
		m_listbox.UnsubclassWindow();
	}
	CComboBox::OnDestroy();

	// TODO: Add your message handler code here
}

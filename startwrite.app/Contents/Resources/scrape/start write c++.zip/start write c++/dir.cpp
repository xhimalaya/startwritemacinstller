// TrueType DirectoryTable

#include "stdafx.h"
#include "Dir.h"

DirectoryTable::DirectoryTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER DirectoryTable::DirectoryTable()"); 
	#endif

	Table.SNFTVersion = 0;
	Table.NumTables = 0;
	Table.SearchRange = 0;
	Table.EntrySelector = 0;
	Table.RangeShift = 0;

	Entries = NULL;
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT DirectoryTable::DirectoryTable: void"); 
	#endif
}

DirectoryTable::~DirectoryTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER DirectoryTable::~DirectoryTable()"); 
	#endif

	// malloc #1
	if (Entries)
		free(Entries);
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT DirectoryTable::~DirectoryTable: void"); 
	#endif
}

int
DirectoryTable::GetTag(char *tag)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER DirectoryTable::GetTag(char*)"); 
	#endif

	int i = 0;
	char string[5];
	DirectoryEntry *entry;

	for( i = 0; i < (int)Table.NumTables; ++i)
    {
		entry = Entries + i;
		string[0] = entry->Tag0;
		string[1] = entry->Tag1;  
		string[2] = entry->Tag2;
		string[3] = entry->Tag3;
		string[4] = '\0';
		
		if( !strcmp( tag, string))
		{		
#ifdef _CRT_SECURE_NO_DEPRECATE
			strcpy(CurrentTag,string);
#else
			strcpy_s(CurrentTag,sizeof(CurrentTag),string);
#endif
			
			CurrentCheckSum = entry->CheckSum;
			CurrentOffset = entry->Offset;
			CurrentLength = entry->Length;
			
			return OK;		
		}		
 	}
 	
	return ERROR;
}

ULong
DirectoryTable::GetCheckSum()
{
	return CurrentCheckSum;
}

ULong
DirectoryTable::GetOffset()
{
	return CurrentOffset;
}

ULong 
DirectoryTable::GetLength()
{
	return CurrentLength;
}

int
DirectoryTable::Read(fstream *fin)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER DirectoryTable::Read(ifstream)"); 
	#endif

	// Read directory table

	// IMPORTANT!!! PROBLEM WITH TEXT AFTER COLOR BMPS SEEMS TO START HERE!!!
	// NEED TO PROVE THAT MEM ALIGNMENT IS OKAY - JRL 10/8/97
	
	// Directory table begins at byte 0
	fin->seekg(0); 
	fin->read( (char *)&Table, sizeof(Table));


	//char string[128];
    //sprintf(string,"PTR = %x", &Table);
    //Report( TO_LIST, "%s", string);
	
	// Swab the shorts...
    myswab((unsigned char *)&Table, sizeof(Table));
    
    
    // Directory entries (begin after directory table)
    // malloc #1
	if (Entries)
		free(Entries);
    
    Entries = (DirectoryEntry *)malloc( (Table.NumTables * sizeof(DirectoryEntry)));
	if( Entries == NULL)
	{
		Report( TO_LIST, "ERROR DirectoryTable::Read: Malloc #1 == NULL"); 
		return ERROR;		
	}

	fin->read( (char *)Entries, Table.NumTables * sizeof(DirectoryEntry));
	
	// Swab the entries...
	myswab((unsigned char *)Entries, Table.NumTables * sizeof(DirectoryEntry));
	
	// Swap the His & Los of the longs...
	{
		int i = 0;
		DirectoryEntry_LE *entry;
		unsigned short tmp;    
    	for( i = 0; i < (int)Table.NumTables; ++i)
    	{
			entry = (DirectoryEntry_LE *)Entries + i;
 			tmp = entry->TagHi; entry->TagHi = entry->TagLo; entry->TagLo = tmp;
 			tmp = entry->CheckSumHi; entry->CheckSumHi = entry->CheckSumLo; entry->CheckSumLo = tmp;
 			tmp = entry->OffsetHi; entry->OffsetHi = entry->OffsetLo; entry->OffsetLo = tmp;
 			tmp = entry->LengthHi; entry->LengthHi = entry->LengthLo; entry->LengthLo = tmp;
 		}	
 	}

    return OK;
}

int
DirectoryTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER DirectoryTable::Print()"); 
	#endif
	
	cout << "** Directory **" << endl;
	cout << "SNFTVersion:\t" << Table.SNFTVersion << endl;
	cout << "NumTables:\t" << Table.NumTables << endl;
	cout << "SearchRange:\t" << Table.SearchRange << endl;
	cout << "EntrySelectory:\t" << Table.EntrySelector << endl;
	cout << "RangeShift:\t" << Table.RangeShift << endl;

	cout << "\n** Table Directory Entries **" << endl;
	{
		int i = 0;
		DirectoryEntry *entry = Entries;
		for( i = 1; i <= (int)Table.NumTables; ++i)
		{
			if( i < 10 ) cout << " ";
			//cout << setfill(' ') << cout << setw(3);
			cout << i << ":";
			cout << "  " << entry->Tag0 << entry->Tag1 << entry->Tag2 << entry->Tag3;
			cout << "\tCheckSum=0x";
			//cout << setfill('0') << setw(8);
			cout << hex	<< entry->CheckSum;
			cout << "\tOffset=0x";
			//cout << setfill('0') << setw(8);
			cout << hex << entry->Offset;
			cout << "\tLength=";
			cout << dec << entry->Length;
			cout << endl;
			++entry;
		}
	}
	
	return OK;
}
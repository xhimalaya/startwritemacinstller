// kern.h
// Get the kerning tables in the font

#ifndef _KERN_TABLE_H_
#define _KERN_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

typedef struct kerntab {
	UShort LeftG;
	UShort RightG;
	Short	kernVal;
} KERNTAB;


class KernTable
{
	private:

	Short	Format;
	UShort	NumPairs;

	KERNTAB *KernTabP;

	char 	*Offsets;
	
	void FreeMem();
	
	public:
	
		KernTable();
		~KernTable();
		
		Short GetKerning(UShort cleft, UShort cright);	// return kern for this pair
		
		int 	Read(fstream *fin, DirectoryTable *dir);
		//				Short format, UShort numglyphs);		
		int 	Print();
};



#endif

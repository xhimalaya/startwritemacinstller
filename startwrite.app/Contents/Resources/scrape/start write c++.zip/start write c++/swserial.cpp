// swSerial.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swSerial.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// swSerial dialog


swSerial::swSerial(CWnd* pParent /*=NULL*/)
	: CDialog(swSerial::IDD, pParent)
{
	//{{AFX_DATA_INIT(swSerial)
	m_SerialNumber = _T("");
	//}}AFX_DATA_INIT
}


void swSerial::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(swSerial)
	DDX_Text(pDX, IDC_EDIT1, m_SerialNumber);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(swSerial, CDialog)
	//{{AFX_MSG_MAP(swSerial)
	ON_BN_CLICKED(IDOK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// swSerial message handlers

void swSerial::OnOk() 
{
	// TODO: Add your control notification handler code here
	// Check the serial number
	char buf[36];

	strncpy(buf, m_SerialNumber, 35);
	if (theApp.isValidSerial(buf)) {
		theApp.setValidSerial(buf);
		CDialog::OnOK();
	}
}

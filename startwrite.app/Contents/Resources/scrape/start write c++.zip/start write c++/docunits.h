// Unit defines for the document/page/etc... classes

// These number are based on TWIPS defined in Windows...
// TWIPS = 1/20 point = 1/1440 inch

#define MAX_PAGES	300
#define MAX_BBOXES	72

// These are _logical_ pixels...

#define DOC_X_EXTENT			1440
#define DOC_Y_EXTENT			1440

#define PIXELS_PER_INCH			1440

//#ifdef SW_SHERSTON
#define PAGE_A1_HT	((float)11.19)
#define PAGE_A1_WD	((float)7.77)
#define PAGE_US_HT	((float)10.5)
#define PAGE_US_WD	((float)8.0)

//#define DOC_X_INCHES	7.77
//#define DOC_Y_INCHES	11.19
//#else
//#define DOC_X_INCHES	8
//#define DOC_Y_INCHES	10.5
//#endif
//#define DOC_X_PIXELS	(DOC_X_INCHES * PIXELS_PER_INCH)
//#define DOC_Y_PIXELS	(DOC_Y_INCHES * PIXELS_PER_INCH)

#define DOC_X_BORDER_PIXELS		(100)
#define DOC_Y_BORDER_PIXELS		(100)

//#define PAGE_X_PIXELS	((PAGE_X_INCHES * PIXELS_PER_INCH) - DOC_X_BORDER_PIXELS)
//#define PAGE_Y_PIXELS	((PAGE_Y_INCHES * PIXELS_PER_INCH) - DOC_Y_BORDER_PIXELS)

#define PAGE_A1_X_PIXELS	((PAGE_A1_WD * PIXELS_PER_INCH) - DOC_X_BORDER_PIXELS)
#define PAGE_A1_Y_PIXELS	((PAGE_A1_HT * PIXELS_PER_INCH) - DOC_Y_BORDER_PIXELS)

#define PAGE_US_X_PIXELS	((PAGE_US_WD * PIXELS_PER_INCH) - DOC_X_BORDER_PIXELS)
#define PAGE_US_Y_PIXELS	((PAGE_US_HT * PIXELS_PER_INCH) - DOC_Y_BORDER_PIXELS)

#define MIN_ZOOM	20
#define MAX_ZOOM	150


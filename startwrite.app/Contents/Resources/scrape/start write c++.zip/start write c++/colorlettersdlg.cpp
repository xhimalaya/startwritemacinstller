// colorlettersdlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "fontdlg.h"
#include "miscutil.h"
#include "colorlettersdlg.h"

extern unsigned int defaultFont;

// CColorLettersDlg dialog

IMPLEMENT_DYNAMIC(CColorLettersDlg, CDialog)

CColorLettersDlg::CColorLettersDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CColorLettersDlg::IDD, pParent)
	, m_SetAsDefault(false)
{
	m_pCustomColors = NULL;
	m_crFirst = RGB(255, 255, 255);

	m_crSecond = RGB(252, 252, 0);// Default is a legacy custom yellow color

	m_crThird = RGB(255, 255, 255);

	m_pBox = new BBox;
	m_pTextItem = NULL;
}

CColorLettersDlg::~CColorLettersDlg()
{
	if (m_pBox)
		delete m_pBox;
}

void CColorLettersDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COLORCOMBO_FIRST, m_ColorComboFirst);
	DDX_Control(pDX, IDC_COLORCOMBO_SECOND, m_ColorComboSecond);
	DDX_Control(pDX, IDC_COLORCOMBO_THIRD, m_ColorComboThird);
	DDX_Control(pDX, IDC_COLORCOMBO_FOURTH, m_ColorComboFourth);
	if (pDX->m_bSaveAndValidate){
	}
	else {
		InitPreview();
	}
}


BEGIN_MESSAGE_MAP(CColorLettersDlg, CDialog)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_SET_COLORLINES_DEFAULT, &CColorLettersDlg::OnBnClickedSetColorlinesDefault)
END_MESSAGE_MAP()


// CColorLettersDlg message handlers
BOOL CColorLettersDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_ColorComboFirst.m_crSelectedColor = m_crFirst;
	m_ColorComboFirst.m_pCustomColors = m_pCustomColors;
	m_ColorComboSecond.m_crSelectedColor = m_crSecond;
	m_ColorComboSecond.m_pCustomColors = m_pCustomColors;
	m_ColorComboThird.m_crSelectedColor = m_crThird;
	m_ColorComboThird.m_pCustomColors = m_pCustomColors;
	m_ColorComboFourth.m_crSelectedColor = m_crFourth;
	m_ColorComboFourth.m_pCustomColors = m_pCustomColors;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CColorLettersDlg::InitPreview()
{
	int status;
	int saveGrow;
	CString strToAdd;
	int testSize = theApp.m_defPoint;

	testSize = testSize * 1440 / 72;

	// TextItem should be set by the caller, but if it is null, create it
	if (m_pTextItem == NULL) {
		m_pTextItem = new TextItem();
	}
	m_pBox->Message(BBOX_ITEM_SET, m_pTextItem, &status);
	m_pTextItem->Message(ITEM_PARENT_SET, m_pBox, &status);

	RECT 		rect;
	CPaintDC	dc(this);
	CWnd		*pPreview = GetDlgItem(IDC_COLORLETTERS_PREVIEW);

	pPreview->GetClientRect(&rect);
	m_rectPreview = rect;
	pPreview->MapWindowPoints(this, &m_rectPreview);

	// Give the 3D look stuff some room.
	InflateRect(&rect, -2, -2);

	PrepareDC(&dc);
	dc.DPtoLP(&rect);
	m_rectBox = rect;

	int middle = (rect.bottom + rect.top)/2;
	middle += testSize;
	if (middle > rect.top) {
		middle = rect.top;
	}

	m_pBox->Message(BBOX_POSITION_SET, CPoint(rect.left, middle), &status);
	saveGrow = m_pBox->Message(BBOX_CAN_GROW, 1, &status);
	m_pBox->Message(BBOX_SET_GROW, 1, &status);
	
	m_pBox->Message(BBOX_SIZE_SET, 
		CPoint((rect.right - rect.left) * 4, 
		(rect.bottom - rect.top) * 4), 
		&status);
	
	m_pBox->Message(BBOX_SET_GROW, saveGrow, &status);

	m_pBox->Message(BBOX_VISIBLE_SET, TRUE, &status);
	m_pBox->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);

	m_pBox->Message(ITEM_ENTER_EDIT_MODE, EMPTY_INT, &status);

	strToAdd = "Mw";

	m_pTextItem->sFontName = theApp.m_defFont;
	m_pTextItem->sFontIndex = defaultFont;
	m_pTextItem->nPointSize = 48; //theApp.m_defPoint;
	m_pTextItem->SetViaMembers();

	m_pTextItem->nAnnoyingFontMsg = TRUE;
	m_pTextItem->nAnnoyingArrowMsg = TRUE;
	m_pTextItem->nAnnoyingOverlayMsg = TRUE;
	m_pTextItem->nOverfullWarning = FALSE;

	for (int i = 0; i < strToAdd.GetLength(); i++)
		m_pTextItem->KeyDown(strToAdd[i], &status);
}

void CColorLettersDlg::PrepareDC(CDC *pDC)
{
	pDC->SetMapMode(MM_ANISOTROPIC);

	pDC->SetWindowExt( DOC_X_EXTENT, DOC_Y_EXTENT);

	pDC->SetViewportExt((int)(pDC->GetDeviceCaps(LOGPIXELSX) * (100 / 100)),
		(int)(-pDC->GetDeviceCaps(LOGPIXELSY) * (100 / 100)));
}

void CColorLettersDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	DrawTextItem(&dc);
}

BOOL CColorLettersDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	if (wParam == IDC_COLORCOMBO_FIRST) {
		m_crFirst = m_ColorComboFirst.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_SECOND) {
		m_crSecond = m_ColorComboSecond.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_THIRD) {
		m_crThird = m_ColorComboThird.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_FOURTH) {
		m_crFourth = m_ColorComboFourth.m_crSelectedColor;
		UpdateTextItem();
	}
	return CDialog::OnNotify(wParam, lParam, pResult);
}

extern void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);

void CColorLettersDlg::DrawTextItem(CDC *pDC)
{
	int 		status;
	BOOL		bDelete;     

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	// First draw the 3D look stuff.
	CPen 	*ppenOld,
			pen;

	// We need to clear the window first
	int testSize = theApp.m_defPoint;

	testSize = testSize * 1440 / 72;

	int middle = (m_rectBox .bottom + m_rectBox .top)/2;
	middle += testSize;
	if (middle > m_rectBox .top) {
		middle = m_rectBox .top;
	}
	m_pBox->Message(BBOX_POSITION_SET, CPoint(m_rectBox .left, middle), &status);

	// Dk gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNSHADOW));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.left, m_rectPreview.top);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Black
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNTEXT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.left + 1, m_rectPreview.top + 1);
	pDC->LineTo(m_rectPreview.right - 2, m_rectPreview.top + 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Lt gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNFACE));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// White
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNHIGHLIGHT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	CDC		dcTemp;   
	CBrush *holdBrush;
	CBitmap	bmpTemp,
				*pbmpOld;
	RECT		rectBmp = {0, 0, 
								(m_rectPreview.right - m_rectPreview.left) * 4, 
								(m_rectPreview.bottom - m_rectPreview.top) * 4};

	if (dcTemp.CreateCompatibleDC(NULL) == FALSE) {
		return;
	}
	if (bmpTemp.CreateCompatibleBitmap(pDC, rectBmp.right, rectBmp.bottom) == FALSE) {
		return;
	}

	pbmpOld = dcTemp.SelectObject(&bmpTemp);
	if (pbmpOld == NULL) {
		return;
	}

	holdBrush = (CBrush *) GetStockObject(HOLLOW_BRUSH);
	if (holdBrush == NULL) {
		return;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) dcTemp.SelectStockObject(NULL_PEN);

	dcTemp.SelectStockObject(WHITE_BRUSH);
	dcTemp.Rectangle(&rectBmp);
	dcTemp.SelectObject(oldpen);		// Restore pen

	// Get the DC ready.
	PrepareDC(&dcTemp);

	m_pTextItem->Draw(&dcTemp, &status);

   // Now blt the TextItem stuff onto the preview area.
	dcTemp.SelectObject(pbmpOld);


	DrawBitmap(pDC->m_hDC, (HBITMAP) bmpTemp.m_hObject, 
		m_rectPreview.left + 2, m_rectPreview.top + 2, SRCCOPY,
		m_rectPreview.right - m_rectPreview.left - 4,
		m_rectPreview.bottom - m_rectPreview.top - 4
		);

	dcTemp.DeleteDC();
	bmpTemp.DeleteObject();

	if (bDelete)
		delete pDC;
}

void CColorLettersDlg::UpdateTextItem()
{
	m_pTextItem->ColorFirstStrokeLetters = m_crFirst;
	m_pTextItem->ColorSecondStrokeLetters = m_crSecond;
	m_pTextItem->ColorThirdStrokeLetters = m_crThird;
	m_pTextItem->ColorFourthStrokeLetters = m_crFourth;

	m_pTextItem->SetViaMembers();

	DrawTextItem();
}


void CColorLettersDlg::OnBnClickedSetColorlinesDefault()
{
	m_SetAsDefault = !m_SetAsDefault;
}

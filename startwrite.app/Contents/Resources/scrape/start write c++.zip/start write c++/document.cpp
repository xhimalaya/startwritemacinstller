// Document Class Implementation

#include "document.h"
#include "sw.h"
#include "miscutil.h"

extern void setPrintOrientation(short);

Document::Document()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::Document()"); 
	#endif

	// Zoom = 100% of page size
	Zoom = 	theApp.GetProfileInt("Settings", "ZoomSetting", 100);
	if (Zoom > 0) {
		dCurrentZoom = ((float)Zoom / (float)100.0);
	}
	else  {
		dCurrentZoom = 1.0;
	}
	nPaper = PAGE_PAPER_LETTER;

	nOrientation = PAGE_ORIENTATION_PORTRAIT;
	setPrintOrientation(DMORIENT_PORTRAIT);

	// All pages are non-existant
	for(int i=0; i < MAX_PAGES + 1; ++i) { 
		pPages[i] = NULL; 
	}

	// The document starts without any pages
	nTotalPages = 0;

	nCurrentPage = 0;
	pCurrentPage = NULL;

	// The document starts without any stories
	nTotalStoryBoxes = 0;
	theApp.m_strStoryOverflowText.Empty();
	theApp.m_strStoryDistributeText.Empty();
	theApp.m_strStoryOverflowShapes.Empty();
	theApp.m_strStoryDistributeShapes.Empty();
	theApp.m_bInStoryDistributeMode = FALSE;
	theApp.m_bInStoryCollectMode = FALSE;
	theApp.m_iStoryOverflowDirection = 0;
	theApp.m_iStoryOverflowBox = 0;
	theApp.m_bStoryTextWasMoved = FALSE;
	theApp.m_nStoryMoveCursorBox = 0;
	theApp.m_nStoryMoveCursorIndex = 0;

	bRestoreBorderArt = TRUE;

	memcpy(this->CustomPalette, theApp.m_crDefaultCustomPalette, sizeof(this->CustomPalette));

	theApp.m_isGridVisible = FALSE;
	theApp.m_isGridSnapTo = FALSE;
	theApp.m_isGridWiped = FALSE;
	theApp.m_iGridHotX = 0;
	theApp.m_iGridHotY = 0;
	theApp.m_iGridMaxX = 0;
	theApp.m_iGridMaxY = 0;
	for (int i = 0; i < 50; i++) {
		theApp.m_iGridX[i] = 0;
		theApp.m_iGridXUsed[i] = 0;
	}
	for (int i = 0; i < 50; i++) {
		theApp.m_iGridY[i] = 0;
		theApp.m_iGridYUsed[i] = 0;
	}
	NeedsOverlapCheck = FALSE;

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::Document"); 
	#endif
}

Document::~Document()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::~Document()"); 
	#endif

	for(int i=0; i < MAX_PAGES + 1; ++i) { 
		if (pPages[i] != NULL)
			delete pPages[i];
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::~Document"); 
	#endif
}

void
Document::Delete()
{
	delete this;
}

void
Document::Read(fstream *fin, Module *pmodule, int *status)
{
	char line[128];
	int newZoom = Zoom;
	int currPage = 1;
	
	pmodule;	/* get rid of compiler warning */

	while( ! fin->eof())	{
		fin->getline( line, 128, SWD_EQ);

		//wsprintf(string,"Doc Tag = %s", line);
		//AfxMessageBox(string);

		if( strcmp(line,SWD_BEGINSWD) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_VERSION) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_BEGINDOC) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_ZOOM) == S1_EQUALS_S2)
		{            
			*fin >> newZoom;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_PAPER) == S1_EQUALS_S2)
		{            
			*fin >> nPaper;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_ORIENTATION) == S1_EQUALS_S2)
		{
			*fin >> nOrientation;
			setPrintOrientation((short)((nOrientation == PAGE_ORIENTATION_LANDSCAPE) 
									? DMORIENT_LANDSCAPE : DMORIENT_PORTRAIT ));
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_TOTALPAGES) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_CURRENTPAGE) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			currPage = atoi(line);	
		}
		else if ( strcmp(line, SWD_CUSTOMPALETTE) == S1_EQUALS_S2) {
			for (int ndx = 0; ndx < 16; ndx++) {
				*fin >> CustomPalette[ndx];
				fin->getline( line, 128, SWD_NL_);
			}
		}
		else if( strcmp(line,SWD_ENDDOC) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			break;
		}
		else if( strcmp(line,SWD_BEGINPAGE) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			int ncp = DocPageNew( DOC_PAGE_LAST, 0, status);

			if( *status == OK)
			{
				pPages[ncp]->Read( fin, NULL, status);
				if (ncp == 1)   
					pPages[1]->Message(PAGE_ACTIVATED, 0, status);
			}
		}
		else
		{
			*status = ERROR;
			return;
		}
//		else
//		{
//			AfxMessageBox("Unknown token in document!");
//		}
	}

//	if (newZoom != Zoom)
//		Message(DOC_ZOOM_SET, newZoom, status);	// Make sure zoom is set
	SetStoryItemsOrder();
	nCurrentPage = 1;	// just set to page one now, later maybe use currPage
	*status = OK;
}

void
Document::Write(fstream *fout, Module *pmodule, int *status)
{
	pmodule;	/* get rid of compiler warning */

	*fout << SWD_BEGINSWD 	<< SWD_EQ << "*" 			<< SWD_NL;
	*fout << SWD_VERSION 	<< SWD_EQ << "2.1"	 		<< SWD_NL;	// VERSION number is here
	*fout << SWD_BEGINDOC 	<< SWD_EQ << "*" 			<< SWD_NL;

	*fout << SWD_ZOOM 		<< SWD_EQ << Zoom 			<< SWD_NL;
	*fout << SWD_PAPER		<< SWD_EQ << nPaper		 	<< SWD_NL;
	*fout << SWD_ORIENTATION << SWD_EQ << nOrientation 	<< SWD_NL;
	*fout << SWD_TOTALPAGES 	<< SWD_EQ << nTotalPages 	<< SWD_NL;
	*fout << SWD_CURRENTPAGE << SWD_EQ << nCurrentPage 	<< SWD_NL;

	*fout << SWD_CUSTOMPALETTE	<< SWD_EQ	<< CustomPalette[0] << SWD_NL;
	for (int ndx = 1; ndx < 16; ndx++) {
		*fout << CustomPalette[ndx] << SWD_NL;
	}
    
	for(int i=0; i < MAX_PAGES + 1; ++i) 
	{ 
		if( pPages[i] != NULL)
		{
			pPages[i]->Write( fout, NULL, status);
		}
	}

	*fout << SWD_ENDDOC 	<< SWD_EQ << "*"	<< SWD_NL;
	*fout << SWD_ENDSWD 	<< SWD_EQ << "*"	<< SWD_NL;

	*status = OK;
}

int Document::WhatIsAtPoint(POINT pt)
{
	if (!pCurrentPage)
		return 0;

	int 	status;
	BBox	*pBox = pCurrentPage->GetBBoxAtPoint(pt);
	POINT	ptWhat;

	if (!pBox)
		return 0;

	ptWhat = pBox->Message(BBOX_WHAT_IS_AT_POINT, pt, &status);

	return ptWhat.x;
}

BBox *Document::GetCurrentBox()
{
	if (!pPages[nCurrentPage])
		return NULL;

	return pPages[nCurrentPage]->GetCurrentBox();
}

TextItem *Document::GetStoryItem(int orderNumber, int *onCurrentPage, int *onPageNumber)
{
	TextItem *pItem = NULL;
	if (!pPages[nCurrentPage])
		return pItem;
		int startPage = orderNumber < 1 ? nCurrentPage : 1;
		for (int nPage = startPage; nPage <= nTotalPages; ++nPage)
		{
			pItem = pPages[nPage]->GetStoryItem(orderNumber);
			if (pItem != NULL) {
				*onPageNumber = nPage;
				if (nPage == nCurrentPage) {
					*onCurrentPage = 1;
				}
				break;
			}
		}

	return pItem;
}

float Document::Message(int message, float number, int *status)
{
	number; 	/* get rid of compiler warning */
	message;	/* get rid of compiler warning */


	*status = 0;
	return((float)0.0);
}

int 
Document::Message( int message, int number, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::Message(int,int,int*)"); 
	#endif

	// Return Integer
	int RI = 0;
	int i = 0;

	CPoint cpTemp(0, 0);

	switch(message)
	{

        case DOC_NONE:
        	*status = ERROR;
        break;

		case DOC_ZOOM_GET:
			RI = Zoom;
			*status = OK;
		break;

		case DOC_ZOOM_SET:
			if (number > MAX_ZOOM)
				number = MAX_ZOOM;
			else if (number < MIN_ZOOM)
				number = MIN_ZOOM;

			if( number != Zoom) {
				RI = Zoom;
				Zoom = number;
				dCurrentZoom  = (float)((float)number / 100);
				*status = OK;

				pPages[nCurrentPage]->Message(ART_SET_RELOAD, TRUE, status);
				pPages[nCurrentPage]->Message(ART_SET_SCROLL, cpTemp, status);
				pPages[nCurrentPage]->Message(TEXT_SET_BORDER_ART_SCROLL, cpTemp, status);
				pPages[nCurrentPage]->Message(PAGE_UPDATE_OVERLAP, 0, status);
				bRestoreBorderArt = TRUE;
			}
		break;

		case PAGE_ORIENTATION_ROTATE:
			RI = nOrientation;
			if (number == 1) {
				setPrintOrientation((short)((nOrientation == PAGE_ORIENTATION_LANDSCAPE) 
									? DMORIENT_LANDSCAPE : DMORIENT_PORTRAIT ));
			}
			else if( nOrientation == PAGE_ORIENTATION_PORTRAIT) {
				nOrientation = PAGE_ORIENTATION_LANDSCAPE;
				setPrintOrientation(DMORIENT_LANDSCAPE);
			}
			else {
				nOrientation = PAGE_ORIENTATION_PORTRAIT;
				setPrintOrientation(DMORIENT_PORTRAIT);
			}


			// Must adjust each page...
			for(i = 1; i <= nTotalPages; ++i) {
				pPages[i]->Message( PAGE_CHANGE_ORIENTATION, nOrientation, status);
			}

			*status = OK;
		break;

		case DOC_PAGE_TOTAL_GET:
			RI = nTotalPages;
			*status = OK;
		break;

		case DOC_PAGE_CURRENT_GET:
			RI = nCurrentPage;
			*status = OK;
		break;

		case DOC_PAGE_CURRENT_SET:
			if( number >= 1 && number <= nTotalPages)
			{
				RI = nCurrentPage;

				// Invalidate all graphics on this page
				if (*status == -1) {
					for(int n=1; (n <= nTotalPages); n++) {
						if (pPages[n] != NULL) {
							pPages[n]->Message(ART_CLEAR_IMAGE, 0, status);
							pPages[n]->Message(ART_SET_SCROLL, cpTemp, status);
							pPages[n]->Message(TEXT_SET_BORDER_ART_SCROLL, cpTemp, status);
						}
					}
				}
				else {
					pPages[nCurrentPage]->Message(ART_CLEAR_IMAGE, 0, status);
				}

				nCurrentPage = number;
				pPages[number]->Message(PAGE_ACTIVATED, number, status);
				*status = OK;
			}
		break;

		case DOC_PAGE_NEW:
			if( number != EMPTY_INT)
			{
				RI = DocPageNew( number, 1, status);
			}
		break;

		case DOC_PAGE_DELETE:
			if( number != EMPTY_INT)
			{
				RI = DocPageDelete( number, status);
			}
		break;

		case DOC_ITEM_COPY:

		break;

		case DOC_ITEM_PASTE:

		break;

		case KEY_DOWN:
			if( pPages[nCurrentPage] != NULL) {
				RI = pPages[nCurrentPage]->Message( message, number, status);
				// Now push any overflow text to any related Story Boxes after this one
				for (int nPage = nCurrentPage; nPage <= nTotalPages && theApp.m_iStoryOverflowBox > 0; ++nPage)
				{
					int pageRet = pPages[nPage]->Message(DOC_STORY_PUSH_TEXT, 0, status);
				}
			}
		break;

		case DOC_STORY_PUSH_TEXT:
			if( pPages[nCurrentPage] != NULL) {
				// Now push any overflow text to any related Story Boxes after this one
				for (int nPage = nCurrentPage; nPage <= nTotalPages && theApp.m_iStoryOverflowBox > 0; ++nPage)
				{
					int pageRet = pPages[nPage]->Message(DOC_STORY_PUSH_TEXT, 0, status);
				}
			}
		break;

		case DOC_STORY_COLLECT:
			theApp.m_strStoryOverflowText.Empty();
			theApp.m_strStoryDistributeText.Empty();
			theApp.m_strStoryOverflowShapes.Empty();
			theApp.m_strStoryDistributeShapes.Empty();
			if (pPages[nCurrentPage] != NULL) {
				// Collect text from any related Story Boxes after this one
				for (int nPage = 1; nPage <= nTotalPages && theApp.m_iStoryOverflowBox > 0; ++nPage)
				{
					int pageRet = pPages[nPage]->Message(DOC_STORY_COLLECT, 0, status);
				}
			}
		break;

		default:
			if( pPages[nCurrentPage] != NULL)
				RI = pPages[nCurrentPage]->Message( message, number, status);
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::Message: %d", status); 
	#endif

	return RI;
}

CPoint
Document::Message( int message, CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::Message(int,CPoint,int*)"); 
	#endif

	// Return CPoint
	CPoint RCP;
	RCP.x = 0;
	RCP.y = 0;

	int nStoryOrder = 0;
	int nStoryOnCurrentPage = 0;
	int nStoryOnPageNumber = 0;
	TextItem *pStoryItem = NULL;
	CPoint cpTemp(0, 0);
	CPoint cpStoryCursor(0, 0);
	int tempStatus = 0;

	switch(message)
	{

        case DOC_NONE:
        	*status = ERROR;
        break;

		case DOC_EXTENT_GET:
			RCP.x = 0;
			RCP.y = 0;
			*status = OK;
		break;

		case DOC_STORY_GET_MOVEPOINT:
			nStoryOrder = *status;
			pStoryItem = GetStoryItem(nStoryOrder, &nStoryOnCurrentPage, &nStoryOnPageNumber);
			if (pStoryItem != NULL)
			{
				cpStoryCursor = pStoryItem->Message(DOC_STORY_GET_MOVEPOINT, point, &tempStatus);
				RCP.x = cpStoryCursor.x;
				RCP.y = cpStoryCursor.y;
			}
			*status = OK;
		break;

		default:
			if( pPages[nCurrentPage] != NULL)
				RCP = pPages[nCurrentPage]->Message( message, point, status);
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::Message: %d", status); 
	#endif

	return RCP;
}

Module*
Document::Message( int message, Module *pmodule, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::Message(int,Module*,int*)"); 
	#endif

	// Return Module
	Module *RM = NULL;

	switch(message)
	{

        case DOC_NONE:
        	*status = ERROR;
        break;

		default:
			if( pPages[nCurrentPage] != NULL)
				RM = pPages[nCurrentPage]->Message( message, pmodule, status);
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::Message: %d", status); 
	#endif

	return RM;
}

void
Document::Draw(CDC* pDC, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::Draw(CDC,int*)"); 
	#endif

	if (bRestoreBorderArt && !pDC->IsPrinting()) {
		bRestoreBorderArt = FALSE;
		DrawAllPages(pDC, status);
	}

	pCurrentPage = pPages[nCurrentPage];

	if( pCurrentPage == NULL ) {
		*status = ERROR;
	}
	else {
		pCurrentPage->Message(PAGE_SET_ZOOM, dCurrentZoom, status);
		for (int nPage = nCurrentPage; nPage <= nTotalPages && theApp.m_iStoryOverflowBox > 0; ++nPage)
		{
			int pageRet = pPages[nPage]->Message(DOC_STORY_PUSH_TEXT, 0, status);
		}
		if (NeedsOverlapCheck) {
			int tempStatus = ERROR;
			BOOL bOverlapChanged = pCurrentPage->Message(PAGE_UPDATE_OVERLAP, 0, &tempStatus);
			pCurrentPage->Draw(pDC, status);
			bOverlapChanged = pCurrentPage->Message(PAGE_UPDATE_OVERLAP, 0, &tempStatus);
			if (bOverlapChanged) {
				pCurrentPage->Draw(pDC, status);
			}
			NeedsOverlapCheck = FALSE;
		}
		pCurrentPage->Draw(pDC, status);
		// If the text box wiped a white rectangle off the grid, draw grid again
		if (theApp.m_isGridWiped) {
			pCurrentPage->Draw(pDC, status);
		}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::Draw: void"); 
	#endif
}

void Document::DrawAllPages(CDC* pDC, int *status)
{
	AfxGetMainWnd()->SetRedraw(FALSE);
	for (int i = nTotalPages; i > 0; i--) {
		pPages[i]->Message(PAGE_SET_ZOOM, dCurrentZoom, status);
		pPages[i]->Draw(pDC, status);
		pPages[i]->Message(ART_CLEAR_IMAGE, 0, status);
	}
	AfxGetMainWnd()->SetRedraw(TRUE);
	AfxGetMainWnd()->Invalidate(FALSE);
}

void Document::SetStoryItemsOrder()
{
	nTotalStoryBoxes = 0;
	int nPrevStoryBoxes = 0;
	int nLastPageWithStoryBox = 0;
	int setLast = 0;
	for (int nPage = 1; nPage <= nTotalPages; ++nPage)
	{
		nPrevStoryBoxes = nTotalStoryBoxes;
		nTotalStoryBoxes = pPages[nPage]->Message(TEXT_SET_STORY_ITEM_ORDER, nTotalStoryBoxes + 1, &setLast);
		if (nPrevStoryBoxes < nTotalStoryBoxes) {
			nLastPageWithStoryBox = nPage;
		}
	}
	// Set the flag for the Last Story Box in the document (it auto-expands)
	if (nLastPageWithStoryBox > 0) {
		setLast = 1;
		TextItem *pItem = pPages[nLastPageWithStoryBox]->GetStoryItem(nTotalStoryBoxes);
		pItem->Message(TEXT_SET_STORY_ITEM_ORDER, nTotalStoryBoxes, &setLast);
	}
}

/////////////////////////////////////////////////////////////////////////////
// Private Member Functions
/////////////////////////////////////////////////////////////////////////////

int
Document::DocPageNew( int where, int doInitBox, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::DocPageNew(int,int,int*)"); 
	#endif

	if( nTotalPages >= MAX_PAGES) {
		Report( TO_LIST, "\tDocument::DocPageNew: Already at MAX_PAGES: %d", &nTotalPages);
       	Report( TO_LIST, "\tDocument::DocPageNew: Returning ERROR");
		AfxMessageBox("Maximum allowed pages reached.");
       	*status = ERROR;
       	return EMPTY_INT;
	}

	if( nTotalPages == 0) {
		nTotalPages = 1;
		nCurrentPage = 1;

		// Default page is letter/portrait
		pPages[nCurrentPage] = new Page(doInitBox, nOrientation);
		pPages[nCurrentPage]->Message( PAGE_CHANGE_PAPER, nPaper, status);
		pPages[nCurrentPage]->Message( PAGE_CHANGE_ORIENTATION, nOrientation, status);
	}
	else
	{
		if( where == DOC_NONE) {;}
		else if( where == DOC_PAGE_PREVIOUS) {
			nTotalPages += 1;

			// Clear images on current page before adding new one
			pPages[nCurrentPage]->Message(ART_CLEAR_IMAGE, 0, status);

			for(int nPage=nTotalPages;nPage > nCurrentPage; nPage--) {
				pPages[nPage] = pPages[nPage-1];
			}
			/* nCurrentPage stays the same; */

		}
		else if( where == DOC_PAGE_NEXT)
		{
			nTotalPages += 1;

			// Clear images on current page before adding new one
			pPages[nCurrentPage]->Message(ART_CLEAR_IMAGE, 0, status);

			for(int nPage=nTotalPages;nPage > nCurrentPage+1; nPage--) {
				pPages[nPage] = pPages[nPage-1];
			}
			nCurrentPage++;		// = nTotalPages;
		}
		else if( where == DOC_PAGE_FIRST) {
			nTotalPages += 1;

			// Clear images on current page before adding new one
			pPages[nCurrentPage]->Message(ART_CLEAR_IMAGE, 0, status);

			for(int nPage=nTotalPages;nPage > 1; nPage--) {
				pPages[nPage] = pPages[nPage-1];
			}
			nCurrentPage = 1;		// = nTotalPages;
		}
		else if( where == DOC_PAGE_LAST)
		{
			nTotalPages += 1;

			// Clear images on current page before adding new one
			pPages[nCurrentPage]->Message(ART_CLEAR_IMAGE, 0, status);

			nCurrentPage = nTotalPages;
		}
		else
		{
			Report( TO_LIST, "\tDocument::DocPageNew: where = %d", &where);
       		Report( TO_LIST, "\tDocument::DocPageNew: Returning ERROR");
       		*status = ERROR;
       		return EMPTY_INT;
		}

		pPages[nCurrentPage] = new Page(doInitBox, nOrientation);
		pPages[nCurrentPage]->Message( PAGE_CHANGE_PAPER, nPaper, status);
		pPages[nCurrentPage]->Message( PAGE_CHANGE_ORIENTATION, nOrientation, status);

	}


	*status = OK;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::DocPageNew: %d", status); 
	#endif

	return nCurrentPage;
}

int
Document::DocPageDelete( int where, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Document::DocPageDelete(int,int*)"); 
	#endif

	pCurrentPage = NULL;

	if( nTotalPages == 1 && (where != DOC_PAGE_DELALL))
	{
		AfxMessageBox("Unable to delete a single paged document!");
	}
	else
	{
		if( where == DOC_NONE) {;}
		else if( where == DOC_PAGE_CURRENT)
		{
			Page *delpage = pPages[nCurrentPage];

			//char string[128];
			//wsprintf(string,"ncp = %d, ncp+1 = %d",nCurrentPage,nCurrentPage+1);
			//AfxMessageBox(string);

			// Pack pages from current page...
			for( int i = nCurrentPage; i < nTotalPages; ++i)
			{
				pPages[i] = pPages[i+1];
			}
			pPages[nTotalPages] = NULL;

			// should this free all the memory allocated to the items on page too?
			delete delpage;

			nTotalPages -= 1;
			if( nCurrentPage > nTotalPages) nCurrentPage = nTotalPages;
		}
		else if (where == DOC_PAGE_DELALL) {
			
			for(int curpage = 1; curpage <= nTotalPages; curpage++) {

				Page *delpage = pPages[curpage];

				pPages[curpage] = NULL;

				// should this free all the memory allocated to the items on page too?
				delete delpage;
			}

			nTotalPages = 0;			
		
		}
		else
		{
			Report( TO_LIST, "\tDocument::DocPageDelete: where = %d", &where);
	       		Report( TO_LIST, "\tDocument::DocPageDelete: Returning ERROR");
	       		*status = ERROR;
	       		return EMPTY_INT;
		}
	}


	*status = OK;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Document::DocPageDelete: %d", status); 
	#endif

	return nCurrentPage;
}
 







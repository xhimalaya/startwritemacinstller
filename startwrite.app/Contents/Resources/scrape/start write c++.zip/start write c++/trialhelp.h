#if !defined(AFX_TRIALHELP_H__28FF4807_5BBA_4293_A25A_DF158FD5669D__INCLUDED_)
#define AFX_TRIALHELP_H__28FF4807_5BBA_4293_A25A_DF158FD5669D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TrialHelp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTrialHelp dialog

class CTrialHelp : public CDialog
{
// Construction
public:
	CTrialHelp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTrialHelp)
	enum { IDD = IDD_TRIAL_HELP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrialHelp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTrialHelp)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRIALHELP_H__28FF4807_5BBA_4293_A25A_DF158FD5669D__INCLUDED_)

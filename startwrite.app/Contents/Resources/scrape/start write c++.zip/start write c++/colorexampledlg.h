#pragma once
#include "afxwin.h"
#include "colorcombo.h"


// CColorExampleDlg dialog

class CColorExampleDlg : public CDialog
{
	DECLARE_DYNAMIC(CColorExampleDlg)

public:
	CColorExampleDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CColorExampleDlg();

	COLORREF m_crColorExample;
	COLORREF * m_pCustomColors;
	CString m_strOptionDescription;
	int m_nFormatType;

	BBox *m_pBox;
	TextItem *m_pTextItem;
	CRect m_rectPreview, m_rectBox;

// Dialog Data
	enum { IDD = IDD_COLORBASE };

protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()
protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
private:
	CColorCombo m_ColorCombo;

public:
	// Set this color for all subsequent boxes
	bool m_setColorAsDefault;
	CButton m_SetColorAsDefaultCheck;
	afx_msg void OnBnClickedColorAsDefault();
};



#include "stdafx.h"
#include <stdarg.h>            
#include <stdio.h>            
#include "common.h"
#include "miscutil.h"

void Trace(LPCSTR szFormat, ...)
{
	va_list ap;

	char szMessage[512];

	va_start(ap, szFormat);
#ifdef _CRT_SECURE_NO_DEPRECATE
	vsprintf(szMessage, szFormat, ap);
#else
	vsprintf_s(szMessage, sizeof(szMessage), szFormat, ap);
#endif
	va_end(ap);

	lstrcat(szMessage, "\n");
	OutputDebugString(szMessage);
}

void WriteSWReleaseLog(LPCSTR szFormat, ...)
{
	va_list ap;

	char szMessage[512];

	va_start(ap, szFormat);
#ifdef _CRT_SECURE_NO_DEPRECATE
	vsprintf(szMessage, szFormat, ap);
#else
	vsprintf_s(szMessage, sizeof(szMessage), szFormat, ap);
#endif
	va_end(ap);

	lstrcat(szMessage, "\n");
	ofstream DFile;
	DFile.open("c:\\SWReleaseLog.txt", std::ios::out | std::ios::app);
	DFile << szMessage;
	DFile.close();
}

void SetRadioRowValue(HWND hwnd, int iValue, int *piIDs, int nCount)
{
	//ASSERT(iValue >= 1 && iValue <= nCount);
	nCount;
	CheckDlgButton(hwnd, piIDs[iValue - 1], TRUE);
}  

void GetRadioRowValue(HWND hwnd, int *piValue, int *piIDs, int nCount)
{
	for (int i = 0; i < nCount; i++)
	{
		if (IsDlgButtonChecked(hwnd, piIDs[i]))
		{
			*piValue = i + 1;
			return;
		}
	}
}  

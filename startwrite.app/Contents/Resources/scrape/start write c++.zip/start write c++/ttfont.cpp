// TrueType Font Class Implementation

#include "stdafx.h"
#include "TTFont.h"
 
TTFont::TTFont() 
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::TTFont()"); 
	#endif

#ifdef _CRT_SECURE_NO_DEPRECATE
	sprintf(Error,"TTFont: No Error...");
	sprintf(File, "");
#else
	sprintf_s(Error,sizeof(Error),"TTFont: No Error...");
	sprintf_s(File,sizeof(File), "");
#endif
	
	Dir = NULL;
	Name = NULL;
	CMap = NULL;
	Head = NULL;
	MaxP = NULL;
	Loca = NULL;
	Glyf = NULL;
	Kern = NULL;
	isOpen=false;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::TTFont"); 
	#endif
}

TTFont::~TTFont()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::~TTFont()");
    #endif

	if (isOpen) {
		Close();
	}
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::~TTFont: void"); 
	#endif
}

int TTFont::SetFile(char *file)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::SetFile(%s)", file); 
	#endif
	
	int status = ERROR;
	
	if( strcmp(file,"") != S1_EQUALS_S2 )
	{
#ifdef _CRT_SECURE_NO_DEPRECATE
		strcpy(File, file);		
#else
		strcpy_s(File, sizeof(File),file);		
#endif
	 	status = OK;
	}
	else
	{
		Report( TO_LIST, "ERROR TTFont::SetFile: File argument was null!");
		status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::SetFile: %d", &status); 
	#endif
	
	return status;
}

int
TTFont::Open() 
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::Open()"); 
	#endif
	
	int status = ERROR;
	
	if( strcmp( File, "") == S1_EQUALS_S2)
	{
		Report( TO_LIST, "ERROR TTFont::Open: File is null!");
	}
    else
    {		
		fstream fin(File, ios_base::binary | ios_base::in);		
	
        if (!fin)
        {
			Report( TO_LIST, "ERROR TTFont::Open: Unable to open file: %s", File);
        }
        else
        {
        	// Load tables here...
            int go = TRUE;

            // Directory Table
            //Dir = new DirectoryTable;
            //Dir->Read(fin);
           	
           	if( go && ((Dir = new DirectoryTable) == NULL)) { go = FALSE; }
            if( go && (Dir->Read(&fin) == ERROR)) { go = FALSE; }	
                
            // Name Table
            //Name = new NameTable;
	        //Name->Read(fin, Dir);

			if( go && ((Name = new NameTable) == NULL)) { go = FALSE; }
			if( go && (Name->Read(&fin, Dir) == ERROR)) { go = FALSE; }
			
            // CMap Table
            //CMap = new CMapTable;
            //CMap->Read(fin, Dir);

			if( go && ((CMap = new CMapTable) == NULL)) { 
				go = FALSE; 
			}
			if( go && (CMap->Read(&fin, Dir) == ERROR)) { go = FALSE; }

            // Head Table
            //Head = new HeadTable;
            //Head->Read(fin, Dir);

			if( go && ((Head = new HeadTable) == NULL)) { go = FALSE; }
			if( go && (Head->Read(&fin, Dir) == ERROR)) { go = FALSE; }

            // Maxp Table
            //MaxP = new MaxPTable;
            //MaxP->Read(fin, Dir);

			if( go && ((MaxP = new MaxPTable) == NULL)) { go = FALSE; }
			if( go && (MaxP->Read(&fin, Dir) == ERROR)) { go = FALSE; }

            // Loca Table
            //Loca = new LocaTable;
            //Loca->Read(fin, Dir, Head->GetIndexToLocFormat(), 
            //            MaxP->GetNumGlyphs());

			if( go && ((Loca = new LocaTable) == NULL)) { go = FALSE; }
			if( go && (Loca->Read(&fin, Dir, Head->GetIndexToLocFormat(),
				 MaxP->GetNumGlyphs()) == ERROR)) { go = FALSE; }

			// Kerning tables are optional so don't fail on kerning
			if( go && ((Kern = new KernTable) == NULL)) { go = go; }
			if( go && (Kern->Read(&fin, Dir) == ERROR)) { go = go; }
            
			// Glyf Table
            //Glyf = new GlyfTable(Head);
            //Glyf->Read(fin, Dir);		

			if( go && ((Glyf = new GlyfTable(Head)) == NULL)) { go = FALSE; }
			if( go && (Glyf->Read(&fin, Dir) == ERROR)) { go = FALSE; }
            
            // Close the actual file...
            fin.close();
            
            if( go == ERROR) 
            {
				Report( TO_LIST, "ERROR TTFont::Open: Reading one of the tables...");        
            	status = ERROR; 
            }
            else { 
				isOpen = true;
				status = OK; 
			}
        }
     
    }

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::Open: %d", &status); 
	#endif

	return status;
}

int
TTFont::Close()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::Close()"); 
	#endif
 	
	int status = ERROR;
 	
 	if( Dir != NULL) delete(Dir);
 	if( Name != NULL) delete(Name);
 	if( CMap != NULL) delete(CMap);
 	if( Head != NULL) delete(Head);
 	if( MaxP != NULL) delete(MaxP);
 	if( Loca != NULL) delete(Loca);
 	if( Glyf != NULL) delete(Glyf);
	if( Kern != NULL) delete(Kern);
	
	// Reset to null
	Dir = NULL;
	Name = NULL;
	CMap = NULL;
	Head = NULL;
	MaxP = NULL;
	Loca = NULL;
	Glyf = NULL;
	Kern = NULL;

 	status = OK;
	isOpen=false;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::Close: %d", &status); 
	#endif
 	
 	return status;
}

int TTFont::GetGlyfData( GlyfData* glyfdata, unsigned short* c)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TTFont::GetGlyfData(?,?)"); 
	#endif

	int status = ERROR;

	// Open file input stream for glyf class...
	if( strcmp( File, "") == S1_EQUALS_S2)
	{
		Report( TO_LIST, "ERROR TTFont::GetGlyfData: File is null!");
       	Report( TO_LIST, "ERROR TTFont::GetGlyfData: Returning ERROR");
		return ERROR;		
	}

	fstream fin(File, ios::binary | ios::in);

	if (!fin)
    {
    	Report( TO_LIST, "ERROR TTFont::GetGlyfData: Unable to open file: %s", File);
       	Report( TO_LIST, "ERROR TTFont::GetGlyfData: Returning ERROR");
		return ERROR;		
    }

	// Pass the classes...
	if( Glyf->GetGlyf( glyfdata, &fin, Dir, CMap, Loca, c) == ERROR) 
	{ 
	   	Report( TO_LIST, "ERROR TTFont::GetGlyfData: Unable to get glyf data!");
       	Report( TO_LIST, "ERROR TTFont::GetGlyfData: Returning ERROR");
		return ERROR;		
	}
	
	status = OK;

  
    //Glyf->Print();
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TTFont::GetGlyfData: %d", &status); 
	#endif

	return status;
}

char*
TTFont::GetError()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "TTFont::GetError()");
    #endif
	
	return Error;
}

short TTFont::GetKern(UShort cleft, UShort cright)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "TTFont::GetKern()");
    #endif
	ULong ULeft;
	ULong URight;

	if ((CMap != NULL) && (CMap->GetIndex(&ULeft, &cleft) == OK)) {
		if (CMap->GetIndex(&URight, &cright) == OK) {
			return Kern->GetKerning((UShort)ULeft, (UShort)URight);
		}
	}
	return(0);

}

int
TTFont::Print()
{

	Dir->Print();
	cout << endl;
	
	Name->Print();
	cout << endl;
	
	CMap->Print();	
	cout << endl;
    
    Head->Print();
    cout << endl;
    
    MaxP->Print();
    cout << endl;
    
    Loca->Print();    
    cout << endl;
    
    Glyf->Print();
    cout << endl;
    
	return OK;
}



#if !defined(AFX_SWUPGRADE_H__F1DE2B61_0A69_11D4_B60B_B48B0AE63976__INCLUDED_)
#define AFX_SWUPGRADE_H__F1DE2B61_0A69_11D4_B60B_B48B0AE63976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// swUpgrade.h : header file
//

#define PAY_CHECK	0x01
#define PAY_VISA	0x02
#define PAY_MASTER	0x04
#define PAY_AMEX	0x08
#define PAY_DISC	0x10

/////////////////////////////////////////////////////////////////////////////
// swUpgrade dialog

class swUpgrade : public CDialog
{
// Construction
public:
	swUpgrade(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(swUpgrade)
	enum { IDD = IDD_UPGRADE_DLG };
	CString	m_fullName;
	CString	m_Address;
	CString	m_City;
	CString	m_zipcode;
	CString	m_phone;
	CString	m_state;
	CString	m_country;
	CString	m_faxnumber;
	CString	m_email;
	CString	m_hopReg;
	CString	m_HOPRegnum;
	CString	m_cardnum;
	CTime	m_expiration;
	CString	m_address2;
	CString	m_Price;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(swUpgrade)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:	
	// Generated message map functions
	//{{AFX_MSG(swUpgrade)
	afx_msg void OnPrintform();
	afx_msg void OnAmericanex();
	afx_msg void OnDiscover();
	afx_msg void OnMastercard();
	afx_msg void OnVisa();
	afx_msg void OnCheck();
	afx_msg void OnOk();
	//}}AFX_MSG
protected:
	DECLARE_MESSAGE_MAP()

public:
	int didPrint;
	int paymentType;
	int checkEntries();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWUPGRADE_H__F1DE2B61_0A69_11D4_B60B_B48B0AE63976__INCLUDED_)

// Registration60.cpp : implementation file
//

#include "stdafx.h"
#include "Registration60.h"
#include "REgGenerator.h"
#include "sw.h"

// CRegistration60 dialog

IMPLEMENT_DYNAMIC(CRegistration60, CDialog)

CRegistration60::CRegistration60(CWnd* pParent /*=NULL*/)
	: CDialog(CRegistration60::IDD, pParent)
{
	m_RegistrationString= _T("");
}

CRegistration60::~CRegistration60()
{
}

void CRegistration60::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_REGISTRATION, m_RegistrationValue);
	DDX_Text(pDX, IDC_EDIT_REGISTRATION, m_RegistrationString);
}


BEGIN_MESSAGE_MAP(CRegistration60, CDialog)
	ON_BN_CLICKED(IDOK, &CRegistration60::OnBnClickedOk)
END_MESSAGE_MAP()


// CRegistration60 message handlers

void CRegistration60::OnBnClickedOk()
{
	CString newRegVal;
	int retv = 0;
	UpdateData(1);

	CRegGenerator cCheck;
	char *regValueToCheck=NULL;

	regValueToCheck = this->m_RegistrationString.GetBuffer(14);
	if (cCheck.VerifyRegistration(regValueToCheck) == true) {
		AfxMessageBox("Registration Accepted");
		retv = theApp.SetSerialNumber(regValueToCheck);
		if (regValueToCheck[2] == 'N')
			theApp.isNetwork = true;
		else if (regValueToCheck[2] == 'L')
			theApp.isLabPack = true;
		if (retv || theApp.isNetwork) {
			theApp.UpdateSpecialConfig("SERIAL", regValueToCheck);	// save to config file
		}
		theApp.m_isDemo = 0;
		OnOK();
	}
	else {
		AfxMessageBox("Registration Failed");
	}
}

// shadedlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CShadeDlg dialog

class CShadeDlg : public CDialog
{
// Construction
public:
	CShadeDlg(CWnd* pParent = NULL);	// standard constructor

	int m_iShading;
	
// Dialog Data
	//{{AFX_DATA(CShadeDlg)
	enum { IDD = IDD_SHADING };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CShadeDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

// Maximum Profile Table Header

#ifndef _MAXP_TABLE_H_
#define _MAXP_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

class MaxPTable
{
	private:
	
	// Maxp Table
	struct
	{
		Fixed	Version;				// 0x00010000 for version 1.0
		UShort	NumGlyphs;				// The number of glyphs in the font
		UShort	MaxPoints;				// Maximum points in a non-composite glyph
		UShort	MaxContours;			// Maximum contours in a non-composite glyph
		UShort	MaxCompositePoints;		// Maximum points in a composite glyph
		UShort	MaxCompositeContours;	// Maximum contours in a composite glyph
		UShort	MaxZones;				// SEE *
		UShort	MaxTwilightPoints;		// Maximum points used in Z0
		UShort	MaxStorage;				// Number of storage area locations
		UShort	MaxFunctionDefs;		// Number of FDEFs
		UShort	MaxInstructionDefs;	// Number of IDEFs
		UShort	MaxStackElements;		// Maximum stack depth
		UShort	MaxSizeOfInstructions;	// Maximum byte count for glyph instructions
		UShort	MaxComponentElements;	// Maximum number of components referenced at "top level" for any composite glyph
		UShort	MaxComponentDepth;		// Maximum levels of recursion; 1 for simple components		
	} Table;

	// * = MaxZones
	//		1 if instructions do not use the twilight zone (Z0),
	//		or 2 if instructions do use Z0
	//		should be set to 2 in most cases
	
	public:
	
		MaxPTable();
		~MaxPTable();
		
		UShort GetNumGlyphs();
		
		int 	Read(fstream *fin, DirectoryTable *dir);		
		int 	Print();
};

#endif // _MAXP_TABLE_H_
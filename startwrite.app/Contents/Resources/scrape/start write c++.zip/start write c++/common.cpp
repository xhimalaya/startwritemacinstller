// My own swabbing routine...

#include "stdafx.h"
#include "Common.h"

void myswab( unsigned char *ptr, int bytes)
{
	char buf[1024];
	char *tmp;	
	
	/* try to reduce the amount of malloc's we do */
	if (bytes > (sizeof(buf)-1)) {
		tmp = (char *)malloc(bytes);
		memcpy( tmp, ptr, bytes);
		_swab( tmp, (char *)ptr, bytes);
		free(tmp);	
	}
	else {
		memcpy( buf, ptr, bytes);
		_swab( buf, (char *)ptr, bytes);
	}
}

// This assumes that data is not byte swapped!

//unsigned char *
//copy_short(unsigned char *src, short *dest)
//{	
//	*dest = ((src[0] & 0x00ff) << 8) | (src[1] & 0x00ff);
//	src += sizeof(short);	
//	return src;
//} 

//unsigned char *
//copy_ushort(unsigned char *src, unsigned short *dest)
//{	
//	*dest = ((src[0] & 0x00ff) << 8) | (src[1] & 0x00ff);
//	src += sizeof(unsigned short);	
//	return src;
//} 

//unsigned char *
//copy_byte2short(unsigned char *src, short *dest)
//{	
//	*dest = (short)(src[0] & 0x00ff);
//	src += sizeof(char);	
//	return src;
//} 

//unsigned char *
//copy_byte2ushort(unsigned char *src, unsigned short *dest)
//{
//	*dest = (unsigned short)(src[0] & 0x00ff);
//	src += sizeof(char);	
//	return src;
//} 


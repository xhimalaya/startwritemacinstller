// mainfrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////
#ifndef _MAINFRM_H
#define _MAINFRM_H

#include "bbox.h"
#include "palette.h"
#include "SlideToolBar.h"
extern BBox *pCopyBBox;
extern BBox *pUndoBBox;

class CFontComboBox : public CComboBox
{
public:
	void EnumFontFamiliesEx(CDC& dc, BYTE nCharSet = DEFAULT_CHARSET);
	void AddFont(ENUMLOGFONT* pelf, LPCTSTR lpszScript = NULL);
	void MatchFont(LPCTSTR lpszName, BYTE nCharSet);
	void EmptyContents();
	void GetTheText(CString& str);
	void SetTheText(LPCTSTR lpszText,BOOL bMatchExact = FALSE);

	static BOOL CALLBACK AFX_EXPORT EnumFamPrinterCallBack(
		ENUMLOGFONT* pelf, NEWTEXTMETRICEX* /*lpntm*/, int FontType,
		LPVOID pThis);
	static BOOL CALLBACK AFX_EXPORT EnumFamPrinterCallBackEx(
		ENUMLOGFONTEX* pelf, NEWTEXTMETRICEX* /*lpntm*/, int FontType,
		LPVOID pThis);

	CPtrArray m_arrayFontDesc;
	static int m_nFontHeight;


	int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
	void DeleteItem(LPDELETEITEMSTRUCT lpDeleteItemStruct);
   void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
   void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
//    void AddFonts();
};

class CSizeComboBox : public CComboBox
{
	virtual BOOL PreTranslateMessage(MSG *lpptr);
};

class CEditBar : public CToolBar
{
public:
	CFontComboBox   m_FontComboBox;
//	CComboBox   m_PointComboBox;
	CSizeComboBox   m_PointComboBox;
};

class CSWStatusBar : public CStatusBar
{
public:
	CButton	m_buttonPageDec,
				m_buttonPageInc,
				m_buttonZoomDec,
				m_buttonZoomInc;

	void CreateButtons();

protected:
	void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
   void FixButtonPos(CButton *pButton, int iPane);
   
	DECLARE_MESSAGE_MAP()
	
};

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;

#endif
	static void AddFontSizes(CComboBox *pBox);
	CString FontPath;
	void loadFontsNew();
	void RemoveFonts();

protected:  // control bar embedded members
	CToolBar	m_wndEditBar;		// NEW/open/view/print/cutpaste/etc
	CEditBar	m_wndPowerBar;		// Startwrite specific TExt/Dotted/Font boxes
	CSWStatusBar  m_wndStatusBar;
	CPaletteBar m_wndPaletteBar;

	void MyHelpCheck();
	BOOL CreateToolBar();
	BOOL CreatePowerBar();
	BOOL CreateEditBar();
	BOOL CreateStatusBar();
	BOOL CreatePaletteBar();
	void InvalidateCurrentView();
	
public:
	TextItem *GetCurrentTextItem();
	
// Generated message map functions
protected:
#ifdef LATER_WRW
	afx_msg void OnSize(UINT nType, int cx, int cy);
#endif
	afx_msg void OnSelChangeFont();	
	afx_msg void OnSelChangeSize();	
	BOOL PreCreateWindow(CREATESTRUCT& cs);
//	afx_msg void OnEditupdateSize();
	afx_msg void OnEditkillFocus();	
	afx_msg void OnUpdatePointCombo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFontCombo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSelect(CCmdUI *pCmdUI);
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnPurchase();
	afx_msg void OnUpdateHelpEnterRegistration(CCmdUI *pCmdUI);
	afx_msg void OnHelpEnterRegistration();
};

/////////////////////////////////////////////////////////////////////////////
#endif

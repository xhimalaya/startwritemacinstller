// colordlg.cpp : implementation file
//

#include "stdafx.h"
#include "colordlg.h"

#ifndef _WIN32_WCE // CColorDialog is not supported for Windows CE.

// CColorDlg

IMPLEMENT_DYNAMIC(CColorDlg, CColorDialog)

CColorDlg::CColorDlg(COLORREF clrInit, DWORD dwFlags, CWnd* pParentWnd) :
	CColorDialog(clrInit, dwFlags, pParentWnd)
{

}

CColorDlg::~CColorDlg()
{
}


BEGIN_MESSAGE_MAP(CColorDlg, CColorDialog)
	ON_WM_CREATE()
	ON_WM_SHOWWINDOW()
	ON_WM_DESTROY()
END_MESSAGE_MAP()



// CColorDlg message handlers


#endif // !_WIN32_WCE

int CColorDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CColorDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  Add your specialized creation code here

	return 0;
}

void CColorDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CColorDialog::OnShowWindow(bShow, nStatus);

	// TODO: Add your message handler code here
}

void CColorDlg::OnDestroy()
{
	CColorDialog::OnDestroy();

	// TODO: Add your message handler code here
}

BOOL CColorDlg::OnInitDialog()
{
	CColorDialog::OnInitDialog();

	// TODO:  Add extra initialization here
     SetWindowPos(NULL, m_pos.x, m_pos.y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	 SetCurrentColor(m_cc.rgbResult);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


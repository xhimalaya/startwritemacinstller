// swview.h : interface of the CSwView class
//
/////////////////////////////////////////////////////////////////////////////

extern BBox *pCopyBBox;
#define POWERBAR_ON 	1
#define STATUSBAR_ON	2

class CSwView : public CScrollView
{
//JRL
private:
	int MouseCaptured;
	int MousePending;
	int nNewBBoxTakesKeys;
	int nBBoxTakesKeys;
	int BarsVisible;
	int CurrPage;			// remember the initial page before printing
	int saveZoom;
	int m_doFontDefault;
	int m_showPrintDialog;
	int nButtonDensity;
	int nButtonShading;
	int nButtonGuidelines;
	int nButtonGuidelineThickness;
	int nButtonYellowGuide;

	CPoint lastPoint;
	CPoint 	m_ptLastMove;
				
	//BBox *pCopyBBox;
	void SharedCutCopy(int cVal);
	char lpszShapes[1024];

protected: // create from serialization only
	CSwView();
	DECLARE_DYNCREATE(CSwView)

// Attributes
public:
	CSwDoc* GetDocument();

// Operations
public:
	BOOL CanCopy();
	BOOL CanPaste();
	BOOL IsCurrentText();
	BOOL IsCurrentDotToDot();
	BOOL IsArrowedFont();
	BOOL IsOverlayFont();
	BOOL IsStartDotFont();
	BOOL BoxIsSelected();

	
	TextItem *GetCurrentTextItem();
	ArtItem *GetCurrentArtItem();
	TextItem *GetStoryItem(int orderNumber, int *onCurrentPage, int *onPageNumber);

	CString TemplatePath;
	CString saveTemplatePath;
	CString TBasePath;
	CString saveTBasePath;
	CString lastDocPath;
	CSize totalSize;
	CSize pageSize;
	CSize lineSize;


	int GetCurrentArrows();
	int GetCurrentOverlay();
	int GetCurrentDensity();
	int GetCurrentShading();
	int GetCurrentLines();
	int GetCurrentStartDot();
	int GetButtonDensitySetting();
	int GetButtonShadingSetting();
	int GetButtonGuidelinesSetting();
	int GetButtonYellowGuideSetting();
	int GetButtonGuideLineThicknessSetting();

	void SetButtonDensitySetting(int i);
	void SetButtonShadingSetting(int i);
	void SetButtonGuidelinesSetting(int i);
	void SetButtonYellowGuideSetting(int i);
	void SetButtonGuideLineThicknessSetting(int i);
	void SetCurrentArrows(int i);
	void SetCurrentOverlay(int i);
	void SetCurrentDensity(int i);
	void SetCurrentShading(int i);
	void SetCurrentLines(int i);
	void SetAllCurrentLines(int i);
	void SetCurrentStartDot(int i);
	void SetModified(void);
	void DoItemRedraw(int flag);
	void setFrameValues(int flag);
	void setFrameChecks(CCmdUI* pCmdUI, int flag);
	void handleGuildeLineEdit();
	void ShowAreaShadingOptions();
	void ShowColorLettersOptions();
	void ShowColorOptions(CString strOptionDescription, int nID);
	void CollectStoryText(int startOrder);
	void DistributeStoryText(int startOrder, bool doRefreshItem, bool doInvalidate);
	void DistributeStoryChar(int nChar, int nShape, TextItem *pItem, CDC* pDC);

// Implementation
public:
	virtual ~CSwView();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	BOOL CheckSelection();

protected:
	virtual void OnInitialUpdate(); // called first time after construct

protected:

	// Printing support
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint( CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	virtual void OnActivateView( BOOL bActivate, CView* pActivateView, 
									CView* pDeactiveView);
	BOOL IsLandscape();
	void SetLandscape(BOOL bValue);


// Generated message map functions
protected:
	afx_msg void OnUpdateStatusPageOfPage(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSelect(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStatusZoom(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePagePrev(CCmdUI* pCmdUI);
	afx_msg void OnUpdatePageNext(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZoomDec(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZoomInc(CCmdUI* pCmdUI);
	afx_msg void OnPagePrev();
	afx_msg void OnPageNext();
	afx_msg void OnZoomDec();
	afx_msg void OnZoomInc();
	afx_msg void OnZoomSelect();
	afx_msg void OnPageSelect();
	//{{AFX_MSG(CSwView)
	afx_msg void OnNewTextItem();
	afx_msg void OnNewArtItem();
	afx_msg void OnItemTool();
	afx_msg void OnDocOrientation();
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnDocSpell();
	afx_msg void OnEditCut();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNewPage();
	afx_msg void OnDeletePage();
	afx_msg void OnDocumentLandscape();
	afx_msg void OnUpdateDocumentLandscape(CCmdUI* pCmdUI);
	afx_msg void OnDocumentPortrait();
	afx_msg void OnUpdateDocumentPortrait(CCmdUI* pCmdUI);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnUpdateUndo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnFormatConnectTheDots();
	afx_msg void OnUpdateFormatConnectTheDots(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensity100();
	afx_msg void OnUpdateFormatLinedensity100(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensity();
	afx_msg void OnUpdateFormatLinedensity(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensityNone();
	afx_msg void OnUpdateFormatLinedensityNone(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensity25();
	afx_msg void OnUpdateFormatLinedensity25(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensity50();
	afx_msg void OnUpdateFormatLinedensity50(CCmdUI* pCmdUI);
	afx_msg void OnFormatLinedensity75();
	afx_msg void OnUpdateFormatLinedensity75(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextarrowsToggle();
	afx_msg void OnUpdateFormatTextarrowsToggle(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextDotToggle();
	afx_msg void OnUpdateFormatTextDotToggle(CCmdUI* pCmdUI);
	afx_msg void OnFormatOverlayToggle();
	afx_msg void OnUpdateFormatOverlayToggle(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextarrows();
	afx_msg void OnUpdateFormatTextarrows(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextlinesBottom();
	afx_msg void OnUpdateFormatTextlinesBottom(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextlinesMidbottom();
	afx_msg void OnUpdateFormatTextlinesMidbottom(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextlinesNone();
	afx_msg void OnUpdateFormatTextlinesNone(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextlinesTopmidbottom();
	afx_msg void OnUpdateFormatTextlinesTopmidbottom(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextshading100();
	afx_msg void OnUpdateFormatTextshading100(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextshading();
	afx_msg void OnUpdateFormatTextshading(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextshading25();
	afx_msg void OnUpdateFormatTextshading25(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextshading50();
	afx_msg void OnUpdateFormatTextshading50(CCmdUI* pCmdUI);
	afx_msg void OnFormatTextshading75();
	afx_msg void OnUpdateFormatTextshading75(CCmdUI* pCmdUI);
	afx_msg void OnEditGoto();
	afx_msg void OnViewZoom();
	afx_msg void OnEditDelete();
	afx_msg void OnBorderArt();
	afx_msg void OnStorySetInclude();
	afx_msg void OnUpdateStoryStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateStorySetInclude(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBorderArt(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditDelete(CCmdUI* pCmdUI);
	afx_msg void OnEditCenterOnPage();
	afx_msg void OnUpdateEditCenterOnPage(CCmdUI* pCmdUI);
	afx_msg void OnEditCenterHorizontal();
	afx_msg void OnUpdateEditCenterHorizontal(CCmdUI* pCmdUI);
	afx_msg void OnEditCenterVertical();
	afx_msg void OnUpdateEditCenterVertical(CCmdUI* pCmdUI);
	afx_msg void OnFormatArt();
	afx_msg void OnUpdateFormatArt(CCmdUI* pCmdUI);
	afx_msg	void OnMaintainProportions();
	afx_msg void OnUpdateMaintainProportions(CCmdUI* pCmdUI);
	afx_msg void OnFormatFont();
	afx_msg void OnUpdateFormatFont(CCmdUI* pCmdUI);
	afx_msg void OnSpecialChars();
	afx_msg void OnUpdateSpecialChars(CCmdUI* pCmdUI);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnUpdateDocSpell(CCmdUI* pCmdUI);
	afx_msg void OnFormatLetterdotdensity();
	afx_msg void OnUpdateFormatLetterdotdensity(CCmdUI* pCmdUI);
	afx_msg void OnFormatLettershading();
	afx_msg void OnUpdateFormatLettershading(CCmdUI* pCmdUI);
	afx_msg void OnFormatLetterstrokearrows();
	afx_msg void OnUpdateFormatLetterstrokearrows(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFilePrintPreview(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFilePrintSetup(CCmdUI* pCmdUI);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnOpenTemplate();
	afx_msg void OnUpdateOpenTemplate(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewPage(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewZoom(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsSettings(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewArtItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNewTextItem(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileNew(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileClose(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDeletePage(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditGoto(CCmdUI* pCmdUI);
	afx_msg void OnKerningOn();
	afx_msg void OnUpdateKerningOn(CCmdUI* pCmdUI);
	afx_msg void OnKerningOff();
	afx_msg void OnUpdateKerningOff(CCmdUI* pCmdUI);
	afx_msg void OnRedrawAll();
	afx_msg void OnRegister();
	afx_msg void OnUpdateRegister(CCmdUI* pCmdUI);
	afx_msg void OnHopUpgrade();
	afx_msg void OnUpdateHopUpgrade(CCmdUI* pCmdUI);
	afx_msg void OnSpaceNormal();
	afx_msg void OnSpaceWide();
	afx_msg void OnUpdateSpaceNormal(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSpaceWide(CCmdUI* pCmdUI);
	afx_msg void OnToolsSetspace();
	afx_msg void OnUpdateToolsSetspace(CCmdUI* pCmdUI);
	afx_msg void OnFormatAreaHighlightToggle();
	afx_msg void OnFormatAreaHighlightTop();
	afx_msg void OnUpdateFormatAreaHighlightTop(CCmdUI* pCmdUI);
	afx_msg void OnFormatAreaHighlightMiddle();
	afx_msg void OnUpdateFormatAreaHighlightMiddle(CCmdUI* pCmdUI);
	afx_msg void OnFormatAreaHighlightBottom();
	afx_msg void OnUpdateFormatAreaHighlightBottom(CCmdUI* pCmdUI);
	afx_msg void OnToolsDefaultsettingsFonts();
	afx_msg void OnUpdateToolsDefaultsettingsFonts(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFormatAllowwindowsfonts(CCmdUI* pCmdUI);
	afx_msg void OnFormatAllowwindowsfonts();
	afx_msg void OnFilePrint();
	afx_msg void OnFileOpen();
	afx_msg void OnEditUndo();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnFormatThicknessNormal();
	afx_msg void OnUpdateFormatThicknessNormal(CCmdUI* pCmdUI);
	afx_msg void OnFormatThicknessThin();
	afx_msg void OnUpdateFormatThicknessThin(CCmdUI* pCmdUI);
	afx_msg void OnFormatThicknessMedium();
	afx_msg void OnUpdateFormatThicknessMedium(CCmdUI* pCmdUI);
	afx_msg void OnFormatThicknessThick();
	afx_msg void OnUpdateFormatThicknessThick(CCmdUI* pCmdUI);
	afx_msg void OnEditSelectall();
	afx_msg void OnUpdateEditSelectall(CCmdUI* pCmdUI);
	
	afx_msg void OnUpdateFormatTopNormal(CCmdUI* pCmdUI);
	afx_msg void OnFormatTopNormal();
	afx_msg void OnUpdateFormatTopThick(CCmdUI* pCmdUI);
	afx_msg void OnFormatTopThick();
	afx_msg void OnUpdateFormatTopThicker(CCmdUI* pCmdUI);
	afx_msg void OnFormatTopThicker();
	afx_msg void OnUpdateFormatTopThickest(CCmdUI* pCmdUI);
	afx_msg void OnFormatTopThickest();

	afx_msg void OnUpdateFormatMidNormal(CCmdUI* pCmdUI);
	afx_msg void OnFormatMidNormal();
	afx_msg void OnUpdateFormatMidThick(CCmdUI* pCmdUI);
	afx_msg void OnFormatMidThick();
	afx_msg void OnUpdateFormatMidThicker(CCmdUI* pCmdUI);
	afx_msg void OnFormatMidThicker();
	afx_msg void OnUpdateFormatMidThickest(CCmdUI* pCmdUI);
	afx_msg void OnFormatMidThickest();

	afx_msg void OnUpdateFormatBasNormal(CCmdUI* pCmdUI);
	afx_msg void OnFormatBasNormal();
	afx_msg void OnUpdateFormatBasThick(CCmdUI* pCmdUI);
	afx_msg void OnFormatBasThick();
	afx_msg void OnUpdateFormatBasThicker(CCmdUI* pCmdUI);
	afx_msg void OnFormatBasThicker();
	afx_msg void OnUpdateFormatBasThickest(CCmdUI* pCmdUI);
	afx_msg void OnFormatBasThickest();

	afx_msg void OnUpdateFormatBotNormal(CCmdUI* pCmdUI);
	afx_msg void OnFormatBotNormal();
	afx_msg void OnUpdateFormatBotThick(CCmdUI* pCmdUI);
	afx_msg void OnFormatBotThick();
	afx_msg void OnUpdateFormatBotThicker(CCmdUI* pCmdUI);
	afx_msg void OnFormatBotThicker();
	afx_msg void OnUpdateFormatBotThickest(CCmdUI* pCmdUI);
	afx_msg void OnFormatBotThickest();
	afx_msg void OnUpdateFormatStartDotColors(CCmdUI* pCmdUI);
	afx_msg void OnFormatStartDotColors();

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBoxframeNone();
	afx_msg void OnUpdateBoxframeNone(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeSingle1();
	afx_msg void OnUpdateBoxframeSingle1(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeSingle2();
	afx_msg void OnUpdateBoxframeSingle2(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeSingle3();
	afx_msg void OnUpdateBoxframeSingle3(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeSingle6();
	afx_msg void OnUpdateBoxframeSingle6(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeDouble1();
	afx_msg void OnUpdateBoxframeDouble1(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeDouble2();
	afx_msg void OnUpdateBoxframeDouble2(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeDouble3();
	afx_msg void OnUpdateBoxframeDouble3(CCmdUI *pCmdUI);
	afx_msg void OnBoxframeDouble6();
	afx_msg void OnUpdateBoxframeDouble6(CCmdUI *pCmdUI);

	afx_msg void OnToolBarBtnDropDown(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg void OnEditBarBtnDropDown(NMHDR* pNMHDR, LRESULT* pRes);
	afx_msg void OnFormatStartDot();
	afx_msg void OnUpdateStartDot(CCmdUI *pCmdUI);
	afx_msg void CSwView::OnUpdateGuidelines(CCmdUI* pCmdUI);
	afx_msg void CSwView::OnFormatGuidelines();

	afx_msg void CSwView::OnFormatTextlinesTMD();
	afx_msg void CSwView::OnUpdateFormatTextlinesTMD(CCmdUI* pCmdUI);

	afx_msg void CSwView::OnFormatTextlinesTMB();
	afx_msg void CSwView::OnUpdateFormatTextlinesTMB(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesTBD();
	afx_msg void CSwView::OnUpdateFormatTextlinesTBD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesMBD();
	afx_msg void CSwView::OnUpdateFormatTextlinesMBD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesT();
	afx_msg void CSwView::OnUpdateFormatTextlinesT(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesM();
	afx_msg void CSwView::OnUpdateFormatTextlinesM(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesB();
	afx_msg void CSwView::OnUpdateFormatTextlinesB(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesD();
	afx_msg void CSwView::OnUpdateFormatTextlinesD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesTM();
	afx_msg void CSwView::OnUpdateFormatTextlinesTM(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesTB();
	afx_msg void CSwView::OnUpdateFormatTextlinesTB(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesTD();
	afx_msg void CSwView::OnUpdateFormatTextlinesTD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesMB();
	afx_msg void CSwView::OnUpdateFormatTextlinesMB(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesMD();
	afx_msg void CSwView::OnUpdateFormatTextlinesMD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesBD();
	afx_msg void CSwView::OnUpdateFormatTextlinesBD(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesAllOff();
	afx_msg void CSwView::OnUpdateFormatTextlinesAllOff(CCmdUI* pCmdUI);
	
	afx_msg void CSwView::OnFormatTextlinesTMBD();
	afx_msg void CSwView::OnUpdateFormatTextlinesTMBD(CCmdUI* pCmdUI);

	afx_msg void CSwView::OnFormatGuidelineThickness();
	afx_msg void CSwView::OnUpdateFormatGuidelineThickness(CCmdUI* pCmdUI);

	afx_msg void CSwView::OnFormatBigSpace();
	afx_msg void CSwView::OnUpdateFormatBigSpace(CCmdUI* pCmdUI);

	afx_msg void OnDoColoredStrokes();
	afx_msg void OnUpdateDoColoredStrokes(CCmdUI *pCmdUI);

	afx_msg void OnDoDecisionDots();
	afx_msg void OnUpdateDoDecisionDots(CCmdUI *pCmdUI);

	afx_msg	void OnGridShow();
	afx_msg void OnUpdateGridShow(CCmdUI *pCmdUI);
	afx_msg	void OnGridSnapTo();
	afx_msg void OnUpdateGridSnapTo(CCmdUI *pCmdUI);

};

#ifndef _DEBUG  // debug version in swview.cpp
inline CSwDoc* CSwView::GetDocument()
   { return (CSwDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

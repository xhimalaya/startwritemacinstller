// TrueType Data Types

#ifndef _TTTYPES_H_
#define _TTTYPES_H_

typedef	unsigned char	Byte;

typedef signed char		Char;

typedef	unsigned short	UShort;
typedef signed short	Short;

typedef	unsigned long	ULong;
typedef signed long		Long;

typedef	long			Fixed;	// fixed point number (16.16)

typedef signed short	FWord;	// 16-bit signed integer that dedcribes a quantity of FUnits
typedef unsigned short	UFWord; // 16-bit unsigned inteter ""


#endif // _TTTYPES_H_
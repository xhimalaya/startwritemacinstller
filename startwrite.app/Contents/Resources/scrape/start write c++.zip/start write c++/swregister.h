#if !defined(AFX_SWREGISTER_H__B1814CA7_7072_11D3_B60A_444553540000__INCLUDED_)
#define AFX_SWREGISTER_H__B1814CA7_7072_11D3_B60A_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// swregister.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// swregister dialog

class swregister : public CDialog
{
// Construction
public:
	swregister(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(swregister)
	enum { IDD = IDD_REGISTER };
	CString	m_fullName;
	CString	m_email;
	CString	m_key;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(swregister)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(swregister)
	afx_msg void OnOrderkey();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWREGISTER_H__B1814CA7_7072_11D3_B60A_444553540000__INCLUDED_)

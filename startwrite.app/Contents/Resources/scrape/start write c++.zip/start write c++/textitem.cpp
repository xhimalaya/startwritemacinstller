// Text Item Class Implementation
#include <math.h>
#include <stdio.h>
#include "stdafx.h"
#include "sw.h"
#include "textitem.h"
#include "spellchk.h"
#include "miscutil.h"
#include "FontDlg.h"
#include "Annoy.h"
#include "swdoc.h"

#ifdef SW_IMAGN
#ifdef TOOL_NONE
#undef TOOL_NONE
#endif
#include "imagn.h"
#endif
#include "artdisp.h"
#include "borderartdlg.h"
#include "storyprompt.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// NOTE: The space width and the letter spacing were the same at 360.
#define LETTER_SPACE 360	/* used only on non-kerned fonts */

extern CString TxtCopy[], TxtCopyShapes[];
extern CStringW TxtCopyAttrs[];
#define MARGIN	(125)
#define BORDERARTMARGIN	100
extern int beginMathFonts;

#ifdef WRWDEBUG
ofstream DFile;
int doDump=1;
#endif
extern int inPrintPreview;
extern int doingPrinting;


// This is a quick KLUDGE but it can only be accessed when clicking so it should
// be safe.  Is is to detect the case where the system thinks we are in selection
// mode but really have not done selection.  Sometimes a single mouse click can
// move a little bit and make us think they are selecting.  So if the selection Cursor is the
// same as the regular cursor, no selection is really on so we set this variable.
// If it is zero when the button goes up, then selection was not really done.
int SelectionIsReal=0;	

// Regular cursive High chars
#define ENDS_HIGH1(c)  ((c == 'b') || (c == 'o') || (c == 'v') || (c == 'w'))

// Italic Cursive High Chars
#define ENDS_HIGH2(c)  ( (c == 'f') || (c == 'o') || (c == 'v') || (c == 'w') || (c == 'x'))

// Cursive Upright High Chars
#define ENDS_HIGH3(c)  ((c == 'o') || (c == 'v') || (c == 'w') || (c == 'x'))

#define ENDS_HIGHPALM(c)  ((c == 'b') || (c == 'v') || (c == 'w'))

#define ENDS_HIGHWOT(c)  ((c == 'b') || (c == 'v') || (c == 'w'))


#define ENDS_HIGH4(c)	((c == 'o') || (c == 'r') || (c == 'w') || (c == 'v'))
#define ENDS_HIGHV(c)	((c == 'b') || (c == 'o') || (c == 'r') || (c == 'w') || (c == 'v'))
#define ENDS_HIGHQ(c) 	((c == 'o') || (c == 'r') || (c == 'w') || (c == 'v'))
#define ENDS_HIGHNW(c)  ((c == 'o') || (c == 'v') || (c == 'w') || (c == 'x'))

// Italic Cursive Mid chars
#define ENDS_MID1(c)	(c == 'r')

#define ENDS_MIDPALM1(c)	((c == 'g') || (c == 'j') || (c == 'y') || (c == 'z'))

// Ends difference still
#define ENDS_MID2(c) ((c == 'b') || (c == 'p') || (c == 's') || (c == 'c'))
#define ENDS_MID3(c) ((c == 's') || (c == 'c') || (c == 'e'))
#define ENDS_MIDPALM2(c) ((c == 'o'))

#define ENDS_MID4(c) ((c == 's') || (c == 'c') || (c == 'b') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'y') || (c == 'z'))
//#define ENDS_MIDV(c) ((c == 's') || (c == 'e') || (c == 'c') || (c == 'p') || (c == 'x'))
#define ENDS_MIDQ(c) ((c == 'c') || (c == 'e'))

#define ENDS_MIDNW(c) (c == 'q')

// Beginning has no connect
#define BEG_NOCON(c) ((c == 'f') || (c == 'z'))
#define BEG_NOCON2(c) (c == 'z')
#define BEG_NOCONPALM(c) (0)
#define BEG_NOCONWOT(c) (0)
#define BEG_NOCON3() (0)
#define BEG_NOCONV(c) (0)
#define BEG_NOCONNW(c) (0)
#define BEG_NOCONQ(c) (0)

// American
#define AMER_BEG_NOCON(c) (c == 'Z')
#define CAP_CONMID2(c)	((c == 'H') || (c == 'G') || (c == 'I') || (c == 'S'))		// H,G,I,S has a middle connector for American

#define PALM_UPPER_CONNECT(c) ((c == 'C') || (c == 'B') || (c == 'G') || (c == 'I') || (c == 'J') || (c == 'S') || (c == 'Y') || (c == 'Z') || (c == 'H'))
#define PALM_UPPER_CONNECT2(c) ((c == 'C') || (c == 'B') || (c == 'G') || (c == 'I') || (c == 'S'))


#define WOT_UPPER_CONNECT(c) ((c == 'A') || (c == 'C') || (c == 'E') || (c == 'J') || (c == 'K') || (c == 'L') || (c == 'M') || (c == 'N') || (c == 'Q') || (c == 'R') || (c == 'U') || (c == 'X') || (c == 'Y'))


// End has no connect
#define ENDS_NOCON1(c) ((c == 'g') || (c == 'j') || (c == 'q') || (c == 'y'))
#define ENDS_NOCON2(c) ((c == 'b') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'q') || (c == 'x') || (c == 'y') || (c == 'z'))
#define ENDS_NOCONPALM(c) (0)	//(c == 'b') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'q') || (c == 'x') || (c == 'y') || (c == 'z'))
#define ENDS_NOCONWOT(c) (0)	//(c == 'b') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'q') || (c == 'x') || (c == 'y') || (c == 'z'))

#define ENDS_NOCONV(c) ((c=='g') || (c == 'y') || (c == 'j') || (c == 'z'))

#define ENDS_NOCONQ(c) ((c == 'b') || (c == 's') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'q') || (c == 'y') || (c == 'z'))

#define ENDS_NOCONNW(c) ((c == 's') || (c == 'b') || (c == 'p') || (c == 'g') || (c == 'j') || (c == 'x') || (c == 'y'))// || (c == 'z'))


// Regular Cursive Caps that connect
#define CAP_CONNECTS1(c)  ( (c == 'A') || (c == 'C') || (c == 'E') || (c == 'J') || \
	(c == 'K') || (c == 'M') || (c == 'N') || (c == 'R') || \
	(c == 'U') || (c == 'Y') || (c == 'Z') )

// Regular Cursive Caps that connect
#define CAP_CONNECTS2(c)  ((c == 'I') || (c == 'L') || (c == 'Q') || (c == 'X'))

// Regular Cursive Cap Mid Connectors
#define CAP_CONMID(c)	(c == 'H')		// H has a middle connector

#define IS_LOWER(c)  ((c >= 'a') && (c <= 'z'))
#define IS_UPPER(c)  ((c >= 'A') && (c <= 'Z'))
#define IS_ALPHA(c)	((IS_LOWER(c)) || (IS_UPPER(c)))
#define IS_NUMBER(c) ((c >= '0') && (c <= '9'))
#define IS_KERNABLE(c) ((c > 0x20) && (c != '\'') ) //&& (c < 127))     //( (IS_LOWER(c)) || (IS_UPPER(c)) || (IS_NUMBER(c)) || (c > 127))
#define IS_ALPHANUMERIC(c) ( (IS_LOWER(c)) || (IS_UPPER(c)) || (IS_NUMBER(c)))
#define IS_APOST(c) ((c == '\'')) // && (*swType != swSHR))
#define MAKESOLID(c) ((c == ',') || (c == '.') || (c == ';') || (c == ':')) //|| (c == '\'') || (c == '"') || (c == '`'))

#define PALM_SPEC(c) ((unsigned short) ((c == 'C') ? 474 : \
	((c == 'B') ? 475 : \
	((c == 'G') ? 476 : \
	((c == 'I') ? 477 : \
	((c == 'J') ? 478 : \
	((c == 'S') ? 479 : \
	((c == 'Y') ? 480 : \
	((c == 'Z') ? 481 : \
	((c == 'H') ? 483 : 0))))))))))



#define WOT_SPEC(c) ((unsigned short) ( \
	(c == 'A') ? 527 : \
	((c == 'C') ? 528 : \
	((c == 'E') ? 529 : \
	((c == 'J') ? 530 : \
	((c == 'L') ? 531 : \
	((c == 'M') ? 532 : \
	((c == 'K') ? 526 : \
	((c == 'N') ? 533 : \
	((c == 'Q') ? 534 : \
	((c == 'R') ? 535 : \
	((c == 'U') ? 536 : \
	((c == 'X') ? 537 : \
	((c == 'Y') ? 538 : 0))))))))))))))


#define DO_ARROW(pc,nc) ( ((pc == ' ') && (nc == ' ')) || \
	((pc == ' ') && !IS_ALPHA(nc)) || \
	((nc == ' ') && !IS_ALPHA(pc)) || \
	(!IS_ALPHA(pc) && !IS_ALPHA(nc))) // || (*swType == swOXF))

extern int GlobalDisplay;
static char *ValidChars = " abcdfghjkmpqtuvwxyzABCDFGHJKMPQTUVWXYZ13568.";	// Valid only in demo mode
//eilnors
int doDrawCursor = 0;
int doSetCursor = 1;
extern FONTINFO szFonts[];
extern int numSwFonts;
extern unsigned int defaultFont;

#define CBASE0 ((unsigned short)('a'))	// regular stand alone
#define CBASE1 ((unsigned short)(565))	// Caps
#define CBASE2 ((unsigned short)(598))	// reg-short
#define CBASE3 ((unsigned short)(624))	// High-short
#define CBASE4 ((unsigned short)(650))	// low - short
#define CBASE5 ((unsigned short)(676))	// High-reg
#define CBASE6 ((unsigned short)(702))	// low-reg
#define CBASE7 ((unsigned short)(727))	// END OF LIST
#define CBASE8 ((unsigned short)(511))	// After H - short
#define CBASE9 ((unsigned short)(537))	// After H - reg

// Defines for the base of the cursive italic fonts
#define ICBASE0	((unsigned short)('a'))		// regular character (stand alone)
#define ICBASE1	((unsigned short)(540))		// reg-connect
#define ICBASE2	((unsigned short)(567))		// connect-reg
#define ICBASE3	((unsigned short)(594))		// connect-connect
#define ICBASE4	((unsigned short)(621))		// high-reg
#define ICBASE5	((unsigned short)(648))		// high-connect
#define ICBASE6	((unsigned short)(675))		// mid-reg
#define ICBASE7	((unsigned short)(702))		// mid-connect
#define ICBASE8	((unsigned short)(486))		// post bps - reg
#define ICBASE9 ((unsigned short)(513))		// post bps - connect

#define ICBASE_O	((unsigned short)(462))	// Special o's
#define ICBASE_V	((unsigned short)(468))	// Special v's	
#define ICBASE_W	((unsigned short)(474))	// Special w's
#define ICBASE_X	((unsigned short)(480))	// Special x's

#define ICBASEa_C	((unsigned short)(444))	// Special c's
#define ICBASEa_S	((unsigned short)(450))	// Special s's
#define ICBASEa_O	((unsigned short)(456))	// Special o's	// for Upright/Sloped
#define ICBASEa_F	((unsigned short)(462))	// Special f's	// for Upright/Sloped
#define ICBASEa_R	((unsigned short)(468))	// Special r's	// for Upright/Sloped
#define ICBASEa_W	((unsigned short)(474))	// Special w's
#define ICBASEa_V	((unsigned short)(480))	// Special x's

/* This set for victorian */
#define ICBASEb_B	((unsigned short)(450))	// Special b's
#define ICBASEb_V	((unsigned short)(480))	// Special v's
#define ICBASEb_R	((unsigned short)(468))	// Special r's
#define ICBASEb_F	((unsigned short)(462))	// Special f's
#define ICBASEb_W	((unsigned short)(474))	// Special w's
#define ICBASEb_O	((unsigned short)(456))	// Special o's

//#define ICBASEb_Z	((unsigned short)(456))	// Special z's

#define ICBASEc_F	462	// SPecial f's

// Special case before 'e'

#define SPEC_E1(c) ((c == 'o') || (c == 'v') || (c == 'w') || (c == 'x'))
#define SETSPEC1(c)  (unsigned short)(((c == 'o') ? ICBASE_O : \
	((c == 'v') ? ICBASE_V : \
	((c == 'w') ? ICBASE_W : ICBASE_X))))

#define SPEC_E2(c) ((c == 'o') || (c == 'f') || (c == 'r') || (c == 'w') || (c == 'v') || (c == 'c') || (c == 's'))
#define SETSPEC2(c)  ((c == 'o') ? ICBASEa_O : \
	((c == 'f') ? ICBASEa_F : \
	((c == 'r') ? ICBASEa_R : \
	((c == 'c') ? ICBASEa_C : \
	((c == 's') ? ICBASEa_S : \
	((c == 'w') ? ICBASEa_W : ICBASEa_V))) )))

#define SPEC_E3(c) ((c == 'r') || (c == 'o') || (c == 'v') || (c == 'w'))
#define SETSPEC3(c)  ((c == 'o') ? ICBASEa_O : \
	((c == 'v') ? ICBASEa_V : \
	((c == 'r') ? ICBASEa_R : ICBASEa_W)))


#define SPEC_EV(c) ((c == 'o') || (c == 'b') || (c == 'v') || (c == 'f') || (c == 'r') || (c == 'w'))
#define SETSPECV(c)  ((c == 'o') ? ICBASEb_O : \
	((c == 'b') ? ICBASEb_B : \
	((c == 'v') ? ICBASEb_V : \
	((c == 'f') ? ICBASEb_F : \
	((c == 'r') ? ICBASEb_R : ICBASEb_W)))))


#define SPEC_EQ(c) ((c == 'f') || (c == 'o') || (c == 'v')  || (c == 'r') || (c == 'w'))
#define SETSPECQ(c)  ((c == 'o') ? ICBASEb_O : \
	((c == 'f') ? ICBASEb_F : \
	((c == 'r') ? ICBASEb_R : \
	((c == 'w') ? ICBASEb_W : ICBASEb_V))) )


#define SPEC_ENW(c) ((c == 'o') || (c == 'f') || (c == 'r') || (c == 'w') || (c == 'v'))
#define SPEC_ENW2(c) ((c == 'f') || (c == 'w') || (c == 'v'))
#define SETSPECNW(c)  ((c == 'o') ? ICBASEa_O : \
	((c == 'f') ? ICBASEa_F : \
	((c == 'r') ? ICBASEa_R : \
	((c == 'w') ? ICBASEa_W : ICBASEa_V))) )


#define MIN_INTERNATIONAL 192

#define A_MIN	192
#define A_MAX	197
#define a_MIN	224
#define a_MAX	229

#define E_MIN	200
#define E_MAX	203
#define e_MIN	232
#define e_MAX	235

#define I_MIN	204
#define I_MAX	207
#define i_MIN	236
#define i_MAX	239

#define O_MIN	210
#define O_MAX	214
#define o_MIN	242
#define o_MAX	246

#define U_MIN	217
#define U_MAX	220
#define u_MIN	249
#define u_MAX	252

#define Y_MIN	221
#define Y_MAX	221
#define y_MIN	253
#define y_MAX	253

#define N_MIN	209
#define N_MAX	209
#define n_MIN	241
#define n_MAX	241




unsigned short TextItem::getNormalChar(unsigned short c)
{
	//	if ((c >= 0xB0) && (c <= 0xB9))
	//		return(c);

	if (c < MIN_INTERNATIONAL) {
		return(c);
	}
	if ((c >= A_MIN) && (c <= A_MAX)) {
		return('A');
	}
	if ((c >= a_MIN) && (c <= a_MAX)) {
		return('a');
	}
	if ((c >= E_MIN) && (c <= E_MAX)) {
		return('E');
	}
	if ((c >= e_MIN) && (c <= e_MAX)) {
		return('e');
	}
	if ((c >= I_MIN) && (c <= I_MAX)) {
		return('I');
	}
	if ((c >= i_MIN) && (c <= i_MAX)) {
		return('i');
	}
	if ((c >= O_MIN) && (c <= O_MAX)) {
		return('O');
	}
	if ((c >= o_MIN) && (c <= o_MAX)) {
		return('o');
	}
	if ((c >= U_MIN) && (c <= U_MAX)) {
		return('U');
	}
	if ((c >= u_MIN) && (c <= u_MAX)) {
		return('u');
	}
	if ((c >= Y_MIN) && (c <= Y_MAX)) {
		return('Y');
	}
	if ((c >= y_MIN) && (c <= y_MAX)) {
		return('y');
	}
	if ((c >= N_MIN) && (c <= N_MAX)) {
		return('N');
	}
	if ((c >= n_MIN) && (c <= n_MAX)) {
		return('n');
	}
	return(c);
}


static int recurse_count = 0;

void TextItem::InitTextItem()
{
	// Font path...
	int i;
	lastGoodPointSize = -1;
	inPasteMode = false;

	myFontInfo = szFonts[defaultFont];

	FontPath = theApp.m_BasePath + "\\Fonts\\";
	sFontName = szFonts[defaultFont].f_fontname; 
	sFontIndex = defaultFont;

	// Use Normal unless it was set in the configs
	LedgerPenTopWidth = myFontInfo.f_TopThickness ? myFontInfo.f_TopThickness : LINE_THICK_NORMAL;
	LedgerPenMidWidth = myFontInfo.f_MidThickness ? myFontInfo.f_MidThickness : LINE_THICK_NORMAL;
	LedgerPenBasWidth = myFontInfo.f_BasThickness ? myFontInfo.f_BasThickness : LINE_THICK_NORMAL;
	LedgerPenBotWidth = myFontInfo.f_BotThickness ? myFontInfo.f_BotThickness : LINE_THICK_NORMAL;

	FontFile = FontPath + myFontInfo.f_filename;
	ConnectTheDotsFile = FontPath + myFontInfo.f_filename;

	if (myFontInfo.f_arrowname[0]) {
		ArrowFile = FontPath + myFontInfo.f_arrowname;
// do this if using connectthedots instead of arrows
//		if (myFontInfo.f_overlayname[0]) {
//			ArrowFile = FontPath + myFontInfo.f_filename;	// make arrows the fillin
//		}
	}
	else {
		ArrowFile.Empty();
	}
	if (myFontInfo.f_overlayname[0]) {
		OverlayFile = FontPath + myFontInfo.f_overlayname;
	}
	else {
		OverlayFile.Empty();
	}

	inCursive = myFontInfo.f_iscursive;
	doReformatText = 0;
	doKerning = inCursive;	// wrw -- for now -- kerning on cursive only
	inCursive &= ~DO_KERNING;	/* remove the kerning flag */
	sign = -1;
	apos_wid = 1;	/* default */
	apos_wid2 = 0;
#define DEF_ARROWWID  16
	saveAreaIsSet = false;
	//doDrawGlyf=true;
	nStartDot = theApp.m_iDefaultStartDot;
	doDrawConnectTheDots = false;
	mDescentLeading=0;  // used for normal fonts
	mDescender = 0;
	spaceWidth = (BASE_SPACEWID * theApp.m_iDefaultSpacing);	// Need to get system default
	lastSpaceWidth = spaceWidth;
	lineWidthMult = 2;
	nPenWidth = 32;
	nArrowWidth = DEF_ARROWWID;  // Width for arrows
	nOverlayWidth = DEF_ARROWWID;

#ifdef LATER_WRW
	// Just use the width of the regular dot font
	for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
		// Just set a default for all these fonts
		fsData[fsi].nWidthFS = 32;
	}
#endif

	nGlyfArrayIndex = 0;
	nLetterSpacing = doKerning ? 0 : LETTER_SPACE;
	lastPointSize=0;
	zLastPointSize=0.0;
	lastFont.Empty();
	lastOverlay = 0;
	dCurrentZoom = 1.0;

	zMargin = MARGIN;
	zBorderArtMargin = BORDERARTMARGIN;
	nPointSize = kDefaultPointSize;
	zPointSize = kDefaultPointSize * dCurrentZoom;
	nLinePointSpace = (int)(zPointSize / (float)4);
	nDot2Dot = TRUE;
	isMathFont = false;
	isMathFont2 = false;

	nOrientation = 0;
	m_bSetSelCursor=0;
	nDot2DotDensityButton = theApp.m_iDefaultDensity;
	nDot2DotShadeButton = theApp.m_iDefaultShading;
	nDot2DotArrowsButton = theApp.m_iDefaultArrows;
	nDot2DotOverlayButton = theApp.m_iDefaultOverlay;

	// which one?
	nDot2DotLinesButton = theApp.m_iDefaultLines;
	nDot2DotLinesButton = myFontInfo.f_fontLine;


	nDot2DotDensity = nDot2DotDensityButton;
	nDot2DotShade = nDot2DotShadeButton;
	nDot2DotArrows = nDot2DotArrowsButton;
	nDot2DotOverlay = nDot2DotOverlayButton;
	nDot2DotGlyfDensity = 0;
	nDot2DotGlyfShade = 0;
	nDot2DotStartDot = 2;

	doKerning = 1;	//theApp.m_iDefaultKernMode;

	// defines from texttool.h
	DensityFormat = DENSITY_NORMAL;
	ShadeFormat = SHADING_NORMAL;
	ArrowsFormat = ARROWS_NORMAL;

	// Initialize format arrays
	for( i = 0; i < MAX_GLYF_ARRAY; ++i) {
		ArrowsFormatArray[i] = 1;
	}
	for( i = 0; i < MAX_GLYF_ARRAY; ++i) {
		OverlayFormatArray[i] = 1;
	}
	resetGlyfPos();

	// Underline
	nUnderline = 0;
	// End Underline

	// The recalc of the ypos has to be done every time nPointSize is changed...
	CalcLinePointSpace();

	for(i = 0; i < (MAX_TEXT_LINES+1); ++i) {
		TxtLines[i].Empty();
		TxtShapes[i].Empty();
		TxtAttrs[i].Empty();
	}
	
	
	TxtLines[0].AppendChar((char)SW_BOL);
	TxtShapes[0].AppendChar((char)SHAPE_NONE);
	TxtAttrs[0].AppendChar((char)DELCHAR);	
	CursorLength = 100;
	CursorDrawn = CPoint(-1,-1);
	CursorPos = CPoint(0,0);	// Point to the zero position as default
	CursorIndex = CPoint(0,0);	// Actual postition in array for cursor
	ScrollPos = CPoint(0,0);		// assume screen not scrolled
	SelCursorDrawn = CPoint(-1,-1);
	SelCursorPos = CPoint(-1,-1);
	SelCursorIndex = CPoint(-1,-1);
	SelectionOn = FALSE;
	boxIsOverFull = FALSE;
	nCursorActive = FALSE;		// Cursor starts not active
	keepBackspacePos = FALSE;
	lastWordPos = -1;

	IsFromSpecialCharDlg = FALSE;
	buildNewAttributes();	// build cCurrAttr and associated data

	nAnnoyingFontMsg = FALSE;
	nAnnoyingArrowMsg = FALSE;
	nAnnoyingOverlayMsg = FALSE;
	nAnnoyingStartdotMsg = FALSE;
	nAnnoyingConnectTheDotsMsg = FALSE;
	for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
		fsData[fsi].nAnnoyingMsgFS = FALSE;
	}
	nOverfullWarning = 0;
	noGrowState = 0;
	allowFixWrap = FALSE; 
	allowAdjustBox = FALSE;

	m_iType = ITEM_TEXT_TYPE;
	mWhichDraw = TEXT_DRAW_ALL;

	memset(&undoList[0], 0, sizeof(UNDO_STRUCT)*MAX_UNDO);
	undoCount=0;
	inUndo=0;

	BorderArtChanged = FALSE;
	BorderArtZoomChanged = FALSE;
	ClearBorderArtFiles(TRUE);
	for (i = 0; i < 8; i++) {
		borderArtBufId[i] = artIdValue++;
	}
	BorderArtSizeOption = 0;
	BorderArtSize.SetPoint(0, 0);
	BorderArtZoomSize.SetPoint(0, 0);
	BorderArtCurrentZoom = 1.0;
	BorderArtMarginSize.SetPoint(0, 0);
	BorderArtMarginZoomSize.SetPoint(0, 0);
	BorderArtAdjustment.SetPoint(0, 0);
	BorderArtAdjustmentZoom.SetPoint(0, 0);
	BorderArtScrollPos.SetPoint(0, 0);
	BorderArtType = BORDER_ART_TYPE_NONE;
	BorderArtShrink = FALSE;
	BorderArtSource = BORDER_ART_SOURCE_NONE;

	// Stories
	StoryNumber = 0;
	StoryLines = 0;
	StoryItemOrder = 0;
	StoryLinesChanged = FALSE;
	StoryBoxFull = FALSE;
	StoryFlowInState = STORY_FLOW_APPEND;
	StoryFlowOutState = STORY_FLOW_APPEND;
	IsLastItemInStory = FALSE;
	StoryCursorMousePos.x = 0;
	StoryCursorMousePos.y = 0;
	tempGuideLinesOff = FALSE;
	inDialogDisplay = FALSE;

	// The three colors the user has chosen for Area Shading
	ColorTopAreaShading = theApp.m_iDefaultColorTopArea;
	IsShadingOnTopArea = theApp.m_TopAreaColorOn;
	ColorMiddleAreaShading = theApp.m_iDefaultColorMiddleArea;
	IsShadingOnMiddleArea = theApp.m_MidAreaColorOn;
	ColorDescenderAreaShading = theApp.m_iDefaultColorBottomArea;
	IsShadingOnDescenderArea = theApp.m_BotAreaColorOn;

	// The color the user selected for stroke arrows
	ColorStrokeArrows = theApp.m_iDefaultArrowColor;
	// The color the user selected for starting dot
	ColorStartingDot = theApp.m_iDefaultStartDotColor; //Red default for Start Dot
	// The color the user selected for outline (outline overlay of outline font)
	ColorOutlineOverlay = theApp.m_iDefaultOverlayColor;
	// The color the user selected for decision dots
	ColorDecisionDots = theApp.m_iDefaultDecisionDotColor; // Orange default for Decision Dots
	ColorConnectTheDots = theApp.m_iDefaultConnectDotColor;
	// The four colors the user chose for drawing colored letters
	ColorFirstStrokeLetters = theApp.m_iDefaultColorStrokeOne;
	ColorSecondStrokeLetters = theApp.m_iDefaultColorStrokeTwo;
	ColorThirdStrokeLetters = theApp.m_iDefaultColorStrokeThree;
	ColorFourthStrokeLetters = theApp.m_iDefaultColorStrokeFour;
	// The four colors the user chose for drawing guidelines
	ColorGuidelineTop = myFontInfo.f_TopColor;//!!!RGB(255,0,0);
	ColorGuidelineMiddle = myFontInfo.f_MidColor;//!!!RGB(0,0,255);
	ColorGuidelineBase = myFontInfo.f_BasColor;//!!!RGB(255,0,0);
	ColorGuidelineBottom = myFontInfo.f_BotColor;//!!!RGB(0,0,0);
}

// Main contructor
TextItem::TextItem() :
m_bSetCursorToClicked(FALSE)
{
	pParentBBox = NULL;
	InitTextItem();
}
// main destructor
TextItem::~TextItem()
{
	if (Dot2DotFont.isOpen == true) {
		Dot2DotFont.Close();
	}
	if (ArrowFont.isOpen == true) {
		ArrowFont.Close();
	}
	if (OverlayFont.isOpen == true) {
		OverlayFont.Close();
	}
	for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
		if (fsData[fsi].TTFontFS.isOpen == true)
			fsData[fsi].TTFontFS.Close();
	}
	if (StartDotFont.isOpen == true) {
		StartDotFont.Close();
	}
	if (ConnectTheDotsFont.isOpen == true) {
		ConnectTheDotsFont.Close();
	}

	FreeBorderArtBuffers();

	pParentBBox = NULL;
}

void TextItem::Delete()
{
	delete this;	// this is BAD code ->~TextItem();
}


void TextItem::Read(fstream *fin, Module *pmodule, int *status)
{
	char line[256];
	int ntextline = -1;
	int doReadnl;
	BOOL upgradeOldBorderArtVersion = TRUE;// Previous BorderArt version did not have separate Shrink option
	bool foundFont=false;
	bool isAmericanFont=false;
	BOOL upgradeForSpecialChars = TRUE;// Files that were saved before existence of Special Chars popup need TxtShapes created

	pmodule;	/* no warning */

	*status = ERROR;	// assume error, good case will set to OK

	while( (!fin->eof()) && (*status == ERROR))
	{
		fin->getline( line, 256, SWD_EQ_);

		doReadnl = 1;	// default: We need to read the newline
		if( strcmp(line,SWD_NEXTLINE) == S1_EQUALS_S2) {            
			TxtLines[++ntextline].Empty();		// Clear out anything there
			fin->getline( line, 256, SWD_NL_);	// Read the next line
			TxtLines[ntextline] = line;			// and assign it into the list
			doReadnl=0;	// already read
			if (TxtLines[ntextline].GetLength() > 1)
			{
				StoryFlowInState = STORY_FLOW_INSERT;
			}
		}
		else if( strcmp(line,SWD_NEXTATTRW) == S1_EQUALS_S2) {            
			TxtAttrs[ntextline].Empty();		// Clear out anything there
			short ti, tcnt, t1;
			char t2;
			*fin >> tcnt;
			*fin >> t2;
			for (ti =0; ti < tcnt; ti++) {
				*fin >> t1;
				*fin >> t2;
				TxtAttrs[ntextline].AppendChar(t1);
			}
			doReadnl=1;	// already read
		}
		else if( strcmp(line,SWD_NEXTATTR) == S1_EQUALS_S2) {            
			TxtAttrs[ntextline].Empty();		// Clear out anything there
			fin->getline( line, 256, SWD_NL_);	// Read the next line
			TxtAttrs[ntextline] = line;			// and assign it into the list
			doReadnl=0;	// already read
		}
		else if( strcmp(line,SWD_NEXTSHAPE) == S1_EQUALS_S2) {            
			TxtShapes[ntextline].Empty();		// Clear out anything there
			fin->getline( line, 256, SWD_NL_);	// Read the next line
			TxtShapes[ntextline] = line;			// and assign it into the list
			doReadnl=0;	// already read
			upgradeForSpecialChars = FALSE;// (This SW file was created after development of Special Chars)
		}
		else if( strcmp(line,SWD_FONTNAME) == S1_EQUALS_S2)
		{            
			sFontName.Empty();
			fin->getline( line, 256, SWD_NL_);
			sFontName = line;
			sFontIndex = 0;
			doReadnl=0;	// already read
			// We made a font name change for long term consistancy
			// So the original Manuscript is SWFont1, Mod Man is SWFont 2, Italic is SWFont 3
			if (!strncmp(sFontName, "SWFont ", 7)) {	// If old method
				char fnum = sFontName[7];
				switch(fnum) {
					default:
					case '1':
						sFontName = "Manuscript";
						break;
					case '2':
						sFontName = "Modern Manuscript";
						break;
					case '3':
						sFontName = "Italic";
						break;
					case '4':
						sFontName = "HOP Manuscript";
						break;
					case '5':
						sFontName = "Cursive";
						break;
					case '6':
						sFontName = "Modern Cursive";
						break;
				}					
			}
			else if (!strcmp(sFontName, "Hooked Manuscript")) {	// If old method
				sFontName = "HOP Manuscript";
			}
			else if ((*swType == swHOP) && (!strcmp(sFontName, "Italic 2"))) {
				sFontName = "HOP Manuscript";
			}
			else if ((!strcmp(sFontName, "Palmer"))) {
				sFontName = "PLMR";
			}
			else if ((!strcmp(sFontName, "Palmer Cursive"))) {
				sFontName = "PLMRCursive";
			}
			else if ((!strcmp(sFontName, "New American Cursive"))) {
				isAmericanFont=true;	// there might be some out there with the old way
			}
			// Get the font index 
			for(unsigned int i = 0; szFonts[i].f_fontname[0] ; i++) {
				if (!strcmp(sFontName, szFonts[i].f_fontname)) {
					sFontIndex = i;
					foundFont=true;
					break;
				}
			}
			if ((foundFont == false) && (isAmericanFont == true)) {
				sFontName = "AmericanCursive";	// so try this if we didn't find the other
				for(unsigned int i = 0; szFonts[i].f_fontname[0] ; i++) {
					if (!strcmp(sFontName, szFonts[i].f_fontname)) {
						sFontIndex = i;
						foundFont=true;
						break;
					}
				}
			}
		}

		else if( strcmp(line,SWD_POINTSIZE) == S1_EQUALS_S2)
		{            
			*fin >> nPointSize;
			CalcLinePointSpace();
		}
		else if( strcmp(line,SWD_DOT2DOT) == S1_EQUALS_S2)
		{            
			*fin >> nDot2Dot;
		}

		else if( strcmp(line,SWD_DENSITYBUTTON) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotDensityButton;
		}
		else if( strcmp(line,SWD_SHADEBUTTON) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotShadeButton;
		}
		else if( strcmp(line,SWD_LINESBUTTON) == S1_EQUALS_S2)
		{
			*fin >> nDot2DotLinesButton;
		}
		else if( strcmp(line,SWD_ARROWSBUTTON) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotArrowsButton;
		}
		else if( strcmp(line,SWD_DENSITY) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotDensity;
		}
		else if( strcmp(line,SWD_DENSITYFORM) == S1_EQUALS_S2)
		{            
			*fin >> DensityFormat;
		}
		else if( strcmp(line,SWD_SHADE) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotShade;
		}
		else if( strcmp(line,SWD_SHADEFORM) == S1_EQUALS_S2)
		{            
			*fin >> ShadeFormat;
		}
		else if( strcmp(line,SWD_ARROWS) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotArrows;
		}
		else if( strcmp(line,SWD_OVERLAY) == S1_EQUALS_S2)
		{            
			*fin >> nDot2DotOverlayButton;
		}
		else if( strcmp(line,SWD_ARROWSFORM) == S1_EQUALS_S2)
		{            
			*fin >> ArrowsFormat;
		}
		else if( strcmp(line,SWD_DOKERNING) == S1_EQUALS_S2)
		{            
			*fin >> doKerning;
		}
		else if ( strcmp(line,SWD_SPACEWIDTH) == S1_EQUALS_S2) {
			*fin >> spaceWidth;
		}
		else if ( strcmp(line,SWD_YELLOWGUIDE) == S1_EQUALS_S2) {
			*fin >> doYellowGuide;
			// Reading old files will set this
			if (doYellowGuide == 1) {
				IsShadingOnMiddleArea = TRUE;
				ColorMiddleAreaShading = RGB(252,252,0);
			}
			else if (doYellowGuide == 2) {
				IsShadingOnDescenderArea = TRUE;
				ColorDescenderAreaShading = RGB(252,252,0);
			}
		}
		else if ( strcmp(line,SWD_TOPAREA_ONOFF) == S1_EQUALS_S2) {
			*fin >> IsShadingOnTopArea;
		}
		else if ( strcmp(line,SWD_TOPAREA_COLOR) == S1_EQUALS_S2) {
			*fin >> ColorTopAreaShading;
		}
		else if ( strcmp(line,SWD_MIDAREA_ONOFF) == S1_EQUALS_S2) {
			*fin >> IsShadingOnMiddleArea;
		}
		else if ( strcmp(line,SWD_MIDAREA_COLOR) == S1_EQUALS_S2) {
			*fin >> ColorMiddleAreaShading;
		}
		else if ( strcmp(line,SWD_BOTAREA_ONOFF) == S1_EQUALS_S2) {
			*fin >> IsShadingOnDescenderArea;
		}
		else if ( strcmp(line,SWD_BOTAREA_COLOR) == S1_EQUALS_S2) {
			*fin >> ColorDescenderAreaShading;
		}
		else if ( strcmp(line, 	SWD_STARTDOT) == S1_EQUALS_S2) {
			*fin >> nStartDot;
		}
		else if ( strcmp(line, 	SWD_COLORED) == S1_EQUALS_S2) {
			int tVal;
			*fin >> tVal;
			for(int fsi=0; fsi < STROKE_COUNT; fsi++) {
				fsData[fsi].nDot2DotFSButton = tVal;
			}
		}
		else if ( strcmp(line, 	SWD_CONNECTDOTS) == S1_EQUALS_S2) {
			*fin >> doDrawConnectTheDots;
		}
		else if ( strcmp(line, 	SWD_DECISIONDOTS) == S1_EQUALS_S2) {
			*fin >> fsData[DECISN_DOT_IND].nDot2DotFSButton;
		}
		else if ( strcmp(line, 	SWD_BORDERARTSHRINK) == S1_EQUALS_S2) {
			*fin >> BorderArtShrink;
			upgradeOldBorderArtVersion = FALSE;// This was saved with current version BorderArt
		}
		else if ( strcmp(line, 	SWD_BORDERARTSOURCE) == S1_EQUALS_S2) {
			*fin >> BorderArtSource;
		}
		else if ( strcmp(line, 	SWD_BORDERARTTYPE) == S1_EQUALS_S2) {
			*fin >> BorderArtType;
			if (upgradeOldBorderArtVersion && BorderArtType == BORDER_ART_TYPE_COMPLEX) {
				BorderArtShrink = TRUE;
			}
			// BorderArtShrink has been made always true and not available as a user choice, but all code is available, just disabled
			// If we decide to re-enable it AS A USER OPTION, remove the line below and also see notes in borderartdlg.cpp
			BorderArtShrink = TRUE;
		}
		else if ( strcmp(line, 	SWD_BORDERARTSIZE) == S1_EQUALS_S2) {
			*fin >> BorderArtSizeOption;
		}
		else if ( strcmp(line, 	SWD_BORDERARTNAME) == S1_EQUALS_S2) {
			BorderArtFile[0].Empty();
			fin->getline( line, 256, SWD_NL_);
			BorderArtFile[0] = line;
			doReadnl=0;	// already read
		}
		else if ( strcmp(line, 	SWD_STORYINCLUDEDIN) == S1_EQUALS_S2) {
			*fin >> StoryNumber;
		}
		else if ( strcmp(line, 	SWD_STORYLINES) == S1_EQUALS_S2) {
			*fin >> StoryLines;
		}
		else if ( strcmp(line, 	SWD_STORYBOXFULL) == S1_EQUALS_S2) {
			*fin >> StoryBoxFull;
		}
		else if ( strcmp(line, 	SWD_TOPLINETYPE) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_TopLine;
		}
		else if ( strcmp(line, 	SWD_TOPLINECOLORIND) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_TopColorInd;
		}
		else if ( strcmp(line, 	SWD_TOPLINECOLORVAL) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_TopColor;
		}
		else if ( strcmp(line, 	SWD_MIDLINETYPE) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_MidLine;
		}
		else if ( strcmp(line, 	SWD_MIDLINECOLORIND) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_MidColorInd;
		}
		else if ( strcmp(line, 	SWD_MIDLINECOLORVAL) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_MidColor;
		}
		else if ( strcmp(line, 	SWD_BOTLINETYPE) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BotLine;
		}
		else if ( strcmp(line, 	SWD_BOTLINECOLORIND) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BotColorInd;
		}
		else if ( strcmp(line, 	SWD_BOTLINECOLORVAL) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BotColor;
		}
		else if ( strcmp(line, 	SWD_BASLINETYPE) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BasLine;
		}
		else if ( strcmp(line, 	SWD_BASLINECOLORIND) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BasColorInd;
		}
		else if ( strcmp(line, 	SWD_BASLINECOLORVAL) == S1_EQUALS_S2) {
			*fin >> myFontInfo.f_BasColor;
		}
		else if ( strcmp(line, 	SWD_ARROWSCOLOR) == S1_EQUALS_S2) {
			*fin >> ColorStrokeArrows;
		}
		else if ( strcmp(line, 	SWD_STARTDOTCOLOR) == S1_EQUALS_S2) {
			*fin >> ColorStartingDot;
		}
		else if ( strcmp(line, 	SWD_OVERLAYCOLOR) == S1_EQUALS_S2) {
			*fin >> ColorOutlineOverlay;
		}
		else if ( strcmp(line, 	SWD_DECISIONCOLOR) == S1_EQUALS_S2) {
			*fin >> ColorDecisionDots;
		}
		else if ( strcmp(line, 	SWD_CONNECTDOTCOLOR) == S1_EQUALS_S2) {
			*fin >> ColorConnectTheDots;
		}
		else if ( strcmp(line, 	SWD_LINE1COLOR) == S1_EQUALS_S2) {
			*fin >> ColorFirstStrokeLetters;
		}
		else if ( strcmp(line, 	SWD_LINE2COLOR) == S1_EQUALS_S2) {
			*fin >> ColorSecondStrokeLetters;
		}
		else if ( strcmp(line, 	SWD_LINE3COLOR) == S1_EQUALS_S2) {
			*fin >> ColorThirdStrokeLetters;
		}
		else if ( strcmp(line, 	SWD_LINE4COLOR) == S1_EQUALS_S2) {
			*fin >> ColorFourthStrokeLetters;
		}
		else if ( strcmp(line, SWD_GUIDELINEOFF) == S1_EQUALS_S2) {
			*fin >> tempGuideLinesOff;
		}
		else if ( strcmp(line, SWD_GUILDLINETOPWID) == S1_EQUALS_S2) {
			*fin >> LedgerPenTopWidth;
		}
		else if ( strcmp(line, SWD_GUILDLINEMIDWID) == S1_EQUALS_S2) {
			*fin >> LedgerPenMidWidth;
		}
		else if ( strcmp(line, SWD_GUILDLINEBASWID) == S1_EQUALS_S2) {
			*fin >> LedgerPenBasWidth;
		}
		else if ( strcmp(line, SWD_GUILDLINEBOTWID) == S1_EQUALS_S2) {
			*fin >> LedgerPenBotWidth;
		}
		else if( strcmp(line,SWD_ENDTEXTITEM) == S1_EQUALS_S2)
		{            
			*status = OK; // Finished
		}
		if (doReadnl) {
			fin->getline( line, 256, SWD_NL_);
		}
	}

	// If we are upgrading a file that was created prior to the existence of Special Chars, create TxtShapes[] now
	if (upgradeForSpecialChars) {
		for (int nLine=0; nLine < MAX_TEXT_LINES; nLine++) {
			int nLineLen = TxtLines[nLine].GetLength();
			if (nLineLen < 1) {
				break;
			}
			for (int nChar = 0;nChar < nLineLen; nChar++) {
				TxtShapes[nLine].AppendChar(SHAPE_NONE);
			}
		}
	}

	// now the file is loaded, updated the correct data
	RestoreBorderArt();
	SetViaMembers();
}

void TextItem::Write(fstream *fout, Module *pmodule, int *status)
{
	pmodule; status;	/* no warning */
	short t1,tcnt,ti;
	*fout << SWD_BEGINTEXTITEM << SWD_EQ << "*" << SWD_NL;

	for( int i = 0; i < MAX_TEXT_LINES; ++i) {
		if( TxtLines[i].IsEmpty()) 	// If we reach an empty one
			break;						// We are done

		*fout << SWD_NEXTLINE << SWD_EQ << TxtLines[i] << SWD_NL;	// dump text

		// NEW WAY   SWD_NEXTATTRW~count5xxxxx\n
		*fout << SWD_NEXTATTRW << SWD_EQ;
		tcnt = TxtAttrs[i].GetLength();
		*fout << tcnt;
		*fout << SWD_EQ;
		for(ti=0; ti < tcnt; ti++) {
			t1 = TxtAttrs[i].GetAt(ti);
			*fout << t1;
			*fout << SWD_EQ;
		}
		*fout <<  SWD_NL;	//.dump attrs

		// NEW WAY end

		*fout << SWD_NEXTSHAPE << SWD_EQ << TxtShapes[i] << SWD_NL;	//.dump shapes
	}

	*fout << SWD_FONTNAME 	<< SWD_EQ	<< sFontName	<< SWD_NL;
	*fout << SWD_POINTSIZE	<< SWD_EQ	<< nPointSize 	<< SWD_NL;

	*fout << SWD_DOT2DOT			<< SWD_EQ	<< nDot2Dot 				<< SWD_NL;
	*fout << SWD_DENSITYBUTTON	<< SWD_EQ	<< (int)nDot2DotDensityButton 	<< SWD_NL;
	*fout << SWD_SHADEBUTTON		<< SWD_EQ	<< (int)nDot2DotShadeButton 		<< SWD_NL;
	*fout << SWD_LINESBUTTON		<< SWD_EQ	<< (int)nDot2DotLinesButton 		<< SWD_NL;
	*fout << SWD_ARROWSBUTTON	<< SWD_EQ	<< (int)nDot2DotArrowsButton 	<< SWD_NL;

	*fout << SWD_DENSITY		<< SWD_EQ	<< (int)nDot2DotDensity	<< SWD_NL;
	*fout << SWD_DENSITYFORM	<< SWD_EQ	<< DensityFormat	<< SWD_NL;
	*fout << SWD_SHADE		<< SWD_EQ	<< (int)nDot2DotShade	<< SWD_NL;
	*fout << SWD_SHADEFORM	<< SWD_EQ	<< ShadeFormat		<< SWD_NL;
	*fout << SWD_ARROWS		<< SWD_EQ	<< nDot2DotArrows 	<< SWD_NL;
	*fout << SWD_OVERLAY	<< SWD_EQ	<< nDot2DotOverlayButton 	<< SWD_NL;
	*fout << SWD_ARROWSFORM	<< SWD_EQ	<< ArrowsFormat 	<< SWD_NL;
	*fout << SWD_DOKERNING	<< SWD_EQ	<< doKerning		<< SWD_NL;
	*fout << SWD_SPACEWIDTH	<< SWD_EQ	<< spaceWidth		<< SWD_NL;
	//*fout << SWD_YELLOWGUIDE	<< SWD_EQ	<< doYellowGuide		<< SWD_NL;

	*fout << SWD_TOPAREA_ONOFF	<< SWD_EQ	<< IsShadingOnTopArea		<< SWD_NL;
	*fout << SWD_TOPAREA_COLOR	<< SWD_EQ	<< ColorTopAreaShading		<< SWD_NL;
	*fout << SWD_MIDAREA_ONOFF	<< SWD_EQ	<< IsShadingOnMiddleArea		<< SWD_NL;
	*fout << SWD_MIDAREA_COLOR	<< SWD_EQ	<< ColorMiddleAreaShading		<< SWD_NL;
	*fout << SWD_BOTAREA_ONOFF	<< SWD_EQ	<< IsShadingOnDescenderArea		<< SWD_NL;
	*fout << SWD_BOTAREA_COLOR	<< SWD_EQ	<< ColorDescenderAreaShading		<< SWD_NL;

	*fout << SWD_STARTDOT	<< SWD_EQ	<< nStartDot		<< SWD_NL;
	
	*fout << SWD_COLORED	<< SWD_EQ	<< fsData[STROKE_ONE_IND].nDot2DotFSButton	<< SWD_NL;
	*fout << SWD_CONNECTDOTS	<< SWD_EQ	<< doDrawConnectTheDots	<< SWD_NL;
	*fout << SWD_DECISIONDOTS	<< SWD_EQ	<< fsData[DECISN_DOT_IND].nDot2DotFSButton		<< SWD_NL;

	*fout << SWD_BORDERARTSHRINK	<< SWD_EQ	<< BorderArtShrink		<< SWD_NL;
	*fout << SWD_BORDERARTTYPE	<< SWD_EQ	<< BorderArtType		<< SWD_NL;
	*fout << SWD_BORDERARTSIZE	<< SWD_EQ	<< BorderArtSizeOption		<< SWD_NL;
	*fout << SWD_BORDERARTSOURCE	<< SWD_EQ	<< BorderArtSource		<< SWD_NL;
	*fout << SWD_BORDERARTNAME	<< SWD_EQ	<< BorderArtFile[0]		<< SWD_NL;
	*fout << SWD_STORYINCLUDEDIN	<< SWD_EQ	<< StoryNumber		<< SWD_NL;
	*fout << SWD_STORYLINES	<< SWD_EQ	<< StoryLines		<< SWD_NL;
	*fout << SWD_STORYBOXFULL	<< SWD_EQ	<< StoryBoxFull		<< SWD_NL;
	*fout << SWD_TOPLINETYPE	<< SWD_EQ	<< myFontInfo.f_TopLine	<< SWD_NL;
	*fout << SWD_TOPLINECOLORIND	<< SWD_EQ	<< myFontInfo.f_TopColorInd	<< SWD_NL;
	*fout << SWD_TOPLINECOLORVAL	<< SWD_EQ	<< myFontInfo.f_TopColor	<< SWD_NL;
	*fout << SWD_MIDLINETYPE	<< SWD_EQ	<< myFontInfo.f_MidLine	<< SWD_NL;
	*fout << SWD_MIDLINECOLORIND	<< SWD_EQ	<< myFontInfo.f_MidColorInd	<< SWD_NL;
	*fout << SWD_MIDLINECOLORVAL	<< SWD_EQ	<< myFontInfo.f_MidColor	<< SWD_NL;
	*fout << SWD_BOTLINETYPE	<< SWD_EQ	<< myFontInfo.f_BotLine	<< SWD_NL;
	*fout << SWD_BOTLINECOLORIND	<< SWD_EQ	<< myFontInfo.f_BotColorInd	<< SWD_NL;
	*fout << SWD_BOTLINECOLORVAL	<< SWD_EQ	<< myFontInfo.f_BotColor	<< SWD_NL;
	*fout << SWD_BASLINETYPE	<< SWD_EQ	<< myFontInfo.f_BasLine	<< SWD_NL;
	*fout << SWD_BASLINECOLORIND	<< SWD_EQ	<< myFontInfo.f_BasColorInd	<< SWD_NL;
	*fout << SWD_BASLINECOLORVAL	<< SWD_EQ	<< myFontInfo.f_BasColor	<< SWD_NL;
	*fout << SWD_ARROWSCOLOR	<< SWD_EQ	<< ColorStrokeArrows	<< SWD_NL;
	*fout << SWD_STARTDOTCOLOR	<< SWD_EQ	<< ColorStartingDot	<< SWD_NL;
	*fout << SWD_OVERLAYCOLOR	<< SWD_EQ	<< ColorOutlineOverlay	<< SWD_NL;
	*fout << SWD_DECISIONCOLOR	<< SWD_EQ	<< ColorDecisionDots	<< SWD_NL;
	*fout << SWD_CONNECTDOTCOLOR << SWD_EQ	<< ColorConnectTheDots	<< SWD_NL;
	*fout << SWD_LINE1COLOR	<< SWD_EQ	<< ColorFirstStrokeLetters	<< SWD_NL;
	*fout << SWD_LINE2COLOR	<< SWD_EQ	<< ColorSecondStrokeLetters	<< SWD_NL;
	*fout << SWD_LINE3COLOR	<< SWD_EQ	<< ColorThirdStrokeLetters	<< SWD_NL;
	*fout << SWD_LINE4COLOR	<< SWD_EQ	<< ColorFourthStrokeLetters	<< SWD_NL;
	*fout << SWD_GUIDELINEOFF << SWD_EQ	<< tempGuideLinesOff << SWD_NL;
	*fout << SWD_GUILDLINETOPWID << SWD_EQ	<< LedgerPenTopWidth << SWD_NL;
	*fout << SWD_GUILDLINEMIDWID << SWD_EQ	<< LedgerPenMidWidth << SWD_NL;
	*fout << SWD_GUILDLINEBASWID << SWD_EQ	<< LedgerPenBasWidth << SWD_NL;
	*fout << SWD_GUILDLINEBOTWID << SWD_EQ	<< LedgerPenBotWidth << SWD_NL;
	*fout << SWD_ENDTEXTITEM	<< SWD_EQ	<< "*" 	<< SWD_NL;
	
}


int TextItem::SetCursor(CPoint cp)
{
	int retv=0;

	if (cp.x == 1) {
		wchar_t testChar = TxtAttrs[cp.y].GetAt(0);
		if ((testChar == DELCHAR) || (testChar == EOLHCHAR)) {
			cp.x--;
			retv=1;
		}
	}

	// There is some case where when we click to the end of a line, we get one too far
	// This catches that case and keeps the cursor from an illegal position
	if (cp.x > TxtLines[cp.y].GetLength()) {
		cp.x = TxtLines[cp.y].GetLength();
	}
	CursorIndex = cp;

	if (m_bSetSelCursor & 2) {	// Set the selection cursor if necessary
		SelCursorIndex = cp;
		m_bSetSelCursor = m_bSetSelCursor & ~2;
	}
	return retv;
}

void TextItem::SetCursorPos(CPoint cp, int curlen)
{
	if (doSetCursor) {
		CursorPos = cp;
		CursorLength = curlen + 100;
	}

	if (m_bSetSelCursor & 1) {	// Set the selection cursor if necessary
		SelCursorPos = cp;
		m_bSetSelCursor = m_bSetSelCursor & ~1;
	}
}
/////
#pragma message("Wayne -- This call resets all the font default from the szFonts settings -- not sure we want on guideline changes")
#pragma message("Do we need to set the defaults font stuff in memory so it doesn't change")

void TextItem::SetViaMembersReverse()
{
	szFonts[sFontIndex].f_TopLine = myFontInfo.f_TopLine;
	szFonts[sFontIndex].f_MidLine = myFontInfo.f_MidLine;
	szFonts[sFontIndex].f_BasLine = myFontInfo.f_BasLine;
	szFonts[sFontIndex].f_BotLine = myFontInfo.f_BotLine;

}

void TextItem::SetViaMembers(int doFullReset)
{
	CString toggle1 = "01";
	CString toggle2 = "38";
	bool doToggle=false;

	//myFontInfo = szFonts[sFontIndex];	// THIS IS BAD.. Clobbers the local settings
	// particularly, the guidelines saved in a file get clobberd by this default setting
	
	// so calc the size of all the data except the guidelines data
	if (doFullReset == 0) {
		int copysize = &szFonts[sFontIndex].midSection -  &szFonts[sFontIndex].f_filename[0];
		memmove(&myFontInfo, &szFonts[sFontIndex], copysize );
	}
	else {
		// we do this in the font dialog example when the fonts can be changing
		myFontInfo = szFonts[sFontIndex];
	}

	if (nDot2DotOverlayButton != lastOverlay) {
		if (*myFontInfo.f_overlayname) {
			doToggle = true;
			if (nDot2DotOverlayButton == 2) {
				toggle1 = myFontInfo.f_filename;
				toggle1 = toggle1.Mid(5,2);
				toggle2 = myFontInfo.f_overlayname;
				toggle2 = toggle2.Mid(5,2);
			}
			else {	// go back the other way
				toggle2 = myFontInfo.f_filename;
				toggle2 = toggle2.Mid(5,2);
				toggle1 = myFontInfo.f_overlayname;
				toggle1 = toggle1.Mid(5,2);
			}
		}
	}

	CalcLinePointSpace();
	//WRW
	float upem = 2048.00;
	float points = zPointSize;

	float points_per_inch = 72.00;
	// Equation from page 4 of 40 in the Apple's Font Engine reference
	float scale = ( points * (float)PIXELS_PER_INCH ) 
		/ ( points_per_inch * upem );

	zMargin = (int) ((float)MARGIN * scale);
	zBorderArtMargin = (int) ((float)BORDERARTMARGIN * scale);
	if (BorderArtType > BORDER_ART_TYPE_NONE) {
		zMargin = (int) ((float)(MARGIN + BORDERARTMARGIN) * scale);
	}
	// WRW
	if( sFontIndex < numSwFonts) {	/* Include swdot and swmath fonts */
		if (sFontIndex < beginMathFonts) {
			nDot2Dot = TRUE;
			isMathFont=false;
			isMathFont2=false;
		}
		else {
			nDot2Dot = false;//TRUE;
			isMathFont = true;
			isMathFont2=false;
		}
		FontFile = FontPath + myFontInfo.f_filename;
		if (doToggle) {
			FontFile.Replace(toggle1, toggle2);
		}
		ConnectTheDotsFile = FontPath + myFontInfo.f_filename;
		if (doToggle) {
			ConnectTheDotsFile.Replace(toggle1, toggle2);
		}

		if (myFontInfo.f_arrowname[0]) {
			ArrowFile = FontPath + myFontInfo.f_arrowname;
			if (doToggle) {
				ArrowFile.Replace(toggle1, toggle2);
			}
		}
		else {
			ArrowFile.Empty();
		}

		if (myFontInfo.f_overlayname[0]) {
			OverlayFile = FontPath + myFontInfo.f_overlayname;
		}
		else {
			nDot2DotOverlayButton = 1;
			OverlayFile.Empty();
		}

		for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
			switch(fsi) {
			case STROKE_ONE_IND:
			case STROKE_TWO_IND:
			case STROKE_THR_IND:
			case STROKE_FOR_IND:
				if (myFontInfo.f_cffont[0]) {
					fsData[fsi].FilenameFS = FontPath + myFontInfo.f_cffont;
					fsData[fsi].FilenameFS.Replace('#', fsi+'w');
					if (doToggle) {
						fsData[fsi].FilenameFS.Replace(toggle1, toggle2);
					}
				}
				else {
					fsData[fsi].FilenameFS.Empty();
					fsData[fsi].nDot2DotFSButton = 1;
				}
				break;
			case DECISN_DOT_IND:
				if (myFontInfo.f_ddfont[0]) {
					fsData[fsi].FilenameFS = FontPath + myFontInfo.f_ddfont;
					if (doToggle) {
						fsData[fsi].FilenameFS.Replace(toggle1, toggle2);
					}
				}
				else {
					fsData[fsi].FilenameFS.Empty();
					fsData[fsi].nDot2DotFSButton = 1;
				}
			}
		}		

		if (myFontInfo.f_dotname[0]) {
			StartDotFile = FontPath + myFontInfo.f_dotname;
			if (doToggle) {
				StartDotFile.Replace(toggle1, toggle2);
			}
		}
		else {
			StartDotFile.Empty();
		}

		inCursive = myFontInfo.f_iscursive;

		apos_wid = 1;	/* set the defaults */
		apos_wid2 = 0;
		if (*swType == swSHR) {
			char testChar6, testChar5;

			/* Be sure these are the English Sherston fonts 09, 10, 11, 12, 13, 14 */
			testChar5 = myFontInfo.f_filename[5];
			testChar6 = myFontInfo.f_filename[6];

			if ((testChar5 == '0') && (testChar6 == '9')) {
				apos_wid = 2;
			}
			else if (testChar5 == '1') {
				switch(testChar6) {
				case '0':
				case '1':
					apos_wid = 2;
					break;
				case '2':
				case '3':
				case '4':	// from the line
					apos_wid2 = 1;
					apos_wid = 1;
					break;
				default:	/* none */
					/* all non-sherston fonts here */
					apos_wid = 1;
					break;
				}
			}
		}
	}
	else if( sFontIndex < numSwFonts) {	/* Include swdot and swmath fonts */
		nDot2Dot = false;
		inCursive = false;
		isMathFont = true;
		isMathFont2=false;
	}
	else { 
		nDot2Dot = FALSE;
		inCursive = FALSE;
		isMathFont = false;
		isMathFont2=false;
	}
	doKerning = inCursive;	// wrw -- for now -- kerning on cursive only
	inCursive &= ~DO_KERNING;
	nLetterSpacing = doKerning ? 0 : LETTER_SPACE;
	if (nDot2Dot == TRUE) {
		// Density
		int nvalue = nDot2DotDensityButton;

		if( nvalue >= 0 && nvalue <= 4)	{ 
			nDot2DotDensity = nvalue;
		}

		// Shade
		nvalue = nDot2DotShadeButton;
		if( nvalue >= 1 && nvalue <= 4) {
			nDot2DotShade = nvalue;
		}

		// Ledger Lines
		//nvalue = nDot2DotLinesButton;
		//if( nvalue >= 1 && nvalue <= 4)	{ 
		//	nDot2DotLinesButton = nvalue;
		//}

		nvalue = nDot2DotArrowsButton;
		if( nvalue >= 1 && nvalue <= 2)	{
			nDot2DotArrows = nvalue;
		}

		nvalue = nDot2DotOverlayButton;
		if( nvalue >= 1 && nvalue <= 2)	{
			nDot2DotOverlay = nvalue;
		}

		for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
			nvalue = fsData[fsi].nDot2DotFSButton;
			if( nvalue >= 1 && nvalue <= 2)	{
				fsData[fsi].nDot2DotFS = nvalue;
			}
		}
		
		nvalue = nStartDot;
		if (nvalue == 1) {
			nDot2DotStartDot = 2;
		}
		else {
			nDot2DotStartDot = 1;
		}
	}  

	/// Rebuild the text with the new formats
	ReformatText();
}

int TextItem::GetColoredStroke()
{
	return(fsData[0].nDot2DotFSButton);
}
void TextItem::SetColoredStroke(int newVal)
{
	for(int fsi=0; fsi < STROKE_COUNT; fsi++) {
		fsData[fsi].nDot2DotFSButton = newVal;
	}
}

int TextItem::GetFSFontSetting(int index)
{
	return(fsData[index].nDot2DotFSButton);
}
void TextItem::SetFSFontSetting(int fsIndex, int newVal)
{
	if ((fsIndex >= 0) && (fsIndex < MAX_FS_FONTS)) {
		fsData[fsIndex].nDot2DotFSButton = newVal;
	}
}

void TextItem::TestAttrState()
{
#ifndef FREEZ
	wchar_t attr;     	           
	int counter=0;
	int len1, len2;
	for(int i =0; i < MAX_TEXT_LINES; i++) {  
		if (TxtLines[i].IsEmpty())
			break;

		len1 = TxtLines[i].GetLength();
		len2 = TxtAttrs[i].GetLength();

		ASSERT(len1 <= len2);
		if (len1 != len2)
			ASSERT(len1+1 == len2);

		counter = 0;
		for(int j=0; j < len2; j++) {
			attr = TxtAttrs[i][j];
			if ((attr & CHARTYPEMSK) != NORMAL_CHAR)
				if (attr & EOL_MASK)
					counter++;
		}
		ASSERT(counter < 2);

		if (len1 > 1) {
			ASSERT(TxtAttrs[i][0] != DELCHAR);
		}
	}
#endif
}

// Make sure the Cursor is at the end of the selection
int TextItem::FixSelectionPostion()
{
	CPoint tpt;

	if (SelCursorIndex.y > CursorIndex.y) {
		tpt = SelCursorIndex;
		SelCursorIndex = CursorIndex;
		CursorIndex = tpt;
	}
	else if (SelCursorIndex.y == CursorIndex.y) {
		if (SelCursorIndex.x > CursorIndex.x) {
			tpt = SelCursorIndex;
			SelCursorIndex = CursorIndex;
			CursorIndex = tpt;
		}
	}
	return OK;
}

int TextItem::IsCharInSelection(int testx, int testy)
{
	int highx, lowx,highy, lowy;

	if (SelectionOn == FALSE) {	// if selection is not on
		return(FALSE);			// This character is not selected
	}
	if ((SelCursorIndex.y == -1) || (SelCursorIndex.x == -1)) {
		return(FALSE);			// THis is not really set yet
	}


	// Find the Range low to high of y
	if (SelCursorIndex.y > CursorIndex.y) {
		highy = SelCursorIndex.y;
		highx = SelCursorIndex.x;
		lowy = CursorIndex.y;
		lowx = CursorIndex.x;

	}
	else if (SelCursorIndex.y == CursorIndex.y) {
		if (SelCursorIndex.x < CursorIndex.x) {
			lowx = SelCursorIndex.x;
			highx = CursorIndex.x;
		}
		else {
			lowx = CursorIndex.x;
			highx = SelCursorIndex.x;
		}
		lowy = SelCursorIndex.y;
		highy = lowy;
	}
	else {
		highy = CursorIndex.y;
		highx = CursorIndex.x;
		lowy = SelCursorIndex.y;
		lowx = SelCursorIndex.x;
	}		

	if ((testy < lowy) || (testy > highy)) {
		return FALSE;		// character not in a row with selection
	}

	if ((testy > lowy) && (testy < highy)) {
		return TRUE;		// Character is on a line where all are selected
	}

	if ((testy == lowy) && (testx >= lowx)) {
		if ((testy == highy) && (testx >= highx)) {	// check if single line selection
			return FALSE;	// Character is NOT selected
		}
		return TRUE;	// Character is selected
	}

	if ((testy == highy) && (testx < highx)) {
		if ((testy == lowy) && (testx < lowx)) {	// check if single line selection
			return FALSE;	// Character is NOT selected
		}
		return TRUE;	// Character is selected
	}

	return FALSE;	// Character is not selected

}

int TextItem::DoBorderArtDialog()
{
	int retval = 0;

	CBorderArtDlg dlg;
	// Pass the text item's current border art settings to the dialog
	dlg.m_strBorderArtName = BorderArtFile[0];
	dlg.m_nBorderArtSize = BorderArtSizeOption;
	dlg.m_nBorderArtSource = BorderArtSource;
	dlg.m_nBorderArtShrink = BorderArtShrink;
	// Give it the font size so the Preview can show in actual size
	dlg.m_nSize = nPointSize;
	if (dlg.DoModal() != IDCANCEL)
	{
		// Get the new selections from the dialog
		BorderArtFile[0] = dlg.m_strBorderArtName;
		BorderArtSizeOption = dlg.m_nBorderArtSize;
		BorderArtSource = dlg.m_nBorderArtSource;
		BorderArtShrink = dlg.m_nBorderArtShrink;
		++retval;
	}

	WriteTextBar();
	SetViaMembers();	// restore the state

	return(retval);
}

bool TextItem::IsPositionOKForBorderArt()
{
	bool bRet = true;

	return bRet;
}


void TextItem::AdjustBorderArt(CDC *pDC, CPoint &size, int sign, bool withZoom)
{
	CPoint cpTemp(0, 0);
	if (withZoom) {
		BorderArtAdjustmentZoom.SetPoint(0, 0);
	}
	else {
		BorderArtAdjustment.SetPoint(0, 0);
	}
	if (pParentBBox == NULL || BorderArtMarginZoomSize.x < 1 || BorderArtMarginZoomSize.y < 1)
		return;
	int statusTemp = OK;
	CPoint pos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	if (!withZoom) {
		pos.x = (int)((float)pos.x / dCurrentZoom);
		pos.y = (int)((float)pos.y / dCurrentZoom);
	}

	// Determine maximum
	int xpix;
	int xmax;
	int	nXPixels;
	int	nYPixels;
	float xpage, ypage;
	if ((*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {	// SHERSTON
		xpage = PAGE_A1_WD * PIXELS_PER_INCH;
		ypage = PAGE_A1_HT * PIXELS_PER_INCH;
	}
	else {
		xpage = PAGE_US_WD * PIXELS_PER_INCH;
		ypage = PAGE_US_HT * PIXELS_PER_INCH;
	}

	int handleSize = (int)((float)BORDER_WIDTH * (withZoom ? dCurrentZoom : 1.0));
	// Needs to be orientation specific
	if ((int)nOrientation == PAGE_ORIENTATION_LANDSCAPE) {	// landscape
		nXPixels = (int) ypage;
		nYPixels = (int) xpage; 
		//xpix = (int)((float)(nXPixels - DOC_X_BORDER_PIXELS + BorderArtScrollPos.x) * (withZoom ? dCurrentZoom : 1.0));
		xpix = (int)((float)(nXPixels - DOC_X_BORDER_PIXELS) * (withZoom ? dCurrentZoom : 1.0) + BorderArtScrollPos.x);
		xmax = xpix - pos.x - handleSize;
	}
	else {
		nXPixels = (int) xpage;
		nYPixels = (int) ypage; 
		//xpix = (int)((float)(nXPixels - DOC_X_BORDER_PIXELS + BorderArtScrollPos.x) * (withZoom ? dCurrentZoom : 1.0));
		xpix = (int)((float)(nXPixels - DOC_X_BORDER_PIXELS) * (withZoom ? dCurrentZoom : 1.0) + BorderArtScrollPos.x);
		xmax = xpix - pos.x - handleSize;
	}
	// Adjust height
	if (withZoom) {
		if (BorderArtMarginZoomSize.y > 0) {
			size.y += (sign * (2 * BorderArtMarginZoomSize.y));
			if (abs(size.y) % BorderArtMarginZoomSize.y > 0) {
				BorderArtAdjustmentZoom.y = (sign * (BorderArtMarginZoomSize.y - (abs(size.y) % BorderArtMarginZoomSize.y)));
				size.y += BorderArtAdjustmentZoom.y;
			}
			BorderArtChanged = TRUE;
		}
	}
	else {
		if (BorderArtMarginSize.y > 0) {
			size.y += (sign * (2 * BorderArtMarginSize.y));
			if (abs(size.y) % BorderArtMarginSize.y > 0) {
				BorderArtAdjustment.y = (sign * (BorderArtMarginSize.y - (abs(size.y) % BorderArtMarginSize.y)));
				size.y += BorderArtAdjustment.y;
			}
			BorderArtChanged = TRUE;
		}
	}

	// Adjust width
	if (BorderArtShrink) {
		if (withZoom) {
			if (BorderArtMarginZoomSize.x > 0 && abs(size.x) % BorderArtMarginZoomSize.x > 0) {
				if (abs(size.x) % BorderArtMarginZoomSize.x > BorderArtMarginZoomSize.x / 2
					&& size.x + (BorderArtMarginZoomSize.x - (abs(size.x) % BorderArtMarginZoomSize.x)) < xmax) {
					BorderArtAdjustmentZoom.x = (BorderArtMarginZoomSize.x - (abs(size.x) % BorderArtMarginZoomSize.x));
				}
				else {
					BorderArtAdjustmentZoom.x = 0 - (abs(size.x) % BorderArtMarginZoomSize.x);
				}
				size.x += BorderArtAdjustmentZoom.x;
			}
		}
		else {
			if (BorderArtMarginSize.x > 0 && abs(size.x) % BorderArtMarginSize.x > 0) {
				if (abs(size.x) % BorderArtMarginSize.x > BorderArtMarginSize.x / 2
					&& size.x + (BorderArtMarginSize.x - (abs(size.x) % BorderArtMarginSize.x)) < xmax) {
					BorderArtAdjustment.x = (BorderArtMarginSize.x - (abs(size.x) % BorderArtMarginSize.x));
				}
				else {
					BorderArtAdjustment.x = 0 - (abs(size.x) % BorderArtMarginSize.x);
				}
				size.x += BorderArtAdjustment.x;
			}
			BorderArtChanged = TRUE;
			mWhichDraw = TEXT_DRAW_ALL;
		}
	}
}

bool TextItem::AdjustBoxSize(CDC *pDC, bool isUserSizing)
{
	bool bRet = FALSE;
	int numLines=1, numLinesAuto=1, numLinesSized = 1, minHeight=0;
	int statusTemp=0;
	CPoint cpTemp(0, 0);
	if (pDC->IsPrinting()) {
		return bRet;
	}
	CPoint size = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);

	// Number of lines: If Auto-size, fit to text
	// The last box in a story will auto-expand, if necessary, but it can also be sized by the user
	if (StoryNumber < 1 || IsLastItemInStory) {
		for(int i=1; i < MAX_TEXT_LINES; i++) {
			if (TxtLines[i].IsEmpty()) {
				numLinesAuto = i;
				break;
			}
		}
	}
	if (StoryNumber > 0) {// If in a Story, fit to nearest whole lines
		int prevStoryLines = StoryLines;
		numLinesSized = BorderArtChanged ? prevStoryLines : StoryLines = size.y / TextLineYs;
		if (numLinesSized < 1) {
			size.y = (int)(uzTextLineYs * dCurrentZoom);
			numLinesSized = 1;
		}
		StoryLinesChanged = (StoryLines != prevStoryLines);
	}
	if (StoryNumber < 1 || IsLastItemInStory && numLinesAuto > numLinesSized) {
		if (IsLastItemInStory && numLinesAuto > numLinesSized) {
			StoryLinesChanged = TRUE;
		}
		numLines = numLinesAuto;
	}
	else {
		numLines = numLinesSized;
	}

	minHeight = (int)((numLines * -uzTextLineYs) * dCurrentZoom);

	if (-size.y >= minHeight || isUserSizing) {
		CPoint setsize;
		setsize.x = (int)((float) size.x / dCurrentZoom);
		setsize.y = (int)((float)-minHeight / dCurrentZoom);

		// change size to adjust
		statusTemp = CLEAROLD;

		CPoint withBorder(setsize);
		int prevBorderArtAdjustmentX = BorderArtAdjustment.x;
		AdjustBorderArt(pDC, withBorder, sign, false);
		if (prevBorderArtAdjustmentX != BorderArtAdjustment.x || StoryLinesChanged) {
			bRet = TRUE;
		}
		pParentBBox->Message( BBOX_SIZE_SET, withBorder, &statusTemp);

		// Get a null pen and white brush and clear the rectangle
		CPen *oldpen = (CPen *) pDC->SelectStockObject(NULL_PEN);

		pDC->SelectStockObject(WHITE_BRUSH);

		CPoint pos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);

		int x1, y1, x2, y2;
		x1 = pos.x-(DOC_X_BORDER_PIXELS-10);
		y1 = pos.y + (int)(withBorder.y * dCurrentZoom);
		x2 = pos.x + size.x;
		x2 += (1*(DOC_X_BORDER_PIXELS+BORDER_WIDTH));
		y2 = pos.y + size.y;
		y2 -= (DOC_Y_BORDER_PIXELS + BORDER_WIDTH);
		pDC->Rectangle(CRect( 
			x1,
			y1,
			x2,
			y2));

		pDC->SelectObject(oldpen);		// Restore pen

		CPen outlinepen( PS_SOLID, 25, RGB( 0, 0, 0));
		oldpen = pDC->SelectObject(&outlinepen);
		pDC->SelectStockObject(BLACK_BRUSH);

		int xval, yval;
		int xpix, ypix;
		int	nXPixels;
		int	nYPixels;
		float xpage, ypage;
		if (doRunUKVersion || (*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {	// SHERSTON
			xpage = PAGE_A1_WD * PIXELS_PER_INCH;
			ypage = PAGE_A1_HT * PIXELS_PER_INCH;
		}
		else {
			xpage = PAGE_US_WD * PIXELS_PER_INCH;
			ypage = PAGE_US_HT * PIXELS_PER_INCH;
		}

		xval = (int)((float)(DOC_X_BORDER_PIXELS) * dCurrentZoom);
		yval = (int)((float)(DOC_Y_BORDER_PIXELS) * dCurrentZoom);

		// Needs to be orientation specific
		if ((int)nOrientation == PAGE_ORIENTATION_LANDSCAPE) {	// landscape
			nXPixels = (int) ypage; //((float)DOC_Y_INCHES * PIXELS_PER_INCH);
			nYPixels = (int) xpage; //((float)DOC_X_INCHES * PIXELS_PER_INCH); 
			xpix = (int)((float)(nXPixels + DOC_X_BORDER_PIXELS) * dCurrentZoom) - ScrollPos.x;
			ypix = (int)((float)(nYPixels + DOC_Y_BORDER_PIXELS) * dCurrentZoom) + ScrollPos.y;
		}
		else {
			nXPixels = (int) xpage; //((float)DOC_X_INCHES * PIXELS_PER_INCH);
			nYPixels = (int) ypage; //((float)DOC_Y_INCHES * PIXELS_PER_INCH); 
			xpix = (int)((float)(nXPixels + DOC_X_BORDER_PIXELS) * dCurrentZoom) - ScrollPos.x;
			ypix = (int)((float)(nYPixels + DOC_Y_BORDER_PIXELS) * dCurrentZoom) + ScrollPos.y;
		}
#define FULLPAGE 32000
		CPen newOutline(PS_SOLID, 1, RGB( 100, 100, 100));
		pDC->SelectStockObject(GRAY_BRUSH);
		pDC->SelectObject(&newOutline);
		pDC->Rectangle(CRect(0, -(ypix-yval), FULLPAGE, -FULLPAGE));

		pDC->SelectObject(&outlinepen);
		pDC->MoveTo( xpix - xval, -(ypix - yval));
		pDC->LineTo( xval+25, -(ypix - yval));
		pDC->SelectObject(oldpen);
	}

	if (isUserSizing && StoryNumber > 0 && !TxtLines[0].IsEmpty()) {
		CPoint newsize = pParentBBox->Message(BBOX_SIZE_GET, cpTemp, &statusTemp);
		if (!IsLastItemInStory && (newsize.y != size.y || newsize.x != size.x)) {
			theApp.m_iStoryOverflowBox = StoryItemOrder;
		}
		bRet = TRUE;
	}

	if (!isUserSizing && theApp.m_isGridVisible) {
		theApp.m_isGridWiped = TRUE;// Need to redraw grid if this function just made a white rectangle
	}

	// If the box now hangs off the bottom of the page,
	// move the box up so it is on the page
	statusTemp = OK;
	CPoint cpNewPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	CPoint cpNewSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);
	CPoint cpMaxXY = pParentBBox->Message( BBOX_MAX_XY_GET, cpTemp, &statusTemp);
	int nMinY = (int)((float)(-BORDER_WIDTH - DOC_Y_BORDER_PIXELS - 25) * dCurrentZoom) - ScrollPos.y;
	int nMaxY = (int)((float)(cpMaxXY.y + BORDER_WIDTH + DOC_Y_BORDER_PIXELS + 25) * dCurrentZoom);
	int nTempY = nMaxY - ScrollPos.y;
	int nEndY = cpNewPos.y + cpNewSize.y;
	if (nEndY < nTempY) {
		int nMoveUp = nTempY - nEndY;
		cpNewPos.y += nMoveUp;
		if (cpNewPos.y < nMinY) {
			cpNewPos.x = (int)((float)(cpNewPos.x) / dCurrentZoom);
			cpNewPos.y = (int)((float)(cpNewPos.y) / dCurrentZoom);
			statusTemp = CLEAROLD;
			pParentBBox->Message( BBOX_POSITION_SET, cpNewPos, &statusTemp);
			nOverfullWarning = 0;
			mWhichDraw = TEXT_DRAW_ALL;
			theApp.m_isGridWiped = TRUE;
		}
	}

	return bRet;
}

void TextItem::resetGlyfPos()
{
	for(int i = 0; i < MAX_GLYF_ARRAY; i++) {
		CharArray[i].charVal = 0;
		CharArray[i].arrowFlag = 0;
		CharArray[i].overlayFlag = 0;
		for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
			CharArray[i].fsFlag[fsi] = 0;
		}
		CharArray[i].connectTheDotsFlag = 0;
		CharArray[i].valUsed = 0;
		CharArray[i].dotFlag = 0;
		CharArray[i].mathFlag = 0;
		CharArray[i].CharData.ClearData();
		CharArray[i].ArrowData.ClearData();
		CharArray[i].OverlayData.ClearData();
		CharArray[i].DotData.ClearData();
	}
}

int TextItem::getGlyfPos(unsigned short c)
{
	int i;
	for(i = 0; i < MAX_GLYF_ARRAY; i++) {
		if (CharArray[i].charVal == c) {		// if there is a match, return it
			CharArray[i].valUsed++;
			return i;		
		}
		if (CharArray[i].charVal == 0) {		// or find the first empty one
			CharArray[i].valUsed = 1;			// set first time
			return i;
		}
	}

	/** find least used character **/
	int charCount=32000;	// a high number for initialization
	int leastInd = 0;
	static int LastStart=0;

	if (LastStart >= MAX_GLYF_ARRAY-1)
		LastStart = 0;

	for(i = LastStart; i < MAX_GLYF_ARRAY; i++) {
		if (CharArray[i].valUsed < charCount) {		// if there is a match, return it
			charCount = CharArray[i].valUsed;
			leastInd = i;
		}
	}
	CharArray[leastInd].valUsed = 1;
	CharArray[leastInd].charVal = 0;
	CharArray[leastInd].arrowFlag = 0;
	CharArray[leastInd].connectTheDotsFlag = 0;
	CharArray[leastInd].overlayFlag = 0;
	for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
		CharArray[leastInd].fsFlag[fsi] = 0;
	}
	CharArray[leastInd].mathFlag = 0;
	CharArray[leastInd].dotFlag = 0;

	LastStart = leastInd+1;
	return leastInd;
}


unsigned short TextItem::getCursiveCharReg(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;		// base for subtraction (upper or lowercase)

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';
		// No prevChar or end of line or a space 
		if (!IS_ALPHA(prevChar)) { // || (prevChar == 0) || (prevChar == SW_EOL) || (prevChar == ' ') ) {
			if (IS_LOWER(nextChar)) {
				useBase = CBASE2;
			}
			//else normal character
		}
		else if (ENDS_HIGH1(prevChar)) {	// previous was bovw?
			// Check next character		high,short : High Reg
			useBase = (IS_LOWER(nextChar)) ? CBASE3 : CBASE5;
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			useBase = (IS_LOWER(nextChar)) ? CBASE4 : CBASE6;
		}
		else if (IS_UPPER(prevChar)) {
			if ((inCursive & CUR_AMER) && AMER_BEG_NOCON(prevChar)) {
				useBase = (IS_LOWER(nextChar)) ? CBASE2 : CBASE0;
			}
			else if ((inCursive & CUR_AMER) && CAP_CONMID2(prevChar)) {
				useBase = (IS_LOWER(nextChar)) ? CBASE8 : CBASE9;
			}
			else if ((inCursive & CUR_AMER) && CAP_CONNECTS2(prevChar)) {
				useBase = (IS_LOWER(nextChar)) ? CBASE4 : CBASE6;
			}
			else if (CAP_CONNECTS1(prevChar)) {
				// front is low		back is		short :  Reg
				useBase = (IS_LOWER(nextChar)) ? CBASE4 : CBASE6;
			}
			else if ((inCursive & CUR_DNEL) && CAP_CONNECTS2(prevChar)) {
				useBase = (IS_LOWER(nextChar)) ? CBASE4 : CBASE6;
			}
			else if ((inCursive & CUR_ZAN2) && (prevChar == 'X')) {
				useBase = (IS_LOWER(nextChar)) ? CBASE4 : CBASE6;	// Simple Cursive Connects X
			}
			else if (CAP_CONMID(prevChar)) {	// short - reg
				useBase = (IS_LOWER(nextChar)) ? CBASE8 : CBASE9;
			}
			else if (IS_LOWER(nextChar)) {	// front is regular
				useBase = CBASE2;			// back is short
			}
			//else back is reg
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A';

		if (IS_LOWER(nextChar)) {
			useBase = CBASE1;
		}
		//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (useBase) {
		c = (unsigned short) (useBase + c - charBase);
	}
	return(c);
}

unsigned short TextItem::getCursiveCharItal(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of obwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				gjqy
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCON1(prevChar))) { //(prevChar == 0) || (prevChar == ' ') || (prevChar == SW_EOL) || 

			useBase = (unsigned short) ((IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE1 : ICBASE0);

			if (nextChar == 'e') {		// Is the the famous e?
				if (SPEC_E1(c)) {				// yes
					useBase = SETSPEC1(c);		// Do the e connection
					specBase = 1;
				}
			}
			else if (c == 't') {		// Check for special case 't'
				useBase = (unsigned short)((nextChar != 't') ? ICBASE0 : ICBASE1);
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE1;
			}
			//else normal character
		}
		else if (ENDS_HIGH2(prevChar)) {	// previous was fovwx?
			// Check next character		high,connect : High Reg
			useBase = (unsigned short)((IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE5 : ICBASE4);
			// Is "fe" a special case?  Yes!  Handle this first.
			if ((c == 'e') && (prevChar == 'f')) {
				useBase = ((IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE1 : ICBASE0);
			}
			else if (nextChar == 'e') {
				if (SPEC_E1(c)) {
					useBase = SETSPEC1(c);
					specBase = 3;
				}
			}
			else if (c == 't') {
				useBase = (nextChar != 't') ? ICBASE4 : ICBASE5;
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE5;
			}
		}
		else if (prevChar == 't') {		// previous is t?

			// Check next character		high,connect : High Reg
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE5 : ICBASE4;
			if (nextChar == 'e') {
				if (SPEC_E1(c)) {
					useBase = SETSPEC1(c);
					specBase = 3;
				}
				else if (c == 't') {	// In this particular case -- it works normally
					useBase = ICBASE9;
				}
				else if (c == 'e') {
					useBase = ICBASE9;
				}
			}
			else if ((c == 't')) {
				useBase = (!IS_LOWER(nextChar) || 
					(IS_LOWER(nextChar) && (!BEG_NOCON(nextChar)) && ('t' != nextChar))) ? ICBASE8 : ICBASE9;
			}
			else if (c == 'e') {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE9 : ICBASE8;
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE5;
			}
		}
		else if (ENDS_MID1(prevChar)) {		// Previous r?
			// front is mid		  back is	 connect : reg
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE7 : ICBASE6;
			if (nextChar == 'e') {
				if (SPEC_E1(c)) {
					useBase = SETSPEC1(c);
					specBase = 4;
				}
			}
			else if (c == 't') {
				useBase = (nextChar != 't') ? ICBASE6 : ICBASE7;
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE7;
			}
		}
		else if (ENDS_MID2(prevChar)) {		// previous bcps
			// front is mid2		  back is	 connect : reg
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE9 : ICBASE8;

			if (nextChar == 'e') {
				if (SPEC_E1(c)) {
					useBase = SETSPEC1(c);
					specBase = 5;
				}
			}
			else if (c == 't') {
				useBase = (nextChar != 't') ? ICBASE8 : ICBASE9;
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE9;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCON(nextChar))) ? ICBASE3 : ICBASE2;
			if (nextChar == 'e') {
				if (SPEC_E1(c)) {
					useBase = SETSPEC1(c);
					specBase = 2;
				}
			}
			else if (c == 't') {
				useBase = (nextChar != 't') ? ICBASE2 : ICBASE3;
			}
			else if (ENDS_HIGH2(c) && (nextChar == 'z')) {
				useBase = ICBASE3;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

/* This is the Upright Fonts */
unsigned short TextItem::getCursiveCharUpright(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				bpgjqxy
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCON2(prevChar))) { 

			if ((nextChar == 'e') && (SPEC_E2(c))) {				// yes
				useBase = SETSPEC2(c);		// Do the e connection
				specBase = 1;
			}
			else {
				//else normal character
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE1 : ICBASE0;
			}
		}
		else if (prevChar == 'f') {
			// Check next character		high,connect : High Reg
			// Is "fe" a special case?  Yes!  Handle this first.
			if (c == 'e') {
				useBase = ((IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE5 : ICBASE4);
			}
			else if ((nextChar == 'e') && (SPEC_E2(c))) {
				useBase = SETSPEC2(c);
				specBase = 4;	/* was 3 */
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE7 : ICBASE6;
			}
		}
		else if (ENDS_HIGH3(prevChar)) {	// previous was ovwx?
			// Check next character		high,connect : High Reg
			if ((nextChar == 'e') && (SPEC_E2(c))) {
				useBase = SETSPEC2(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		else if (ENDS_MID1(prevChar)) {		// Previous r?
			// front is mid		  back is	 connect : reg
			if ((nextChar == 'e') && (SPEC_E2(c))) {
				useBase = SETSPEC2(c);
				specBase = 3;
			}
			else if (c == 'e') {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE7 : ICBASE6;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		else if (ENDS_MID3(prevChar)) {		// previous cs
			// front is mid2		  back is	 connect : reg

			if ((nextChar == 'e') && (SPEC_E2(c))) {
				useBase = SETSPEC2(c);
				specBase = 5;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE9 : ICBASE8;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			if ((nextChar == 'e') && (SPEC_E2(c))) {
				useBase = SETSPEC2(c);
				specBase = 2;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON2(nextChar))) ? ICBASE3 : ICBASE2;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

/* This is the Upright Fonts */
unsigned short TextItem::getCursiveCharVictorian(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				bpgjqxy
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCONV(prevChar))) { 
			if ((nextChar == 'e') && (SPEC_EV(c))) {				// yes
				useBase = SETSPECV(c);		// Do the e connection
				specBase = 1;
			}
			else {
				//else normal character
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE1 : ICBASE0;
			}
		}
		else if (prevChar == 'q') {
			if ((nextChar == 'e') && (SPEC_EV(c))) {				// yes
				useBase = SETSPECV(c);		// Do the e connection
				specBase = 5;
			}
			else {
				useBase = ((IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE9 : ICBASE8);
			}
		}
		//		else if (ENDS_MIDV(prevChar)) {		// previous cse
		//			if ((nextChar == 'e') && (SPEC_EV(c))) {				// yes
		//				useBase = SETSPECV(c);		// Do the e connection
		//				specBase = 2;
		//			}
		//			else {
		//				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE3 : ICBASE2;
		//			}
		//		}
		else if (ENDS_HIGHV(prevChar)) {	// previous was borwv?
			// Check next character		high,connect : High Reg
			if ((nextChar == 'e') && (SPEC_EV(c))) {
				useBase = SETSPECV(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		else if (prevChar == 'f') {
			if ((nextChar == 'e') && (SPEC_EV(c))) {
				useBase = SETSPECV(c);
				specBase = 4;	/* was 3 */
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE7 : ICBASE6;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			if ((nextChar == 'e') && (SPEC_EV(c))) {
				useBase = SETSPECV(c);
				specBase = 2;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONV(nextChar))) ? ICBASE3 : ICBASE2;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

unsigned short TextItem::getCursiveCharQueens(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCONQ(prevChar))) { 

			if ((nextChar == 'e') && (SPEC_EQ(c))) {				// yes
				useBase = SETSPECQ(c);		// Do the e connection
				specBase = 1;
			}
			else {
				//else normal character
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE1 : ICBASE0;
			}
		}
		// This path is not clear
		else if (prevChar == 'f') {
			if ((nextChar == 'e') && (SPEC_EQ(c))) {
				useBase = SETSPECQ(c);
				specBase = 4;	/* was 3 */
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE7 : ICBASE6;
			}
		}
		else if (ENDS_HIGHQ(prevChar)) {	// previous was ovwr?
			/* These chars don't connect to e */
			if (c == 'e') {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE1 : ICBASE0;
			}
			// Check next character		high,connect : High Reg
			else if ((nextChar == 'e') && (SPEC_EQ(c))) {
				useBase = SETSPECQ(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		//		else if (ENDS_MID1(prevChar)) {		// Previous r?
		//			// front is mid		  back is	 connect : reg
		///			if ((nextChar == 'e') && (SPEC_EQ(c))) {
		//				useBase = SETSPECQ(c);
		//				specBase = 3;
		//			}
		//			else if (c == 'e') {
		//				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE7 : ICBASE6;
		//			}
		//			else {
		//				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE5 : ICBASE4;
		//			}
		//		}
		else if (ENDS_MID3(prevChar)) {		// previous cs
			// front is mid2		  back is	 connect : reg
			if ((nextChar == 'e') && (SPEC_EQ(c))) {
				useBase = SETSPECQ(c);
				specBase = 5;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE9 : ICBASE8;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			if ((nextChar == 'e') && (SPEC_EQ(c))) {
				useBase = SETSPECQ(c);
				specBase = 2;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONQ(nextChar))) ? ICBASE3 : ICBASE2;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

/* This is the Fron the line font*/
unsigned short TextItem::getCursiveCharFromTheLine(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		/* WAYNE -- take out the !BEG_NOCON3 stuff since it is really useless */
		// No prevChar or end of line or a space				bpgjqxy
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar)) { /*   || (ENDS_NOCON3())) { */

			if ((nextChar == 'e') && (SPEC_E3(c))) {				// yes
				useBase = SETSPEC3(c);		// Do the e connection
				specBase = 1;
			}
			else {
				//else normal character
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE1 : ICBASE0;
			}
		}
		else if (prevChar == 'f') {
			// Check next character		high,connect : High Reg
			// Is "fe" a special case?  Yes!  Handle this first.
			if (c == 'e') {
				useBase = ((IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE7 : ICBASE6);
			}
			else if ((nextChar == 'e') && (SPEC_E3(c))) {
				useBase = SETSPEC3(c);
				specBase = 4;	/* was 3 */
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE7 : ICBASE6;
			}
		}
		else if (prevChar == 'e') {
			if ((nextChar == 'e') && (SPEC_E3(c))) {
				useBase = SETSPEC3(c);
				specBase = 5;
			}
			else {
				useBase = (IS_ALPHA(nextChar) ? ICBASE9 : ICBASE8);
			}
		}
		else if (ENDS_HIGH4(prevChar)) {	// previous was orvw?
			// Check next character		high,connect : High Reg
			if ((nextChar == 'e') && (SPEC_E3(c))) {
				useBase = SETSPEC3(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE5 : ICBASE4;
			}
		}
		else if (ENDS_MID4(prevChar)) {		// previous csbpgjyz
			// front is mid2		  back is	 connect : reg
			if ((nextChar == 'e') && (SPEC_E3(c))) {
				useBase = SETSPEC3(c);
				specBase = 5;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE9 : ICBASE8;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			if ((nextChar == 'e') && (SPEC_E3(c))) {
				useBase = SETSPEC3(c);
				specBase = 2;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCON3())) ? ICBASE3 : ICBASE2;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}


unsigned short TextItem::getCursiveCharNSW(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				bpgjqxys
		if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCONNW(prevChar))) { 

			if ((nextChar == 'e') && (SPEC_ENW(c))) {				// yes
				useBase = SETSPECNW(c);		// Do the e connection
				specBase = 1;
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 1;
			}
			else {
				//else normal character
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE1 : ICBASE0;
			}
		}
		else if (prevChar == 'f') {
			// Check next character		high,connect : High Reg
			// Is "fe" a special case?  Yes!  Handle this first.
			if (c == 'e') {
				useBase = ((IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE5 : ICBASE4);
			}
			else if ((nextChar == 'e') && (SPEC_ENW(c))) {
				useBase = SETSPECNW(c);
				specBase = 4;	/* was 3 */
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 4;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE7 : ICBASE6;
			}
		}
		else if (ENDS_HIGHNW(prevChar)) {	// previous was ovwx?
			// Check next character		high,connect : High Reg
			/* Special case 'o' */
			if ((nextChar == 'e') && (SPEC_ENW(c))) {
				useBase = SETSPECNW(c);
				specBase = 3;
			}
			else if ((prevChar != 'o') && ((c == 'e') || (c == 'f'))) {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE1 : ICBASE0;
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		else if (ENDS_MID1(prevChar)) {		// Previous r?
			// front is mid		  back is	 connect : reg
			if ((nextChar == 'e') && (SPEC_ENW(c))) {
				useBase = SETSPECNW(c);
				specBase = 3;
			}
			else if (c == 'e') {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE1 : ICBASE0;
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 3;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE5 : ICBASE4;
			}
		}
		else if (ENDS_MIDNW(prevChar)) {		// previous q	// nw ok
			// front is mid2		  back is	 connect : reg
			if ((nextChar == 'e') && (SPEC_ENW(c))) {
				useBase = SETSPECNW(c);
				specBase = 5;
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 5;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE9 : ICBASE8;
			}
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			// front is low		back is		short : Reg
			if ((nextChar == 'e') && (SPEC_ENW(c))) {
				useBase = SETSPECNW(c);
				specBase = 2;
			}
			else if ((nextChar == 'f') && (SPEC_ENW2(c))) {
				useBase = SETSPECNW(c);
				specBase = 2;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONNW(nextChar))) ? ICBASE3 : ICBASE2;
			}
		}
		//else regular character
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

/* This is the Palmer Fonts */
unsigned short TextItem::getCursiveCharPalmer(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		// No prevChar or end of line or a space				


		if ((!(IS_ALPHA(prevChar))) || ((IS_UPPER(prevChar)) && !PALM_UPPER_CONNECT(prevChar)) || (ENDS_NOCONPALM(prevChar))) { 
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE1 : ICBASE0;
		}
		else if (ENDS_HIGHPALM(prevChar)) {	// previous was bvw?
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE5 : ICBASE4;
		}
		else if (ENDS_MIDPALM2(prevChar)) {		// Previous o?
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE7 : ICBASE6;
		}
		else if (ENDS_MIDPALM1(prevChar)) {		// previous gjyz
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE9 : ICBASE8;
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE3 : ICBASE2;
		}
		else if (PALM_UPPER_CONNECT(prevChar)) {
			if (PALM_UPPER_CONNECT2(prevChar)) {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE3 : ICBASE2;
			}
			else if (prevChar == 'H') {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE5 : ICBASE4;
			}
			else {
				useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE9 : ICBASE8;
			}
		}
		//else regular character
	}
	else if (PALM_UPPER_CONNECT(c)) {
		specBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? PALM_SPEC(c) : c;
		useBase=1;
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}

/* This is the Upright Fonts */
unsigned short TextItem::getCursiveCharWithOutTears(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	unsigned short useBase=0;	// base for character conversion
	unsigned short charBase=0;	// base for subtraction (upper or lowercase)
	unsigned short specBase=0;	// base of ofrwx special case with 'e'

	if (IS_LOWER(c)) {		// lower case?
		charBase = 'a';

		/* Get the uppercase connect first */
		if (WOT_UPPER_CONNECT(prevChar)) {
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? ICBASE3 : ICBASE2;
		}
		// No prevChar or end of line or a space				
		else if ((!(IS_ALPHA(prevChar))) || IS_UPPER(prevChar) || (ENDS_NOCONWOT(prevChar))) { 
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONWOT(nextChar))) ? ICBASE1 : ICBASE0;
		}
		else if (ENDS_HIGHWOT(prevChar)) {	// previous was bvw?
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONWOT(nextChar))) ? ICBASE5 : ICBASE4;
		}
		else if (prevChar == 'o') {
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONWOT(nextChar))) ? ICBASE7 : ICBASE6;
		}
		else if (IS_LOWER(prevChar)) {  // previous lower?
			useBase = (IS_LOWER(nextChar) && (!BEG_NOCONWOT(nextChar))) ? ICBASE3 : ICBASE2;
		}
		//else regular character
	}
	else if (WOT_UPPER_CONNECT(c)) {
		specBase = (IS_LOWER(nextChar) && (!BEG_NOCONPALM(nextChar))) ? WOT_SPEC(c) : c;
		useBase=1;
	}
	else if (IS_UPPER(c)) {
		charBase = 'A'; 	//else Regular caps
	}
	//else regular char
	//prevChar = c;
	if (specBase) {
		c = ((unsigned short)(useBase + specBase - 1));
	}
	else if (useBase) {
		c = ((unsigned short)(useBase + c - charBase));
	}
	return(c);
}


unsigned short TextItem::GetCursiveChar(unsigned short c, unsigned short prevChar, unsigned short nextChar)
{
	if (inCursive & (CUR_ZAN1 | CUR_ZAN2 | CUR_DNEL | CUR_AMER)) {	// Regular Cursive
		return(getCursiveCharReg(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_ITAL) {		// Italic Cursive
		return(getCursiveCharItal(c, prevChar, nextChar));
	}
	else if (inCursive & (CUR_UPRT)) {
		return(getCursiveCharUpright(c, prevChar, nextChar));
	}
	else if (inCursive & (CUR_FRML)) {
		return(getCursiveCharFromTheLine(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_VICT) {
		return(getCursiveCharVictorian(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_QUEEN) {
		return(getCursiveCharQueens(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_NSW) {
		return(getCursiveCharNSW(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_PALMR) {
		return(getCursiveCharPalmer(c, prevChar, nextChar));
	}
	else if (inCursive & CUR_WOT) {
		return(getCursiveCharWithOutTears(c, prevChar, nextChar));
	}
	if (!inCursive) {
		if ((c >= 129) && (c <= 165)) {
			c = c - 129 + 559;
		}
		else if ((c >= 171) && (c <= 182)) {
			c = c - 171 + 594;
		}
	}
	return c;
}

void TextItem::SetBorderArtMargins(CDC *pDC, bool isDistributeStory)
{
	int statusTemp = 0;
	CPoint cpTemp(0, 0);
	CPoint zSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);
	CPoint zBorderSize(abs(BorderArtZoomSize.x), abs(BorderArtZoomSize.y));
	CSize tempSize1 = pDC->GetViewportExt();
	CSize tempSize2 = pDC->GetWindowExt();
	pDC->DPtoLP(&zBorderSize);
	if (!isDistributeStory) {
		BorderArtMarginZoomSize.x = BorderArtScrollPos.x > 0 ? zBorderSize.x - BorderArtScrollPos.x : zBorderSize.x;
		BorderArtMarginZoomSize.y = BorderArtScrollPos.y < 0 ? (abs(zBorderSize.y - BorderArtScrollPos.y)) : abs(zBorderSize.y);
	}
	else {
		BorderArtMarginZoomSize.x = zBorderSize.x;
		BorderArtMarginZoomSize.y = abs(zBorderSize.y);
	}
	CPoint lBorderSize(abs(BorderArtSize.x), abs(BorderArtSize.y));
	pDC->DPtoLP(&lBorderSize);
	if (!isDistributeStory) {
		BorderArtMarginSize.x = BorderArtScrollPos.x > 0 ? lBorderSize.x - BorderArtScrollPos.x : lBorderSize.x;
		BorderArtMarginSize.y = BorderArtScrollPos.y < 0 ? (abs(lBorderSize.y - BorderArtScrollPos.y)) : abs(lBorderSize.y);
	}
	else {
		BorderArtMarginSize.x = lBorderSize.x;
		BorderArtMarginSize.y = abs(lBorderSize.y);
	}
	if (!BorderArtZoomChanged && (mWhichDraw == TEXT_DRAW_ALL || mWhichDraw == TEXT_DRAW_ALL_AGAIN)) {
		AdjustBorderArt(pDC, zSize, sign, true);
		CPoint tempPoint((int)((float)zSize.x / dCurrentZoom), (int)((float)zSize.y / dCurrentZoom));
		AdjustBorderArt(pDC, tempPoint, sign, false);
		int status = TEXT_DRAW_ALL;
		pParentBBox->Message( BBOX_SIZE_SET, tempPoint, &status);
	}
	else {
		CPoint tempPoint2(zSize.x, zSize.y);
		AdjustBorderArt(pDC, tempPoint2, sign, true);
	}
	BorderArtZoomChanged = FALSE;
}

/* 
;Draw
*/
void TextItem::Draw(CDC *pDC, int *status)
{
	/* Don't draw during print process */
	if (doingPrinting && !pDC->IsPrinting()) {
		return;
	}
	if (!doingPrinting && pDC->IsPrinting()) {
		return;
	}

	int		statusTemp=0;
	int saveStatus = *status;
	CFont*	pOldFont=NULL;
	unsigned short prevChar=0, nextChar=0;
	CPoint cpTemp(0, 0);

	// Test drawing ability...
	if (!pParentBBox || (mWhichDraw == TEXT_DRAW_NOTHING)){
		return;
	}

	mWhichDraw = *status;
	ShadeType = theApp.m_iDefaultShadeType + SHADETYPE_SHADE-1;	/* Make sure this is up to date always */


	CalcLinePointSpace();

	CPoint	zPos, zSize, ptLookingFor;
	bool	bCursorFound,
		bCursorSet, 			// Use this to say we have actually set the cursor pos
		bFontReset=false,
		resizeOK=false;

	zPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	zSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);

	if (BorderArtType > BORDER_ART_TYPE_NONE && (BorderArtZoomChanged || BorderArtMarginZoomSize.x == 0)) {
		SetBorderArtMargins(pDC, FALSE);
	}
	if (BorderArtChanged) {
		mWhichDraw = TEXT_DRAW_ALL_AGAIN;
		*status = TEXT_DRAW_ALL_AGAIN;
	}

	TestAttrState();

	if (nDot2DotOverlayButton != lastOverlay) {
		lastOverlay = -1;	// force a reste
		bFontReset = true;
		resetGlyfPos();
	}

	if (lastSpaceWidth != spaceWidth) {
		lastSpaceWidth = spaceWidth;
		allowFixWrap = TRUE;
		CursorIndex.x = 0;
		CursorIndex.y = 0;
	}

	// This lets font point size changes occur and soft returns will fix up correctly
	if ((lastPointSize != nPointSize)|| (lastFont != sFontName))  {
		if (nCursorActive && !theApp.m_bInStoryDistributeMode) {
			DrawCursor(pDC, 0);
			CursorIndex.x = 0;
			CursorIndex.y = 0;
		}
		if (lastFont != sFontName) {
			resizeOK=true;
		}
		lastFont = sFontName;
		lastPointSize = nPointSize;
		zLastPointSize = zPointSize;
		allowFixWrap = TRUE;
		allowAdjustBox = TRUE;
		resetGlyfPos();
		mDescender=0;
		lastOverlay=-1;	// force this to toggle too
		bFontReset = true;
	}
	else if (zLastPointSize != zPointSize) {
		lastFont = sFontName;
		lastPointSize = nPointSize;
		zLastPointSize = zPointSize;
		resetGlyfPos();
		mDescender=0;
		lastOverlay=-1;	// force this to toggle too
		bFontReset = true;
	}
	if (doReformatText) {
		ReformatText();	/* Something happened that makes the formatting incorrect */
		mDescender=0;
	}
	if (bFontReset) {
		if (Dot2DotFont.isOpen) {
			Dot2DotFont.Close();
		}
		if (ArrowFont.isOpen) {
			ArrowFont.Close();
		}		
		if (OverlayFont.isOpen == true) {
			OverlayFont.Close();
		}
		if (StartDotFont.isOpen) {
			StartDotFont.Close();
		}
		if (ConnectTheDotsFont.isOpen) {
			ConnectTheDotsFont.Close();
		}
		for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
			if (fsData[fsi].TTFontFS.isOpen == true)
				fsData[fsi].TTFontFS.Close();
		}
	}

	// If we're trying to reposition the cursor according to where the user
	// clicked, set up some vars to help us out.
	if (m_bSetCursorToClicked)	{
		ptLookingFor = m_ptClicked;

		bCursorFound = FALSE;
	}
	else {
		bCursorFound = TRUE;
	}
	bCursorSet = FALSE;

	// Should be nEditMode   
	nCursorActive = pParentBBox->Message(BBOX_STATE_GET, 0, &statusTemp) == BBOX_STATE_SELECT;

	if (nDot2Dot || isMathFont2) {                    

		if (Dot2DotFont.isOpen == false) {
			Dot2DotFont.SetFile((char *)(LPCSTR)FontFile);
			if (Dot2DotFont.Open() == ERROR) {
				if ((nAnnoyingFontMsg == FALSE) && (theApp.m_InSplash == false)){
					char erbuf[512];

					nAnnoyingFontMsg = TRUE;
					wsprintf(erbuf, "Unable to open Dot2DotFont:\n%s\nThis message will not repeat!", (char *)(LPCSTR)FontFile);
					AfxMessageBox(erbuf);
				}
				nDot2Dot = FALSE;		// Rather than not do anything, exit dot 2 dot mode
			}
		}
		if (nDot2Dot && (mDescender == 0)) {
			unsigned short cTmp = 'g';
			Dot2DotFont.GetGlyfData( &GlyfArray[0], &cTmp);
			mDescender = -((int)( GlyfArray[0].GetYMin()));
		}
		if (!isMathFont2 && (Dot2DotFont.isOpen == true)) {
			if (ArrowFile.IsEmpty() == false) {
				if (ArrowFont.isOpen == false) {
					ArrowFont.SetFile((char *)(LPCSTR)ArrowFile);
					if ((ArrowFont.Open() == ERROR)) {

						if ((nAnnoyingArrowMsg == FALSE)&& (theApp.m_InSplash == false)) { 
							char erbuf[512];
							nAnnoyingArrowMsg = TRUE;
							wsprintf(erbuf, "Unable to open Arrow Font:\n%s\nError will not repeat", ArrowFile);
							AfxMessageBox(erbuf);	// "Unable to open ArrowFont!");
						}
					}
				}
			}
			if (ConnectTheDotsFile.IsEmpty() == false) {
				if (ConnectTheDotsFont.isOpen == false) {
					ConnectTheDotsFont.SetFile((char *)(LPCSTR)ConnectTheDotsFile);
					if ((ConnectTheDotsFont.Open() == ERROR)) {
						// kind of silly to do this....since it is the same font file as the main font
						//if ((nAnnoyingConnectTheDotsMsg == FALSE)&& (theApp.m_InSplash == false)) { 
						//	char erbuf[512];
						//	nAnnoyingConnectTheDotsMsg = TRUE;
						//	wsprintf(erbuf, "Unable to open ConnectTheDots Font:\n%s\nError will not repeat", ConnectTheDotsFile);
						//	AfxMessageBox(erbuf);	// "Unable to open ConnectTheDotsFile!");
						//}
					}
				}
			}
			if (OverlayFile.IsEmpty() == false) {
				if (OverlayFont.isOpen == false) {
					OverlayFont.SetFile((char *)(LPCSTR)OverlayFile);
					if ((OverlayFont.Open() == ERROR)) {
						nDot2DotOverlayButton = 1;

						if ((nAnnoyingOverlayMsg == FALSE)&& (theApp.m_InSplash == false)) { 
							char erbuf[512];
							nAnnoyingOverlayMsg = TRUE;
							wsprintf(erbuf, "Unable to open Overlay Font:\n%s\nError will not repeat", OverlayFile);
							AfxMessageBox(erbuf);	// "Unable to open Overlay!");
						}
					}
				}
			}
			else {
				nDot2DotOverlayButton = 1;
			}
			
			// Open all the possible fonts for this
			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
				if (fsData[fsi].FilenameFS.IsEmpty() == false )
					if (fsData[fsi].TTFontFS.isOpen == false) {
						fsData[fsi].TTFontFS.SetFile((char *)(LPCSTR)fsData[fsi].FilenameFS);
						if ((fsData[fsi].TTFontFS.Open() == ERROR)) {
							fsData[fsi].nDot2DotFS = 1;	// can't draw if its not open
							fsData[fsi].nDot2DotFSButton = 1;

							if ((fsData[fsi].nAnnoyingMsgFS == FALSE)&& (theApp.m_InSplash == false)) { 
								char erbuf[512];
								fsData[fsi].nAnnoyingMsgFS = TRUE;
								wsprintf(erbuf, "Unable to open Font:\n%s\nError will not repeat", fsData[fsi].FilenameFS);
								AfxMessageBox(erbuf);	// "Unable to open FSfont!");
							}
						}
					}
			}
		}
		if ((nStartDot == 1) && (Dot2DotFont.isOpen == true)) {
			if (StartDotFile.IsEmpty() == false) {
				if (StartDotFont.isOpen == false) {
					StartDotFont.SetFile((char *)(LPCSTR)StartDotFile);
					if (StartDotFont.Open() == ERROR) {
						nStartDot = 0;
						if ((nAnnoyingStartdotMsg == FALSE) && (theApp.m_InSplash == false)) { 
							char erbuf[512];
							nAnnoyingStartdotMsg = TRUE;
							wsprintf(erbuf, "Unable to open StartDot Font:\n%s\nError will not repeat", StartDotFile);
							AfxMessageBox(erbuf);	// "Unable to open Overlay!");
						}
					}
				}
			}
		}
	}
	if (!nDot2Dot || isMathFont) {
		if (isMathFont) {
			TextFont.CreateFont( ((int)zPointSize) * -1 * 20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
				//ANSI_CHARSET, OUT_DEFAULT_PRECIS,
				//myFontInfo.nCharSet, OUT_DEFAULT_PRECIS,
				myFontInfo.nCharSet, OUT_DEFAULT_PRECIS,
				CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
				//DEFAULT_PITCH+TMPF_TRUETYPE, sFontName);
				//myFontInfo.nPitchAndFamily, myFontInfo.f_arrowname);
				myFontInfo.nPitchAndFamily, myFontInfo.f_arrowname);

		}
		else {
			TextFont.CreateFont( ((int)zPointSize) * -1 * 20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
				//ANSI_CHARSET, OUT_DEFAULT_PRECIS,
				//myFontInfo.nCharSet, OUT_DEFAULT_PRECIS,
				myFontInfo.nCharSet, OUT_DEFAULT_PRECIS,
				CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
				//DEFAULT_PITCH+TMPF_TRUETYPE, sFontName);
				//myFontInfo.nPitchAndFamily, sFontName);
				myFontInfo.nPitchAndFamily, sFontName);
		}

		pOldFont = (CFont*)pDC->SelectObject(&TextFont);
	}
	// Beginning of real drawing mechanism
	int i = 0;

	wchar_t currAttr;
	CWordArray word_string;
	int word_string_ind = 0;
	unsigned short c = '?', cLastChar=0;
	long char_pos = 0;
	long word_pos = 0;
	int word_width = 0;
	int linelen;
	int char_width = 0;
	int last_space = 0;
	int ignoreLast_space = FALSE;
	int restrainCursor = 0;
	int iLastCharWidth;
	int lineHeight = (sign * TextLineYs);
	int doLedger=0;		// In cursive we need to draw the ledger from the word pos
	int 	ly = 0,
		lx = 0;
	//iLastWordX = 0;
	bool 	bSplitLine;
	short bUnWrap = FALSE;

	nGlyfArrayIndex = 0;		// Start at the beginning
	SelectionIsReal = 0;
	// Reset bbox warning every time we redraw...
	// pParentBBox->Message( BBOX_WARNING_SET, FALSE, &statusTemp);

	switch (mWhichDraw) {
		case TEXT_DRAW_CURSOR_LINE1:	// The line changed, do line again
			// Set to previous line than cursor
			ly = (CursorIndex.y > 0) ? CursorIndex.y - 1 : 0;
			break;

		case TEXT_DRAW_CURSOR_LINE:
		case TEXT_DRAW_CHAR:
			// Set to display current line
			ly = CursorIndex.y;
			break;

		case TEXT_DRAW_CURSOR:
			// Fall through here
			ly = 0;
			break;

		case TEXT_DRAW_SELECTION:
			mWhichDraw = TEXT_DRAW_CURSOR; // temp
			ly =0;
			break;

		case TEXT_DRAW_ALL:
			ly = 0;
			break;

		case TEXT_DRAW_ALL_AGAIN:	// Forced full redraw
		default:	// ERROR
			ly = 0; // Start at the beginning
			mWhichDraw = TEXT_DRAW_ALL;	// Just draw the whole thing
			break;
	}


	// Erase the cursor if necessary.

	if (doDrawCursor && nCursorActive) {
		if (!GlobalDisplay) {
			DrawCursor(pDC, 0); 	// Turn the cursor OFF
		}
	}
	if (inCursive && (mWhichDraw == TEXT_DRAW_CHAR)) {
		doLedger=1;		// only do this the first time
	}

	if (BorderArtMarginZoomSize.x != 0) {
		zPos.y += (sign * (BorderArtMarginZoomSize.y));
		zPos.x += BorderArtMarginZoomSize.x;
		zSize.x -= (2 * BorderArtMarginZoomSize.x);
		zSize.y -= (sign * (2 * BorderArtMarginZoomSize.y));
	}
	// Adjust for the box margins
	zPos.y += (sign*zMargin);
	zPos.x += zMargin;
	zSize.x -= (2*zMargin);

#ifdef WRWDEBUG

	if (doDump) {
		DFile.open("c:\\wrwout.txt");
		DFile << "Debug Junk file. May be deleted.\nBegin\n";
		if (!inCursive) {
			DFile << "Not a cursive file.  Characters not printed\n";
		}
	}
#endif
	for ( ; ly < MAX_TEXT_LINES; ++ly) {

#ifdef WRWDEBUG
		if (doDump) {
			DFile << "\n";
		}
#endif
		int TextY = (int)((uzTextLineYs*ly) * dCurrentZoom);
		// If this line is empty it is the last...
		if	(TxtLines[ly].IsEmpty() && StoryNumber < 1 || StoryLinesChanged || ly >= StoryLines && StoryNumber > 0) {
			if (bUnWrap && StoryNumber < 1 || StoryLinesChanged) {	// did we pull up last line
				DrawBorderArt(pDC, false);
				DrawLedgerLines( pDC, CPoint(zPos.x, zPos.y + TextY), zSize, zMargin, zPos.x, ly);
			}
			if (!(StoryLinesChanged && StoryLines < 1) && !(ly >= StoryLines && IsLastItemInStory && !TxtLines[ly].IsEmpty())) {
				break;
			}
			else StoryLinesChanged = FALSE;
		}

		// If we get to big for the box, resize the box
		// this	was; if (((TextLineYs*ly)+ 20.0) < (size.y - TextLineYs)) {
		// Changed the test so we wouldn't get rounding error
		int testVal = (int)((float)(uzTextLineYs*ly) * dCurrentZoom);
		testVal += 20;
		int testVal2 = zSize.y - TextLineYs;
		if (BorderArtMarginZoomSize.y > 0) {
		}
		if (testVal < testVal2 && !StoryBoxFull) {
			allowAdjustBox = TRUE;

			zPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
			zSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);

			CPoint newsize = zSize;
			CPoint newpos = zPos;
			CPoint setsize, setpos;
			if (ly == 0) {	// This should only occur on a newly built text box with cursive default
				// The problem was that the new box was defaulting small, then we added an extra line
				// Then the adjust routine cleared out the second line area and restored it to one
				// line.  Just looked bad.
				newsize.y = TextLineYs; // This is minimum height for this box
			}
			else{
				newsize.y += TextLineYs;
			}

			// Reset the size with the 100% default zoom
			setpos = CPoint((int)((float)newpos.x / dCurrentZoom),
				(int)((float)newpos.y / dCurrentZoom));
			setsize = CPoint((int)((float)newsize.x / dCurrentZoom),
				(int)((float)newsize.y / dCurrentZoom));

			*status = CLEAROLD;
			CPoint withBorder(setsize);
			if (ly == 0)
			{
				AdjustBorderArt(pDC, withBorder, sign, false);
			}
			pParentBBox->Message( BBOX_SIZE_SET, withBorder, status);
			if (*status == OK || StoryLinesChanged) {
				*status = saveStatus;
				nOverfullWarning  = 0;		// Seems to fit now

			}
			else {
				if (*status == -3) {
					noGrowState = 1;
				}
				else {
					noGrowState = 0;
				}
				// To fix the infinite loop of redraw when changing the size of the text
				// makes it redraw but it does not fit on the page
				*status = saveStatus;

				if (noGrowState == 0) {
					if (nOverfullWarning == 0) {
						CAnnoy thisDialog;
						nOverfullWarning = 1;

						if (!inPasteMode || (inPasteMode && (nPointSize < 6))) {
							MessageBeep(MB_ICONEXCLAMATION);
							// Just make the sound and let them figure it out
							// This dialog only makes trouble in the long run
							//thisDialog.DoModal();
							//return;
						}
						else
							break;
					}
				}
				else {
					break;
				}
			}
			zSize = newsize;
			zPos = newpos;
			if (BorderArtMarginZoomSize.x != 0) {
				zPos.y += (sign * (BorderArtMarginZoomSize.y));
				zPos.x += BorderArtMarginZoomSize.x;
				zSize.x -= (2 * BorderArtMarginZoomSize.x);
				zSize.y -= (sign * (2 * BorderArtMarginZoomSize.y));
			}
			zPos.x += zMargin;
			zPos.y += (sign*zMargin);
			zSize.x -= (2*zMargin);
		}

		// Only draw the lines if we are doing more than the cursor/or one char
		if (BorderArtChanged || StoryLinesChanged || (mWhichDraw != TEXT_DRAW_CHAR && mWhichDraw != TEXT_DRAW_CURSOR)) {
			DrawBorderArt(pDC, false);
			DrawLedgerLines( pDC, CPoint(zPos.x, zPos.y + TextY), zSize, zMargin, zPos.x, ly);
		}

		i = 0;  	// reset index of word
		bUnWrap = FALSE;
		word_string.SetAtGrow(word_string_ind, 0);
		word_string_ind = 0;
		char_pos = 0;
		word_pos = 0;
		word_width = 0;
		char_width = 0;
		restrainCursor = 0;
		last_space = 0;
		ignoreLast_space = FALSE;
		nGlyfArrayIndex = 0;
		bSplitLine = FALSE;
		statusTemp = OK;	
		for (lx = 0, iLastCharWidth = 0;lx <= (linelen = TxtLines[ly].GetLength()); ++lx) {

			if (bSplitLine) {
				bSplitLine = FALSE;	// done with this line

				// We need to draw any text that is still there at this point
				if (mWhichDraw != TEXT_DRAW_CURSOR) {
					int yPos = zPos.y + TextY;
					if (nDot2Dot == TRUE) { //&& (!isMathFont || (isMathFont && !(IS_ALPHA(cLastChar))))) {
						DrawTextString(pDC, zPos.x + word_pos, yPos,
							&word_string, &statusTemp, TRUE, zSize
							,word_string_ind, TextY, lx, ly
							);
					}
					else {
						CString realString;

						for(int t=0; t < word_string_ind; t++ ) {
							realString += (char) word_string.GetAt(t);
						}

						if (!theApp.m_bInStoryDistributeMode) {
							pDC->TextOut( zPos.x + word_pos, yPos+zMargin, realString);
						}
						statusTemp = OK;


					}
				}
				break;
			}
			// If there IS more room on this line then append the next line.
			nDot2DotArrows=2;	/* allow arrow if we are supposed to */
//			nDot2DotOverlay=2;
			
//			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
//				fsData[fsi].nDot2DotFS = 2;
//			}

			nDot2DotConnectTheDots=doDrawConnectTheDots ? 2 : 1;
			if (lx == linelen) {
				c = SW_EOL;				// This is the end of the line
				prevChar = SW_EOL;
			}
			else {
				unsigned short c2, p2, n2, c3;
				c3 = TxtLines[ly][lx];		// Get the next character
				if (c3 == 0) {
					continue;
				}

				c3 = (unsigned short)((unsigned short)c3 & ((unsigned short)0xFF));		/* Get international char if there */

				if (doRunUKVersion || (*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {
					c = getNormalChar(c3);	/* convert the international char to normal for now */
				}
				else {
					c = c3;
				}
				if (TxtShapes[ly][lx] == SHAPE_UNSIGNED) {
					c = c3;
				}
				else if (TxtShapes[ly][lx] == SHAPE_EXTENDED) {
					c = c3 + SHAPES_START_EXTENDED;
				}

				if (doKerning || inCursive) 
				{

					// Get the next character too
					if ((lx + 1) == linelen) {
						nextChar = SW_EOL;
					}
					else {
						nextChar = TxtLines[ly][lx+1];

						if (TxtShapes[ly][lx+1] == SHAPE_EXTENDED) {
							nextChar = nextChar + SHAPES_START_EXTENDED;
						}
						else {
							nextChar = (unsigned short)((unsigned short)nextChar & ((unsigned short)0xFF));		/* Get international char if there */
						}

						if (IS_APOST(nextChar)) {
							nextChar = (unsigned short)(((lx+2) >= linelen) ? SW_EOL : TxtLines[ly][lx+2]);
							nextChar = (unsigned short)((unsigned short)nextChar & ((unsigned short)0xFF));		/* Get international char if there */
						}
					}
#if 0	// allow arrows, overlay and connect dots on all non alphanumeric chars?
					if (!IS_ALPHANUMERIC(c)) {
						nDot2DotArrows=1;
						nDot2DotOverlay=1;
//						for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
//							fsData[fsi].nDot2DotFS = 1;
//						}
						nDot2DotConnectTheDots=1;
					}
					else 
#endif
					if (inCursive) {
						nDot2DotArrows = (!ArrowFile.IsEmpty() && DO_ARROW(prevChar,nextChar) ) ? 2: 1;
						nDot2DotOverlay=1;	// not for cursive
//						for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
//							fsData[fsi].nDot2DotFS = 1;
//						}
						if (doDrawConnectTheDots) {
							nDot2DotConnectTheDots = (!ConnectTheDotsFile.IsEmpty()) ? 2: 1;
						}
						else {
							nDot2DotConnectTheDots = 1;
						}
					}

					if ((TxtShapes[ly][lx] > SHAPE_NONE)) {
						c2 = c;
					}
					else {
						c2 = GetCursiveChar(c, prevChar, nextChar);
					}

					if (!IS_APOST(c)) {
						prevChar = c;	// Remember the previous char
					}
					c = c2;			// and set the new one

					if (nextChar != SW_EOL && TxtShapes[ly][lx] < SHAPE_UNSIGNED) {
						// We need to change next char if possible to get the right kern
						n2 = (unsigned short)(((lx+2) >= linelen) ? SW_EOL : TxtLines[ly][lx+2]);
						if (IS_APOST(n2)) {
							n2 = (unsigned short)(((lx+3) >= linelen) ? SW_EOL : TxtLines[ly][lx+3]);
						}
						p2 = prevChar;	// use what the pre-adjusted char was
						c2 = nextChar;	// look at next char as if current
						nextChar = GetCursiveChar(c2,p2,n2);
					}
#ifdef WRWDEBUG
					if (doDump) {
						DFile << c << ',';
					}
#endif
				}
				if ((c == SW_BOL) && (TxtAttrs[ly][lx] == DELCHAR)) {
					c = SW_EOL;
				}
				if (!IS_ALPHANUMERIC(c)) {
					nDot2DotOverlay = 1;
//					nDot2DotStartDot=1;
					nDot2DotStartDot = (nStartDot == 1) ? 2 : 1; //(StartDotFont.isOpen == true) ? 2 : 1;
//					for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
//						fsData[fsi].nDot2DotFS = 1;
//					}
				}
				else  {
					nDot2DotStartDot = (nStartDot == 1) ? 2 : 1; //(StartDotFont.isOpen == true) ? 2 : 1;
//					for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
//						fsData[fsi].nDot2DotFS = 2;
//					}
				}
			}
			iLastCharWidth = char_width;
			if (c == SW_TAB) {
				int tabVal = (int) (750.0 * dCurrentZoom);
				char_width =  tabVal - (char_pos % tabVal);
			}
			else if (c != SW_EOL) {
				currAttr = TxtAttrs[ly][lx];	// Get this chars attributes

				if ((currAttr & ARROW_ON) && (nDot2DotArrows == 2)) {
					nDot2DotArrows = 2;
				}
				else if (nDot2DotArrows == 2) {
					nDot2DotArrows = (currAttr & ARROW_ON) ? 2 : 1;
				}
				/* else we should not do it at all */
#ifdef LATER_WRW
				if (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9')))
				{
					nDot2DotOverlay = (currAttr & OVERLAY_ON) ? 2 : 1;
				}
				else {
					nDot2DotOverlay = 1;
				}
#else
				nDot2DotOverlay = (currAttr & OVERLAY_ON) ? 2 : 1;
#endif
				for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
					fsData[fsi].nDot2DotFS = fsData[fsi].nDot2DotFSButton;
				}
#ifdef LATER_WRW
				if (((c >= 'A') && (c <= 'Z')) || ((c >= 'a') && (c <= 'z')) || ((c >= '0') && (c <= '9'))) {
					for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
						fsData[fsi].nDot2DotFS = fsData[fsi].nDot2DotFSButton;
					}
				}
				else {
					// Only try to draw on our displayable font characters
					for(int fsi=0; fsi < STROKE_COUNT; fsi++) {
						fsData[fsi].nDot2DotFS = 1;
					}
				}
#endif

				switch(currAttr & DENSMASK) {
					case DENS00:
						nDot2DotDensity = kDotDens00; 
						break;
					case DENS25:
						nDot2DotDensity = kDotDens25; 
						break;
					case DENS50:
						nDot2DotDensity = kDotDens50;
						break;
					case DENS75:
						nDot2DotDensity = kDotDens75;
						break;
					case DENS100:
						nDot2DotDensity = kDotDens100;
						break;
				}
				switch(currAttr & SHADMASK) {
					case SHAD25:
						nDot2DotShade = kDotShad25;
						break;
					case SHAD50:
						nDot2DotShade = kDotShad50;
						break;
					case SHAD75:
						nDot2DotShade = kDotShad75;
						break;
					case SHAD100:
						nDot2DotShade = kDotShad100;
						break;
				}

				DensityFormatArray[nGlyfArrayIndex] = nDot2DotDensity;
				ShadeFormatArray[nGlyfArrayIndex] = nDot2DotShade;
				ArrowsFormatArray[nGlyfArrayIndex] = nDot2DotArrows;
				OverlayFormatArray[nGlyfArrayIndex] = nDot2DotOverlay;
				for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
					fsData[fsi].ArrayInfoFS[nGlyfArrayIndex] = fsData[fsi].nDot2DotFS;
				}

				ConnectTheDotsFormatArray[nGlyfArrayIndex] = nDot2DotConnectTheDots;
#ifdef SW50
				StartDotFormatArray[nGlyfArrayIndex] = nDot2DotStartDot;
#endif

				// Underline
				UnderlineArray[nGlyfArrayIndex] = 0; //(currAttr & CHAR_UNDERLINE);
				// End Underline
				SelectedArray[nGlyfArrayIndex] = IsCharInSelection(lx, ly);
				// This must come after formats are set for char, but
				// before the nGlyfArrayIndex is modified...
				char_width = GetCharacterWidth(pDC, &c, &nextChar, lx, ly, &statusTemp);
				//LWRW				if (inCursive && (IS_APOST(c)) &&	IS_ALPHANUMERIC(nextChar) && IS_ALPHANUMERIC(prevChar)) {//		(nextChar != SW_EOL)) {
				//LWRW					char_width = 0;
				//LWRW				}
				if (statusTemp == ERROR)
					continue;	// Skip drawing this set if nothing there
			}

			// With the width known, can we check the cursor here? */
			if (!bCursorFound) {
				RECT rectChar1;

				rectChar1.left = zPos.x + char_pos + ScrollPos.x;
				rectChar1.right= zPos.x + char_pos + ScrollPos.x + char_width;
				rectChar1.top = zPos.y + TextY + (sign*lineHeight) + ScrollPos.y;
				rectChar1.bottom = zPos.y + TextY;

				if (PtInRect(&rectChar1, ptLookingFor)) {			// If it is in the whole character cell
					CPoint zCurpos;

					// Now find the half way mark 
					RECT rectChar2 = rectChar1;
					rectChar2.right -= (char_width / 2);

					// Set the actual cursor position here too
					bCursorSet = TRUE; //??
					zCurpos = CPoint((zPos.x + char_pos - ScrollPos.x),
						(zPos.y + (TextY + ScrollPos.y)));

					if (PtInRect(&rectChar2, ptLookingFor) || (lx >= linelen)) {		// Check which half
						SetCursor(CPoint(lx, ly));
					}
					else {
						SetCursor(CPoint(lx+1, ly));
						zCurpos.x += char_width;
					}
					CPoint cpDrawCursor(zCurpos.x - restrainCursor, zCurpos.y);
					SetCursorPos(cpDrawCursor, TextLineYs);
					m_bSetCursorToClicked = FALSE;   			// Must be in first half
					bCursorFound = TRUE;

					if (mWhichDraw == TEXT_DRAW_CURSOR) {
						break;
					}
				}
				else if (lx >= linelen) {

					int iTop = zPos.y + TextY - lineHeight + ScrollPos.y;
					int iBottom = zPos.y + TextY + ScrollPos.y;

					if ((ptLookingFor.y >= iTop) && (ptLookingFor.y <= iBottom)) {

							CPoint zCurpos;
							int retv;

							m_bSetCursorToClicked = FALSE;
							bCursorFound = TRUE;
							bCursorSet = TRUE; //??
							retv = SetCursor(CPoint(lx, ly));	/* go to last position */
							// Set the actual cursor position here too
							zCurpos = zPos;
							if (retv == 0) {
								zCurpos.x += char_pos - ScrollPos.x;
							}
							else {
								zCurpos.x += ScrollPos.x;
							}
							zCurpos.y += (TextY + ScrollPos.y);
							CPoint cpDrawCursor(zCurpos.x - restrainCursor, zCurpos.y);
							SetCursorPos(cpDrawCursor, TextLineYs);
					}
					else if (TxtLines[ly + 1].IsEmpty()) {
						// do nothing if they dragged off the end
					}
				}
			} 
			if (!bCursorSet && bCursorFound) {
				// Is this the right position
				if ((lx == CursorIndex.x) && (ly == CursorIndex.y)) {
					CPoint zCurpos;
					zCurpos = zPos;
					zCurpos.x += (char_pos - ScrollPos.x);		// Remove the scroll from actual
					zCurpos.y += (TextY + ScrollPos.y);	// cursor position setting
					if (SelectionOn) {
						SetCursor(CursorIndex);	// Duplicate to get selection 
					}
					CPoint cpDrawCursor(zCurpos.x - restrainCursor, zCurpos.y);
					SetCursorPos(cpDrawCursor, TextLineYs);
					bCursorSet = TRUE;
					if (mWhichDraw == TEXT_DRAW_CURSOR) {
						break;
					}
				}
			}
			if (c != SW_EOL) {

				// Unless there is a new-line present...
				if (allowFixWrap && ((lx+1) >= TxtLines[ly].GetLength()) && ((char_pos + char_width) < zSize.x)) {

					if (!TxtLines[ly+1].IsEmpty()) {
						int lenTxt = TxtLines[ly].GetLength();
						int lenAtt = TxtAttrs[ly].GetLength();
						int lenShp = TxtShapes[ly].GetLength();
						wchar_t fattr = 0;

						if (lenAtt > lenTxt) {
							fattr = TxtAttrs[ly].GetAt(lenAtt-1);
							fattr = (char)((char)fattr & ((char)(CHARTYPEMSK | EOL_MASK)));
						}


						// See if it is a soft return line	   
						if (fattr == (FUNCT_CHAR | EOL_SOFT)) {
							CPoint cp = CursorIndex;

							TxtLines[ly] = TxtLines[ly] + TxtLines[ly+1];
							TxtShapes[ly] = TxtShapes[ly] + TxtShapes[ly+1];
							bUnWrap = 3;

							// Append the attrs omitting the endofline function
							TxtAttrs[ly] = TxtAttrs[ly].Mid(0,lenTxt) + TxtAttrs[ly+1];
							/*
							On selection delete, this messes ip the cursor if it is on > 2 line on soft return lines
							Since the cursor is already in a good place, let's just leave it		       
							if (cp.y >= (ly+1)) {
							cp.y--;
							if (cp.y == ly) {
							cp.x += lenTxt;
							if (cp.x > TxtLines[cp.y].GetLength()) {
							cp.x = TxtLines[cp.y].GetLength();
							}
							}
							//SetCursor(cp);
							}
							*/
							RemoveLine(ly+1, false);
						}

						TestAttrState();

					} 
				}
			}

			if (/*isMathFont || */(c == ' ') || (c == SW_EOL) || (c == SW_TAB)) {	// End of word or end of line
				// If the the word tacked on to existing string is larger than the
				// x size of the box then empty the word and start on next line.
				// Reset the string index to the last breaking point.
				// If the char is a space and cursor would draw outside the box, keep it inside the box
				BOOL isShrinkTrailingSpace = (c == ' '  && char_width + word_pos + word_width > zSize.x);
				if (isShrinkTrailingSpace) {
					restrainCursor = (char_width + word_pos + word_width) - zSize.x;
				}
				if (word_pos + word_width > zSize.x) {

					int lenT = TxtLines[ly].GetLength();
					int lenA = TxtAttrs[ly].GetLength();
					int lenS = TxtShapes[ly].GetLength();
					int doItFlag = 1;

					if (lenA > lenT) {
						if (TxtAttrs[ly][lenA-1] == (EOLHCHAR)) {
							// Do some thing else here
							if (OpenLine(ly+1) == TRUE) {	// Create a new line  

								// Make the new line have just the last word
								TxtLines[ly+1] = TxtLines[ly].Mid(last_space + 1);
								TxtShapes[ly+1] = TxtShapes[ly].Mid(last_space + 1);
								if (TxtLines[ly+1].IsEmpty()) {
									TxtLines[ly+1].AppendChar(SW_BOL);	
									TxtShapes[ly+1].AppendChar(SHAPE_NONE);	
									TxtAttrs[ly+1].Empty();	// Make sure we start clean
									TxtAttrs[ly+1].AppendChar(DELCHAR); // deletable space
								}
								TxtAttrs[ly+1] = TxtAttrs[ly].Mid(last_space + 1);

								// Cut off the first line at the space
								TxtLines[ly] = TxtLines[ly].Mid(0, last_space + 1);								
								TxtShapes[ly] = TxtShapes[ly].Mid(0, last_space + 1);								
								TxtAttrs[ly] = TxtAttrs[ly].Mid(0, last_space + 1);

								doItFlag = 0;
							}		
						}
					}
					if (doItFlag) {					                    
						TxtAttrs[ly] = TxtAttrs[ly].Left(lenT);
						TxtShapes[ly] = TxtShapes[ly].Left(lenS);
						if (StoryNumber > 0 && !StoryLinesChanged && !IsLastItemInStory && ly >= StoryLines - 1 && !ignoreLast_space) {
							theApp.m_strStoryOverflowText += TxtLines[ly].Mid(last_space + 1);
							theApp.m_strStoryOverflowShapes += TxtShapes[ly].Mid(last_space + 1);
							StoryBoxFull = TRUE;
							theApp.m_iStoryOverflowDirection = ((last_space < lenT - 2 || StoryFlowOutState == STORY_FLOW_INSERT) ? 2 : 1);
							theApp.m_iStoryOverflowBox = StoryItemOrder + 1;
							if (!theApp.m_bInStoryDistributeMode && CursorIndex.y >= StoryLines - 1 && CursorIndex.x > last_space) {
								theApp.m_nStoryMoveCursorBox = StoryItemOrder + 1;
								// Offset only if preceding character is not a space
								if (last_space != CursorIndex.x - 1) {
									theApp.m_nStoryMoveCursorIndex = CursorIndex.x - last_space - 1;
								}
								else {
									theApp.m_nStoryMoveCursorIndex = 0;
								}
							}
						}

						if (!StoryBoxFull || ly < StoryLines - 1)
							TxtLines[ly+1] = TxtLines[ly].Mid(last_space + 1) + TxtLines[ly + 1];
						TxtLines[ly] = TxtLines[ly].Mid(0, last_space + 1);

						if (!StoryBoxFull || ly < StoryLines - 1)
							TxtShapes[ly+1] = TxtShapes[ly].Mid(last_space + 1) + TxtShapes[ly + 1];
						TxtShapes[ly] = TxtShapes[ly].Mid(0, last_space + 1);

						// And wrap the attr
						if (!StoryBoxFull || ly < StoryLines - 1)
							TxtAttrs[ly+1] = TxtAttrs[ly].Mid(last_space + 1) + TxtAttrs[ly + 1];
						TxtAttrs[ly] = TxtAttrs[ly].Mid(0, last_space + 1);
					}

					TxtAttrs[ly].AppendChar(FUNCT_CHAR|EOL_SOFT);	// Add soft return code
					doReformatText=1;

					CPoint cp = CursorIndex;
					if ((cp.y == ly) && (cp.x > last_space) && !keepBackspacePos) {
						if (TxtLines[ly+1].IsEmpty() == false) {
							cp.y++;
							cp.x = cp.x - last_space - 1;
							SetCursor(cp);
							bCursorSet = FALSE;
						}
					}

					TestAttrState();

					// If we're only trying to draw the char, but the line changed,
					// tell the caller so he can do what he needs to do and call us
					// again.
					if (mWhichDraw == TEXT_DRAW_CHAR) {
						*status = TEXT_DRAW_CURSOR_LINE1;  
						mWhichDraw = TEXT_DRAW_CURSOR_LINE1;
						goto leaving;
					}
					else if (mWhichDraw == TEXT_DRAW_CURSOR_LINE) {
						mWhichDraw = TEXT_DRAW_ALL;	// The rest of the box is affected now
					}

					word_string_ind = 0;
					word_string.SetAtGrow(0,0);
					word_width = 0;
					nGlyfArrayIndex = 0;
					word_pos = 0;
					char_pos = 0;
				}
				// Tack on the 'space' character and print the word. Then zero
				// word and length to prep for next word.
				else  {

					bUnWrap--;

					//iLastWordX = word_pos + word_width;

					if (c != SW_EOL) {
						if (c != SW_TAB) {
							word_string.SetAtGrow(word_string_ind, c);
							word_string_ind++;
						}
					}
					else {
						char_width = 0;
					}
					// See if we're only trying to draw the last char on the last line.
					if (mWhichDraw == TEXT_DRAW_CHAR) {
						// Are we on the last char?
						if (doKerning || inCursive) 		// In cursive it means last word
						{
							if (lx > lastWordPos) {
								if (doLedger) {
									DrawBorderArt(pDC, true);
									DrawLedgerLines( pDC, 
										CPoint(zPos.x + word_pos, zPos.y + TextY), 
										CPoint(zSize.x - word_pos, zSize.y),
										0, 
										zPos.x,
										ly);
									doLedger=0;
								}

								DrawTextString(pDC, zPos.x + word_pos, zPos.y + TextY, 
									&word_string, &statusTemp, TRUE, zSize
									, word_string_ind, TextY, lx, ly);
								goto leaving;		// We drew the char. get out
							}
						}
						else if (isMathFont2 || (lx >= linelen)) {
							CWordArray str;
							str.SetAtGrow(0,cLastChar);
							str.SetAtGrow(1, 0);
							if (nDot2Dot == TRUE) { //&& (!isMathFont || (isMathFont && !(IS_ALPHA(cLastChar))))) {
								DrawTextString(pDC, 
									zPos.x + word_pos + word_width - iLastCharWidth, 
									zPos.y + TextY, 
									&str, 
									&statusTemp, 
									FALSE,
									zSize
									,1, TextY, lx, ly
									);
								goto leaving;		// We drew the char. get out
							}
							else {
								CString str;

								str = (char) cLastChar;

								// TRY COLOR						
								//								if (nSelected) 
								//									pDC->SetTextColor(RGB(255,0,0));
								//								else
								//									pDC->SetTextColor(RGB(0,255,0));

								if (!theApp.m_bInStoryDistributeMode) {
									pDC->TextOut( zPos.x + word_pos + word_width - iLastCharWidth, 
										zPos.y + TextY + zMargin, str);
								}



								statusTemp = OK;
							}
						}
						else {
							cLastChar = ' ';	// make it a space
						}
					}
					else if (mWhichDraw != TEXT_DRAW_CURSOR) {
						if (nDot2Dot == TRUE) {//&& (!isMathFont || (isMathFont && !(IS_ALPHA(cLastChar))))) {
							DrawTextString(pDC, zPos.x + word_pos, zPos.y + TextY,
								&word_string, &statusTemp, TRUE, zSize, word_string_ind, TextY, lx, ly);
						}
						else {
							CString realString;

							for(int t=0; t < word_string_ind; t++ ) {
								realString += (char) word_string.GetAt(t);
							}


							//							if (nSelected) 
							//								pDC->SetTextColor(RGB(255,0,0));
							//							else
							//								pDC->SetTextColor(RGB(0,255,0));

							// TRY COLOR						

							if (!theApp.m_bInStoryDistributeMode) {
								pDC->TextOut( zPos.x + word_pos, zPos.y + zMargin + TextY - mDescentLeading, realString);
							}



							statusTemp = OK;
						}
					}

					last_space = lx;
					// If a space caused the overflow in a Story Box, it needs to overflow to the next Story box
					// (generally, the trailing space is being left on the line even when it does not fit)
					if (c == ' ' && StoryNumber > 0 && *status == TEXT_DRAW_ALL && !IsLastItemInStory && ly >= StoryLines - 1 && ((word_pos + word_width + char_width) > zSize.x)) {
						//--last_space;
						ignoreLast_space = true;
					}
					word_pos += word_width + char_width;
					char_pos += char_width;
					word_string.SetAtGrow(word_string_ind, 0);
					word_string_ind = 0;
					word_width = 0;
					nGlyfArrayIndex = 0; 
				}
			}
			// Add a character to the current word and change its size.
			else {
				TestAttrState();
				// Test for lx since it is possible that the box gets narrower than one char.  
				// In which case the character will not display instead of trying to wrap.
				if (lx && ((/*word_pos + */word_width + char_width) > zSize.x)) {
					// WORD TOO LONG CODE
					// For the case where the word is wider than the box.
					// If it is, split it up with a space and continue.

					int len1, len2;

					len1 = TxtLines[ly].GetLength();
					len2 = TxtAttrs[ly].GetLength();
					bool isMaintainHEOL = (len2 > len1 && TxtAttrs[ly].GetAt(len2 - 1) == EOLHCHAR && StoryNumber < 1);
					if (!StoryBoxFull || ly < StoryLines - 1) {
						if (!isMaintainHEOL) {
							TxtLines[ly + 1] = TxtLines[ly].Mid(lx) + TxtLines[ly + 1];
							TxtShapes[ly + 1] = TxtShapes[ly].Mid(lx) + TxtShapes[ly + 1];
						}
						else {
							for (int yline = MAX_TEXT_LINES-1; yline > ly + 1; yline--) {
								TxtLines[yline] = TxtLines[yline - 1];
								TxtShapes[yline] = TxtShapes[yline - 1];
								TxtAttrs[yline] = TxtAttrs[yline - 1];
							}
							TxtLines[ly + 1] = TxtLines[ly].Mid(lx);
							TxtShapes[ly + 1] = TxtShapes[ly].Mid(lx);
						}
					}
					TxtLines[ly] = TxtLines[ly].Left(lx);
					TxtShapes[ly] = TxtShapes[ly].Left(lx);

					if (len2 > len1) {	// If there is a function char at the end
						TxtAttrs[ly] = TxtAttrs[ly].Left(len1);// use string len
					}

					if (!isMaintainHEOL) {
						TxtAttrs[ly + 1] = TxtAttrs[ly].Mid(lx) + TxtAttrs[ly + 1];
						TxtAttrs[ly] = TxtAttrs[ly].Left(lx);
						TxtAttrs[ly].AppendChar(FUNCT_CHAR|EOL_SOFT);	// Add soft return code
					}
					else {
						TxtAttrs[ly + 1] = TxtAttrs[ly].Mid(lx);
						TxtAttrs[ly + 1].AppendChar(EOLHCHAR);	// Add HARD return code
						TxtAttrs[ly] = TxtAttrs[ly].Left(lx);
						TxtAttrs[ly].AppendChar(FUNCT_CHAR|EOL_SOFT);	// Add soft return code
					}
					doReformatText=1;

					// If this is the insert char moving lines, reset cursor
					if ((CursorIndex.x >= (lx+1)) && (CursorIndex.y == ly)) {
						SetCursor(CPoint(CursorIndex.x-lx, CursorIndex.y+1));
						*status = TEXT_DRAW_ALL_AGAIN;	
					}

					// Go back one since it isn't really here anymore
					lx--;
					bSplitLine = TRUE;
					TestAttrState();
					bUnWrap = 3;
					continue;

				}
				//iLastCharWidth = char_width;

				// Only add this char if it is inside the box
				// this should stop from displaying out the end before  a wrap
				if ((word_pos + word_width + char_width) < zSize.x) {
					word_string.SetAtGrow(word_string_ind, c);
					word_string_ind++;
				}

				cLastChar = c;

				if (nGlyfArrayIndex < MAX_GLYF_ARRAY - 1 )
					nGlyfArrayIndex += 1;

				word_width += char_width;
				char_pos += char_width;
			}
		} // end of lx for loop
		if (bCursorSet && (mWhichDraw == TEXT_DRAW_CURSOR)) {
			break;
		}

		if (mWhichDraw == TEXT_DRAW_CURSOR_LINE) {
			if (bUnWrap <= 0) {
				bUnWrap = FALSE;
				break;	// we are done with the one line we were supposed to write
			}
			else if ((bUnWrap == 1) || (bUnWrap == 3)){
				// if there are no more lines, we need to clear out the one that was there
				mWhichDraw = TEXT_DRAW_ALL;
			}
			else {
				bUnWrap = FALSE;
			}
		}
		else {
			bUnWrap = FALSE;
		}
	}  // end of ly for loop

#ifdef WRWDEBUG
	if (doDump) {
		DFile << "\nEnd\n";
		DFile.close();
		doDump=0;
	}
#endif
leaving:
	if (doDrawCursor && nCursorActive)
		DrawCursor(pDC,1);


	if (nDot2Dot || isMathFont2) {
		if (nCursorActive == false) {
			if (Dot2DotFont.isOpen == true) {
				Dot2DotFont.Close();
			}
			if (ArrowFont.isOpen == true) {
				ArrowFont.Close();
			}
			if (OverlayFont.isOpen == true) {
				OverlayFont.Close();
			}
			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
				if (fsData[fsi].TTFontFS.isOpen == true)
					fsData[fsi].TTFontFS.Close();
			}
			if (StartDotFont.isOpen == true) {
				StartDotFont.Close();
			}
			if (ConnectTheDotsFont.isOpen == true) {
				ConnectTheDotsFont.Close();
			}
		}

	}
	if (!nDot2Dot || isMathFont) {
		if (pOldFont) {
			pDC->SelectObject(pOldFont);
		}
		TextFont.DeleteObject();
	}
	m_bSetCursorToClicked = FALSE;
	allowFixWrap = FALSE;

	if (allowAdjustBox == TRUE) {
		allowAdjustBox = FALSE;
		*status = TEXT_DRAW_ALL;
		mWhichDraw = TEXT_DRAW_ALL;
		bool sizeChanged = AdjustBoxSize(pDC, FALSE);
		DrawBorderArt(pDC, true);
	}
	//if ((nOverfullWarning) && ((lastGoodPointSize != -1) || (inPasteMode && (nPointSize > 13)))) {
	if ((nOverfullWarning) && (resizeOK || inPasteMode)) {
		//if (inPastMode && (allowFontSizeChange)) {
			int lastPoint = nPointSize;
			if (lastGoodPointSize == -1) {
				if (nPointSize > 48) {
					nPointSize -= 5;
				}
				else if (nPointSize > 25) {
					nPointSize -= 2;
				}
				else {
					nPointSize = 6;
				}
			}
			else {
				nPointSize = lastGoodPointSize;
			}
			if (nPointSize != lastPoint || BorderArtChanged) {
				WriteTextBar();		// reset point size
				SetViaMembers();	
				*status = TEXT_DRAW_ALL_AGAIN;	
				nOverfullWarning = 0;
			}
		//}
	}
	lastGoodPointSize = -1;
	BorderArtChanged = FALSE;
	StoryLinesChanged = FALSE;
#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::Draw: void"); 
#endif
}

// Underline
void TextItem::DrawUnderline(CDC *pDC, CPoint zPos, CPoint zSize)
{
	int ht = zPos.y + TextLineYs;
	int wd = zPos.x + zSize.x;

	if ((ht > 32000) || (wd > 32000)) {
		return;
	}

	float upem = 2048.00;
	float points = zPointSize;

	float points_per_inch = 72.00;
	// Equation from page 4 of 40 in the Apple's Font Engine reference
	float scale = ( points * (float)PIXELS_PER_INCH ) 
		/ ( points_per_inch * upem );

	float maxy_em = 1836 - 336;
	//float maxx_em = 2048;

	//int maxx = (int)(maxx_em * scale);
	int maxy = (int)(maxy_em * scale);

	unsigned long bcolor = RGB(0,0,0);				// make it black

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) pDC->SelectStockObject(NULL_PEN);
	CPen blackpen(PS_SOLID, 4, bcolor);
	pDC->SelectObject(&blackpen);

	// Draw the line
	pDC->MoveTo(zPos.x, zPos.y - maxy - 20);
	pDC->LineTo(zPos.x + zSize.x, zPos.y - maxy - 20);

	pDC->SelectObject(oldpen);
}
// End Underline

void TextItem::RestoreBorderArt()
{
	CString imagePieces[] =
	{
		"_TL",
		"_TR",
		"_BL",
		"_BR",
		"_TH",
		"_BH",
		"_VL",
		"_VR"
	};

	BorderArtChanged = TRUE;
	allowAdjustBox = TRUE;	// Will need to allow box size to change if image or image size changes
	nOverfullWarning = 0;	// Clear to allow retesting the box size
	ClearBorderArtFiles(FALSE);
	BorderArtSize.SetPoint(0, 0);
	BorderArtZoomSize.SetPoint(0, 0);
	BorderArtMarginSize.SetPoint(0, 0);
	BorderArtMarginZoomSize.SetPoint(0, 0);
	BorderArtAdjustment.SetPoint(0, 0);
	BorderArtAdjustmentZoom.SetPoint(0, 0);
	FreeBorderArtBuffers();

	if (BorderArtFile[0].IsEmpty()) {
		BorderArtType = BORDER_ART_TYPE_NONE;
		BorderArtShrink = FALSE;
		BorderArtSource = BORDER_ART_SOURCE_NONE;
		BorderArtSizeOption = 0;
		return;
	}

	if (BorderArtFile[0].Find("_TL.") < 0) {
		BorderArtType = BORDER_ART_TYPE_SIMPLE;
	}
	else {
		BorderArtType = BORDER_ART_TYPE_COMPLEX;
		// For "true-border" (eight pieces) borders, we are expecting the pieces in a certain order, as can be seen above
		for (int imagePiece=1; imagePiece<8; imagePiece++) {
			BorderArtFile[imagePiece] = BorderArtFile[0];
			BorderArtFile[imagePiece].Replace("_TL", imagePieces[imagePiece]);
		}
	}
	BorderArtSizeOption = max(MIN_BORDERARTSIZE, BorderArtSizeOption);

	CPoint imageSize(0, 0);
	// This only loads the image, and allows us to know the dimensions-- it does not display here!
	if (BorderArtType == BORDER_ART_TYPE_SIMPLE) {
		borderArtDisplay(NULL, borderArtBufId[0], CPoint(0, 0), CPoint(BorderArtSizeOption, BorderArtSizeOption), BorderArtFile[0], false, CPoint(0, 0), imageSize);
		borderArtBufId[0] |= SWA_LOADED;	// remember that this was loaded
	}
	else if (BorderArtType == BORDER_ART_TYPE_COMPLEX) {
		for (int i = 0; i < 8; i++) {
			borderArtDisplay(NULL, borderArtBufId[i], CPoint(0, 0), CPoint(BorderArtSizeOption, BorderArtSizeOption), BorderArtFile[i], false, CPoint(0, 0), imageSize);
			borderArtBufId[i] |= SWA_LOADED; // remember that these were loaded
		}
	}
	int nRatio = max(1, max(imageSize.y, imageSize.x) / BorderArtSizeOption);
	BorderArtSize.x = imageSize.x/nRatio;
	BorderArtSize.y = imageSize.y/nRatio;
	BorderArtZoomSize.x = (int)(((float)BorderArtSize.x + 0.5) * dCurrentZoom);
	BorderArtZoomSize.y = (int)(((float)BorderArtSize.y + 0.5) * dCurrentZoom);
}

void TextItem::FreeBorderArtBuffers()
{
	for (int i = 0; i < 8; i++) {
		artFreeBuffer(&borderArtBufId[i]);
	}
}

void TextItem::ClearBorderArtFiles(bool clearBase)
{
	for (int i = (clearBase ? 0 : 1); i < 8; i++) {
		BorderArtFile[i] = "";
	}
}

void TextItem::DrawBorderArt(CDC *pDC, bool doClear)
{
	if (pParentBBox == NULL || BorderArtMarginZoomSize.x < 1 || BorderArtMarginZoomSize.y < 1)
		return;
	if (pDC->IsPrinting()) {
		if (!inPrintPreview)
			PrintBorderArt(pDC);
		else
			PrintBorderArtPreview(pDC);
		return;
	}

	int statusTemp = 0;
	CPoint imageSize(0, 0);
	CPoint cpTemp(0, 0);
	CPoint lPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	CPoint lSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);

	if (doClear || BorderArtChanged) {
		CPen *oldpen = (CPen *) pDC->SelectStockObject(NULL_PEN);
		pDC->SelectStockObject(WHITE_BRUSH);
		if (!pDC->IsPrinting()) {
			pDC->Rectangle(CRect( 
				lPos.x,
				lPos.y + lSize.y + BorderArtMarginZoomSize.y - (int)((float)BorderArtAdjustment.y * dCurrentZoom) + zMargin,
				lPos.x + lSize.x,
				lPos.y + lSize.y));
		}
		pDC->SelectObject(oldpen);
	}

	CPoint lPosNormal(0, 0);
	CPoint lSizeNormal(lSize.x, lSize.y);
	pDC->LPtoDP(&lPos);
	pDC->LPtoDP(&lSize);
	lSizeNormal.y = abs(lSizeNormal.y);//Before conversion
	lSizeNormal.x = abs(lSizeNormal.x);//Before conversion
	pDC->LPtoDP(&lPosNormal);
	pDC->LPtoDP(&lSizeNormal);
	lSizeNormal.y = abs(lSizeNormal.y);//And after conversion
	lSizeNormal.x = abs(lSizeNormal.x);//And after conversion
	int curX = lPos.x;
	int curY = lPos.y;
	int maxX = lPosNormal.x + lSizeNormal.x - BorderArtZoomSize.x + 1;
	int maxY = lPosNormal.y + lSizeNormal.y - BorderArtZoomSize.y;
	// For even distribution of images (the border is never an exact multiple of any image height or width...)
	int countX = (abs(lPosNormal.x) + lSizeNormal.x) / BorderArtZoomSize.x;
	int countY = (lPosNormal.y + lSizeNormal.y) / BorderArtZoomSize.y;
	int leftoverX = (abs(lPosNormal.x)+ lSizeNormal.x) % BorderArtZoomSize.x;
	int leftoverY = (lPosNormal.y + lSizeNormal.y) % BorderArtZoomSize.y;
	// This is a little special handling to make it look a little nicer in some Zoom views
	// If there are less than five images on the sides, and the two in the middle would end up very stretched,
	// Add an extra one and shrink their height, instead
	if (dCurrentZoom != 1.0 && countY < 5 && leftoverY > BorderArtZoomSize.y / 2) {
		++countY;
		leftoverY = -leftoverY;
	}
	int extraEachX = 0;
	int extraEachY = 0;
	int remainderX = 0;
	int remainderY = 0;
	if (countX > 2) {
		if (leftoverX >= (countX - 2)) {
			extraEachX = leftoverX / (countX - 2);
			remainderX = leftoverX % (countX - 2);
		}
		else {
			remainderX = leftoverX;
		}
	}
	if (countY > 2) {
		if (leftoverY >= (countY - 2)) {
			extraEachY = leftoverY / (countY - 2);
			remainderY = leftoverY % (countY - 2);
		}
		else {
			remainderY = leftoverY;
		}
	}
	int imageNum = 0;
	CPoint dibpos1(curX, curY);// For left side and for top row
	CPoint dibpos2(curX, curY);// To draw right side or bottom row at same time as left side or top row
	CPoint dibsize(BorderArtZoomSize.x, BorderArtZoomSize.y);
	// Draw top and bottom rows
	dibpos1.y = lPos.y;
	dibpos2.y = lPos.y + maxY;
	curX = lPos.x;
	if (BorderArtType == BORDER_ART_TYPE_SIMPLE && !BorderArtShrink) {
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			if (imageNum > 0) {
				curX += (BorderArtZoomSize.x + extraEachX);
				if (remainderX > 0) {
					++curX;
					--remainderX;
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, CPoint(0, 0), imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, CPoint(0, 0), imageSize);
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = lPos.y;
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			curY += (BorderArtZoomSize.y + extraEachY);
			if (remainderY > 0) {
				++curY;
				--remainderY;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, CPoint(0, 0), imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, CPoint(0, 0), imageSize);
		}
	}
	else if (BorderArtType == BORDER_ART_TYPE_COMPLEX || (BorderArtType == BORDER_ART_TYPE_SIMPLE && BorderArtShrink)) {
		dibsize.y = BorderArtZoomSize.y;
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			dibsize.x = BorderArtZoomSize.x;
			if (imageNum > 0) {
				curX += BorderArtZoomSize.x;
				if (imageNum > 1) {
					curX += extraEachX;
				}
				if (imageNum < countX - 1) {
					dibsize.x += extraEachX;
				}
				if (remainderX > 0) {
					if (imageNum > 1 && imageNum < countX - 1) {
						curX += 1;
						--remainderX;
					}
					else if (imageNum == countX - 1) {
						curX += remainderX;
						remainderX = 0;
					}
					if (imageNum < countX - 2) {
						++dibsize.x;
					}
					else if (imageNum == countX - 2) {
						dibsize.x += remainderX;
					}
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			if (imageNum == 0) {
				borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, CPoint(0, 0), imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], true, CPoint(0, 0), imageSize);
			}
			else if (imageNum == countX - 1) {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], true, CPoint(0, 0), imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], true, CPoint(0, 0), imageSize);
			}
			else {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], true, CPoint(0, 0), imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], true, CPoint(0, 0), imageSize);
			}
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = lPos.y;
		dibsize.x = BorderArtZoomSize.x;
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			dibsize.y = BorderArtZoomSize.y;
			curY += BorderArtZoomSize.y;
			if (imageNum > 1) {
				curY += extraEachY;
			}
			dibsize.y += extraEachY;
			if (remainderY > 0) {
				if (imageNum > 1) {
					++curY;
					--remainderY;
				}
				dibsize.y += 1;
			}
			if (imageNum >= countY - 2 && remainderY > 0) {
				dibsize.y += remainderY;
				remainderY = 0;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 6 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 6 : 0], true, CPoint(0, 0), imageSize);
			borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 7 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 7 : 0], true, CPoint(0, 0), imageSize);
		}
	}
}

void TextItem::PrintBorderArt(CDC *pDC)
{
	if (pParentBBox == NULL || BorderArtMarginZoomSize.x < 1 || BorderArtMarginZoomSize.y < 1)
		return;
	int statusTemp = 0;
	CPoint cpTemp(0, 0);
	CPoint imageSize(0, 0);
	CPoint padSize(2, 2);
	CPoint lPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	CPoint lSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);
	CPoint lPosNormal(0, 0);
	CPoint lSizeNormal(lSize.x, lSize.y);
	CPoint lSizeImageNormal(BorderArtMarginSize.x, BorderArtMarginSize.y);
	pDC->LPtoDP(&lPos);
	pDC->LPtoDP(&lSize);
	pDC->LPtoDP(&lSizeImageNormal);
	lSizeNormal.y = abs(lSizeNormal.y);//Before conversion
	lSizeNormal.x = abs(lSizeNormal.x);//Before conversion
	lSizeImageNormal.y = abs(lSizeImageNormal.y);//Before conversion
	lSizeImageNormal.x = abs(lSizeImageNormal.x);//Before conversion
	pDC->LPtoDP(&lPosNormal);
	pDC->LPtoDP(&lSizeNormal);
	lSizeNormal.y = abs(lSizeNormal.y);//And after conversion
	lSizeNormal.x = abs(lSizeNormal.x);//And after conversion
	lSizeImageNormal.y = abs(lSizeImageNormal.y);//And after conversion
	lSizeImageNormal.x = abs(lSizeImageNormal.x);//And after conversion
	int curX = lPos.x;
	int curY = lPos.y;
	int maxX = lPosNormal.x + lSizeNormal.x - BorderArtZoomSize.x + 1;
	int maxY = lPosNormal.y + lSizeNormal.y - lSizeImageNormal.y;
	// For even distribution of images (the border is never an exact multiple of any image height or width...)
	int countX = (abs(lPosNormal.x) + lSizeNormal.x) / lSizeImageNormal.x;
	int countY = (lPosNormal.y + lSizeNormal.y) / lSizeImageNormal.y;
	int leftoverX = (abs(lPosNormal.x)+ lSizeNormal.x) % lSizeImageNormal.x;
	if (leftoverX != 0 && BorderArtShrink) {
		if (leftoverX > lSizeImageNormal.x / 2) {
			++countX;
			maxX += (lSizeImageNormal.x - leftoverX);
		}
		else {
			maxX -= leftoverX;
		}
		leftoverX = 0;
	}
	int leftoverY = (lPosNormal.y + lSizeNormal.y) % lSizeImageNormal.y;
	if (leftoverY != 0) {
		if (leftoverY > lSizeImageNormal.y / 4) {
			++countY;
			maxY += (lSizeImageNormal.y - leftoverY);
		}
		else {
			maxY -= leftoverY;
		}
		leftoverY = 0;
	}
	// normal zoom good:
	int extraEachX = 0;
	int extraEachY = 0;
	int remainderX = 0;
	int remainderY = 0;
	if (!BorderArtShrink) {
		if (countX > 1) {
			if (leftoverX >= (countX - 1)) {
				extraEachX = leftoverX / (countX - 1);
				remainderX = leftoverX % (countX - 1);
			}
			else {
				remainderX = leftoverX;
			}
		}
		if (countY > 1) {
			if (leftoverY >= (countY - 1)) {
				extraEachY = leftoverY / (countY - 1);
				remainderY = leftoverY % (countY - 1);
			}
			else {
				remainderY = leftoverY;
			}
		}
	}
	int imageNum = 0;
	CPoint dibpos1(curX, curY);// For left side and for top row
	CPoint dibpos2(curX, curY);// To draw right side or bottom row at same time as left side or top row
	CPoint dibsize(lSizeImageNormal.x, lSizeImageNormal.y);
	// Draw top and bottom rows
	dibpos1.y = lPos.y;
	dibpos2.y = lPos.y + maxY;
	curX = lPos.x;
	if (BorderArtType == BORDER_ART_TYPE_SIMPLE && !BorderArtShrink) {
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			if (imageNum > 0) {
				curX += (lSizeImageNormal.x + extraEachX);
				if (remainderX > 0) {
					++curX;
					--remainderX;
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, padSize, imageSize);
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = lPos.y;
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			curY += (lSizeImageNormal.y + extraEachY);
			if (remainderY > 0) {
				++curY;
				--remainderY;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, padSize, imageSize);
		}
	}
	else if (BorderArtType == BORDER_ART_TYPE_COMPLEX || (BorderArtType == BORDER_ART_TYPE_SIMPLE && BorderArtShrink)) {
		dibsize.y = lSizeImageNormal.y;
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			dibsize.x = lSizeImageNormal.x;
			if (imageNum > 0) {
				curX += lSizeImageNormal.x;
				if (imageNum > 1) {
					curX += extraEachX;
				}
				if (imageNum < countX - 1) {
					dibsize.x += extraEachX;
				}
				if (remainderX > 0) {
					if (imageNum > 1) {
						curX += 1;
						--remainderX;
					}
					if (imageNum < countX - 1) {
						++dibsize.x;
					}
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			if (imageNum == 0) {
				borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], true, padSize, imageSize);
			}
			else if (imageNum == countX - 1) {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], true, padSize, imageSize);
			}
			else {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], true, padSize, imageSize);
			}
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = lPos.y;
		dibsize.x = lSizeImageNormal.x;
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			dibsize.y = lSizeImageNormal.y;
			curY += lSizeImageNormal.y;
			if (imageNum > 1) {
				curY += extraEachY;
			}
			dibsize.y += extraEachY;
			if (remainderY > 0) {
				if (imageNum > 1) {
					++curY;
					--remainderY;
				}
				dibsize.y += 1;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[6], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 6 : 0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[7], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 7 : 0], true, padSize, imageSize);
		}
	}
}

void TextItem::PrintBorderArtPreview(CDC *pDC)
{
	if (pParentBBox == NULL || BorderArtMarginZoomSize.x < 1 || BorderArtMarginZoomSize.y < 1)
		return;
	int statusTemp = -5;
	CPoint cpTemp(0, 0);
	CPoint borderArtPreviewSize(BorderArtMarginZoomSize);
	CPoint imageSize(0, 0);
	CPoint padSize(20,-20);
	CPoint lPos = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, &statusTemp);
	CPoint lSize = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, &statusTemp);
	CPoint lPosNormal(0, 0);
	CPoint lSizeNormal(abs(lSize.x), abs(lSize.y));
	int curX = lPos.x;
	int curY = (lPos.y > 0 ? -lPos.y : lPos.y);
	int maxX = lPosNormal.x + lSizeNormal.x - borderArtPreviewSize.x + 1;
	int maxY = lPosNormal.y + lSizeNormal.y - borderArtPreviewSize.y;
	// For even distribution of images (the border is never an exact multiple of any image height or width...)
	int countX = (abs(lPosNormal.x) + lSizeNormal.x) / borderArtPreviewSize.x;
	int countY = (lPosNormal.y + lSizeNormal.y) / borderArtPreviewSize.y;
	int leftoverX = (abs(lPosNormal.x)+ lSizeNormal.x) % borderArtPreviewSize.x;
	int leftoverY = (lPosNormal.y + lSizeNormal.y) % borderArtPreviewSize.y;
	int extraEachX = 0;
	int extraEachY = 0;
	int remainderX = 0;
	int remainderY = 0;
	if (!BorderArtShrink) {
		if (countX > 1) {
			if (leftoverX >= (countX - 1)) {
				extraEachX = leftoverX / (countX - 1);
				remainderX = leftoverX % (countX - 1);
			}
			else {
				remainderX = leftoverX;
			}
		}
		if (countY > 1) {
			if (leftoverY >= (countY - 1)) {
				extraEachY = leftoverY / (countY - 1);
				remainderY = leftoverY % (countY - 1);
			}
			else {
				remainderY = leftoverY;
			}
		}
	}
	int imageNum = 0;
	CPoint dibpos1(curX, curY);// For left side and for top row
	CPoint dibpos2(curX, curY);// To draw right side or bottom row at same time as left side or top row
	CPoint dibsize(borderArtPreviewSize.x, -borderArtPreviewSize.y);
	// Draw top and bottom rows
	dibpos1.y = curY;
	dibpos2.y = curY - maxY;
	curX = lPos.x;
	if (BorderArtType == BORDER_ART_TYPE_SIMPLE && !BorderArtShrink) {
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			if (imageNum > 0) {
				curX += (borderArtPreviewSize.x + extraEachX);
				if (remainderX > 0) {
					++curX;
					--remainderX;
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, padSize, imageSize);
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = (lPos.y > 0 ? -lPos.y : lPos.y);
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			curY -= (borderArtPreviewSize.y + extraEachY);
			if (remainderY > 0) {
				--curY;
				--remainderY;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[0], dibpos2, dibsize, BorderArtFile[0], true, padSize, imageSize);
		}
	}
	else if (BorderArtType == BORDER_ART_TYPE_COMPLEX || (BorderArtType == BORDER_ART_TYPE_SIMPLE && BorderArtShrink)) {
		for (imageNum=0; imageNum<countX; imageNum++)
		{
			dibsize.x = borderArtPreviewSize.x;
			if (imageNum > 0) {
				curX += borderArtPreviewSize.x;
				if (imageNum > 1) {
					curX += extraEachX;
				}
				if (imageNum < countX - 1) {
					dibsize.x += extraEachX;
				}
				if (remainderX > 0) {
					if (imageNum > 1) {
						curX += 1;
						--remainderX;
					}
					if (imageNum < countX - 1) {
						++dibsize.x;
					}
				}
			}
			dibpos1.x = curX;
			dibpos2.x = curX;
			if (imageNum == 0) {
				borderArtDisplay(pDC, borderArtBufId[0], dibpos1, dibsize, BorderArtFile[0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 2 : 0], true, padSize, imageSize);
			}
			else if (imageNum == countX - 1) {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 1 : 0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 3 : 0], true, padSize, imageSize);
			}
			else {
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 4 : 0], true, padSize, imageSize);
				borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 5 : 0], true, padSize, imageSize);
			}
		}
		// Draw left and right sides
		dibpos1.x = lPos.x;
		curY = (lPos.y > 0 ? -lPos.y : lPos.y);
		dibsize.x = borderArtPreviewSize.x;
		for (imageNum=1; imageNum<countY - 1; imageNum++)// Don't draw on top and bottom rows since we did those already
		{
			dibsize.y = -borderArtPreviewSize.y;
			curY -= borderArtPreviewSize.y;
			if (imageNum > 1) {
				curY -= extraEachY;
			}
			dibsize.y -= extraEachY;
			if (remainderY > 0) {
				if (imageNum > 1) {
					--curY;
					--remainderY;
				}
				dibsize.y -= 1;
			}
			dibpos1.y = curY;
			dibpos2.y = curY;
			borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 6 : 0], dibpos1, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 6 : 0], true, padSize, imageSize);
			borderArtDisplay(pDC, borderArtBufId[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 7 : 0], dibpos2, dibsize, BorderArtFile[BorderArtType == BORDER_ART_TYPE_COMPLEX ? 7 : 0], true, padSize, imageSize);
		}
	}
}

int TextItem::DrawLedgerLines( CDC *pDC, CPoint zPos, CPoint zSize, int MarginVal, int startX, int ly)
{
	int ht = zPos.y + TextLineYs;
	int wd = zPos.x + zSize.x;

	if ((ht > 32000) || (wd > 32000)) {
		return TRUE;
	}



	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) pDC->SelectStockObject(NULL_PEN);
	pDC->SelectStockObject(WHITE_BRUSH);

	if (!pDC->IsPrinting()) {
		pDC->Rectangle(CRect( 
			zPos.x - MarginVal,
			zPos.y + zMargin + (ly > 0 || BorderArtType == 0 ? (2*(int)zPointSize) : 0),
			wd + MarginVal,
			ht + (zMargin)+(2*(int)zPointSize) - 10));

		// Set top left point to be used for Story Box automatic cursor advancement
		if (theApp.m_nStoryMoveCursorBox == 0 && ly == 0) {
			CPoint cpMouse(zPos.x, zPos.y);
			int nMode = pDC->GetMapMode();
			pDC->LPtoDP(&cpMouse);
			StoryCursorMousePos.x = cpMouse.x;
			StoryCursorMousePos.y = cpMouse.y;
		}
	}

	if (!nDot2Dot) {		// Need to do this here
		return TRUE;		// so normal text is erased properly.
	}
	if (tempGuideLinesOff == TRUE) {
		return TRUE;
	}

	float upem = 2048.00;
	float points = zPointSize;

	float points_per_inch = 72.00;
	// Equation from page 4 of 40 in the Apple's Font Engine reference
	float scale = ( points * (float)PIXELS_PER_INCH ) 
		/ ( points_per_inch * upem );

	float maxy_em = 1836 - 336;
	//float maxx_em = 2048;

	//int maxx = (int)(maxx_em * scale);
	int maxy = (int)(maxy_em * scale);

	unsigned long topColor = myFontInfo.f_TopColor;
	unsigned long midColor = myFontInfo.f_MidColor;
	unsigned long basColor = myFontInfo.f_BasColor;
	unsigned long botColor = myFontInfo.f_BotColor;

	if (inDialogDisplay) {	// only use these in demo mode / from dialogs
		topColor = ColorGuidelineTop;
		midColor = ColorGuidelineMiddle;
		basColor = ColorGuidelineBase;
		botColor = ColorGuidelineBottom;
	}

	if (IsShadingOnTopArea) {
		unsigned long shadeTopAreaColor = ColorTopAreaShading;

		shadeTopAreaColor = pDC->GetNearestColor(ColorTopAreaShading);	// See what color we get
		if (shadeTopAreaColor == RGB(255,255,255)) {	// If it goes white
			shadeTopAreaColor = RGB(200,200,200);		// make it gray
		}
		CBrush shadeTopAreaPen(shadeTopAreaColor);
		pDC->SelectObject(&shadeTopAreaPen);

		// Doing the Top area (area above the midline)
		pDC->Rectangle(CRect( 
			zPos.x,
			(zPos.y),
			wd,
			zPos.y - (maxy/2)- LedgerPenTopWidth )); 
	}
	if (IsShadingOnMiddleArea) { // Shading the Middle area (below midline) using the chosen color
		unsigned long shadeMiddleAreaColor = ColorMiddleAreaShading;

		shadeMiddleAreaColor = pDC->GetNearestColor(shadeMiddleAreaColor);	// See what color we get
		if (shadeMiddleAreaColor == RGB(255,255,255)) {	// If it goes white
			shadeMiddleAreaColor = RGB(200,200,200);		// make it gray
		}
		CBrush shadeMiddleAreaPen(shadeMiddleAreaColor);
		pDC->SelectObject(&shadeMiddleAreaPen);

		// Doing the Middle area (area below the midline)
		pDC->Rectangle(CRect( 
			zPos.x,
			(zPos.y - (int)(maxy/2)),
			wd,
			zPos.y - maxy - 20 - LedgerPenMidWidth)); 
	}
	if (IsShadingOnDescenderArea) { // Shading the descender area using the chosen color
		unsigned long shadeDescenderAreaColor = ColorDescenderAreaShading;

		shadeDescenderAreaColor = pDC->GetNearestColor(shadeDescenderAreaColor);	// See what color we get
		if (shadeDescenderAreaColor == RGB(255,255,255)) {	// If it goes white
			shadeDescenderAreaColor = RGB(200,200,200);		// make it gray
		}
		CBrush shadeDescenderAreaPen(shadeDescenderAreaColor);
		pDC->SelectObject(&shadeDescenderAreaPen);
		// Doing the descender 
		pDC->Rectangle(CRect( 
			zPos.x,
			zPos.y - maxy - 20 - LedgerPenBotWidth,
			wd,
			(zPos.y - maxy - ((int)((float)mDescender*scale)) - 20))
			);
	}

	int doY, doDot, x, y;
	CPen topPen, midPen, basPen, botPen;

	for(x=0, y = 1; x< 4; x++, y = y * 2) {
		if (!(nDot2DotLinesButton & y)) {
			continue;	/* no line defined */
		}
		switch(y) {
		default:
		case SWLINE_TOP:
			doY = zPos.y + 20;
			topPen.CreatePen(PS_SOLID, LedgerPenTopWidth, topColor);
			doDot = myFontInfo.f_TopLine & SWLINE_DOT;
			pDC->SelectObject(&topPen);
			break;
		case SWLINE_MID:
			doY = zPos.y - (int)(maxy/2);
			midPen.CreatePen(PS_SOLID, LedgerPenMidWidth, midColor);
			doDot = myFontInfo.f_MidLine & SWLINE_DOT;
			pDC->SelectObject(&midPen);
			break;
		case SWLINE_BAS:
			doY = zPos.y - (int)(maxy) - 20;
			basPen.CreatePen(PS_SOLID, LedgerPenBasWidth, basColor);
			doDot = myFontInfo.f_BasLine & SWLINE_DOT;
			pDC->SelectObject(&basPen);
			break;
		case SWLINE_BOT:
			doY = zPos.y - maxy - ((int)((float)mDescender*scale)) - 20;
			botPen.CreatePen(PS_SOLID, LedgerPenBotWidth, botColor);
			doDot = myFontInfo.f_BotLine & SWLINE_DOT;
			pDC->SelectObject(&botPen);
			break;
		}

		if (doDot) {
			// Draws dashed line with 100 pixel line & 100 pixel space
			for( int len=100, dx = startX; dx < wd; dx += 200) {
				if (dx+100 > wd) {
					len = 100 - (dx+100 - wd);	// don't go beyond end of box
				}
				if (dx >= zPos.x) {		// Just so the red line stays the same with cursive method
					pDC->MoveTo(dx, doY);   
					pDC->LineTo(dx + len, doY);
				}
			}
		}
		else {
			pDC->MoveTo( zPos.x, doY);
			pDC->LineTo( wd, doY);
		}
	}
	pDC->SelectObject(oldpen);
	if (nDot2DotLinesButton & SWLINE_TOP)
		topPen.DeleteObject();
	if (nDot2DotLinesButton & SWLINE_MID)
		midPen.DeleteObject();
	if (nDot2DotLinesButton & SWLINE_BAS)
		basPen.DeleteObject();
	if (nDot2DotLinesButton & SWLINE_BOT)
		botPen.DeleteObject();

	return TRUE;
}

int density=1;

int TextItem::GetCharacterWidth( CDC *pDC, unsigned short *c, unsigned short *nc, int lx, int ly, int *status)
{
#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TextItem::GetCharacterWidth(CDC,char*,int*)"); 
#endif
	int glyfPos;

	int width = -1;
	if ((nDot2Dot == TRUE) && (!isMathFont2 || (isMathFont2 && !(IS_ALPHA(*c))))) {
		if( nGlyfArrayIndex >= 0 && nGlyfArrayIndex < MAX_GLYF_ARRAY ) {
			int j = 0;
			int newx, newy, maxp;
			float upem;// = 2048.00;
			float points;// = zPointSize;
			float points_per_inch;// = 72.00;
			// Equation from page 4 of 40 in the Apple's Font Engine reference
			float scale = 0.0;//  = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );

			UShort cleft = *c;
			UShort cright = *nc;
			int kernval = 0;
			// wrw this following test also had "if incursive"
			if (doKerning && IS_KERNABLE(cright) && IS_KERNABLE(cleft)) {
				kernval = (int) Dot2DotFont.GetKern(cleft, cright);
			}
			int drawThing;
			nDot2DotGlyfDensity = DensityFormatArray[nGlyfArrayIndex];

			if (nDot2DotGlyfDensity == kDotDens100) { 
				drawThing = 1;
			}
			else if( nDot2DotGlyfDensity == kDotDens25) {
				drawThing = 8;		// 10
			}
			else if ( nDot2DotGlyfDensity == kDotDens50) {
				drawThing = 7;		// 7
			}
			else if ( nDot2DotGlyfDensity == kDotDens00) {
				drawThing = 1;		// This would be zero, but we ned calculations
			}
			else /*if( nDot2DotGlyfDensity == kDotDens75) */ {
				drawThing = 5;		// 5
			}
			//drawThing = density;

			if ((CharArray[(glyfPos = getGlyfPos(*c))].charVal == 0) || ((*swType == swSHR) && (*c == '\''))) {

				upem = 2048.00;
				points = zPointSize;
				points_per_inch = 72.00;
				// Equation from page 4 of 40 in the Apple's Font Engine reference
				scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );

				/* Reset this data too */
				GlyfArray[nGlyfArrayIndex].releaseSegmentData();

				if (Dot2DotFont.GetGlyfData( &GlyfArray[nGlyfArrayIndex], c) == ERROR) {
					*status = ERROR;
					return(0);
				}

				CharArray[glyfPos].charVal = *c;

				if (*c != ' ') {

					GlyfArray[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

					maxp = GlyfArray[nGlyfArrayIndex].GetMaxPoints();

					for( j = 0; j < maxp; ++j) {
						newx = (int)(GlyfArray[nGlyfArrayIndex].GetX(j) * scale);
						newy = (int)(GlyfArray[nGlyfArrayIndex].GetY(j) * scale);
						GlyfArray[nGlyfArrayIndex].SetX( j, newx);
						GlyfArray[nGlyfArrayIndex].SetY( j, newy);
					}

					width = ((int)( GlyfArray[nGlyfArrayIndex].GetXMax() * scale));
					//if (!IS_APOST(*c)) {	// we need apostrophe to be short as possible
					if (!(*c == '\'') || (*swType == swSHR)) {	// we need apostrophe to be short as possible
						width += (int)( nLetterSpacing * scale);
					}
					else { //LWRWif (!inCursive) { // *c == '\''
						width += (int)(( nLetterSpacing * scale) / 2);
					}
				}
				else {
					// Set the space width
					width = (int) (spaceWidth * scale);
				}

				// We need to add some space after the hyphen in cursive
				if (inCursive) {
					if (*c == '-') {
						width += (width/4);
					}
					else if (*c == '.') {
						width *= 2;
					}
				}
				if ((*swType == swSHR) && (*c == '\'')) {
					if (apos_wid2 && (IS_UPPER(*nc))) {
						width *= (apos_wid+apos_wid2);
					}
					else {
						width *= (apos_wid);
					}
				}

				GlyfArray[nGlyfArrayIndex].CreateGlyf();

				GlyfArray[nGlyfArrayIndex].SetDots(drawThing, MAKESOLID(*c) ? true : false);


				CharArray[glyfPos].width = width;
				if (*c != ' ') {
					GlyfArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].CharData);
				}
				else {
					GlyfArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].CharData);
					CharArray[glyfPos].CharData.SetXMax(spaceWidth);	// Set space width here 
				}
			}
			else {
				// Copy the data into the needed array
				CharArray[glyfPos].CharData.SetDots(drawThing, MAKESOLID(*c) ? true : false);		/* make sure the dots are right */

				CharArray[glyfPos].CharData.Copy(&GlyfArray[nGlyfArrayIndex]);

				width = CharArray[glyfPos].width;

			}

			// Arrows
			if( (ArrowFont.isOpen == true) && (ArrowsFormatArray[nGlyfArrayIndex] == 2)) {
				if (CharArray[glyfPos].arrowFlag == 0) {
					if (scale == 0.0) {
						upem = 2048.00;
						points = zPointSize;
						points_per_inch = 72.00;
						// Equation from page 4 of 40 in the Apple's Font Engine reference
						scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
					}

					ArrowArray[nGlyfArrayIndex].releaseSegmentData();

					// Build the arrows for this character
					if (ArrowFont.GetGlyfData( &ArrowArray[nGlyfArrayIndex], c) == ERROR) {
						/* We didn't get the data, so just clear the data so we don't get bad stuff */
						ArrowArray[nGlyfArrayIndex].ClearData();						
					}
					else {
						ArrowArray[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

						maxp = ArrowArray[nGlyfArrayIndex].GetMaxPoints();

						for( j = 0; j < maxp; ++j) 	{
							newx = (int)(ArrowArray[nGlyfArrayIndex].GetX(j) * scale);
							newy = (int)(ArrowArray[nGlyfArrayIndex].GetY(j) * scale);
							ArrowArray[nGlyfArrayIndex].SetX( j, newx);
							ArrowArray[nGlyfArrayIndex].SetY( j, newy);
						}
					}
					ArrowArray[nGlyfArrayIndex].CreateGlyf();
					ArrowArray[nGlyfArrayIndex].SetDots(1, MAKESOLID(*c) ? true : false);

					ArrowArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].ArrowData);
					CharArray[glyfPos].arrowFlag = 1;
				}
				else {
					CharArray[glyfPos].ArrowData.Copy(&ArrowArray[nGlyfArrayIndex]);
				}
			}

			// ConnectTheDots
			if( (ConnectTheDotsFont.isOpen == true) && (ConnectTheDotsFormatArray[nGlyfArrayIndex] == 2)) {
				if (CharArray[glyfPos].connectTheDotsFlag == 0) {
					if (scale == 0.0) {
						upem = 2048.00;
						points = zPointSize;
						points_per_inch = 72.00;
						// Equation from page 4 of 40 in the Apple's Font Engine reference
						scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
					}

					ConnectTheDotsArray[nGlyfArrayIndex].releaseSegmentData();

					// Build the ConnectTheDots for this character
					if (ConnectTheDotsFont.GetGlyfData( &ConnectTheDotsArray[nGlyfArrayIndex], c) == ERROR) {
						/* We didn't get the data, so just clear the data so we don't get bad stuff */
						ConnectTheDotsArray[nGlyfArrayIndex].ClearData();						
					}
					else {
						ConnectTheDotsArray[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

						maxp = ConnectTheDotsArray[nGlyfArrayIndex].GetMaxPoints();

						for( j = 0; j < maxp; ++j) 	{
							newx = (int)(ConnectTheDotsArray[nGlyfArrayIndex].GetX(j) * scale);
							newy = (int)(ConnectTheDotsArray[nGlyfArrayIndex].GetY(j) * scale);
							ConnectTheDotsArray[nGlyfArrayIndex].SetX( j, newx);
							ConnectTheDotsArray[nGlyfArrayIndex].SetY( j, newy);
						}
					}
					ConnectTheDotsArray[nGlyfArrayIndex].CreateGlyf();
					ConnectTheDotsArray[nGlyfArrayIndex].SetDots(1, MAKESOLID(*c) ? true : false);

					ConnectTheDotsArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].ConnectTheDotsData);
					CharArray[glyfPos].connectTheDotsFlag = 1;
				}
				else {
					CharArray[glyfPos].ConnectTheDotsData.Copy(&ConnectTheDotsArray[nGlyfArrayIndex]);
				}
			}

			// Overlay
			if( (OverlayFont.isOpen == true) && (OverlayFormatArray[nGlyfArrayIndex] == 2)) {
				if (CharArray[glyfPos].overlayFlag == 0) {
					if (scale == 0.0) {
						upem = 2048.00;
						points = zPointSize;
						points_per_inch = 72.00;
						// Equation from page 4 of 40 in the Apple's Font Engine reference
						scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
					}

					OverlayArray[nGlyfArrayIndex].releaseSegmentData();

					// Build the Overlays for this character
					if (OverlayFont.GetGlyfData( &OverlayArray[nGlyfArrayIndex], c) == ERROR) {
						/* We didn't get the data, so just clear the data so we don't get bad stuff */
						OverlayArray[nGlyfArrayIndex].ClearData();						
					}
					else {
						OverlayArray[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

						maxp = OverlayArray[nGlyfArrayIndex].GetMaxPoints();

						for( j = 0; j < maxp; ++j) 	{
							newx = (int)(OverlayArray[nGlyfArrayIndex].GetX(j) * scale);
							newy = (int)(OverlayArray[nGlyfArrayIndex].GetY(j) * scale);
							OverlayArray[nGlyfArrayIndex].SetX( j, newx);
							OverlayArray[nGlyfArrayIndex].SetY( j, newy);
						}
					}
					OverlayArray[nGlyfArrayIndex].CreateGlyf();
					OverlayArray[nGlyfArrayIndex].SetDots(1, MAKESOLID(*c) ? true : false);

					OverlayArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].OverlayData);
					CharArray[glyfPos].overlayFlag = 1;
				}
				else {
					CharArray[glyfPos].OverlayData.Copy(&OverlayArray[nGlyfArrayIndex]);
				}
			}
			// FSFonts
			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
				if( (fsData[fsi].TTFontFS.isOpen == true) && (fsData[fsi].ArrayInfoFS[nGlyfArrayIndex] == 2)) {
					if (CharArray[glyfPos].fsFlag[fsi] == 0) {
						if (scale == 0.0) {
							upem = 2048.00;
							points = zPointSize;
							points_per_inch = 72.00;
							// Equation from page 4 of 40 in the Apple's Font Engine reference
							scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
						}

						if (fsi < STROKE_COUNT) {
							// dotted fonts could be changing
							fsData[fsi].ArrayFontFS[nGlyfArrayIndex].releaseSegmentData();
						}

						// Build the FSFonts for this character
						if (fsData[fsi].TTFontFS.GetGlyfData( &fsData[fsi].ArrayFontFS[nGlyfArrayIndex], c) == ERROR) {
							/* We didn't get the data, so just clear the data so we don't get bad stuff */
							fsData[fsi].ArrayFontFS[nGlyfArrayIndex].ClearData();						
						}
						else {
							fsData[fsi].ArrayFontFS[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

							maxp = fsData[fsi].ArrayFontFS[nGlyfArrayIndex].GetMaxPoints();

							for( j = 0; j < maxp; ++j) 	{
								newx = (int)(fsData[fsi].ArrayFontFS[nGlyfArrayIndex].GetX(j) * scale);
								newy = (int)(fsData[fsi].ArrayFontFS[nGlyfArrayIndex].GetY(j) * scale);
								fsData[fsi].ArrayFontFS[nGlyfArrayIndex].SetX( j, newx);
								fsData[fsi].ArrayFontFS[nGlyfArrayIndex].SetY( j, newy);
							}
						}
						if (fsi < STROKE_COUNT) {
							// create them
							fsData[fsi].ArrayFontFS[nGlyfArrayIndex].CreateGlyf();
							fsData[fsi].ArrayFontFS[nGlyfArrayIndex].SetDots(drawThing, MAKESOLID(*c) ? true : false);
						}
						fsData[fsi].ArrayFontFS[nGlyfArrayIndex].Copy(&CharArray[glyfPos].DataFS[fsi]);
						CharArray[glyfPos].fsFlag[fsi] = 1;
					}
					else {
						//fsData[fsi].ArrayFontFS[nGlyfArrayIndex].SetDots(drawThing, MAKESOLID(*c) ? true : false);
						CharArray[glyfPos].DataFS[fsi].SetDots(drawThing, MAKESOLID(*c) ? true : false);
						//fsData[fsi].ArrayFontFS[nGlyfArrayIndex].Copy(&CharArray[glyfPos].DataFS[fsi]);
						CharArray[glyfPos].DataFS[fsi].Copy(&fsData[fsi].ArrayFontFS[nGlyfArrayIndex]);
						
						//CharArray[glyfPos].CharData.SetDots(drawThing, MAKESOLID(*c) ? true : false);		/* make sure the dots are right */
						//CharArray[glyfPos].CharData.Copy(&GlyfArray[nGlyfArrayIndex]);
					}
				}
				else {
					fsData[fsi].nDot2DotFS = false;
				}
			}
			///// StartDot Stuff
#ifdef SW50
			if( (StartDotFont.isOpen == true) && (StartDotFormatArray[nGlyfArrayIndex] == 2)) {

				if (CharArray[glyfPos].dotFlag == 0) {
					if (scale == 0.0) {
						upem = 2048.00;
						points = zPointSize;
						points_per_inch = 72.00;
						// Equation from page 4 of 40 in the Apple's Font Engine reference
						scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
					}

					// Build the start dot for this character
					if (StartDotFont.GetGlyfData( &StartDotArray[nGlyfArrayIndex], c) == ERROR) {
						/* We didn't get the data, so just clear the data so we don't get bad stuff */
						StartDotArray[nGlyfArrayIndex].ClearData();						
					}
					else {
						StartDotArray[nGlyfArrayIndex].MakeGlyfPointsAbsolute();

						maxp = StartDotArray[nGlyfArrayIndex].GetMaxPoints();

						for( j = 0; j < maxp; ++j) 	{
							newx = (int)(StartDotArray[nGlyfArrayIndex].GetX(j) * scale);
							newy = (int)(StartDotArray[nGlyfArrayIndex].GetY(j) * scale);
							StartDotArray[nGlyfArrayIndex].SetX( j, newx);
							StartDotArray[nGlyfArrayIndex].SetY( j, newy);
						}
					}

					StartDotArray[nGlyfArrayIndex].Copy(&CharArray[glyfPos].DotData);
					CharArray[glyfPos].dotFlag = 1;
				}
				else {
					CharArray[glyfPos].DotData.Copy(&StartDotArray[nGlyfArrayIndex]);
				}
			}
#endif
			/////////////////

			*status = OK;

			if (kernval) {
				if (scale == 0.0) {
					upem = 2048.00;
					points = zPointSize;
					points_per_inch = 72.00;
					// Equation from page 4 of 40 in the Apple's Font Engine reference
					scale = ( points * (float)PIXELS_PER_INCH ) / ( points_per_inch * upem );
				}
				width = width + (int)(kernval * scale);
			}
		}
		else
		{
			*status = ERROR;
		}


	}
	else {
		if (CharArray[(glyfPos = getGlyfPos(*c))].charVal == 0) {
			CharArray[glyfPos].charVal = *c;
			pDC->GetCharWidth( *c, *c, &width);
			CharArray[glyfPos].width = width;
			if (isMathFont) {
				CharArray[glyfPos].mathFlag = 1;
			}
		}
		else {
			width = CharArray[glyfPos].width;
		}

		*status = OK;
	}

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::GetCharacterWidth: %d", &width); 
#endif

	return width;
}

void TextItem::DrawTextString( CDC* pDC, int x, int y, CWordArray *cstring, int *status, 
							  bool bEntireString /* = TRUE */ , CPoint zSize, int strCnt, int TextY, int lx, int ly)
{
	if (theApp.m_bInStoryDistributeMode) return;
	//	int saveY = y;
	int sizeX = cstring->GetSize();
	int nCharsToDo = strCnt,
		nCharsDone = 0,
		prevChar = 0,
		charWidth;

	zSize;	// no longer used?

	if (((cstring->GetAt(0) == 0x20) && (sizeX > 1) && (cstring->GetAt(1) == 0)) || (cstring->GetAt(0) == 0))
		return; 

	if ((cstring->GetAt(0) < 0x20) && (cstring->GetAt(0) >= 0)) {
		TextY;	// rid compiler warning
		return;
	}

#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TextItem::DrawTextString(CDC*,int,int,CString,int*)"); 
#endif

	*status = ERROR;


	if( nGlyfArrayIndex >= 0 && nGlyfArrayIndex < MAX_GLYF_ARRAY )
	{
		float upem = 2048.00;

		float points = zPointSize;

		float points_per_inch = 72.00;

		// Equation from page 4 of 40 in the Apple's Font Engine reference
		float scale = ( points * (float)PIXELS_PER_INCH ) 
			/ ( points_per_inch * upem );

		float maxy_em = 1836 - 336;
		//float maxx_em = 2048;

		//int maxx = (int)(maxx_em * scale);
		int maxy = (int)(maxy_em * scale);

		y = y + (sign*maxy);

		for (int i = bEntireString ? 0 : nGlyfArrayIndex - 1; 
			(i >= 0) && (i <= nGlyfArrayIndex) && nCharsToDo || (nCharsDone == nCharsToDo); i++, nCharsDone++)
		{
			//Trace("i = %d, len = %d, todo = %d", i, cstring.GetLength(), nCharsToDo);
			if (strCnt /*cstring->GetSize()*/ <= nCharsDone)
				break;

#ifdef LATER_WRW
			if ((i < sizeX) && isMathFont2 && ((cstring->GetAt(i) < '0') || (cstring->GetAt(i) > '9'))) {
				CString str;
				str = (char) cstring->GetAt(i);

				if (str.IsEmpty() == false) {
					int c, width;
					pDC->TextOut( x, y+TextY, str);
					c = str.GetAt(0);
					pDC->GetCharWidth( c, c, &width);
					x += width;
				}
				continue;
			}
#endif

			nDrawingArrows = FALSE;
			nDrawingOverlay = false;
			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
				fsData[fsi].nDrawingFontFS  = false;
			}

			nDrawingStartDot = false;
			nDrawingConnectTheDots = false;
//			nDot2DotGlyfDensity = DensityFormatArray[i];
			nDot2DotGlyfShade = ShadeFormatArray[i];

			nSelected = SelectedArray[i];

			bool didColorStrokes = false;
			bool doDrawGlyf = DensityFormatArray[i] ? true : false;
			for(int fsi=0; doDrawGlyf && (fsi < STROKE_COUNT); fsi++) {
				if (fsData[fsi].ArrayInfoFS[i] == 2) {
					fsData[fsi].nDrawingFontFS = true;
					DrawGlyf( pDC, &fsData[fsi].ArrayFontFS[i], CPoint(x,y), fsi);
					didColorStrokes =true;
				}
			}
			if (doDrawGlyf && !didColorStrokes) {
				DrawGlyf( pDC, &GlyfArray[i], CPoint(x,y));
			}
			
			if(ArrowsFormatArray[i] == 2) {
				nDrawingArrows = true;
				DrawGlyf( pDC, &ArrowArray[i], CPoint(x,y));
				nDrawingArrows = false;
			}
			if (ConnectTheDotsFormatArray[i] == 2) {
				nDrawingConnectTheDots = true;
				DrawGlyf( pDC, &ConnectTheDotsArray[i], CPoint(x,y));
				nDrawingConnectTheDots = false;
			}
			if(OverlayFormatArray[i] == 2) {
				nDrawingOverlay = true;
				DrawGlyf( pDC, &OverlayArray[i], CPoint(x,y));
				nDrawingOverlay = false;
			}
			if (fsData[DECISN_DOT_IND].ArrayInfoFS[i] == 2) {
				fsData[DECISN_DOT_IND].nDrawingFontFS = true;
				DrawStartDot( pDC, &fsData[DECISN_DOT_IND].ArrayFontFS[i], CPoint(x,y), true);
			}

			if ((StartDotFont.isOpen == true) && (StartDotFormatArray[i] == 2)) {
				nDrawingStartDot = true;
				DrawStartDot( pDC, &StartDotArray[i], CPoint(x,y), false);
				nDrawingStartDot = false;
			}

			charWidth = ((int)( GlyfArray[i].GetXMax() * scale));
			if (i < sizeX) {
				int newChar;
				charWidth += (int)(nLetterSpacing * scale);
				newChar = cstring->GetAt(i);
				if (newChar == '-') {
					charWidth += (charWidth / 4);
				}
				else if (inCursive && (newChar == '.')) {
					charWidth *= 2;
				}
				else if (IS_APOST(newChar)) {
					if (!inCursive) {
						// Give apostrophe some width in non cursive
						// subtract back out half the value we added
						charWidth -= (int)((nLetterSpacing * scale) / 2);
					}
					else if (i < (sizeX-1)) {	// as long as it is not the last char
						UShort cright = cstring->GetAt(i+1);
						if (IS_KERNABLE(prevChar) && IS_KERNABLE(cright)) {
							charWidth = 0;
						}
					}
				}
				else if ((*swType == swSHR) && (newChar == '\'')) {
					UShort cright;
					cright = (unsigned short)((i < (sizeX-1)) ? cstring->GetAt(i+1) : 0);

					if (apos_wid2 && (IS_UPPER(cright))) {
						charWidth *= (apos_wid+apos_wid2);
					}
					else {
						charWidth *= (apos_wid);
					}
				}
				if (inCursive && (!IS_APOST(newChar))) {
					prevChar = (i < sizeX) ? newChar : 0;
				}
				StoryFlowOutState = STORY_FLOW_INSERT;
			}
			if (i >= sizeX && (StoryNumber > 0 && !StoryLinesChanged && !IsLastItemInStory || StoryBoxFull)) {
				int pushChar = cstring->GetAt(i);
				unsigned char nText = (unsigned char)(TxtShapes[ly][lx + i] < SHAPE_EXTENDED ? (unsigned char)pushChar : (unsigned char)pushChar - SHAPES_START_EXTENDED);
				theApp.m_strStoryOverflowText += nText;
				theApp.m_strStoryOverflowShapes += TxtShapes[ly][lx + i];
				StoryBoxFull = TRUE;
				theApp.m_iStoryOverflowDirection = 1;
				theApp.m_iStoryOverflowBox = StoryItemOrder + 1;
			}

			if (doKerning && (i < (sizeX-1))) {
				UShort cleft = cstring->GetAt(i);
				UShort cright = cstring->GetAt(i+1);
				if ((IS_APOST(cleft)) && i)
					cleft = cstring->GetAt(i-1);

				// This test alos had if inCursive
				if (IS_KERNABLE(cright) && IS_KERNABLE(cleft)) {
					int kernval = (int) Dot2DotFont.GetKern(cleft, cright);
					if (kernval) {
						charWidth = charWidth + (int)(kernval * scale);
					}
				}
			}

			// Underline
			//			if (UnderlineArray[i]) {
			//				zSize.x = charWidth;
			//				DrawUnderline( pDC, CPoint(x, saveY), zSize);
			//			}
			// End Underline
			x += charWidth;

		}
	}

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::DrawTextString(CDC*,int,int,CString,int*)"); 
#endif
}
void TextItem::DrawEllipse(CDC *pDC, GlyfData *pGD, int dotIndex, CPoint zPt)
{
	int x1, x2;//, x3, x4;
	int y1, y2;//, y3, y4;
	int x3, y3;
	double hLen;
	int spanVal; // = (int)((float)100 * scale);

	x1 = pGD->GetX(dotIndex) + zPt.x;
	x2 = pGD->GetX(dotIndex+1) + zPt.x;

	y1 = pGD->GetY(dotIndex) + zPt.y;
	y2 = pGD->GetY(dotIndex+1) + zPt.y;

	// Calculate the length of the line for the dot
	x3 = (x1 > x2) ? x1 - x2 : x2 - x1;
	y3 = (y1 > y2) ? y1 - y2 : y2 - y1;
	hLen = (double)(((double)x3*(double)x3) + ((double)y3*(double)y3));
	hLen = sqrt(hLen);
	//if (zPointSize > 72) {
	if (nPointSize > 100) {
		spanVal = (int) (hLen / 3); // * scale / 2.0);
	}
	else if (nPointSize >= 48) {
		spanVal = (int) (hLen / 2); // * scale / 2.0);
	}
	else {
		spanVal = (int) (hLen); // * scale / 2.0);
	}
	if (spanVal == 0) {
		spanVal = 100;
	}

	x1 = (x1 + x2) / 2;
	y1 = (y1 + y2) / 2;


	x2 = x1 + spanVal;
	x1 = x1 - spanVal;

	y2 = y1 + spanVal;
	y1 = y1 - spanVal;

	pDC->Ellipse( x1, y1, x2, y2);	
}

#ifdef SW50
int TextItem::DrawStartDot(CDC *pDC, GlyfData *pGD, CPoint zPt, bool doDecisionDots)
{
	CPen m_Pen;
	int dotIndex;
	unsigned long ncolor;

	// Draws filled circles at points
	int numcontours = pGD->GetNumberOfContours();

	// Don't draw if there are no contours...
	if( numcontours <= 0 ) { 
		return OK;
	}
	int MaxPoints = pGD->GetMaxPoints();

	if (MaxPoints < 2) {
		return OK;
	}

	if (doDecisionDots == false) {
		m_Pen.CreatePen( PS_SOLID, 25, ColorStartingDot);	// User-selected color or default=Red for Startdot
		ncolor = ColorStartingDot; // RGB(255,0,0);	// make selection override- red
	}
	else {
		m_Pen.CreatePen( PS_SOLID, 25, ColorDecisionDots);	// User-selected color or default=Orange For Decision Dots
		ncolor = ColorDecisionDots; //RGB(25,25,255);	// make selection override- red
	}
	CPen *old_pen = pDC->SelectObject(&m_Pen) ;
	CBrush redPen(ncolor);	// this fills the circle
	pDC->SelectObject(&redPen);

	for (dotIndex = 0; (dotIndex+1) < MaxPoints; dotIndex += 2) {
		DrawEllipse(pDC, pGD, dotIndex, zPt);
	}
	// Restore pen
	if (old_pen != NULL) 
		pDC->SelectObject(old_pen);

	return OK;
}
#endif

//int shadingValue=0;
//int thickness=2;
// fsIndex is -1 by default 0-4 for colored strokes
int TextItem::DrawGlyf(CDC *pDC, GlyfData *pGD, CPoint zPt, int fsIndex)
{
	int shade_type;

	unsigned long ncolor;
	unsigned long ncolor2;
	static int typeCnt;
	
	if (pGD->GetMaxPoints() == 0) {
		return(0);
	}

	int pen_width = nPenWidth;

	if (nSelected) {
		ncolor = RGB(255,0,0);	// make selection override- red
	}
	else {
		if(nDrawingArrows == TRUE) {
			ncolor = ColorStrokeArrows;
		}
		else if (nDrawingOverlay == TRUE) {
			ncolor = ColorOutlineOverlay;
		}
		else if (nDrawingConnectTheDots == TRUE) {
			ncolor = ColorConnectTheDots;
		}
		else if( nDot2DotGlyfShade == 1 ) {
			ncolor = RGB(192,192,192);
			pen_width = 2;
		}
		else if( nDot2DotGlyfShade == 2 ) {
			ncolor = RGB(128,128,128);
			pen_width = 8;
		}
		else if( nDot2DotGlyfShade == 3 ) {
			ncolor = RGB(64,64,64);
			pen_width = 16;
		}
		else {
			ncolor = RGB(0,0,0);
		}
		pen_width = 32;
		
		
		bool doColors =true;
	
		unsigned long solidGray=RGB(0,0,0);
		unsigned long darkGray=RGB(100,100,100);
		unsigned long midGray=RGB(150,150,150);
		unsigned long lightGray=RGB(200,200,200);

		if (doColors == false) {
			switch(nDot2DotGlyfShade) {
			default:
			case 0: 
				solidGray=RGB(0,0,0);
				darkGray=RGB(100,100,100);
				midGray=RGB(150,150,150);
				lightGray=RGB(200,200,200);
				break;
			case 3: 
				solidGray=RGB(75,75,75);
				darkGray=RGB(125,125,125);
				midGray=RGB(175,175,175);
				lightGray=RGB(225,225,225);
				break;
			case 2: 
				solidGray=RGB(150,150,150);
				darkGray=RGB(200,200,200);
				midGray=RGB(225,225,225);
				lightGray=RGB(240,240,240);
				break;
			case 1: 
				solidGray=RGB(200,200,200);
				darkGray=RGB(225,225,225);
				midGray=RGB(235,235,235);
				lightGray=RGB(245,245,245);
				break;
			}
		}


		switch (fsIndex) {
		case STROKE_ONE_IND:
			switch(nDot2DotGlyfShade) {//wrwwork
			case 1: ncolor = (doColors ? RGB(185,185, 255) : solidGray); break;
			case 2: ncolor = (doColors ? RGB(133,133, 255) : solidGray); break;
			case 3: ncolor = (doColors ? RGB(75,75, 255) :solidGray); break;
			//!!!default: ncolor = (doColors ? RGB(0,0,255) : solidGray); break;
			default: ncolor = (doColors ? ColorFirstStrokeLetters : solidGray); break;
			}
			break;
		case STROKE_TWO_IND: 
			switch(nDot2DotGlyfShade) {
			case 1: ncolor = (doColors ? RGB(255,190, 190) : darkGray); break;
			case 2: ncolor = (doColors ? RGB(255,125, 125) : darkGray); break;
			case 3: ncolor = (doColors ? RGB(255,60, 00) : darkGray); break;
			//!!!default: ncolor = (doColors ? RGB(255,0,0) : darkGray); break;
			default: ncolor = (doColors ? ColorSecondStrokeLetters : darkGray); break;
			}
			//ncolor = RGB(255,0,0); 
			break;
		case STROKE_THR_IND: 
			switch(nDot2DotGlyfShade) {
			case 1: ncolor = (doColors ? RGB(175,255, 175) : midGray); break;
			case 2: ncolor = (doColors ? RGB(100,230, 100) : midGray); break;
			case 3: ncolor = (doColors ? RGB(50,230, 50) : midGray); break;
			//!!!default: ncolor = (doColors ? RGB(0,255,0) : midGray); break;
			default: ncolor = (doColors ? ColorThirdStrokeLetters : midGray); break;
			}
			//ncolor = RGB(0,255,0); 
			break;
		case STROKE_FOR_IND: 
			switch(nDot2DotGlyfShade) {
			case 1: ncolor = (doColors ? RGB(255,160, 255) : lightGray); break;
			case 2: ncolor = (doColors ? RGB(255,75, 255) : lightGray); break;
			case 3: ncolor = (doColors ? RGB(200,0, 200) : lightGray); break;
			//!!!default: ncolor = (doColors ? RGB(255,0,255) : lightGray); break;
			default: ncolor = (doColors ? ColorFourthStrokeLetters : lightGray); break;
			}
			//ncolor = RGB(255,0,255); 
			break;
		}

//		ncolor = RGB(shadingValue,shadingValue,shadingValue);
//		pen_width = thickness;
//		nPenWidth = thickness;	// TEMP
	}
		// Since some printers do not seem to do grayscale for colors
		// we need to change the width of the pen.  But for display, we need
		// to see the characters, so use the thicker pen for display

		if (!pDC->IsPrinting()) {
			pen_width = nPenWidth;	// display uses full width
			//#pragma message ("Display Line width Change Made Here")
			if (theApp.m_doThick) {
				if (zPointSize > 32) {
					pen_width = (pen_width /* * lineWidthMult */ * 10) / 7;	/* make thick for larger chars */
				}
			}
		}
		else {
			if (ShadeType == SHADETYPE_NARROW) {
				ncolor = RGB(0,0,0);	// For printing we do black
			}
			else {
				pen_width = nPenWidth;	/* For printers that can do it */
				// One customer complained about the size here.  Keep the lines thin
				if (((theApp.m_doThick) || (*swType == swSHR)) && (zPointSize > 24)) {
					pen_width = (pen_width /* * lineWidthMult */ * 10) / 7;	/* make thick for larger chars */
				}
			}

			/* For printing we have always tested on 300 dpi.  Now we have to print on higher dpi */
			/* so increase the printing width */
			/* Sherston kind of asked for this then recanted */
			//if (iVal && (!inPrintPreview)) {
			//	pen_width = pen_width * iVal / 300;
			//}
		}

		if (ShadeType == SHADETYPE_NARROW) {
			// With PS_INSIDEFRAME, we get a dithered color, so this call is not necessary
			ncolor2 = pDC->GetNearestColor(ncolor);	// See what color we get
			if (ncolor2 == RGB(255,255,255)) {	// If we got white
				ncolor = RGB(0,0,0);			// force to black
			}		
		}

		// As the font gets smaller, we need to make the character lines thinner
		// Otherwise, the lines are too thick to read at the smaller size
		// This reduces the size by the (pointsize * 3)% so 24 => 72% of normal
		if (zPointSize < 33) {
			pen_width = (int)((float)pen_width * (zPointSize * 3) / (float)100.0);
			nArrowWidth =  (int)((float)DEF_ARROWWID * (zPointSize * 3) / (float)100.0);
		}

		// Change the width of the pen and color for arrows.
		if( nDrawingArrows == TRUE) { 
			if (nArrowWidth < pen_width) {	// make thickness no thicker than text
				pen_width = nArrowWidth;  
			}
		}
		if (nDrawingConnectTheDots) {
			if (nArrowWidth < pen_width) {	// make thickness no thicker than text
				pen_width = nArrowWidth;	// use the arrow width
			}
		}
		if( nDrawingOverlay == TRUE) { 
			if (nOverlayWidth < pen_width) {	// make thickness no thicker than text
				pen_width = nOverlayWidth;  
			}
		}

#if 0
		for(int fsi=0; fsi < STROKE_COUNT; fsi++) {
			if (fsData[fsi].nDrawingFontFS == TRUE) {
				if (fsData[fsi].nWidthFS < pen_width) {
					pen_width = fsData[fsi].nWidthFS;
				}
			}
		}
#endif
		if (ShadeType == SHADETYPE_NARROW) {
			shade_type = PS_SOLID ;
		}
		else {
			shade_type = PS_INSIDEFRAME;
		}
		shade_type |= (PS_GEOMETRIC | PS_JOIN_MITER | PS_ENDCAP_ROUND);	

		/* New method of display */
		LOGBRUSH    lb ;

		lb.lbStyle = BS_SOLID ;
		lb.lbColor = ncolor;
		lb.lbHatch = 0 ;
		CPen m_Pen ;
		m_Pen.CreatePen(shade_type, pen_width, &lb, 0, NULL);
		CPen *old_pen = pDC->SelectObject(&m_Pen);

		pDC->BeginPath();
		{
			int i;
			SEGMENT_DATA *tPtr;

			tPtr = pGD->segPtr;
			if (tPtr) {
				for(i=0; i < pGD->segCnt; i++) {
					if (tPtr->onFlag == true) {
						pDC->MoveTo(tPtr->bx+zPt.x,tPtr->by+zPt.y);
						pDC->LineTo(tPtr->ex+zPt.x,tPtr->ey+zPt.y);
					}
					tPtr++;
				}
			}
		}
		pDC->EndPath();
		pDC->StrokePath();

		// Restore pen
		if (old_pen != NULL) 
			pDC->SelectObject(old_pen);

		return OK;
}



int TextItem::BeginPreviousWord()
{
	CPoint cp = CursorIndex;
	int i;
	char ch;

	if (cp.x == 0) {
		return FALSE;
	}

	for(i=cp.x-1; i > 0; i--) {
		ch = TxtLines[cp.y][i];
		if (IS_ALPHANUMERIC(ch)) {
			break;
		}
	}
	for(; i > 0; i--) {
		ch = TxtLines[cp.y][i];
		if (IS_ALPHANUMERIC(ch)) {
			continue;
		}
		i++;
		break;
	}
	if (i == cp.x) {
		return FALSE;
	}

	cp.x = i;
	SetCursor(cp);
	return TRUE;
}

void TextItem::doCursorLeft(int doSetCursor, int *x, int *y)
{
	CPoint cp = CursorIndex;
	wchar_t testChar;

	if (cp.x == 0) {
		cp.y--;
		if (cp.y < 0) {
			cp.y = 0;
		}
		else {
			// If it is a hard return, just go in front of it.
			cp.x = TxtLines[cp.y].GetLength();
			if (cp.x == 1) {
				testChar = TxtAttrs[cp.y].GetAt(0);
				if ((testChar == DELCHAR) || (testChar == EOLHCHAR)) {
					cp.x = 0;
				}
			}
		}
	}
	else {
		cp.x--;
	}

	// Common event where moving left is still in array
	if (doSetCursor) {
		SetCursor(cp);
	}
	else {
		if (x != (int *)0)
			*x = cp.x;
		if (y != (int *)0)
			*y = cp.y;
	}

}

/*
;KeyDown
*/
int TextItem::KeyDown( int nchar, int *status)
{          
	bool doDispAll = false;
	bool incUndo=true;
	unsigned short delChar;
	bool selectOK=false;
	bool needReformat=false;

	keepBackspacePos = FALSE;

	if (StoryNumber > 0 && (nchar == 10 || nchar == 13)) {// Storyboxes can't handle CRLF
		nchar = 32;
	}

	if (*status == TEXT_EXTEND_SELECTION) {
		selectOK=true;
		if (SelectionOn == FALSE) {
			m_bSetSelCursor = 2;	// Need to set position
			SetCursor(CursorIndex);
			SelCursorPos = CursorDrawn;	// Set the selection base position
			SelectionOn = TRUE;		// and turn selection on
		}
		//m_bSetCursorToClicked = TRUE;
		//m_ptClicked = point;
		*status = TEXT_DRAW_SELECTION;
	}

	if (nchar == TEXT_CURSOR_WORDLEFT) { 	// Word left
		if (BeginPreviousWord() == TRUE) {
			*status = TEXT_DRAW_CURSOR;		// found it
		}
		else {
			nchar = TEXT_CURSOR_LEFT;		// hit beginning of line, just do a cursor left
		}
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_WORDRIGHT) {	// Word right
		(void) FindEndOfWord();					// Find end of current word
		if (FindBeginOfWord(0) == FALSE) {		// New word?
			nchar = TEXT_CURSOR_RIGHT;          // no, just do a cursor right to next line
		}
		else {
			*status = TEXT_DRAW_CURSOR;			// yes, found
		}
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_LEFT) {
		*status = TEXT_DRAW_CURSOR;
		doCursorLeft(TRUE, (int *)0, (int *)0);
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_RIGHT) {
		CPoint cp = CursorIndex;
		*status = TEXT_DRAW_CURSOR;

		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
		// Move one to the right
		cp.x++;
		if (cp.x > TxtLines[cp.y].GetLength()) {
			if (TxtLines[cp.y+1].IsEmpty()) {
				if (StoryNumber < 1 || IsLastItemInStory || !StoryBoxFull) {
					cp.x--;	// end of the road, just stay put
				}
				else {
					theApp.m_nStoryMoveCursorBox = StoryItemOrder + 1;
					theApp.m_nStoryMoveCursorIndex = 0;
				}
			}
			else {
				cp.x = 0;
				cp.y++;
			}
		}
		else if (cp.x == 1) {
			if (TxtAttrs[cp.y].GetAt(0) == DELCHAR) {
				if (TxtLines[cp.y+1].IsEmpty()) {
					cp.x = 0;
				}
				else {
					cp.x = 0;
					cp.y++;
				}
			}
			else if (TxtAttrs[cp.y].GetAt(0) == EOLHCHAR) {
				cp.x = 0;
				cp.y++;
			}
		}

		SetCursor(cp);

	}          
	else if (nchar == TEXT_CURSOR_UP) {
		CPoint cp = CursorIndex;

		if (cp.y > 0) {
			cp.y -= 1;

			if (cp.x > TxtLines[cp.y].GetLength()) {
				cp.x = TxtLines[cp.y].GetLength();
			}

			if (cp.x == 1) {
				if (TxtAttrs[cp.y].GetAt(0) == DELCHAR) {
					cp.x = 0;
				}
				else if (TxtAttrs[cp.y].GetAt(0) == EOLHCHAR) {
					cp.x = 0;
				}
			}

			SetCursor(cp);
		}                   

		*status = TEXT_DRAW_CURSOR;

		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_DOWN) {
		CPoint cp = CursorIndex;

		if (cp.y < MAX_TEXT_LINES - 1 && !(TxtLines[cp.y+1].IsEmpty())) {
			cp.y += 1;

			if (cp.x > TxtLines[cp.y].GetLength()) {
				cp.x = TxtLines[cp.y].GetLength();
			}

			SetCursor(cp);
		}

		*status = TEXT_DRAW_CURSOR;
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_HOME) {
		CPoint cp = CursorIndex;
		cp.x = 0;
		SetCursor(cp);
		*status = TEXT_DRAW_CURSOR;
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_GOTO_BEGIN) {
		SetCursor(CPoint(0,0));
		*status = TEXT_DRAW_CURSOR;
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_GOTO_END) {
		CPoint cp;
		int i;

		for(i=0; i < MAX_TEXT_LINES; i++) {
			if (TxtLines[i+1].IsEmpty()) {
				cp.y = i;
				break;
			}
		}
		cp.x = TxtLines[i].GetLength();
		SetCursor(cp);
		*status = TEXT_DRAW_CURSOR;
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_END) {
		CPoint cp = CursorIndex;
		cp.x = TxtLines[cp.y].GetLength();
		SetCursor(cp);
		*status = TEXT_DRAW_CURSOR;
		if (SelectionOn == TRUE) {
			if (!selectOK) {
				Message(TEXT_SELECTION_OFF, CPoint(-1,-1), status);
			}
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == TEXT_CURSOR_DELETE) {	// Delete Right
		incUndo=false;
		if (SelectionOn == TRUE) {
			*status = DeleteSelection();
		}
		else 
		{
			*status = (EWhichDraw) DeleteRight(&delChar);
			InsertUndoItem(UNDO_INSERT_CHAR_R, delChar);
		}
	}
	else if ((nchar > 0) && (nchar < 11)) {

		if (SelectionOn == TRUE) {
			*status = DeleteSelection();
			incUndo=false;
		}
		else if (nchar == 8) {	// Backspace
			//IncUndoLevel();
			incUndo=false;
			*status = (EWhichDraw) DeleteLeft(&delChar);
			InsertUndoItem(UNDO_INSERT_CHAR, delChar);
			return OK;
		}
		/* It is okay to delete the selection, then fall through here */
		if (*status & 0x80) {
			/* control # for math font */
			*status = (EWhichDraw)InsertCharacter((short)nchar);
			incUndo=false;
		}
		else if (nchar == 9) {
			*status = (EWhichDraw)InsertCharacter((short)nchar);
			incUndo=false;
		}
	}
	else if (((nchar >= 32) && (nchar < 127)) || (nchar == 163)) { // Other Valid Character
		if (SelectionOn == TRUE) {
			*status = DeleteSelection();
			doDispAll = true;
		}
		// Underline
		//		if ((*status & 0x1000) && (nchar == 'U')) {
		//			*status = TEXT_DRAW_NOTHING;
		//			nUnderline ^= ATTR_UND_ON;	// Toggle Underline state
		//		}
		//		else
		// End Underline

		if ((theApp.m_isDemo == DEMO_ON) || (theApp.m_isDemo == DEMO_RELEASE)) {
			char *tst = ValidChars;
			int isValid = 0;
			*status = TEXT_DRAW_NOTHING;
			while (*tst) {
				if (*tst == (char)nchar) {
					*status = (EWhichDraw)InsertCharacter((short)nchar);
					incUndo=false;
					isValid = 1;
					break;
				}
				tst++;
			}
			if (isValid == 0) {
				CString tStr;
				static int validCount=0;
				if ((validCount++ % 10) == 0) {
					tStr.LoadString(IDS_DEMO_IRRITATE);
					AfxMessageBox(tStr, MB_OK);
				}
			}
		}
		else {
			*status = (EWhichDraw)InsertCharacter((short)nchar);
			incUndo=false;
		}
		if (doDispAll) {
			*status = TEXT_DRAW_ALL;
		}
	}
	else if (nchar == 13) {	// ENTER
		needReformat=true;
		if (*status != -979) {	/* make sure we are not in undo process */
			IncUndoLevel();
			InsertUndoItem(UNDO_DEL_LEFT , 0);
		}
		else {
			incUndo=false;
		}

		CPoint cp = CursorIndex;
		CString leftAttr, rightAttr, leftString, rightString, leftShapes, rightShapes;
		CStringW leftAttrW, rightAttrW, leftStringW, rightStringW;
		if (SelectionOn == TRUE) {
			*status = DeleteSelection();

			/* it is possible for the delete selection to mess this up */
			while(cp.y) {
				if (TxtAttrs[cp.y].IsEmpty() == FALSE) {
					break;
				}
				cp.y--;
			}
		}
		if ((TxtAttrs[cp.y].GetLength() == 0) || (TxtAttrs[cp.y].GetAt(0) == DELCHAR)) {	// if the line we are on is empty
			rightString = "";						// Then make some dummy end of lines
			rightShapes = "";
			rightAttrW = "";
		}
		else {
			leftAttrW = TxtAttrs[cp.y].Mid(0, cp.x);	// Get up to cursor
			rightAttrW = TxtAttrs[cp.y].Mid(cp.x);	// Get anything left on the line

			leftString = TxtLines[cp.y].Mid(0, cp.x);	// Get up to cursor
			rightString = TxtLines[cp.y].Mid(cp.x);	// Get anything left on the line

			leftShapes = TxtShapes[cp.y].Mid(0, cp.x);	// Get up to cursor
			rightShapes = TxtShapes[cp.y].Mid(cp.x);	// Get anything left on the line

			if (leftString.IsEmpty()) {
				TxtLines[cp.y].Empty();
				TxtLines[cp.y].AppendChar(SW_BOL);	// Force a beginning of line char
				TxtShapes[cp.y].Empty();
				TxtShapes[cp.y].AppendChar(SHAPE_NONE);
				TxtAttrs[cp.y].Empty();	// Make sure we start clean
				TxtAttrs[cp.y].AppendChar(DELCHAR); // deletable space
			}
			else {
				TxtLines[cp.y] = leftString;	// make new line
				TxtShapes[cp.y] = leftShapes;	// make new line
				TxtAttrs[cp.y] = leftAttrW;		// make new line
			}
		}

		if (OpenLine(cp.y+1) == FALSE) {	// Create a new line
			// There are no more lines available
			TxtLines[cp.y] += rightString;	// Add back on the right side
			TxtShapes[cp.y] += rightShapes;	// Add back on the right side
			TxtAttrs[cp.y] += rightAttrW;
			*status = TEXT_DRAW_CURSOR;
			if (incUndo) {
				IncUndoLevel();
			}
			return OK;

		}
		if (rightString.IsEmpty()) {	// If the new lines are empty too
			TxtLines[cp.y+1].Empty();
			TxtLines[cp.y+1].AppendChar(SW_BOL);	// Force a beginning of line char
			TxtShapes[cp.y+1].Empty();
			TxtShapes[cp.y+1].AppendChar(SHAPE_NONE);	// Force a beginning of line char
			TxtAttrs[cp.y+1].Empty();	// Make sure we start clean
			TxtAttrs[cp.y+1].AppendChar(DELCHAR); // deletable space
		}
		else {
			TxtLines[cp.y+1] = rightString;	// Assign the wrapped text
			TxtShapes[cp.y+1] = rightShapes;	// Assign the wrapped text
			TxtAttrs[cp.y+1] = rightAttrW;
		}

		// Force get rid of any old newline information
		TxtAttrs[cp.y] = TxtAttrs[cp.y].Left(TxtLines[cp.y].GetLength());

		// and add the hard newline
		TxtAttrs[cp.y].AppendChar(EOLHCHAR);

		// Set the cursor to beginning of next line
		cp.y++;
		cp.x = 0;
		SetCursor(cp);
		if (needReformat)
			ReformatText();
		*status = TEXT_DRAW_ALL;
	}
	else if (nchar > 128) {
		*status = (EWhichDraw) InsertCharacter((short)nchar);
		incUndo=false;
	}
	if (incUndo==true) {
		IncUndoLevel();
	}

	return OK;
}

void TextItem::InsertUndoItem(int flag, unsigned short item)
{
	if (inUndo)
		return;
	undoList[undoCount].uType = flag;
	switch(flag) {
	case UNDO_DEL_LEFT:
		undoList[undoCount].uCount++;
		undoList[undoCount].uClick = CursorIndex;
		break;
	case UNDO_INSERT_CHAR:
		if (item) {
			if (undoList[undoCount].charCount < (MAX_UNDO_CHARS-1)) {
				undoList[undoCount].uChars[undoList[undoCount].charCount] = item;
				undoList[undoCount].charCount++;
			}
		}
		break;
	case UNDO_INSERT_CHAR_R:
		if (item) {
			if (undoList[undoCount].charCount < (MAX_UNDO_CHARS-1)) {
				undoList[undoCount].uChars[undoList[undoCount].charCount] = item;
				undoList[undoCount].charCount++;
			}
		}
		break;
	case  UNDO_MOUSECLICK:
		undoList[undoCount].uClick = CursorIndex;
		break;
	}
}

void TextItem::IncUndoLevel()
{
	if (SelectionOn || inUndo) {
		return;
	}
	if ((undoCount + 1) >= MAX_UNDO) {
		memmove(&undoList[0], &undoList[1], sizeof(UNDO_STRUCT)*(MAX_UNDO-1));
		memset(&undoList[MAX_UNDO-1], 0, sizeof(UNDO_STRUCT));
		return;
	}
	/* If something has been done */
	if (undoList[undoCount].uType) {
		undoCount++;
		memset(&undoList[undoCount], 0, sizeof(UNDO_STRUCT));
	}
}

void TextItem::textHandleUndo()
{
	int i;
	UNDO_STRUCT saveIt;
	unsigned short delChar;
	int status=-979;
	bool didChange = false;

	if ((undoCount > 0) && (undoList[undoCount].uType == 0)) {
		undoCount--;
	}
	if (undoCount == -1) {
		return;
	}
	inUndo=1;
	saveIt = undoList[undoCount];

	switch(saveIt.uType) {
	case UNDO_DEL_LEFT:
		SetCursor(saveIt.uClick);
		for (i=0; i < saveIt.uCount; i++) {
			DeleteLeft(&delChar);
			if (delChar == (EOL_SOFT|FUNCT_CHAR)) {
				i--;
			}
		}
		break;
	case UNDO_INSERT_CHAR:
		for(i=undoList[undoCount].charCount-1; i >=0 ; i--) {
			if (undoList[undoCount].uChars[i] == EOLHCHAR) {
				KeyDown(13, &status);
			}
			else {
				if (undoList[undoCount].uChars[i] >= SHAPES_START_UNSIGNED) {
					if (IsFromSpecialCharDlg == FALSE) {
						IsFromSpecialCharDlg = TRUE;
						didChange = true;
					}
				}
				InsertCharacter(undoList[undoCount].uChars[i]);
				if (didChange) {
					IsFromSpecialCharDlg = FALSE;
				}
			}
		}
		break;
	case UNDO_INSERT_CHAR_R:
		for(i=undoList[undoCount].charCount-1; i >=0 ; i--) {
			if (undoList[undoCount].uChars[i] >= SHAPES_START_UNSIGNED) {
				if (IsFromSpecialCharDlg == FALSE) {
					IsFromSpecialCharDlg = TRUE;
					didChange = true;
				}
			}
			InsertCharacter(undoList[undoCount].uChars[i]);
			if (didChange) {
				IsFromSpecialCharDlg = FALSE;
			}
			doCursorLeft(TRUE, (int *)0, (int *)0);
		}
		break;
	case UNDO_MOUSECLICK:
		SetCursor(saveIt.uClick);
		break;
	}
	/* Clear it out */
	memset(&undoList[undoCount], 0, sizeof(UNDO_STRUCT));
	inUndo=0;

}

int TextItem::InsertCharacter(unsigned short nc)
{
	CString left_string, right_string;
	CStringW left_stringw, right_stringw ;
	CPoint cp = CursorIndex;
	int ly = cp.y;
	int lx = cp.x;
//	bool doOverlay=false;

	if (nOverfullWarning) {
		return 0;
	}
	//bool bLastLine = (ly == (MAX_TEXT_LINES - 1)) || TxtLines[ly + 1].IsEmpty();

	if (StoryBoxFull) {
		if (ly >= StoryLines - 1 && lx >= TxtLines[ly].GetLength()) {
			if (StoryFlowOutState == STORY_FLOW_APPEND) {
				theApp.m_strStoryOverflowText += (unsigned char)nc;
				theApp.m_strStoryOverflowShapes += TxtShapes[ly][lx];
				theApp.m_iStoryOverflowDirection = 1;
				theApp.m_iStoryOverflowBox = StoryItemOrder + 1;
				StoryFlowInState = STORY_FLOW_INSERT;
			}

			return TEXT_DRAW_CURSOR;
		}
	}
	// Replace the bol char with the real one
	if ((lx == 0) && !TxtAttrs[ly].IsEmpty() && (TxtAttrs[ly].GetAt(0) == DELCHAR)) {
		TxtLines[ly] = "";	// Remove the beginning of line char
		TxtShapes[ly] = "";
		TxtAttrs[ly] = "";
	}

	/* Make sure we are not beoynd the end to start with */
	if (lx > TxtLines[ly].GetLength()) {
		lx = TxtLines[ly].GetLength();
		CursorIndex.x = lx;
	}

	left_string = TxtLines[ly].Mid( 0, lx);
	right_string = TxtLines[ly].Mid( lx);
	TxtLines[ly] = left_string;

	unsigned short ncTemp = 0;
	if (IsFromSpecialCharDlg && nc >= SHAPES_START_UNSIGNED && nc <= SHAPES_END_EXTENDED) {
		ncTemp = nc - (nc >= SHAPES_START_EXTENDED ? SHAPES_START_EXTENDED : 0);
		TxtLines[ly].AppendChar((unsigned char)ncTemp);
	}
	else {
		TxtLines[ly].AppendChar((unsigned char)nc);
	}
	TxtLines[ly] += right_string;
	left_string = TxtShapes[ly].Mid( 0, lx);
	right_string = TxtShapes[ly].Mid( lx);
	TxtShapes[ly] = left_string;
	if (IsFromSpecialCharDlg && nc >= SHAPES_START_UNSIGNED && nc <= SHAPES_END_EXTENDED) {
		TxtShapes[ly].AppendChar((unsigned char) (nc >= SHAPES_START_EXTENDED ? SHAPE_EXTENDED : SHAPE_UNSIGNED));
	}
	else {
		TxtShapes[ly].AppendChar((unsigned char)SHAPE_NONE);
	}
	TxtShapes[ly] += right_string;

	// Now update the attributes
	left_stringw = TxtAttrs[ly].Mid( 0, lx);
	right_stringw = TxtAttrs[ly].Mid( lx);
	TxtAttrs[ly] = left_stringw;

	TxtAttrs[ly].AppendChar(cCurrAttr);	// Current Attribute
	TxtAttrs[ly] += right_stringw;

	cp.x++;
	SetCursor(cp);
	ReformatText();
	lastWordPos = lx;	// remember where this is

	InsertUndoItem(UNDO_DEL_LEFT , 0);
	if (nc == ' ') {
		IncUndoLevel();
	}

	// if last line and not pushing text
	if ((cp.x >= TxtLines[ly].GetLength())) {

		lastWordPos=lx;

		if (doKerning || inCursive) {
			while (lastWordPos && (IS_ALPHANUMERIC(TxtLines[ly][lastWordPos]))) {
				lastWordPos--;
			}
		}

		return TEXT_DRAW_CHAR;
	}

	return TEXT_DRAW_CURSOR_LINE;

}

/*
;DrawCursor
*/
void TextItem::DrawCursor(CDC *pDC, int flag)
{
	if (pDC->IsPrinting())
		return;

	if (!flag && (CursorDrawn.x == -1))	// just leave if there is nothing to undo
		return;

	int aZigzag[] = { 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF, 0x7FFF };
	HBITMAP 	hbmp = CreateBitmap(8, 8, 1, 1, aZigzag);
	HBRUSH 		hbrush = CreatePatternBrush(hbmp);
	HBRUSH      hbrushOld;
	hbrushOld = (HBRUSH) ::SelectObject(pDC->m_hDC, hbrush);

	if (flag) {
		CPoint cp;
		CursorDrawn = CursorPos;
		cp = CursorPos;
		cp.x += ScrollPos.x;
		cp.y -= ScrollPos.y;

		// adjust the cursor to match the margin change
		if (inCursive) {
			cp.y += zMargin;
		}
		else if (!nDot2Dot) {
			cp.y += zMargin;
		}
		pDC->PatBlt(cp.x, cp.y, 24, CursorLength, PATINVERT);

		if (SelectionOn) {
			if (SelCursorPos != CursorDrawn) {
				SelectionIsReal++;				// There is really a selection here
				SelCursorDrawn = SelCursorPos;	// Go ahead and draw the cursor
				cp = SelCursorPos;
				cp.x += ScrollPos.x;
				cp.y -= ScrollPos.y;
				// adjust the cursor to match the margin change
				if (inCursive) {
					cp.y += zMargin;
				}
				else if (!nDot2Dot) {
					cp.y += zMargin;
				}
				pDC->PatBlt(cp.x, cp.y, 24, CursorLength, PATINVERT);
			}
			else {
				SelectionIsReal = 0;			// Not yet any real selection
			}

		}
	}
	else if (CursorDrawn.x != -1) {
		CursorDrawn.x += ScrollPos.x;
		CursorDrawn.y -= ScrollPos.y;
		// adjust the cursor to match the margin change
		if (inCursive) {
			CursorDrawn.y += zMargin;
		}
		else if (!nDot2Dot) {
			CursorDrawn.y += zMargin;
		}
		pDC->PatBlt(CursorDrawn.x, CursorDrawn.y, 24, CursorLength, PATINVERT);
		CursorDrawn.x = -1;
		CursorDrawn.y = -1;


		if (SelectionOn && (SelCursorDrawn.x != -1)) {
			SelCursorDrawn.x += ScrollPos.x;
			SelCursorDrawn.y -= ScrollPos.y;
			if (inCursive) {
				SelCursorDrawn.y += zMargin;
			}
			else if (!nDot2Dot) {
				SelCursorDrawn.y += zMargin;
			}
			pDC->PatBlt(SelCursorDrawn.x, SelCursorDrawn.y, 24, CursorLength, PATINVERT);
			SelCursorDrawn.x = -1;
			SelCursorDrawn.y = -1;
		}
	}
	::SelectObject(pDC->m_hDC, hbrushOld);
	DeleteObject(hbrush);
	DeleteObject(hbmp);
}

/*
;DeleteLeft
*/
int TextItem::DeleteLeft(unsigned short *delChar)
{
	CPoint cp = CursorIndex;
	int len1, len2;
	int retstatus = TEXT_DRAW_ALL;
	wchar_t testChar;

	if (cp.x <= 0) {

		// If we are already at the top of the screen, forget delete
		if (--cp.y < 0) {
			cp.y = 0;
			*delChar = 0;
			return TEXT_DRAW_NOTHING;
		}

		cp.x = TxtLines[cp.y].GetLength();

		testChar = TxtAttrs[cp.y].GetAt(0);
		// If the line we are moving up to is blank just delete it
		if ((cp.x == 1) && ((testChar == DELCHAR) || (testChar == EOLHCHAR))) {
			RemoveLine(cp.y,true);
			cp.x = 0;		// reset to the beginning of the line
			*delChar = EOLHCHAR;
			IncUndoLevel();
		}
		else {
			//			*delChar = EOL_SOFT|FUNCT_CHAR;
			//			IncUndoLevel();
			*delChar = 0;	/* Don't save the soft returns */

			len1 = TxtLines[cp.y+1].GetLength();

			len2 = TxtAttrs[cp.y].GetLength();

			if ((len1 > 1) || (len1 && (TxtAttrs[cp.y+1].GetAt(0) != DELCHAR))) {

				len1 = TxtLines[cp.y].GetLength();
				len2 = TxtAttrs[cp.y].GetLength();

				if (len2 > len1) {
					TxtAttrs[cp.y] = TxtAttrs[cp.y].Left(len1);
				}

				TxtLines[cp.y] += TxtLines[cp.y+1];	// Move up line  
				TxtShapes[cp.y] += TxtShapes[cp.y+1];	// Move up line  
				TxtAttrs[cp.y] += TxtAttrs[cp.y+1];	// move up attrs

				// Don't allow the re-wrapping to move the cursor back down if we are at a space at the end of the line
				keepBackspacePos = TRUE;
			}
			else if (len1) {
				// Make the attribute match the line
				TxtAttrs[cp.y] = TxtAttrs[cp.y].Left(TxtLines[cp.y].GetLength());
				if (TxtAttrs[cp.y+2].GetLength()) {
					TxtAttrs[cp.y].AppendChar(FUNCT_CHAR|EOL_SOFT);
					doReformatText=1;
				}
			}
			RemoveLine(cp.y+1, true);
		}
	}
	else
	{
		*delChar = (unsigned char)TxtLines[cp.y].GetAt(cp.x-1);
		if (TxtShapes[cp.y][cp.x-1] == SHAPE_EXTENDED) {
			*delChar += SHAPES_START_EXTENDED;
		}
		else if (TxtShapes[cp.y][cp.x-1] == SHAPE_UNSIGNED) {
			*delChar += SHAPES_START_UNSIGNED;
		}
		else if (isspace(*delChar)) {
			IncUndoLevel();
		}
		CString left_string = TxtLines[cp.y].Mid(0, cp.x - 1);
		CString right_string = TxtLines[cp.y].Mid(cp.x);
		TxtLines[cp.y] = left_string + right_string;

		// Update Shapes
		left_string = TxtShapes[cp.y].Mid(0, cp.x - 1);
		right_string = TxtShapes[cp.y].Mid(cp.x);
		TxtShapes[cp.y] = left_string + right_string;

		// Update attrs
		CStringW left_stringw = TxtAttrs[cp.y].Mid(0, cp.x - 1);
		CStringW right_stringw = TxtAttrs[cp.y].Mid(cp.x);
		TxtAttrs[cp.y] = left_stringw + right_stringw;
		// Move back one
		cp.x--;

		allowFixWrap = TRUE;	// Allow formatting to rebuild a line
		retstatus = TEXT_DRAW_CURSOR_LINE;	// assume just the one line
		//doReformatText=1;	/* Not always necessary, but it doesn't hurt too much */
	}

	// Make sure we at least have the bol char 
	if (TxtLines[cp.y].GetLength() == 0) {
		TxtLines[cp.y].AppendChar(SW_BOL);
		TxtShapes[cp.y].AppendChar(SHAPE_NONE);
		TxtAttrs[cp.y].AppendChar(DELCHAR);
	}

	SetCursor(cp);
	TestAttrState();
	if (!IsLastItemInStory && (StoryNumber > 0)) {
		// If we do this and not in story mode, then the cursor gets left behind
		// but we change the size of the box possibly
		theApp.m_iStoryOverflowBox = StoryItemOrder + 1;
		theApp.m_strStoryOverflowText.Empty();
		theApp.m_strStoryOverflowShapes.Empty();
	}

	ReformatText();	// word alignments for attributes could have changed

	return retstatus;
}

int TextItem::DeleteRight(unsigned short *delChar)
{
	int linelen; 
	int retStatus = TEXT_DRAW_ALL;

	// If there is nothing on this line
	// then bring up any lines below
	CPoint cp = CursorIndex;
	linelen = TxtLines[cp.y].GetLength();

	if ((cp.x == 0) && linelen && 
		( (TxtAttrs[cp.y].GetAt(0) == DELCHAR) || (TxtAttrs[cp.y].GetAt(0) == EOLHCHAR) )) {
			RemoveLine(cp.y, true);
			IncUndoLevel();
	}
	else if (cp.x >= linelen) {	// sitting and end of line
		IncUndoLevel();
		if ((TxtLines[cp.y].GetLength() == 1) && ((TxtAttrs[cp.y].GetAt(0) == DELCHAR) ||
			(TxtAttrs[cp.y].GetAt(0) == EOLHCHAR))			
			) {
				*delChar = EOLHCHAR;
				RemoveLine(cp.y, true);
		}
		else {
			linelen = TxtLines[cp.y+1].GetLength();
			if (linelen) {
				if ((linelen > 1) || (TxtAttrs[cp.y+1][0] != DELCHAR))  {
					CString left_string = TxtLines[cp.y].Mid(0, cp.x);	// Cut of newline
					TxtLines[cp.y] = left_string + TxtLines[cp.y+1];	// pull up next line

					left_string = TxtShapes[cp.y].Mid(0, cp.x);	// Cut off newline
					TxtShapes[cp.y] = left_string + TxtShapes[cp.y+1];	// pull up next line

					// Combine the attrs line too 
					CStringW left_stringW = TxtAttrs[cp.y].Mid(0, cp.x);
					TxtAttrs[cp.y] = left_stringW + TxtAttrs[cp.y+1];
				}
				*delChar = EOLHCHAR;
				RemoveLine(cp.y+1,true);
			}
			else {
				*delChar = 0;
				retStatus = TEXT_DRAW_NOTHING;
			}
		}
	}
	else {
		// Change the line to remove the character
		*delChar = (unsigned char) TxtLines[cp.y].GetAt(cp.x);
		if (TxtShapes[cp.y][cp.x] == SHAPE_EXTENDED) {
			*delChar += SHAPES_START_EXTENDED;
		}
		else if (TxtShapes[cp.y][cp.x] == SHAPE_UNSIGNED) {
			*delChar += SHAPES_START_UNSIGNED;
		}
		else if (isspace(*delChar)) {
			IncUndoLevel();
		}
		CString left_string = TxtLines[cp.y].Mid(0, cp.x);
		CString right_string = TxtLines[cp.y].Mid(cp.x+1 /*, TxtLines[cp.y].GetLength() - cp.x*/);
		TxtLines[cp.y] = left_string + right_string;

		left_string = TxtShapes[cp.y].Mid(0, cp.x);
		right_string = TxtShapes[cp.y].Mid(cp.x+1);
		TxtShapes[cp.y] = left_string + right_string;

		// Now remove the attribute for that char
		CStringW left_stringw = TxtAttrs[cp.y].Mid(0, cp.x);
		CStringW right_stringw = TxtAttrs[cp.y].Mid(cp.x+1);
		TxtAttrs[cp.y] = left_stringw + right_stringw;

		allowFixWrap = TRUE;	// Allow formatting to rebuild a line
		retStatus = TEXT_DRAW_CURSOR_LINE;
		if (!IsLastItemInStory && (StoryNumber > 0)) {
			theApp.m_iStoryOverflowBox = StoryItemOrder + 1;
			theApp.m_strStoryOverflowText.Empty();
			theApp.m_strStoryOverflowShapes.Empty();
		}
	}

	// Make sure we at least have the bol char 
	if (TxtLines[CursorIndex.y].IsEmpty()) {
		TxtLines[CursorIndex.y].AppendChar(SW_BOL); 		// added the deletable space
		if (TxtShapes[CursorIndex.y].IsEmpty()) {
			TxtShapes[CursorIndex.y].AppendChar((char)SHAPE_NONE);
		}
		if (TxtAttrs[CursorIndex.y].IsEmpty()) { 	// if there is no length (check for hardreturn)
			TxtAttrs[CursorIndex.y].AppendChar((char)DELCHAR);
		}
	}

	TestAttrState();
	ReformatText();
	return retStatus;
}


void TextItem::doTextCutCopy(int mestype)
{
	int y, cnt, cChrb, cChre;
	int lineInd;
	// Remove previous copy
	cnt = 0;
	while(TxtCopy[cnt].IsEmpty() == FALSE) {
		TxtCopy[cnt].Empty();
		TxtCopyAttrs[cnt].Empty();
		TxtCopyShapes[cnt].Empty();
		cnt++;
	}
	if (SelCursorIndex.x < 0) {
		return;
	}
	if (SelCursorIndex.y < 0) {
		return;
	}

	FixSelectionPostion();	// make sure cursor is at the end

	/* Check if first char is a space */
	if (TxtLines[SelCursorIndex.y].GetLength() > SelCursorIndex.x) {
		cChrb = TxtLines[SelCursorIndex.y].GetAt(SelCursorIndex.x);
		if (TxtLines[CursorIndex.y].GetLength() > CursorIndex.x) {
			cChre = TxtLines[CursorIndex.y].GetAt(CursorIndex.x);
			if ((cChrb != ' ') && (cChre == ' ')) {
				CursorIndex.x++;
			}
		}
	}

	if (SelCursorIndex.y == CursorIndex.y) {
		cnt = CursorIndex.x - SelCursorIndex.x;
		TxtCopy[0] = TxtLines[CursorIndex.y].Mid(SelCursorIndex.x, cnt);
		TxtCopyShapes[0] = TxtShapes[CursorIndex.y].Mid(SelCursorIndex.x, cnt);
		TxtCopyAttrs[0] = TxtAttrs[CursorIndex.y].Mid(SelCursorIndex.x, cnt);
	}
	else {
		// Copy the end of the first line of selection
		TxtCopy[0] = TxtLines[SelCursorIndex.y].Mid(SelCursorIndex.x);
		TxtCopyShapes[0] = TxtShapes[SelCursorIndex.y].Mid(SelCursorIndex.x);
		TxtCopyAttrs[0] = TxtAttrs[SelCursorIndex.y].Mid(SelCursorIndex.x);
		// copy each line in between
		y = SelCursorIndex.y+1;
		lineInd = 1;
		while (y < CursorIndex.y) {
			TxtCopy[lineInd] = TxtLines[y];
			TxtCopyShapes[lineInd] = TxtShapes[y];
			TxtCopyAttrs[lineInd] = TxtAttrs[y];
			lineInd++;
			y++;
		}
		// And copy the last line
		TxtCopy[lineInd] = TxtLines[y].Left(CursorIndex.x);
		TxtCopyShapes[lineInd] = TxtShapes[y].Left(CursorIndex.x);
		TxtCopyAttrs[lineInd] = TxtAttrs[y].Left(CursorIndex.x);
	}
	if (mestype == TEXT_DOCUT) {
		DeleteSelection();
	}
	else {
		//Message(TEXT_SELECTION_OFF, CPoint(-1,-1), &status);
	}
}

int TextItem::DeleteSelection()
{
	int status, x, y;
	unsigned short delChar;

	FixSelectionPostion();	// make sure cursor is at the end
	doCursorLeft(FALSE, &x, &y);	// Don't actually move cursor

	while(IsCharInSelection(x,y)) {
		DeleteLeft(&delChar);
		InsertUndoItem(UNDO_INSERT_CHAR, delChar);
		doCursorLeft(FALSE, &x, &y);
	}

	Message(TEXT_SELECTION_OFF, CPoint(-1,-1), &status);
	return TEXT_DRAW_ALL;
}


void TextItem::doTextPaste()
{
	int x,y, cnt, status;
	char chr;
	for(x=0; TxtCopy[x].IsEmpty() == FALSE; x++) {
		cnt = TxtCopy[x].GetLength();
		for(y=0; y < cnt; y++) {
			chr = TxtCopy[x].GetAt(y);
			if (chr == 13) {
				KeyDown(13, &status);
			}
			else {
				InsertCharacter(chr);
				IncUndoLevel();
			}
		}
	}

}

///******************************
/// ;RemoveLine(int line)
///******************************
int TextItem::RemoveLine( int line, bool setCur)
{
	int ly;

	for( ly = line; ly < MAX_TEXT_LINES; ++ly) {
		if (TxtLines[ly].IsEmpty())	{// just go as far as we need
			TxtShapes[ly].Empty();
			TxtAttrs[ly].Empty();
			break;
		}

		/* If there is nothing left on the line, really, then just delete it */
		if ((TxtLines[ly].GetLength() == 1) && (TxtAttrs[ly].GetLength() > 0) && (TxtAttrs[ly].GetAt(0) == DELCHAR))  {
			TxtLines[ly].Empty();
			TxtShapes[ly].Empty();
			TxtAttrs[ly].Empty();
		}
		TxtLines[ly] = TxtLines[ly+1];
		TxtShapes[ly] = TxtShapes[ly+1];
		TxtAttrs[ly] = TxtAttrs[ly+1];
	}
	//*** adjust cursor if we just deleted the line it was on
	if (setCur && (CursorIndex.y >= line)) {
		if (CursorIndex.y == line) {
			if (CursorIndex.x > TxtLines[line].GetLength()) {
				CursorIndex.x = TxtLines[line].GetLength();
			}
		}
		else if (CursorIndex.y > 0) {
			CursorIndex.y--;
			/* now move to the end of the previous line */
			//CursorIndex.x += TxtLines[CursorIndex.y].GetLength();
		}
	}
	if (StoryLines < 1) {// (No auto-sizing for boxes included in Story)
		allowAdjustBox = TRUE;	// If a line was removed, maybe we can shrink the box
		nOverfullWarning = 0;	// Clear so we can retest the box size
	}
	theApp.m_isGridWiped = TRUE;// Need to redraw grid if this function just made a white rectangle
	return TRUE;
}

int TextItem::OpenLine( int line)
{
	int ly;

	// make sure line is a valid number
	if( line <= 0 || line > MAX_TEXT_LINES) 
		return FALSE;

	// See how many lines there are now
	for(ly = line; !TxtLines[ly].IsEmpty();) {
		ly++;
	}

	if (ly >= MAX_TEXT_LINES)	// Is it beyond the end?
		return FALSE;			// yes, exit 

	// Shift the current lines down
	for( ; ly > line; --ly) {
		TxtLines[ly] = TxtLines[ly-1];
		TxtShapes[ly] = TxtShapes[ly-1];
		TxtAttrs[ly] = TxtAttrs[ly-1];
	}

	// and create the new empty line
	TxtLines[line] = "";
	TxtShapes[line] = "";
	TxtAttrs[line] = "";

	return TRUE;
}

int TextItem::CalcLinePointSpace()
{
	// Change the line spacing array...
	int tempval;
	int mulVal;

	mulVal = 20*sign;

	zPointSize = (float)((float)nPointSize * dCurrentZoom);

	//zMargin = (int) ((float)MARGIN * dCurrentZoom);

	nLinePointSpace = (int)(zPointSize / (float)(inCursive ? 2.0 : 3.0));	

	tempval = (int)(nPointSize / (float)(inCursive ? 2.0 : 3.0));	

	TextLineYs = (int)((float)((((float)nPointSize * dCurrentZoom) + nLinePointSpace) * mulVal));
	uzTextLineYs = (int)((float)((((float)nPointSize) + tempval) * mulVal));
	return OK;
}

int TextItem::ReadTextBar(BOOL bIncludeFont)
{
	if (bIncludeFont) {
		char string[100];
		CComboBox *pcombobox = NULL;
		int cbindex = 0;

		pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_FONT_COMBO);

		cbindex = pcombobox->GetCurSel();
		if (cbindex < 0)
			cbindex =	0;	// default to zero
		pcombobox->GetLBText(cbindex, string);
		sFontName = string;
		sFontIndex = cbindex;

		pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_POINT_COMBO);
		//		cbindex = pcombobox->GetCurSel();
		//		if (cbindex != CB_ERR)
		//			pcombobox->GetLBText(cbindex, string);
		//		else
		// ALWAYS just get the text since it may not be a standard value
		// and then it resets the box incorrectly.
		// create a box, type 92 in the point size, click in the box, click out, click in, 
		// change a density -- then the text changes size too.
		pcombobox->GetWindowText(string, sizeof(string));

		nPointSize = atoi(string);
		zPointSize = (float) ((float)nPointSize * dCurrentZoom);
	}

	SetViaMembers();

	return OK;
}


int
TextItem::WriteTextBar()
{
	char string[32];

	CComboBox *pcombobox = NULL;

	pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_POINT_COMBO);
	wsprintf(string,"%d", nPointSize);

	if (pcombobox->FindStringExact(0, string) == CB_ERR) {
		pcombobox->SetWindowText(string);
	}
	else
		pcombobox->SelectString(-1, string);

	pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_FONT_COMBO);
	wsprintf(string,"%s", sFontName);
	pcombobox->SelectString(-1, string);

	return OK;
}

int
TextItem::DisableButtons()
{
	CEditBar *ptoolbar = (CEditBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDW_POWER_BAR);

	ptoolbar->SetButtonInfo( D2D_DENSITY_BUTTON, ID_DOT2DOT_DENSITY, 
		TBBS_BUTTON, D2D_DENSITY_IMAGE);

	ptoolbar->SetButtonInfo( D2D_SHADE_BUTTON, ID_DOT2DOT_SHADE, 
		TBBS_BUTTON, D2D_SHADE_IMAGE);

	ptoolbar->SetButtonInfo( D2D_LINES_BUTTON, ID_DOT2DOT_LINES, 
		TBBS_BUTTON, D2D_LINES_IMAGE);

	ptoolbar->SetButtonInfo( D2D_ARROWS_BUTTON, ID_DOT2DOT_ARROWS, 
		TBBS_BUTTON, D2D_ARROWS_IMAGE);

	return OK;
}

int TextItem::UseTools(int iNewDensity, int iNewShade, int iNewArrows)
{
	int valueChanged = 0;
	// Density
	if ((DensityFormat != iNewDensity) && (iNewDensity != -1)) {
		DensityFormat = iNewDensity;
		valueChanged++;
	}

	// SHADE
	if (ShadeFormat != iNewShade && iNewShade != -1) {        
		ShadeFormat = iNewShade;
		valueChanged++;
	}

	//	if ((ShadeType != iNewShadeType) && (iNewShadeType != -1)) {
	//		ShadeType = iNewShadeType;
	//		valueChanged++;
	//	}

	// ARROWS
	// Only modify variables if formats don't agree... (user changed them in dialog)
	if (ArrowsFormat != iNewArrows && iNewArrows != -1) {
		ArrowsFormat = iNewArrows;
		valueChanged++;
	}

//	if (OverlayFormat != iNewOverlay && iNewOverlay != -1) {
//		OverlayFormat = iNewOverlay;
//		valueChanged++;
//	}

	if (valueChanged) {
		ReformatText();
	}
	return OK;
}

int TextItem::DoFontDialog(int flag)
{
	CFontDlg dlg;
	int retval = 0;
	FONTINFO saveInfo={0};

	dlg.m_strFont = sFontName;
	dlg.m_nFontIndex = sFontIndex;
	dlg.m_nSize = nPointSize;
	dlg.m_setAsDefault = (flag ? TRUE : FALSE);	/* Set to default if set */
	if (sFontIndex >= 0) {
		saveInfo = myFontInfo;
	}


	if (dlg.DoModal() != IDCANCEL) {

		if (sFontName != dlg.m_strFont) {
			sFontName = dlg.m_strFont;
			retval++;
		}
		if (sFontIndex != dlg.m_nFontIndex) {
			sFontIndex = dlg.m_nFontIndex;
			/* Set the default lines for this font */
			nDot2DotLinesButton = myFontInfo.f_fontLine;
			retval++;
		}
		if (
			(saveInfo.f_TopLine != myFontInfo.f_TopLine) ||
			(saveInfo.f_MidLine != myFontInfo.f_MidLine) ||
			(saveInfo.f_BotLine != myFontInfo.f_BotLine) ||
			(saveInfo.f_BasLine != myFontInfo.f_BasLine) ||
			(saveInfo.f_TopColor != myFontInfo.f_TopColor) ||
			(saveInfo.f_MidColor != myFontInfo.f_MidColor) ||
			(saveInfo.f_BasColor != myFontInfo.f_BasColor) ||
			(saveInfo.f_BotColor != myFontInfo.f_BotColor)) {
				retval++;
				nDot2DotLinesButton = myFontInfo.f_fontLine;

		}

		if (nPointSize != dlg.m_nSize) {
			nPointSize = dlg.m_nSize;
			retval++;
		}
		if (retval) {	// only do the update if something changed
			zPointSize = (float)((float) nPointSize * dCurrentZoom);
			WriteTextBar();
			SetViaMembers();
		}

		if (dlg.m_fontLines != -1) {
			nDot2DotLinesButton = dlg.m_fontLines;
			retval++;
		}
	}
	return(retval);
}

// Update cCurrAttr and appropriate variables
void TextItem::buildNewAttributes()
{
	cCurrAttr = NORMAL_CHAR;
	switch(nDot2DotDensityButton) {
		case kDotDens00:
			cCurrAttr |= DENS00;
			break;
		case kDotDens25:
			cCurrAttr |= DENS25;
			break;
		case kDotDens50:
			cCurrAttr |= DENS50;
			break;
		case kDotDens75:
			cCurrAttr |= DENS75;
			break;
		case kDotDens100:
			cCurrAttr |= DENS100;
			break;
	}
	switch(nDot2DotShadeButton) {
		case kDotShad25:
			cCurrAttr |= SHAD25;
			break;
		case kDotShad50:
			cCurrAttr |= SHAD50;
			break;
		case kDotShad75:
			cCurrAttr |= SHAD75;
			break;
		case kDotShad100:
			cCurrAttr |= SHAD100;
			break;
	} 

	// Arrow is off at this point
	cCurrAttr |= ((nDot2DotArrowsButton == 2) ? ARROW_ON : 0);
	cCurrAttr |= (nDot2DotOverlayButton == 2) ? OVERLAY_ON : 0;

	cFirstAllWordOfLineAttr = cCurrAttr;
	cFirstWordOfLineAttr = cCurrAttr;
	cFirstLetOfWordAttr = cCurrAttr;
	cFirstLetOfWord2Attr = cCurrAttr;

	if (DensityFormat == DENSITY_ALLFIRST_WORD) {
		cFirstAllWordOfLineAttr |= DENS100;
		cFirstAllWordOfLineAttr  &= ~DENS00;
	}
	else if (DensityFormat == DENSITY_FIRST_LINE) {
		cFirstWordOfLineAttr |= DENS100;
		cFirstWordOfLineAttr  &= ~DENS00;
	}
	else if (DensityFormat == DENSITY_FIRST_WORD) {
		cFirstLetOfWordAttr |= DENS100;
	}
	else if (DensityFormat == DENSITY_ALTER_WORD) {
		cFirstLetOfWord2Attr |= DENS100;
	}

	if (ShadeFormat == SHADING_ALLFIRST_WORD) {
		cFirstAllWordOfLineAttr |= SHAD100;
	}
	else if (ShadeFormat == SHADING_FIRST_LINE) {
		cFirstWordOfLineAttr |= SHAD100;
	}
	else if (ShadeFormat == SHADING_FIRST_WORD) {
		cFirstLetOfWordAttr |= SHAD100;
	}
	else if (ShadeFormat == SHADING_ALTER_WORD) {
		cFirstLetOfWord2Attr |= SHAD100;
	}

	if (ArrowsFormat == ARROWS_ALLFIRST_WORD) {
		cFirstAllWordOfLineAttr |= ARROW_ON;	// make sure arrow is on
	}
	else if (ArrowsFormat == ARROWS_FIRST_LINE) {
		cFirstWordOfLineAttr |= ARROW_ON;	// make sure arrow is on
	}
	else if (ArrowsFormat == ARROWS_FIRST_WORD) {
		cFirstLetOfWordAttr |= cCurrAttr | ARROW_ON;
	}
	else if (ArrowsFormat == ARROWS_ALTER_WORD) {
		cFirstLetOfWord2Attr |= cCurrAttr | ARROW_ON;
	}


}

// Set the string with the new default settings
// Use all globals to set the string
void TextItem::ReformatText()
{
	int lx, ly, linelen;
	int beginLine; 	// True for first character in the line
	int beginWord;	// True for the beginning of each word
	int beginWord2;	// True for the beginning of every other word
	int lastWasSpace=0;
	int inFirstWord;
	wchar_t tAttr;
	doReformatText=0;

	buildNewAttributes();	// set cCurrAttr to new attributes

	for(ly = 0; (linelen = TxtLines[ly].GetLength()) > 0; ly++) {
		if (ly > MAX_TEXT_LINES) {
			break;
		}
		inFirstWord = (cFirstAllWordOfLineAttr != cCurrAttr) ? TRUE : FALSE;
		beginLine = (cFirstWordOfLineAttr != cCurrAttr) ? TRUE : FALSE;
		beginWord = (cFirstLetOfWordAttr != cCurrAttr) ? TRUE : FALSE;
		beginWord2 = (cCurrAttr != cFirstLetOfWord2Attr) ? TRUE : FALSE;
		lastWasSpace = TRUE;	// trick for the first character

		// start by skipping any spaces at beginning of line
		for(lx = 0; lx < linelen; lx++) {
			if (TxtLines[ly].GetAt(lx) != ' ')
				break;
			if (TxtAttrs[ly].GetAt(lx) != DELCHAR) {
				TxtAttrs[ly].SetAt(lx,cCurrAttr);	// give the space normal attribute
			}
		}

		for(; lx < linelen; lx++) {
			if (TxtShapes[ly].GetAt(lx) == SHAPE_NONE) {
				if (!IS_ALPHANUMERIC(TxtLines[ly].GetAt(lx))) {
					lastWasSpace = TRUE;
					TxtAttrs[ly].SetAt(lx,cCurrAttr);
					inFirstWord = false;
					continue;
				}
			}
			if (lastWasSpace) {
				beginWord = (cFirstLetOfWordAttr != cCurrAttr) ? TRUE : FALSE;
				beginWord2 +=   ((cCurrAttr != cFirstLetOfWord2Attr) ? 1 : 0);
				lastWasSpace = FALSE;
			}

			if (beginLine) {
				// This is really beginning of word/line/and first of every other
				tAttr = (cFirstAllWordOfLineAttr | cFirstWordOfLineAttr | cFirstLetOfWord2Attr | cFirstLetOfWordAttr);
				if ((cCurrAttr & DENS00) && (tAttr & DENS100)) {
					tAttr &= ~DENS00;
				}
				TxtAttrs[ly].SetAt(lx,tAttr);
				beginLine = 0;
				beginWord = 0;
				beginWord2 = 0;
			}
			else if (inFirstWord) {
				// This is really beginning of word/line/and first of every other
				tAttr = (cFirstAllWordOfLineAttr);
				if (beginWord) 
					tAttr |= cFirstLetOfWordAttr;
				if ((cCurrAttr & DENS00) && (tAttr & DENS100)) {
					tAttr &= ~DENS00;
				}
				TxtAttrs[ly].SetAt(lx,tAttr);
				beginWord = 0;
				beginWord2 = 0;
			}
			else if (beginWord2 == 2) {
				// This is really beginning of every other and every word
				tAttr = cFirstLetOfWord2Attr | cFirstLetOfWordAttr;
				if ((cCurrAttr & DENS00) && (tAttr & DENS100)) {
					tAttr &= ~DENS00;
				}
				TxtAttrs[ly].SetAt(lx,tAttr);
				beginWord2 = 0;
				beginWord = 0;
			}
			else if (beginWord) {
				tAttr = cFirstLetOfWordAttr;
				if ((cCurrAttr & DENS00) && (tAttr & DENS100)) {
					tAttr &= ~DENS00;
				}
				TxtAttrs[ly].SetAt(lx,tAttr);
				beginWord = 0;
			}
			else if (TxtAttrs[ly].GetLength() > lx) {
				TxtAttrs[ly].SetAt(lx,cCurrAttr);
			}

		}

	}
}

// Find the beginning of the next word on this line if there is one
// return FALSE if no new words
int TextItem::FindBeginOfWord(int doSkip)
{
	CPoint cp = CursorIndex;
	char ch;

	for(int i = cp.x+doSkip; i < TxtLines[cp.y].GetLength(); i++) {
		ch = TxtLines[cp.y][i];
		if (IS_ALPHANUMERIC(ch)) {
			cp.x = i;
			SetCursor(cp);
			return TRUE;
		}
	}
	return FALSE;	// never found a real character
}


// Find the end of the current word on this line
// False if there is an error
int TextItem::FindEndOfWord()
{
	CPoint cp = CursorIndex;
	char ch;
	int i;

	for(i = cp.x; i < TxtLines[cp.y].GetLength(); i++) {
		ch = TxtLines[cp.y][i];
		if (IS_ALPHANUMERIC(ch)) {
			continue;
		}
		break;
	}
	if (cp.x == i) {
		return FALSE;
	}
	cp.x = i;
	SetCursor(cp);
	return TRUE;	// never found a real character
}

int TextItem::DoSpellCheck()
{
	int i = 0;

	if (theApp.m_isDemo == DEMO_ON) {
		return FALSE;
	}

	SpellChk spell;
	if( spell.GetError() > 0) 
		return FALSE;

	// Loop through TextLines until empty string is found
	CString raw_word, corrected_word;
	int 	start_x, 
		end_x, rawlen, corrlen, doSkip;
	CPoint 	spell_cursor,
		ptLastGood = CursorIndex;

	CursorIndex = CPoint(0,0);	// Start at the beginning

	for( i = 0; i < MAX_TEXT_LINES; ++i) {
		if( TxtLines[i].IsEmpty()) {
			break;
		}
		spell_cursor.y = i;
		spell_cursor.x = 0;
		start_x = 0;
		SetCursor(spell_cursor);
		doSkip=0;
		while( TRUE) {	// later_wrw this was iscursorvalid
			if (FindBeginOfWord(doSkip) == FALSE)	// make sure we are at the beginning of a word
				break;

			start_x = CursorIndex.x;	// point to the beginning of the word
			doSkip = 0;	// After first word we skip the last character

			if( FindEndOfWord() == FALSE) 	// Now find the end of the word
				break;
			end_x = CursorIndex.x;			// Point to just after the last character in word

			spell_cursor = CursorIndex;

			// Copy the word out of the box
			raw_word = TxtLines[i].Mid( start_x, end_x - start_x);

			// Remember the length
			rawlen = raw_word.GetLength();

			// Check the word

			char *sptr = (char *)(LPCTSTR)raw_word;
			int isNumber=0;
			while (*sptr) {
				if (IS_NUMBER(*sptr)) {
					isNumber++;
				}
				sptr++;
			}
			if (isNumber == rawlen) {
				isNumber = 0;	// skip spell check on numbers
			}
			else if( spell.CheckWord(raw_word) == FALSE)	{			// Set the word to be checked
				spell.SetOriginalWord(raw_word);                // set the original word string
				if( spell.DoModal() == IDOK) {					// and do the check
					corrected_word = spell.GetCorrectedWord();	// User corrected the word

					corrlen = corrected_word.GetLength();		// get length of new word

					// Replace raw_word with corrected_word for now...
					CString left_string = TxtLines[i].Mid( 0, start_x);
					CString right_string = TxtLines[i].Mid( start_x+rawlen);
					TxtLines[i] = left_string + corrected_word + right_string;

					left_string = TxtShapes[i].Mid( 0, start_x);
					right_string = TxtShapes[i].Mid( start_x+rawlen);
					CString mid_shapes="";
					// and the right number of shape placeholders
					for(int j=0; j < corrlen; j++) {
						mid_shapes += (char) 1;
					}
					TxtShapes[i] = left_string + mid_shapes + right_string;

					CStringW left_stringw = TxtAttrs[i].Mid( 0, start_x);
					CStringW right_stringw = TxtAttrs[i].Mid( start_x+rawlen);
					CStringW mid_attrw="";
					// and the right number of attr chars
					for(int j=0; j < corrlen; j++) {
						mid_attrw += cCurrAttr;
					}
					TxtAttrs[i] = left_stringw + mid_attrw + right_stringw;

					TestAttrState();

					// Reset the cursor to the end of the new word
					spell_cursor.x = start_x + corrlen;           
				}
			}

			ptLastGood = CursorIndex;
			SetCursor(spell_cursor);
			if( spell.GetError() > 0) {
				char string[128];
				wsprintf(string,"Spellcheck Aborted");
				AfxMessageBox(string);
				SetCursor(ptLastGood);
				return OK;
			}
		}
	}

	SetCursor(ptLastGood);

	char string[128];
	wsprintf(string,"Spellcheck Complete");
	AfxMessageBox(string);
	return OK;
}

float TextItem::Message(int message, float number, int *status)
{
	float RI = 0.0;

	switch(message) {
		case TEXT_SET_DZOOM:
			RI = dCurrentZoom;
			dCurrentZoom = number;
			*status = OK;

			float upem = 2048.00;
			float points = zPointSize;

			float points_per_inch = 72.00;
			// Equation from page 4 of 40 in the Apple's Font Engine reference
			float scale = ( points * (float)PIXELS_PER_INCH ) 
				/ ( points_per_inch * upem );

			zMargin = (int) ((float)MARGIN * scale * dCurrentZoom);
			zBorderArtMargin = (int) ((float)BORDERARTMARGIN * scale * dCurrentZoom);
			if (BorderArtType > BORDER_ART_TYPE_NONE) {
				zMargin = (int) ((float)(MARGIN + BORDERARTMARGIN) * scale * dCurrentZoom);
			}

			if (BorderArtCurrentZoom != dCurrentZoom) {
				BorderArtZoomSize.x = (int)(((float)BorderArtSize.x + 0.5) * dCurrentZoom);
				BorderArtZoomSize.y = (int)(((float)BorderArtSize.y + 0.5) * dCurrentZoom);
				BorderArtMarginZoomSize.SetPoint(0, 0);
				BorderArtCurrentZoom = dCurrentZoom;
				allowFixWrap = TRUE;
				BorderArtZoomChanged = TRUE;
			}
			break;
	}
	return(RI);
}


int 
TextItem::Message( int message, int number, int *status)
{
#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TextItem::Message(int,int,int*)"); 
#endif

	// Return Integer
	int RI = 0;

	switch(message) {
		case ITEM_NONE:
			*status = ERROR;
			break;

		case DOC_STORY_PUSH_TEXT:
			*status = OK;
			if (StoryNumber > 0 && StoryItemOrder == theApp.m_iStoryOverflowBox) {
				int tempStatus = TEXT_DRAW_ALL;
				if (theApp.m_iStoryOverflowDirection > 0 && (!StoryBoxFull || theApp.m_iStoryOverflowDirection == 2 || StoryFlowInState == STORY_FLOW_INSERT)) {// Push (insert or append) characters
					if (theApp.m_iStoryOverflowDirection == 2 || StoryFlowInState == STORY_FLOW_INSERT) {
						CursorIndex.y = 0;
						CursorIndex.x = 0;
					}
					theApp.m_iStoryOverflowBox = 0;
					int t=0;
					int max = theApp.m_strStoryOverflowText.GetLength();
					CString csPush = theApp.m_strStoryOverflowText;
					CString csPushShapes = theApp.m_strStoryOverflowShapes;
					theApp.m_strStoryOverflowText.Empty();
					theApp.m_strStoryOverflowShapes.Empty();
					for (t=0; t<max; t++) {
						IsFromSpecialCharDlg = (csPushShapes.GetAt(t) > 1);
						KeyDown((csPushShapes.GetAt(t) == SHAPE_EXTENDED ? csPush.GetAt(t) + SHAPES_START_EXTENDED : csPush.GetAt(t)), &tempStatus);
					}
					IsFromSpecialCharDlg = FALSE;
					theApp.m_iStoryOverflowDirection = 0;
					theApp.m_bStoryTextWasMoved = TRUE;
				}
				else {
					theApp.m_iStoryOverflowBox++;
				}
			}
			else {
				theApp.m_iStoryOverflowBox++;
			}
			break;

		case DOC_STORY_COLLECT:
			*status = OK;
			if (StoryNumber > 0 && StoryItemOrder == theApp.m_iStoryOverflowBox) {
				int tempStatus = TEXT_DRAW_ALL;
				int i = 0;
				for(i = 0; i < (MAX_TEXT_LINES+1); ++i) {
					if (i > 0 || TxtLines[i].GetLength() > 1) {
						theApp.m_strStoryDistributeText += TxtLines[i];
						theApp.m_strStoryDistributeShapes += TxtShapes[i];
					}
					TxtLines[i].Empty();
					TxtShapes[i].Empty();
					TxtAttrs[i].Empty();
				}
				TxtLines[0].AppendChar((char)SW_BOL);
				TxtShapes[0].AppendChar((char)SHAPE_NONE);
				TxtAttrs[0].AppendChar((char)DELCHAR);
				StoryBoxFull = FALSE;
				StoryFlowInState = STORY_FLOW_APPEND;
				StoryFlowOutState = STORY_FLOW_APPEND;
				CursorIndex.y = 0;
				CursorIndex.x = 0;
				SelectionOn = FALSE;
				nOverfullWarning = 0;
				noGrowState = 0;
				if (IsLastItemInStory) {
					theApp.m_iStoryOverflowBox = 0;
				}
				else {
					theApp.m_iStoryOverflowBox++;
				}
			}
			else {
				theApp.m_iStoryOverflowBox++;
			}
			break;

		case TEXT_SET_STORY_ITEM_ORDER:
			StoryItemOrder = number;
			IsLastItemInStory = (*status == 1);
			break;

		case TEXT_SET_BORDER_ART:
			if (IsPositionOKForBorderArt()) {
				RestoreBorderArt();
				*status = OK;
			}
			else {
				MessageBeep(MB_ICONEXCLAMATION);
				*status = ERROR;
			}
			break;

		case ITEM_DIALOG_EDIT:
			// moving to source/sw
			//RI = ItemDialogEdit();
			IncUndoLevel();
			RI = DoFontDialog(number);
			*status = OK;
			break;

		case TEXT_DO_BORDER_ART_DLG:
			RI = DoBorderArtDialog();
			//Message(ITEM_ENTER_EDIT_MODE, EMPTY_INT, status);
			*status = OK;
			break;

		case KEY_DOWN:
			StoryFlowInState = STORY_FLOW_INSERT;
			KeyDown(number, status);        
			break;

		case PAGE_ACTIVATED:
			WriteTextBar();
			break;

		case ITEM_ENTER_EDIT_MODE:
			IncUndoLevel();
			SetCursor(CPoint(0,0));
			ReadTextBar();         // On box creation, get current setting
			*status = OK;
			break;                      

		case ITEM_EXIT_EDIT_MODE:
			theApp.m_iStoryOverflowDirection = 0;
			theApp.m_iStoryOverflowBox = 0;
			theApp.m_strStoryOverflowText.Empty();
			theApp.m_strStoryOverflowShapes.Empty();
			IncUndoLevel();
			nCursorActive = FALSE;
			DisableButtons();
			*status = OK;
			break;

		case SPELL_SELECTED_ITEM:
			IncUndoLevel();
			DoSpellCheck();
			*status = OK;
			break;

		case TEXTITEM_GET_LINEHEIGHT:
			RI = -TextLineYs;	// Return the line height (positive number)
			*status = OK;
			break;

		case BBOX_ITEM_WHATAMI:
			RI = ITEM_TEXT_TYPE;
			*status = OK;
			break;

		case TEXT_SET_ZOOM:
			RI = 0;
			*status = OK;
			zPointSize = ((float)nPointSize * dCurrentZoom);
			CalcLinePointSpace();
			if (BorderArtCurrentZoom != dCurrentZoom) {
				BorderArtZoomSize.x = (int)(((float)BorderArtSize.x + 0.5) * dCurrentZoom);
				BorderArtZoomSize.y = (int)(((float)BorderArtSize.y + 0.5) * dCurrentZoom);
				BorderArtMarginZoomSize.SetPoint(0, 0);// Forces recalc
				BorderArtCurrentZoom = dCurrentZoom;
			}
			break;

		case TEXT_SET_STORY_INCLUDE:
			if (number < 1) {
				StoryLines = 0;
				StoryLinesChanged = TRUE;
				StoryItemOrder = 0;
				IsLastItemInStory = FALSE;
			}
			else if (number != StoryNumber) {
				StoryLines = 1;
				for(int i=1; i < MAX_TEXT_LINES; i++) {
					if (TxtLines[i].IsEmpty()) {
						StoryLines = i;
						break;
					}
				}
			}
			StoryNumber = number;
			*status = OK;
			break;

		case TEXT_DOCUT:
			IncUndoLevel();
			doTextCutCopy(message);
			*status = TEXT_DRAW_ALL;
			break;
		case TEXT_DOCOPY:
			IncUndoLevel();
			doTextCutCopy(message);
			*status = OK;
			break;
		case TEXT_DOPASTE:
			IncUndoLevel();
			doTextPaste();
			*status = OK;
			break;
#ifdef LATER_WRW
		case TEXT_SET_KERNING:
			if (number != doKerning) {
				doKerning = number;
				*status = OK;
			}
			else {
				*status = ERROR;
			}
			break;

		case TEXT_GET_KERNING:
			RI = doKerning;
			*status = OK;
			break;
#endif
		case TEXT_SET_ORIENTATION:
			nOrientation = number;
			break;

		case TEXT_SET_SPACE_WIDTH:
			spaceWidth = BASE_SPACEWID * number;	// 360, 720, 900
			resetGlyfPos();
			break;
		case TEXT_UNDO:
			textHandleUndo();
			*status = OK;
			break;
		case TEXT_IS_OVERFULL:
			RI = (boxIsOverFull ? 1 : 0);
			*status = OK;
			break;

		default:
			//RI = pBBoxes[nCurrentBBox]->Message( message, number, status);
			*status = ERROR;
			break;
	}

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::Message: %d", status); 
#endif

	return RI;
}

CPoint
TextItem::Message( int message, CPoint point, int *status)
{
#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TextItem::Message(int,CPoint,int*)"); 
#endif

	// Return CPoint
	CPoint RCP;
	RCP.x = 0;
	RCP.y = 0;    

	CPoint cpTemp(0, 0);
	switch(message)
	{

	case ITEM_NONE:
		*status = ERROR;
		break;	    

	case ITEM_ENTER_EDIT_MODE:
		// So we try to set the cursor where we got clicked.
		//IncUndoLevel();
		//InsertUndoItem(UNDO_MOUSECLICK,0);
		m_bSetCursorToClicked = TRUE;
		m_ptClicked = point;
		WriteTextBar();
		*status = OK;
		break;

	case DOC_GET_INVALIDATE_POS:
		if( pParentBBox != NULL) {
			RCP = pParentBBox->Message( BBOX_POSITION_GET, cpTemp, status);
			//AfxMessageBox("Returning pos!");
			*status = OK;
		}
		break;

	case DOC_GET_INVALIDATE_SIZE:
		if( pParentBBox != NULL) {
			RCP = pParentBBox->Message( BBOX_SIZE_GET, cpTemp, status);
			//AfxMessageBox("Returning size!");
			*status = OK;
		}
		break;

	case TEXT_SET_SCROLL_POS:
		ScrollPos = point;
		*status = OK;
		break;

	case TEXT_SET_BORDER_ART_SCROLL:
		BorderArtScrollPos = point;
		*status = OK;
		break;

	case TEXT_GET_CURSOR_POS:
		RCP = CursorPos;
		*status = CursorLength;
		break;

	case DOC_STORY_GET_MOVEPOINT:
		if( pParentBBox != NULL) {
			RCP.x = StoryCursorMousePos.x + (int)(dCurrentZoom * ((float)point.x + (float)1.0));
			RCP.y = StoryCursorMousePos.y + (int)(dCurrentZoom * (float)20.0);
			*status = OK;
		}
		break;

	case TEXT_SET_SELECTION:
		//IncUndoLevel();
		RCP = CPoint(0,0);
		if (SelectionOn == FALSE) {
			SelCursorPos = point;	// Set the selection base position
			SelCursorIndex = CPoint(-1,-1);	// default to clear
			SelectionOn = TRUE;		// and turn selection on
			m_bSetSelCursor = 3;	// Need to set position
		}
		m_bSetCursorToClicked = TRUE;
		m_ptClicked = point;
		*status = TEXT_DRAW_SELECTION;
		break;

	case TEXT_SELECTION_OFF:
		//IncUndoLevel();
		SelectionOn = FALSE;
		SelCursorPos = CPoint(-1,-1);
		SelCursorIndex = CPoint(-1,-1);
		SelCursorDrawn = CPoint(-1,-1);

		*status = OK;
		break;

		/*
		case ITEM_EXIT_EDIT_MODE:
		nCursorActive = FALSE;
		*status = OK;
		break;
		*/	    
	default:
		//RCP = pBBoxes[nCurrentBBox]->Message( message, point, status);
		*status = ERROR;
	}

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::Message: %d", status); 
#endif

	return RCP;
}

Module*
TextItem::Message( int message, Module *pmodule, int *status)
{
#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER TextItem::Message(int,Module*,int*)"); 
#endif

	// Return Module
	Module *RM = NULL;
	TextItem *pntext = NULL;
	int i = 0;

	switch(message)
	{
	case ITEM_NONE:
		*status = ERROR;
		break;

	case ITEM_PARENT_SET:
		RM = pParentBBox;
		pParentBBox = pmodule;
		*status = OK;
		break;

		/*
		case GET_ITEM_FOR_REDRAW:
		RM = this;
		*status = OK;
		break;
		*/

	case ITEM_RETURN_COPY:
		IncUndoLevel();
		pntext = new TextItem();

		for( i = 0; i < MAX_TEXT_LINES && *status != TEXT_NO_TEXT_COPY; ++i) {
			if(TxtLines[i].IsEmpty()) 
				break;
			pntext->TxtLines[i] = TxtLines[i];
			pntext->TxtShapes[i] = TxtShapes[i];
			pntext->TxtAttrs[i] = TxtAttrs[i];
		}

#ifdef LATER_WRW
		for( i=0; i < MAX_GLYF_ARRAY; i++) {
			/* Clear the data for reset on this copy */
			/* before we copy else the points will be shared */
			CharArray[i].charVal = 0;
			CharArray[i].arrowFlag = 0;
			CharArray[i].overlayFlag = 0;
			CharArray[i].valUsed = 0;
			CharArray[i].dotFlag = 0;
			CharArray[i].mathFlag = 0;
			CharArray[i].AData.FreeMemory();
			CharArray[i].DData.FreeMemory();
			CharArray[i].CData.FreeMemory();

			pntext->CharArray[i] = CharArray[i];
		}
#else
		for( i=0; i < MAX_GLYF_ARRAY; i++) {
			/* Clear the data for reset on this copy */
			/* before we copy else the points will be shared */
			pntext->CharArray[i].charVal = CharArray[i].charVal;
			pntext->CharArray[i].arrowFlag = CharArray[i].arrowFlag;
			pntext->CharArray[i].overlayFlag = CharArray[i].overlayFlag;
			pntext->CharArray[i].valUsed = CharArray[i].valUsed;
			pntext->CharArray[i].dotFlag = CharArray[i].dotFlag;
			pntext->CharArray[i].mathFlag = CharArray[i].mathFlag;
			for(int fsi=0; fsi < MAX_FS_FONTS; fsi++) {
				pntext->CharArray[i].fsFlag[fsi] = CharArray[i].fsFlag[fsi];
			}

			pntext->CharArray[i].width = CharArray[i].width;
			CharArray[i].CharData.Copy(&(pntext->CharArray[i].CharData));
			CharArray[i].ArrowData.Copy(&(pntext->CharArray[i].ArrowData));
			CharArray[i].OverlayData.Copy(&(pntext->CharArray[i].OverlayData));
			CharArray[i].DotData.Copy(&(pntext->CharArray[i].DotData));
			pntext->CharArray[i].connectTheDotsFlag = CharArray[i].connectTheDotsFlag;
			CharArray[i].ConnectTheDotsData.Copy(&(pntext->CharArray[i].ConnectTheDotsData));

			for(int dfsi=0; dfsi<MAX_FS_FONTS; dfsi++) {
				CharArray[i].DataFS[dfsi].Copy(&(pntext->CharArray[i].DataFS[dfsi]));
			}
		}
#endif
		// something in here is bad -- when you delete the copy of the box
		for(i=0; i < MAX_FS_FONTS; i++) {
			for(int j=0; j < MAX_GLYF_ARRAY;j++) {
				fsData[i].ArrayFontFS[j].Copy(&(pntext->fsData[i].ArrayFontFS[j]));
			}
			//pntext->fsData[i].ArrayFontFS;
			for(int j=0; j < MAX_GLYF_ARRAY;j++) {
				pntext->fsData[i].ArrayInfoFS[j] = fsData[i].ArrayInfoFS[j];
			}
			pntext->fsData[i].DoThisFS = fsData[i].DoThisFS;
			pntext->fsData[i].FilenameFS = fsData[i].FilenameFS;
			pntext->fsData[i].FormatFS = fsData[i].FormatFS;
			pntext->fsData[i].nAnnoyingMsgFS = fsData[i].nAnnoyingMsgFS;
			pntext->fsData[i].nDot2DotFS = fsData[i].nDot2DotFS;
			pntext->fsData[i].nDot2DotFSButton = fsData[i].nDot2DotFSButton;
			pntext->fsData[i].nDrawingFontFS = fsData[i].nDrawingFontFS;
			pntext->fsData[i].nWidthFS = fsData[i].nWidthFS;
			pntext->fsData[i].TTFontFS;
		}
		pntext->sFontName = sFontName;
		pntext->sFontIndex = sFontIndex;
		pntext->myFontInfo = myFontInfo;
		// pParentBBox?
		pntext->FontPath = FontPath;
		//m_ptClicked
		//m_bSetCursorToClicked
		pntext->lastPointSize = lastPointSize;
		pntext->zLastPointSize = zLastPointSize;
		pntext->lastFont = lastFont;
		pntext->TextLineYs = TextLineYs;
		pntext->uzTextLineYs = uzTextLineYs;
		//nDrawingArrows

		pntext->DensityFormat = DensityFormat;
		pntext->ShadeFormat = ShadeFormat;
		pntext->ArrowsFormat = ArrowsFormat;
		pntext->OverlayFormat = OverlayFormat;
		pntext->nStartDot = nStartDot;
		//pntext->doDrawGlyf = doDrawGlyf;

		pntext->FontFile= FontFile;
		pntext->ArrowFile = ArrowFile;
		pntext->OverlayFile = OverlayFile;
#ifdef SW50	
		pntext->StartDotFile = StartDotFile;
#endif
		pntext->nLinePointSpace = nLinePointSpace;
		pntext->nPointSize = nPointSize;
		pntext->nDot2Dot = nDot2Dot;

		pntext->nDot2DotDensityButton = nDot2DotDensityButton;
		pntext->nDot2DotShadeButton = nDot2DotShadeButton;
		pntext->nDot2DotLinesButton = nDot2DotLinesButton;
		pntext->nDot2DotArrowsButton = nDot2DotArrowsButton;
		pntext->nDot2DotOverlayButton = nDot2DotOverlayButton;
		pntext->doDrawConnectTheDots = doDrawConnectTheDots;

		pntext->nDot2DotDensity = nDot2DotDensity;
		pntext->nDot2DotShade = nDot2DotShade;
		pntext->nDot2DotArrows = nDot2DotArrows;
		pntext->nDot2DotOverlay = nDot2DotOverlay;
		pntext->nDot2DotStartDot = nDot2DotStartDot;
		pntext->nDot2DotConnectTheDots = nDot2DotConnectTheDots;
		pntext->doKerning = doKerning;
		pntext->inCursive = inCursive;
		pntext->nLetterSpacing = nLetterSpacing;
//		pntext->LedgerPenWidthOrig = LedgerPenWidthOrig;
		pntext->LedgerPenTopWidth = LedgerPenTopWidth;
		pntext->LedgerPenMidWidth = LedgerPenMidWidth;
		pntext->LedgerPenBasWidth = LedgerPenBasWidth;
		pntext->LedgerPenBotWidth = LedgerPenBotWidth;

		pntext->ColorTopAreaShading = ColorTopAreaShading;
		pntext->IsShadingOnTopArea = IsShadingOnTopArea;
		pntext->ColorMiddleAreaShading = ColorMiddleAreaShading;
		pntext->IsShadingOnMiddleArea = IsShadingOnMiddleArea;
		pntext->ColorDescenderAreaShading = ColorDescenderAreaShading;
		pntext->IsShadingOnDescenderArea = IsShadingOnDescenderArea;
		pntext->ColorStrokeArrows = ColorStrokeArrows;
		pntext->ColorStartingDot = ColorStartingDot;
		pntext->ColorOutlineOverlay = ColorOutlineOverlay;
		pntext->ColorDecisionDots = ColorDecisionDots;
		pntext->ColorConnectTheDots = ColorConnectTheDots;
		pntext->ColorFirstStrokeLetters = ColorFirstStrokeLetters;
		pntext->ColorSecondStrokeLetters = ColorSecondStrokeLetters;
		pntext->ColorThirdStrokeLetters = ColorThirdStrokeLetters;
		pntext->ColorFourthStrokeLetters = ColorFourthStrokeLetters;
		//pntext->ColorGuidelineTop = ColorGuidelineTop;
		//pntext->ColorGuidelineMiddle = ColorGuidelineMiddle;
		//pntext->ColorGuidelineBase = ColorGuidelineBase;
		//pntext->ColorGuidelineBottom = ColorGuidelineBottom;

		pntext->BorderArtFile[0] = BorderArtFile[0];
		pntext->BorderArtFile[1] = BorderArtFile[1];
		pntext->BorderArtFile[2] = BorderArtFile[2];
		pntext->BorderArtFile[3] = BorderArtFile[3];
		pntext->BorderArtFile[4] = BorderArtFile[4];
		pntext->BorderArtFile[5] = BorderArtFile[5];
		pntext->BorderArtFile[6] = BorderArtFile[6];
		pntext->BorderArtFile[7] = BorderArtFile[7];
		pntext->BorderArtCurrentZoom = BorderArtCurrentZoom;
		pntext->BorderArtSizeOption = BorderArtSizeOption;
		pntext->BorderArtSize = BorderArtSize;
		pntext->BorderArtZoomSize = BorderArtZoomSize;
		pntext->BorderArtMarginSize = BorderArtMarginSize;
		pntext->BorderArtMarginZoomSize = BorderArtMarginZoomSize;
		pntext->BorderArtAdjustment = BorderArtAdjustment;
		pntext->BorderArtAdjustmentZoom = BorderArtAdjustmentZoom;
		pntext->BorderArtScrollPos = BorderArtScrollPos;
		pntext->BorderArtType = BorderArtType;
		pntext->BorderArtShrink = BorderArtShrink;
		pntext->BorderArtSource = BorderArtSource;
		//pntext->BorderArtZoomChanged = TRUE;// In case they're in a different Zoom when they paste than when they copied

		RM = pntext;
		break;

	default:
		//RM = pBBoxes[nCurrentBBox]->Message( message, pmodule, status);
		*status = ERROR;
	}

#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT TextItem::Message: %d", status); 
#endif

	return RM;
}




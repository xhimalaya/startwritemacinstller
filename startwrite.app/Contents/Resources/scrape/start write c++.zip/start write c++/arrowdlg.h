// arrowdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CArrowDlg dialog

class CArrowDlg : public CDialog
{
// Construction
public:
	CArrowDlg(CWnd* pParent = NULL);	// standard constructor

	int m_iArrows;
	
// Dialog Data
	//{{AFX_DATA(CArrowDlg)
	enum { IDD = IDD_ARROWS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CArrowDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedArrowsNormal();
};

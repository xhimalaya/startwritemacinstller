#if !defined(AFX_SWABOUTDEMODLG_H__6EACC282_A842_11D3_B60A_444553540000__INCLUDED_)
#define AFX_SWABOUTDEMODLG_H__6EACC282_A842_11D3_B60A_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// swAboutDemoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDemoAboutDlg dialog

class CDemoAboutDlg : public CDialog
{
// Construction
public:
	CDemoAboutDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDemoAboutDlg)
	enum { IDD = IDD_ABOUT_DEMO1 };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
// Implementation
protected:
	RECT		m_rectSplash;

protected:

	// Generated message map functions
	//{{AFX_MSG(CDemoAboutDlg)
	afx_msg void OnActivate();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedPurchase();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWABOUTDEMODLG_H__6EACC282_A842_11D3_B60A_444553540000__INCLUDED_)

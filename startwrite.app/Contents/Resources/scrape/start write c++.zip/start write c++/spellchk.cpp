// spellchk.cpp : implementation file
//
#include "stdafx.h"
#include "sw.h"
#include "spellchk.h"

#ifndef SSCE_S16
#define SSCE_S16 S16
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SpellChk dialog
SpellChk::SpellChk(CWnd* pParent /*=NULL*/)
	: CDialog(SpellChk::IDD, pParent)
{
	//{{AFX_DATA_INIT(SpellChk)
	m_OriginalWord = "";
	m_CorrectedWord = "";
	m_replacelist = "";
	//}}AFX_DATA_INIT
	CString clxfile;
	CString tlxfile;
	CString swFile;	// startwrite lexicon
    int rv = 0;  
	isLocalLex=false;
	           
	if ((theApp.m_isDemo == DEMO_ON) || (*swType == swOXD)) {
		char string[128];
		wsprintf(string,"Speller not available in Demo mode.");
		AfxMessageBox(string);
		SpellCheckError = TRUE;
		return;
	}		   
	
	SpellCheckError = FALSE;
	// Lexicon path...
	LexiconPath = (CString)AfxGetApp()->m_pszHelpFilePath;
	LexiconPath = LexiconPath.Left(LexiconPath.ReverseFind('\\'));
	LexiconPath += "\\LEXICONS\\";
	if (doRunUKVersion || (*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {	//SHERSTON
		clxfile = "sscebr2.clx";
		tlxfile = "sscebr.tlx";
	}
	else {
		clxfile = "ssceam2.clx";
		tlxfile = "ssceam.tlx";
	}
	swFile = "sscesw.lex";

	rv = lexicon[0].Open(&ssce, LexiconPath+tlxfile);
	if (rv < 0) {
		char string[128];
		wsprintf(string,"Unable to open lexicon %s: <%d>", LexiconPath+tlxfile, rv);
		AfxMessageBox(string);
		SpellCheckError = TRUE;
	}
	else {
		rv +=lexicon[1].Open(&ssce, LexiconPath+clxfile);

		if( rv < 0 )
		{
			char string[128];
			wsprintf(string,"Unable to open lexicon %s: <%d>",LexiconPath+clxfile, rv);
			AfxMessageBox(string);
			SpellCheckError = TRUE;
		}
		else {
			// First create if not already there
			lexicon[2].Create(&ssce, LexiconPath+swFile, SSCE_AMER_ENGLISH_LANG);
			rv += lexicon[2].Open(&ssce, LexiconPath+swFile);
			if (rv < 0) {
				lexicon[2].Create(&ssce, theApp.m_strDocPath+swFile, SSCE_AMER_ENGLISH_LANG);
				rv += lexicon[2].Open(&ssce, theApp.m_strDocPath+swFile);
				if (rv < 0) {
					//char string[128];
					//wsprintf(string,"Unable to open lexicon %s: <%d>",LexiconPath+swFile, rv);
					//AfxMessageBox(string);
				}
				else {
					isLocalLex=true;
				}
			}
			else {
				isLocalLex=true;
			}
		}
	}
}

void SpellChk::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SpellChk)
	DDX_Text(pDX, IDC_ORIGINAL_WORD, m_OriginalWord);
	DDX_Text(pDX, IDC_CORRECTED_WORD, m_CorrectedWord);
	DDX_LBString(pDX, IDC_SUGGESTED_WORDS, m_replacelist);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(SpellChk, CDialog)
	//{{AFX_MSG_MAP(SpellChk)
	ON_BN_CLICKED(IDC_SUGGEST, OnSuggest)
	ON_LBN_DBLCLK(IDC_SUGGESTED_WORDS, OnDblclkSuggestedWords)
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(ID_QUIT, OnQuit)
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnAdd)
	ON_LBN_SELCHANGE(IDC_SUGGESTED_WORDS, OnSelchangeSuggestedWords)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SpellChk Custom Fucntions

int
SpellChk::GetError()
{
	return SpellCheckError;
}

int
SpellChk::CheckWord(CString word)
{
	SSCE_CHAR rbuf[SSCE_MAX_WORD_SZ+2];

	if( ssce.CheckWord( 0, (SSCE_CHAR *)word.GetBuffer(32), rbuf, SSCE_MAX_WORD_SZ+1) != 0)
	{
		word.ReleaseBuffer();
		return FALSE;
	}

	word.ReleaseBuffer();
	return TRUE;
}

int
SpellChk::SetOriginalWord(CString word)
{
	m_OriginalWord = word;
	m_CorrectedWord = word;

	return TRUE;
}

CString
SpellChk::GetCorrectedWord()
{
	return m_CorrectedWord;
}

/////////////////////////////////////////////////////////////////////////////
// SpellChk message handlers

BOOL SpellChk::OnInitDialog()
{
	CDialog::OnInitDialog();

	OnSuggest();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void SpellChk::OnSuggest()
{
	// TODO: Add your control notification handler code here
    int srv = 0;
	SSCE_CHAR buffer[1024];
	SSCE_S16 scores[32];

	srv = ssce.Suggest( (SSCE_CHAR *)m_OriginalWord.GetBuffer(32), 
						35, buffer, sizeof(buffer), scores, 32);

    m_OriginalWord.ReleaseBuffer(-1);
    
	CListBox *lbptr = (CListBox *)this->GetDescendantWindow(IDC_SUGGESTED_WORDS);

	char *strptr = (char *)buffer;

	for( int pos=0, r = 0; r < 256; ++r, ++strptr)
	{
		if( strptr[0] == NULL) { break;}
		lbptr->InsertString(pos++, strptr);
		while( strptr[0] != NULL) { ++r; ++strptr;}
	}
}

// A double click replaces the word
void SpellChk::OnDblclkSuggestedWords()
{
	OnOk();
}

void SpellChk::OnOk()		// This is the replace code
{
	// TODO: Add your control notification handler code here
	CDialog::OnOK();
}

void SpellChk::OnCancel()
{
	// TODO: Add extra cleanup here

	CDialog::OnCancel();	// This is really a skip, cancel this word
}


// Quit the spelling process
void SpellChk::OnQuit()
{
	SpellCheckError = TRUE;		// Make sure the calling function knows we quit
	CDialog::OnCancel();
}

void SpellChk::OnAdd()
{
	int retv;
	if (isLocalLex) {
		retv = lexicon[2].AddWord((const unsigned char *)(LPCSTR)m_OriginalWord, SSCE_IGNORE_ACTION, NULL);
		CDialog::OnCancel();
	}
	else {
		AfxMessageBox("Unable to create local spelling dictionary");
	}
}

void SpellChk::OnSelchangeSuggestedWords()
{
	// TODO: Add your control notification handler code here
	CListBox *lbptr = (CListBox *)this->GetDescendantWindow(IDC_SUGGESTED_WORDS);
	lbptr->GetText( lbptr->GetCurSel(), m_CorrectedWord);
	CEdit *eptr = (CEdit *)this->GetDescendantWindow(IDC_CORRECTED_WORD);
	eptr->SetWindowText(m_CorrectedWord);

}


// Reporting Routines...

#include "Reporter.h"

int
Report( int where, char *string)
{	

#ifndef FREEZ
#ifdef LATER_WRW
	if( where & TO_SCREEN ) {
		cout << string << endl;
		cout.flush();
	}
	
	if( where & TO_FILE ) {
		char report_file[] = "debug.out";

		ofstream fout( report_file, ios::app);

		if (!fout)
		{
			cout << "Reporter: Report: Unable to open report file" << endl;
	 		return ERROR;
		}

		fout << string << endl;
		fout.flush();
	}
#endif
#else
	string;
	where;
#endif
	return OK;
}

int
Report( int where, char *format, char *arg1)
{	
	char string[364];
#ifdef _CRT_SECURE_NO_DEPRECATE
	sprintf(string, format, (char*)arg1);
#else
	sprintf_s(string, sizeof(string), format, (char*)arg1);
#endif
	if( Report( where, string) == OK) { return OK;} 
	return ERROR;
}

int
Report( int where, char *format, int *arg1)
{	
	char string[364];
#ifdef _CRT_SECURE_NO_DEPRECATE
	sprintf(string, format, (int*)*arg1);
#else
	sprintf_s(string, sizeof(string), format, (int*)*arg1);
#endif
	if( Report( where, string) == OK) { return OK;} 
	return ERROR;
}


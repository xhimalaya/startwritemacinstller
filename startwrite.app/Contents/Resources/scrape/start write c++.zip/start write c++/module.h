// Module Abstract Base Class

#ifndef _MODULE_H_
#define _MODULE_H_

#include "stdafx.h"

#include "reporter.h"

// Used when an argument is not needed...
#define EMPTY_INT		0
#define NOT_EMPTY		99
#define EMPTY_CPOINT	CPoint(0,0)
#define EMPTY_MODULE	NULL

class Module
{
public:
   int m_iType;
   
	virtual void Read(fstream *fin, Module *pmodule, int *status) = 0;
	virtual void Write(fstream *fout, Module *pmodule, int *status) = 0;	
		
	virtual void Delete() = 0;
				
	virtual float Message( int message, float number, int *status) = 0;
	virtual int Message( int message, int number, int *status) = 0;
	virtual CPoint Message( int message, CPoint point, int *status) = 0;
	virtual Module* Message( int message, Module *pmodule, int *status) = 0;

	virtual void Draw(CDC* pDC, int *status) = 0;
};

#endif // _MODULE_H_ 
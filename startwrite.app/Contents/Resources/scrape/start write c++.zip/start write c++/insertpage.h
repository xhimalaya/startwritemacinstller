#if !defined(AFX_INSERTPAGE_H__749C9FE2_A56F_48D8_85A4_D43B66A0B499__INCLUDED_)
#define AFX_INSERTPAGE_H__749C9FE2_A56F_48D8_85A4_D43B66A0B499__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InsertPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInsertPage dialog

class CInsertPage : public CDialog
{
// Construction
public:
	CInsertPage(CWnd* pParent = NULL);   // standard constructor
	int m_which;

// Dialog Data
	//{{AFX_DATA(CInsertPage)
	enum { IDD = IDD_INSERT_PAGE };
	int		m_insertPage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInsertPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInsertPage)
	afx_msg void OnOk();
	afx_msg void OnBegDocument();
	afx_msg void OnBeforePage();
	afx_msg void OnAfterPage();
	afx_msg void OnEndDocument();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSERTPAGE_H__749C9FE2_A56F_48D8_85A4_D43B66A0B499__INCLUDED_)

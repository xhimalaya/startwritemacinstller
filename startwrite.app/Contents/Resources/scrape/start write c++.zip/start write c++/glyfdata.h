// Glyph Data Header

#ifndef _GLYF_DATA_H_
#define _GLYF_DATA_H_

#include "TTCommon.h"
#include "TTTypes.h"
#include "Dir.h"
#include "Cmap.h"
#include "Head.h"
#include "Loca.h"

typedef struct segmentData {
	int bx;
	int by;
	int ex;
	int ey;
	bool onFlag;	/* indicates this flag is on */
	//int beginFlag;	/* This segment is the first */
	//int endFlag;	/* This segment is the last */
	struct segmentData *next;
} SEGMENT_DATA;


#define GLYF_ITEMSIZE	128

	#define GLYF_ONCURVE	0x01	
	#define GLYF_XBYTE 		0x02
	#define GLYF_YBYTE		0x04
	#define GLYF_REPEAT		0x08
	#define GLYF_XDUAL 		0x10
	#define GLYF_YDUAL		0x20
	#define GLYF_RESERVED1	0x40
	#define GLYF_RESERVED2	0x80
    
    // Must not have something included...
    #define TRUE 1
    #define FALSE 0
    
	typedef struct GlyfHeader
	{
		Short	NumberOfContours;
		FWord	XMin;
		FWord	YMin;
		FWord	XMax;
		FWord	YMax;	
	} GlyphHeader;

	typedef struct GlyfDescription
	{
		UShort	EndPointsOfContours[GLYF_ITEMSIZE];
		UShort	MaxPoints;
		UShort	InstructionLength;
		// UShort  ?Instructions[??]; // We dont' deal with instructions yet...
		UShort	Flags[GLYF_ITEMSIZE];
		Short	XCoordinates[GLYF_ITEMSIZE];
		Short	YCoordinates[GLYF_ITEMSIZE];
	} GlyfDescription;


class GlyfData
{
	private:

	GlyfHeader gh, *ghp;
	GlyfDescription gd, *gdp;
	void addToList(SEGMENT_DATA *ts);
	void closeList();
	int MakeCurve( CPoint zPt1, CPoint zPt2, CPoint zPt3);
	int recurse_count;

	public:

    ULong Index;
    ULong Offset;
    ULong Size;
	GlyfHeader *Header;
	GlyfDescription *Description;
	SEGMENT_DATA *segPtr;
	SEGMENT_DATA *segList;
	SEGMENT_DATA *segFreeList;
	int segCnt;
	int segListCnt;
	int segAvail;
	int dotValue;
	
#ifdef _DEBUG
	int allocCnt;
	int freeCnt;
#endif


	GlyfData();
	GlyfData(GlyfData *source);
	~GlyfData();

	int CreateGlyf();
	void FreeMemory();
	void SetDots(int newDotValue, bool makeSolid);

	int MakeGlyfPointsAbsolute();
	//int DivideGlyfPointsBy( int divisor);
		
	int GetMaxPoints();
	int GetNumberOfContours();
	int GetEndPoint( int ep);

	int IsOnCurve( int p);
	int IsOffCurve( int p);

	int GetX( int i);
	int GetY( int i);

	int GetXMin();
	int GetYMin();

	void SetXMax(int newX);// in cursive we need to set the spacing value
	int GetXMax();
	int GetYMax();
	
	int SetX( int i, int x);
	int SetY( int i, int y);
	
	int Print();
	void Copy(GlyfData *dest);
	void CopyList(GlyfData *dest);
	void ClearData();
	void releaseSegmentData();
};
	
#endif // _GLYF_DATA_H_
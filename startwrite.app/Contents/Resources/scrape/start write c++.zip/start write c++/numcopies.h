#if !defined(AFX_NUMCOPIES_H__2EC821B8_0C8E_4CD0_8DDC_8D2642595959__INCLUDED_)
#define AFX_NUMCOPIES_H__2EC821B8_0C8E_4CD0_8DDC_8D2642595959__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NumCopies.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNumCopies dialog

class CNumCopies : public CDialog
{
// Construction
public:
	CNumCopies(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNumCopies)
	enum { IDD = IDD_NUM_COPIES };
	UINT	m_numCopies;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNumCopies)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNumCopies)
	afx_msg void OnChangeNumCopies(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NUMCOPIES_H__2EC821B8_0C8E_4CD0_8DDC_8D2642595959__INCLUDED_)

// sw.h : main header file for the SW application
//
//6.0.b54  (11/04/11)
	// try to find registration crash


// 5.0.x212 (02/24/09)
	// Allow UK flag "USE_UK Y" in config

// 5.0.x211 (01/26/09)
	// Fixed NAC Bug where it lost the font name in the file

// 5.0.x210 (09/16/08)
	// Update HWOT arrow font
	// Update New American Cursive upgrade phone

// 5.0.x209
	// Fix Registration crash

// 208 - allow thickneess change for printing

// Fix Thickness value


// 5.0.x157 (11/29/05)
	// Changed registray to currUser settings rather than ROOT key
	// hopefully to allow people to have their personal settings better

// 5.0.x156 (09/27/05)
	// updated ledger dialog to say Guideline
	//  Changes for Sherston menus


// 5.0.x155  (08/13/05)
	// Added handling for XP Theme

// 5.0.x154  (04/21/05)
	// Changed max pages to 300
	


#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#define DEMO_RELEASE	0x10	// FOr unregistered full version
#define DEMO_ON		0x20
#define DEMO_OFF	0x40

#define DEMO_HOPON	0x80	// Demo hop version

// This is for the dialog setting, 
// The offset is one off
#define YELLOW_ON	2
#define YELLOW_OFF	1

#define DEMO_TIME	1		// Days for demo to work

#include "miscutil.h"

extern unsigned char *swType;

const unsigned char swHOP = 'P';	// FULL HOP version
const unsigned char swHPD = 'D';	// HOP Demo version
const unsigned char swREL = 'L';	// FULL RELEASE
const unsigned char swDEM = 'M';	// REGULAR DEMO
const unsigned char swSHR = 'R';	// SHERSTON/FULL
const unsigned char swOXF = 'X';	// Oxford University Press
const unsigned char swOXD = 'W';	// Oxford Demo Version
const unsigned char swRL5 = '5';	// Full Version 5
const unsigned char swUPG = 'U';	// Upgrade to 5.0 from download (Demo)
const unsigned char swUPC = 'C';	// Upgrade from full version (CD)
const unsigned char swNAC = 'A';	// North American Font 
const unsigned char swNAU = 'B';	// North American Font Upgrade
const unsigned char swUPG6 = 'E';	// 6.0 upgrade

/////////////////////////////////////////////////////////////////////////////
// CSwApp:
// See sw.cpp for the implementation of this class
//

class CSwApp : public CWinApp
{
public:
	CSwApp();
	void OpenSpecialConfig();
	void UpdateSpecialConfig(char *key, char *data);
	void ProcessConfig(char *cptr);

	CDC		m_dcPrinter;	// printer instance
	CString m_strDocPath;
	int		m_isDemo;			// If set then we are still in demo mode
	int		m_daysLeft;			// Time until demo goes disabled
	int		m_doThick;			// Has to do with line thickness
	int		m_screenWid;
	int		m_screenHt;
	CString m_BasePath;
	CString	m_strArtPath;
	CString	m_defFont;
	CString	m_lastDocPath;	
	CString	m_splashStr;	/* string for this versions splash */
	CString	m_strStoryOverflowText;// Story overflow text
	CString	m_strStoryOverflowShapes;// Story overflow text/special chars flags
	CString	m_strStoryDistributeText;// Story text for redistribution (can be entire story)
	CString	m_strStoryDistributeShapes;// Story text/special chars flags for redistribution (can be entire story)
	bool	m_bInStoryDistributeMode;// In the process of distributing entire forward Story text
	bool	m_bInStoryCollectMode;// In the process of collecting entire forward Story text
	int		m_iStoryOverflowDirection;// Story overflow text direction (None 0, Push +1(append), +2(insert))
	int		m_iStoryOverflowBox;// StoryItemOrder number of the current text item for Story overflow handling
	bool	m_bStoryTextWasMoved;// When Story text is redistributed or overflowed among related textitems, we need to redraw text
	int		m_nStoryMoveCursorBox;// Move user's typing cursor to this StoryBox
	int		m_nStoryMoveCursorIndex;// Move user's typing cursor after this character index
	bool	m_isGridVisible;
	bool	m_isGridSnapTo;
	bool	m_isGridWiped;
	int		m_iGridX[50];
	int		m_iGridY[50];
	int		m_iGridXUsed[50];
	int		m_iGridYUsed[50];
	int		m_iGridHotX;
	int		m_iGridHotY;
	int		m_iGridMaxX;
	int		m_iGridMaxY;
	int		m_wasDemo;	/* To indicate this is a demo version, possible made full */
	int		m_defPoint;
	bool	m_showGraphics,
			m_TopAreaColorOn,
			m_MidAreaColorOn,
			m_BotAreaColorOn;
	int		m_iDefaultDensity,
			m_iDefaultShading,
			m_iDefaultArrows,
			m_iDefaultLines,
			m_iDefaultKernMode,
			m_isTemplate,
			m_iDefaultSpacing,
			m_iDefaultYellowGuide,
			m_allowWindowsFonts,
			m_iDefaultShadeType,
			m_iDefaultOverlay,
			m_iDefaultStartDot;
	COLORREF m_iDefaultArrowColor,
			m_iDefaultStartDotColor,
			m_iDefaultOverlayColor,
			m_iDefaultDecisionDotColor,
			m_iDefaultConnectDotColor,
			m_iDefaultColorStrokeOne,
			m_iDefaultColorStrokeTwo,
			m_iDefaultColorStrokeThree,
			m_iDefaultColorStrokeFour,
			m_iDefaultColorTopArea,
			m_iDefaultColorMiddleArea,
			m_iDefaultColorBottomArea;

	COLORREF m_crDefaultCustomPalette[16];

	bool	m_DoPowerReload;
	bool m_InSplash;
	DWORD shutdownTime;
	char m_SerialNumber[15];
	bool isNetwork;
	bool isLabPack;
	bool isCorporateVersion;
// Overrides
	virtual BOOL InitInstance();
	virtual void swSetLedgerSettings(FONTINFO *fontPtr);
	virtual void swGetLedgerSettings();
	virtual void swSetDefaultCustomPalette();
	virtual void swGetSettings(char *szName, CString strDocPath, CString strArtPath);
	virtual bool CheckForOldVersion();
	virtual void swSetSettings(CString strDocPath, CString strArtPath, 
							int newDensity,	int newShading, int newArrows, int newLines, 
							int newKerning, int newSpacing, int newShadeType,
							int allowWindowsFonts);
	virtual void setSpaceSettings(int newSpace);
	virtual void setWindowsFontDisplay(int newFontDisplayFlag);
	virtual void setColorSettings(int item, COLORREF newVal);
	virtual void setFontSettings(CString newFontStr, int newPointSize);
	virtual BOOL OnIdle(LONG lCount);
	virtual BOOL ExitInstance();
//	virtual int checkStartTime();
	virtual void DoCancelProduct();

	virtual void SetRegistration(char *email, char *name, char *key, bool get60);
	virtual void GetRegistration(char *email, char *name, char *key, int *flag, bool get60);
	virtual void CheckDemoTime();
	virtual int SetSerialNumber(char *regString);
	virtual int GetSerialNumber(char *regString);
	void SetPrintDocumentName();

// Implementation

	//{{AFX_MSG(CSwApp)
	afx_msg void OnAppAbout();
	afx_msg void OnToolsSettings50();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CSwApp theApp;
extern void setPrintOrientation(short);
extern long artIdValue;
extern bool doRunUKVersion;
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// Power bar button info needed by dialogs...

#include "barinfo.h"

#define SW_CORPORATE_VERSION	105
#define SW_LABPACK_VERSION	106
#define SW_SITELICENSE_VERSION	107

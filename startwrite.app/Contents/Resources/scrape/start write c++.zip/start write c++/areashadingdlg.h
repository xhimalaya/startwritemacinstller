#pragma once
#include "afxwin.h"
#include "colorcombo.h"


// CAreaShadingDlg dialog

class CAreaShadingDlg : public CDialog
{
	DECLARE_DYNAMIC(CAreaShadingDlg)

public:
	CAreaShadingDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAreaShadingDlg();

	int m_isShadingOnTopArea;
	int m_isShadingOnMiddleArea;
	int m_isShadingOnDescenderArea;
	COLORREF m_crTopArea;
	COLORREF m_crMiddleArea;
	COLORREF m_crDescenderArea;
	COLORREF * m_pCustomColors;

	BBox *m_pBox;
	TextItem *m_pTextItem;
	CRect m_rectPreview, m_rectBox;

// Dialog Data
	enum { IDD = IDD_AREASHADING };

protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);

	DECLARE_MESSAGE_MAP()
private:
	CColorCombo m_ColorComboTopArea;
	CColorCombo m_ColorComboMiddleArea;
	CColorCombo m_ColorComboDescenderArea;

public:
	afx_msg void OnBnClickedShadingRadio();
	// Use these settings for all new boxes
	bool m_colorAreaAsDefault;
	afx_msg void OnBnClickedAsDefault();
};

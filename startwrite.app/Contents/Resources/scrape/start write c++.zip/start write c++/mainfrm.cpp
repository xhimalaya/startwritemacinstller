// mainfrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "string.h"
#include "sw.h"

#include "mainfrm.h"
#include "swdoc.h"
#include "swview.h"

#include "miscutil.h"
#include "registration60.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
static int fontsLoaded;

BBox *pCopyBBox = NULL;
BBox *pUndoBBox = NULL;

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	// These have been added by hand - JRL
	ON_CBN_SELCHANGE(IDC_EDIT_BAR_FONT_COMBO, OnSelChangeFont)
	ON_CBN_SELCHANGE(IDC_EDIT_BAR_POINT_COMBO, OnSelChangeSize)
	//ON_CBN_EDITUPDATE(IDC_EDIT_BAR_POINT_COMBO, OnEditupdateSize)	// happens on every keystroke
	ON_CBN_KILLFOCUS(IDC_EDIT_BAR_POINT_COMBO, OnEditkillFocus)
	ON_CBN_SELENDOK(IDC_EDIT_BAR_POINT_COMBO, OnEditkillFocus)
	ON_CBN_CLOSEUP(IDC_EDIT_BAR_POINT_COMBO, OnSelChangeSize)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	// Global help commands
	//ON_COMMAND(ID_HELP_INDEX, CMDIFrameWnd::OnHelpIndex)
	//ON_COMMAND(ID_HELP_USING, CMDIFrameWnd::OnHelpUsing)
	//ON_COMMAND(ID_HELP_FINDER, CMDIFrameWnd::OnHelpFinder)
	ON_COMMAND(ID_HELP_INDEX, MyHelpCheck)
	ON_COMMAND(ID_HELP_USING, MyHelpCheck)
	ON_COMMAND(ID_HELP_FINDER, MyHelpCheck)
	//ON_COMMAND(ID_HELP, CMDIFrameWnd::OnHelp)
	//ON_COMMAND(ID_CONTEXT_HELP, CMDIFrameWnd::OnContextHelp)
	//ON_COMMAND(ID_DEFAULT_HELP, CMDIFrameWnd::OnHelpIndex)
	ON_COMMAND(ID_DEFAULT_HELP, MyHelpCheck)

	ON_UPDATE_COMMAND_UI(ID_VIEW_POWERBAR, OnUpdateControlBarMenu)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_BAR_POINT_COMBO, OnUpdatePointCombo)
	ON_UPDATE_COMMAND_UI(IDC_EDIT_BAR_FONT_COMBO, OnUpdateFontCombo)
	ON_COMMAND_EX(ID_VIEW_POWERBAR, OnBarCheck)
	ON_COMMAND(IDD_PURCHASE, &CMainFrame::OnPurchase)
	ON_UPDATE_COMMAND_UI(ID_HELP_ENTERREGISTRATION, &CMainFrame::OnUpdateHelpEnterRegistration)
	ON_COMMAND(ID_HELP_ENTERREGISTRATION, &CMainFrame::OnHelpEnterRegistration)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// arrays of IDs used to initialize control bars

// powerbar buttons
static UINT BASED_CODE power_bar_buttons[] =
{
	// same order as in the bitmap 'powerbar.bmp'
	ID_SEPARATOR,             
	ID_SEPARATOR,             
	ID_SEPARATOR,             
	ID_SEPARATOR,             
	ID_FORMAT_TEXTSHADING, 
//	ID_SEPARATOR,
	ID_FORMAT_LINEDENSITY,
//	ID_SEPARATOR,
	ID_GUIDELINES,
//	ID_SEPARATOR,
//	ID_GUIDELINES_THICKNESS,
//	ID_SEPARATOR,
//	ID_SEPARATOR,
	ID_FORMAT_TEXTARROWS,
	ID_FORMAT_STARTDOT,
	ID_FORMAT_OVERLAY,
	ID__DECISIONDOTS,
	ID_CONNECTTHEDOTS,
	ID__COLOREDSTROKES,
	ID_FORMAT_YELLOWGUIDE,
//	ID_BIGSPACING,
	ID_STORY_SETINCLUDE,
	ID_BORDER_ART
};

// editbar buttons
static UINT BASED_CODE edit_bar_buttons[] =
{
	// same order as in the bitmap 'editbar.bmp'
	ID_FILE_NEW,
	ID_FILE_OPEN,
	ID_FILE_SAVE,
	ID_FILE_PRINT,
	ID_SEPARATOR,
	ID_EDIT_CUT,
	ID_EDIT_COPY,
	ID_EDIT_PASTE,
	ID_SEPARATOR,
	ID_NEW_ART_ITEM,
	ID_NEW_TEXT_ITEM,
	ID_SEPARATOR,
	ID_DOC_SPELL,
	ID_VIEW_ZOOM,
	ID_FORMAT_FONT,
	ID_SEPARATOR,
	ID_DOCUMENT_PORTRAIT,
	ID_DOCUMENT_LANDSCAPE,
	ID_VIEW_GRIDSHOW
//	ID_SEPARATOR,	// Make plenty of space between 
//	ID_SEPARATOR,	// the main buttons and this
//	ID_SEPARATOR,	// upgrade button
//	ID_SEPARATOR,
//	ID_SEPARATOR,
//	ID_HOP_UPGRADE
};

static UINT BASED_CODE indicators[] =
{
	ID_SEPARATOR,           // status line indicator'
	ID_INDICATOR_SELECT,
	ID_DUMMY_FAKE_PAGE_DEC,
	ID_PAGE_NUMBER,
	ID_DUMMY_FAKE_PAGE_INC,
	ID_SEPARATOR,           // status line indicator'
	ID_DUMMY_FAKE_ZOOM_DEC,
	ID_PAGE_ZOOM,
	ID_DUMMY_FAKE_ZOOM_INC,
	ID_SEPARATOR
};

#define TEXTTXT	0
#define SELTEXT	1
#define PAGEDEC 2
#define PAGEOFP 3
#define PAGEINC 4
#define PAGEZOM 5
#define ZOOMDEC 6
#define ZOOMTXT 7
#define ZOOMINC 8

void FAR PASCAL DrawEntireItem(LPDRAWITEMSTRUCT lpdis, int inflate);
void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction
HBITMAP 	hbmpTT,         
			hbmpMaskTT,
			hbmpA,
			hbmpMaskA,
			hbmpM,
			hbmpMaskMM;

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{

	RemoveFonts();

	if (hbmpTT)
		DeleteObject(hbmpTT);

	if (hbmpMaskTT)
		DeleteObject(hbmpMaskTT);

	if (hbmpM)
		DeleteObject(hbmpM);

	if (hbmpMaskMM)
		DeleteObject(hbmpMaskMM);

	if (hbmpA)
		DeleteObject(hbmpA);

	if (hbmpMaskA)
		DeleteObject(hbmpMaskA);

	if (pCopyBBox != NULL) {
		delete pCopyBBox;
		pCopyBBox = NULL;
	}
	if (pUndoBBox != NULL) {
		delete pUndoBBox ;
		pUndoBBox  = NULL;
	}
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{	
	int x,y,h,w, defh=1000, defw=1000;

	if (theApp.m_screenHt) {
		defh = (theApp.m_screenHt * 2) / 3;
	}
	if (theApp.m_screenWid) {
		defw = (theApp.m_screenWid * 2) / 3;
	}


	y=theApp.GetProfileInt("Settings", "TopY", 100);
	x=theApp.GetProfileInt("Settings", "TopX", 100);
	h=theApp.GetProfileInt("Settings", "BottomY", defh);
	w=theApp.GetProfileInt("Settings", "BottomX", defw);
	if (x < 0) {
		x = 100;
	}
	if (y < 0) {
		y = 100;
	}

	CMDIFrameWnd::SetWindowPos(&this->wndTop, x, y, w, h, SWP_NOACTIVATE);

	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	EnableDocking(CBRS_ALIGN_ANY);

	if (!CreateEditBar()) { return -1;}

	if (!CreatePowerBar()) { return -1;}

	//if (!CreatePaletteBar()) {return -1;}

	if (!CreateStatusBar()) { return -1;}

	setPrintOrientation(DMORIENT_PORTRAIT);	// set default

	hbmpTT = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_TT));
	hbmpMaskTT = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_TT_MASK));
	hbmpA = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_A));
	hbmpMaskA = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_A_MASK));
	hbmpM = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_M));
	hbmpMaskMM = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_M_MASK));

	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// Bar Creation

#define FONT_POS			0
#define POINT_POS			2
#define FONT_ITEM_SIZE 	18
#define LAST_SW_FONT	1

int numSwFonts = LAST_SW_FONT;
int beginMathFonts = -1;

unsigned int defaultFont = 0;	// Default to the first one
unsigned int defaultSizeLoc = 12;	// default position in fontsize array
unsigned int defaultSize = 48;
static unsigned int iFontSizes[] =
{ 8, 10, 12, 14, 16, 18, 20, 22, 24, 30, 36, 42, 48, 54, 60, 66, 72, 96, 128, 144, 160, 192 };

FONTINFO szFonts[MAX_ALLOWED_FONTS] = 
{
//	{"swfont1_.ttf","SWFont 1", 1,0, "swfont1a.ttf"},
//	{"swfont2_.ttf","SWFont 2", 0,0, "swfont2a.ttf"},
//	{"swfont3_.ttf","SWFont 3", 0,0, "swfont3a.ttf"},
//	{"","Arial",0,0,""},
//	{"","Comic Sans MS",0,0,""},
//	{"","Courier New",0,0,""},
//	{"","Century Schoolbook",0,0,""},
//	{"","Times New Roman",0,0,""},
//	{"","Verdana",0,0,""}
	{"","",0,0,""}
};                                     

// possible swfont.fnt data
//{swfnt01_.ttf},{Manuscript},{},{},{swfnt01a.ttf}{Top=0,0,255}{Mid=255,0,0}{Bas=0,0,255}{Bot=-1}
//{FF=swfnt01_.ttf}{FN=Manuscrupt}{Kerning=Yes}{Cursive=<nameornothing>}{AF=swfnt01a.ttf}{Top=0,0,255}{Mid=255,0,0}{Bas=0,0,255}{Bot=-1}

BOOL CMainFrame::CreatePowerBar()
{
	m_wndPowerBar.SetSizes(CSize(39, 39), CSize(32, 32));
	//if (!m_wndPowerBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
	//	| CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))
	if (!m_wndPowerBar.Create(this, WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | TBSTYLE_FLAT, ID_VIEW_POWERBAR))
	{
		TRACE("Failed to create power bar\n");
		return FALSE;       // fail to create
	}
	if (!m_wndPowerBar.LoadBitmap(IDBM_POWERBAR))
	{
		TRACE("Failed to create power bar\n");
		return FALSE;       // fail to create
	}

	CToolBarCtrl& tbCtrl = m_wndPowerBar.GetToolBarCtrl();
	tbCtrl.AddBitmap(1, IDBM_STORYPICT);
	tbCtrl.AddBitmap(1, IDB_BORDERART);
	
	if (!m_wndPowerBar.SetButtons(power_bar_buttons,  sizeof(power_bar_buttons)/sizeof(UINT)))
	{
		TRACE("Failed to create power bar\n");
		return FALSE;       // fail to create
	}

	m_wndPowerBar.SetButtonInfo(FONT_POS, IDC_EDIT_BAR_FONT_COMBO, TBBS_SEPARATOR, 165);
	m_wndPowerBar.SetButtonInfo(POINT_POS, IDC_EDIT_BAR_POINT_COMBO, TBBS_SEPARATOR, 47);
	
	CRect rect;
                                                      
	m_wndPowerBar.GetItemRect(FONT_POS, &rect);
	rect.top = 5;
	rect.bottom = rect.top + 400;	// Length of Font Combo Box

	if (!m_wndPowerBar.m_FontComboBox.Create(
		CBS_SORT|CBS_DROPDOWNLIST|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS | CBRS_TOOLTIPS | CBRS_FLYBY,
			rect, &m_wndPowerBar, IDC_EDIT_BAR_FONT_COMBO))
	{
		TRACE("Failed to create font combo-box\n");
		return FALSE;
	}

	m_wndPowerBar.GetItemRect(POINT_POS, &rect);
	rect.top = 5;
	rect.bottom = rect.top + 400;

	if (!m_wndPowerBar.m_PointComboBox.Create(
		CBS_DROPDOWN|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL,
		rect, &m_wndPowerBar, IDC_EDIT_BAR_POINT_COMBO))
	{
		TRACE("Failed to create point combo-box\n");
		return FALSE;
	}

	// Populate the font box

	// Populate the point box
	AddFontSizes(&m_wndPowerBar.m_PointComboBox);

	/* This call sets the default font sizes */
	/* which we need for this setcursel call */
	if (!fontsLoaded) {
		loadFontsNew();
	}

	m_wndPowerBar.m_PointComboBox.SetCurSel(defaultSizeLoc);		// Set the default to 48 Point

	theApp.CreatePrinterDC(theApp.m_dcPrinter);

	m_wndPowerBar.m_FontComboBox.EnumFontFamiliesEx(theApp.m_dcPrinter);

	m_wndPowerBar.m_FontComboBox.SetCurSel(defaultFont);		// Set the default to Modern Manuscript
	
	DWORD dwExStyle = TBSTYLE_EX_DRAWDDARROWS;
	m_wndPowerBar.GetToolBarCtrl().SendMessage(TB_SETEXTENDEDSTYLE, 0, (LPARAM)dwExStyle);

	DWORD dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_TEXTSHADING));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_TEXTSHADING), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID__COLOREDSTROKES));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID__COLOREDSTROKES), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID__DECISIONDOTS));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID__DECISIONDOTS), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_OVERLAY));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_OVERLAY), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_CONNECTTHEDOTS));
	dwStyle |= (TBSTYLE_DROPDOWN);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_CONNECTTHEDOTS), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_LINEDENSITY));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_LINEDENSITY), dwStyle);
	
	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_TEXTARROWS));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_TEXTARROWS), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_STARTDOT));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_STARTDOT), dwStyle);

	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_GUIDELINES));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_GUIDELINES), dwStyle);

#if 0
	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_GUIDELINES_THICKNESS));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_GUIDELINES_THICKNESS), dwStyle);
#endif
	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_YELLOWGUIDE));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_FORMAT_YELLOWGUIDE), dwStyle);

//	dwStyle = m_wndPowerBar.GetButtonStyle(m_wndPowerBar.CommandToIndex(ID_BIGSPACING));
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | BTNS_WHOLEDROPDOWN);
//	dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
//	m_wndPowerBar.SetButtonStyle(m_wndPowerBar.CommandToIndex(ID_BIGSPACING), dwStyle);

	return TRUE;
}

BOOL CMainFrame::CreatePaletteBar()
{
	if ((!m_wndPaletteBar.Create(this, WS_CHILD | WS_VISIBLE | CBRS_SIZE_FIXED | 
		CBRS_TOP | CBRS_TOOLTIPS, ID_PALETTEBAR)) ) {
			return FALSE;
	}
	if (!m_wndPaletteBar.LoadBitmap(IDBM_POWERBAR))
	{
		TRACE("Failed to create power bar\n");
		return FALSE;       // fail to create
	}

	if (!m_wndPaletteBar.SetButtons(power_bar_buttons,  sizeof(power_bar_buttons)/sizeof(UINT)))
	{
		TRACE("Failed to create power bar\n");
		return FALSE;       // fail to create
	}
	//m_wndPaletteBar.SetWindowTextA("Ken");
	m_wndPaletteBar.EnableDocking(0);// CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	//DockControlBar(&m_wndPaletteBar);
	CPoint pt(GetSystemMetrics(SM_CXSCREEN)-100, GetSystemMetrics(SM_CXSCREEN)/3);
	m_wndPaletteBar.SetColumns(3);

	FloatControlBar(&m_wndPaletteBar, pt);
	
    return TRUE;

}



// THIS IS THE FUNCTION THAT CREATES BLACK BOXES SOMETIMES
BOOL CMainFrame::CreateEditBar()
{
	int sizebar = sizeof(edit_bar_buttons)/sizeof(UINT);
//	if ((*swType != swHPD) && (*swType != swNAC)) {	// Leave upgrade button for HOP and NAC Demo only
//		sizebar -= 1;
//	}
	m_wndEditBar.SetSizes(CSize(39, 39), CSize(32, 32));
	if (!m_wndEditBar.Create(this, WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | TBSTYLE_FLAT, ID_VIEW_TOOLBAR))
	{
		TRACE("Failed to create edit bar\n");
		return FALSE;       // fail to create
	}

	if (!m_wndEditBar.LoadBitmap(IDB_EDIT_BAR))
	{
		TRACE("Failed to create edit bar\n");
		return FALSE;       // fail to create
	}

	CToolBarCtrl& tbCtrl = m_wndEditBar.GetToolBarCtrl();
	tbCtrl.AddBitmap(1, IDB_DO_GRID);

	if (!m_wndEditBar.SetButtons(edit_bar_buttons, sizebar))
	{
		TRACE("Failed to create edit bar\n");
		return FALSE;       // fail to create
	}

#if 1
	DWORD dwExStyle = TBSTYLE_EX_DRAWDDARROWS;
	m_wndEditBar.GetToolBarCtrl().SendMessage(TB_SETEXTENDEDSTYLE, 0, (LPARAM)dwExStyle);

	DWORD dwStyle;
	int itemIndex = m_wndEditBar.CommandToIndex(ID_VIEW_GRIDSHOW);
	if (itemIndex != -1) {
		dwStyle = m_wndEditBar.GetButtonStyle(itemIndex);
		dwStyle |= (TBSTYLE_DROPDOWN | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS);
		m_wndEditBar.SetButtonStyle(itemIndex , dwStyle);
	}
#endif

	return TRUE;
}

#define STATUS_SIZE_PAGE_OF_PAGE	68
#define STATUS_SIZE_ZOOM			40
#define STATUS_SIZE_OTHER			60

BOOL CMainFrame::CreateStatusBar()
{
	if (!m_wndStatusBar.Create(this,WS_VISIBLE|CBRS_BOTTOM|CBRS_TOOLTIPS|CBRS_FLYBY,ID_VIEW_STATUS_BAR) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE("Failed to create status bar\n");
		return FALSE;      // fail to create
	}

#define STATUS_SIZE_BUTTON		10

	m_wndStatusBar.SetPaneInfo(TEXTTXT, indicators[TEXTTXT], SBPS_STRETCH | SBPS_NOBORDERS, 0);
	m_wndStatusBar.SetPaneInfo(PAGEDEC, indicators[PAGEDEC], SBPS_NOBORDERS, STATUS_SIZE_BUTTON);
	m_wndStatusBar.SetPaneInfo(PAGEOFP, indicators[PAGEOFP], SBPS_NOBORDERS, STATUS_SIZE_PAGE_OF_PAGE);
	m_wndStatusBar.SetPaneInfo(PAGEINC, indicators[PAGEINC], SBPS_NOBORDERS, STATUS_SIZE_BUTTON);
	m_wndStatusBar.SetPaneInfo(PAGEZOM, indicators[PAGEZOM], SBPS_NOBORDERS, 15);
	m_wndStatusBar.SetPaneInfo(ZOOMDEC, indicators[ZOOMDEC], SBPS_NOBORDERS, STATUS_SIZE_BUTTON);
	m_wndStatusBar.SetPaneInfo(ZOOMTXT, indicators[ZOOMTXT], SBPS_NOBORDERS, STATUS_SIZE_ZOOM);
	m_wndStatusBar.SetPaneInfo(ZOOMINC, indicators[ZOOMINC], SBPS_NOBORDERS, STATUS_SIZE_BUTTON);
	m_wndStatusBar.SetPaneInfo(ZOOMINC+1, indicators[ZOOMINC+1], SBPS_NOBORDERS, 5);	// bogus to get '+' working


	m_wndStatusBar.CreateButtons();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::RemoveFonts()
{
	int i;
	CString FontFile;

	for(i=beginMathFonts; i < numSwFonts; i++) {
		FontFile = FontPath + szFonts[i].f_filename;
		RemoveFontResource(FontFile);
	}

}

void CMainFrame::OnSelChangeFont()
{
	CString 	strWhich;
	int		iWhich, iStatus;
	TextItem	*pItem = GetCurrentTextItem();

	iWhich = m_wndPowerBar.m_FontComboBox.GetCurSel();

	if (iWhich == CB_ERR)
		return;

	m_wndPowerBar.m_FontComboBox.GetLBText(iWhich, strWhich);

	if (pItem) {
		CFrameWnd *pFrame = GetActiveFrame();
		CSwView *pView = NULL;
		if (pFrame) {
			pView = (CSwView *) pFrame->GetActiveView();
		}
		pItem->sFontName = strWhich;

		if (pItem->sFontIndex != iWhich) {
			CFrameWnd *pFrame = GetActiveFrame();

			if (pView) {
				pView->SetModified();
				if (pItem->StoryNumber > 0 && !pItem->IsLastItemInStory) {
					theApp.m_iStoryOverflowBox = pItem->StoryItemOrder;
					pView->CollectStoryText(0);
				}
			}
			// not sure we do this.  Do we change the lines based on the font, even after they have changed the box?
			// pItem->nDot2DotLinesButton = szFonts[iWhich].f_fontLine;
		}

		pItem->sFontIndex = iWhich;
	
		pItem->SetViaMembers();
		if (pView && pItem->StoryNumber > 0 && !pItem->IsLastItemInStory) {
			pView->DistributeStoryText(0, TRUE, TRUE);
		}
		InvalidateCurrentView();
		pItem->Message(ITEM_ENTER_EDIT_MODE, 0, &iStatus);

	}
	else {
		defaultFont = iWhich;		// Make this the current default font
	}

	SetFocus();		// Make sure focus goes back to the main window
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{

#pragma message ("Fix the window size here...............................")
	//cs.cy = ::GetSystemMetrics(SM_CYSCREEN);// / 4; 
	//cs.cx = ::GetSystemMetrics(SM_CXSCREEN);// / 4; 
	//cs.y = ((cs.cy * 4) - cs.cy) / 2; 
	//cs.x = ((cs.cx * 4) - cs.cx) / 2;
	theApp.m_screenWid = ::GetSystemMetrics(SM_CXSCREEN);
	theApp.m_screenHt = ::GetSystemMetrics(SM_CYSCREEN);


	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	// Keeps toolbars and main window from flickering when resizing
    cs.lpszClass = AfxRegisterWndClass(0, NULL, NULL, AfxGetApp()->LoadIcon(IDR_MAINFRAME));

	return TRUE;
}

void CMainFrame::OnSelChangeSize()
{
	CString 	strWhich;
	int		iWhich;
	TextItem	*pItem = GetCurrentTextItem();

	iWhich = m_wndPowerBar.m_PointComboBox.GetCurSel();

	if (iWhich == CB_ERR)
		return;

	m_wndPowerBar.m_PointComboBox.GetLBText(iWhich, strWhich);

	if (pItem) {
		int newPoint = atoi(strWhich);

		if (newPoint < 5) {
			return;
		}
		CFrameWnd *pFrame = GetActiveFrame();
		CSwView *pView = NULL;
		if (pFrame) {
			pView = (CSwView *) pFrame->GetActiveView();
		}

		if (pItem->nPointSize != newPoint) {
			
			// Mark that we aren't sure about size change
			// if we are getting bigger
			if (pItem->nPointSize < newPoint) {
				pItem->lastGoodPointSize = pItem->nPointSize;
			}

			if (pView) {
				pView->SetModified();
				if (pItem->StoryNumber > 0 && !pItem->IsLastItemInStory) {
					theApp.m_iStoryOverflowBox = pItem->StoryItemOrder;
					pView->CollectStoryText(0);
				}
			}
		}
		pItem->nPointSize = newPoint;
		pItem->SetViaMembers();
		if (pView && pItem->StoryNumber > 0 && !pItem->IsLastItemInStory) {
			pView->DistributeStoryText(0, TRUE, TRUE);
		}
		InvalidateCurrentView();
	}
	else {
		defaultSize = atoi(strWhich);
	}

	SetFocus();		// Make sure focus goes back to the main window

}


void CMainFrame::OnEditkillFocus()
{
	CString 	strWhich;
	TextItem	*pItem = GetCurrentTextItem();
	int testNum;

	if (!pItem)
		return;

	if (pItem->SelectionOn) {
		return;
	}

	m_wndPowerBar.m_PointComboBox.GetWindowText(strWhich);
	testNum = atoi(strWhich);

	if (testNum < 5) {
		return;	// too small
	}
	pItem->nPointSize = testNum;
	pItem->SetViaMembers();
	InvalidateCurrentView();    
}


void CMainFrame::OnUpdateFontCombo(CCmdUI* pCmdUI)
{
	TextItem	*pItem = GetCurrentTextItem();
#pragma message("WHY IS THIS FORCED")
	pCmdUI->Enable((pItem && !pItem->SelectionOn) || !pItem);
	pCmdUI->Enable(TRUE);

}

void CMainFrame::OnUpdatePointCombo(CCmdUI* pCmdUI)
{
	TextItem	*pItem = GetCurrentTextItem();

	pCmdUI->Enable((pItem && !pItem->SelectionOn) || !pItem);
}

int CSizeComboBox::PreTranslateMessage(MSG *lpmsg)
{
    if (lpmsg->message == WM_KEYDOWN) {
		int testChar = lpmsg->wParam;
		if ((testChar == VK_UP) || (testChar == VK_DOWN)) {
			if ((GetKeyState(VK_MENU) >= 0) && (GetKeyState(VK_CONTROL) >=0) &&
				!GetDroppedState())
			{
				ShowDropDown();
				return TRUE;
			}
		}
		else if (testChar == VK_RETURN) {
			// Fake the kill focus so we can grab the entered text
			lpmsg->message = WM_KILLFOCUS;
		}
		else if ((GetKeyState(VK_NUMLOCK) & 0x01) && testChar >= VK_NUMPAD0 && testChar <= VK_NUMPAD9) {
			return CComboBox::PreTranslateMessage(lpmsg);// Allow numbers on numeric keypad
		}
		else if (((testChar >= 'a') && (testChar <= 'z')) ||
				 ((testChar >= 'A') && (testChar <= 'Z')) ||
				 (testChar == 0x20)) {

			return(TRUE);	// ignore alpha chars
		}
    }
	return CComboBox::PreTranslateMessage(lpmsg);
}



int CFontComboBox::CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct)
{
	lpCompareItemStruct;	/* get rid of compiler warning */
	return 0;
}

void CFontComboBox::DeleteItem(LPDELETEITEMSTRUCT lpDeleteItemStruct)
{
	lpDeleteItemStruct;	/* get rid of compiler warning */
}

void CFontComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	DrawEntireItem(lpDrawItemStruct, 0);
}

void CFontComboBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	lpMeasureItemStruct->itemHeight = FONT_ITEM_SIZE;
}

static char *headerStr = "STARTWRITE FONTFILE";
static char *versionStr3 = "VERSION 3";
static char *versionStr4 = "VERSION 4";


/* 0 = end of file, -1 = end of line, 1 = data */
static int getNextWord(char **sptr, char **eptr)
{
	*sptr = strchr(*sptr, '{');	// find first bracket for font name
	if (*sptr == NULL) {
		return(1);
	}
	(*sptr)++;						// point to font name
	*eptr = strchr(*sptr, '}');	// point after name 
	if (*eptr == NULL) {
		return(1);
	}
	**eptr = 0;
	return(!strcmp(*sptr, "END"));	// Return if this is the end
}

/* keypre, dataptr, nextptr */
static int getNextPair(char **kptr, char **dptr, char **eptr)
{
	char *sptr;

	sptr = *eptr;	/* start at beginning */
	
	/* Find the beginning */
	while (*sptr && (*sptr != '{') && (*sptr != '\n')) {
		sptr++;
	}
	if (!*sptr ) {
		return(0);	/* hit the end */
	}
	if (*sptr == '\n') {
		return(-1);
	}

	*kptr = ++sptr;	/* point to the beginning */
	while (*sptr && (*sptr != '=') && (*sptr != '}')) {
		sptr++;
	}
	if (!*sptr ) {
		return(0);	/* hit the end */
	}
	if (*sptr == '\n') {
		return(-1);
	}
	if (*sptr != '=') {
		return(-1);
	}
	*sptr = '\0';	/* null terminate the keyword */

	*dptr = ++sptr;	/* point to the data */
	while (*sptr && (*sptr != '\n') && (*sptr != '}')) {
		sptr++;
	}
	if (!*sptr ) {
		return(0);	/* hit the end */
	}
	if (*sptr == '\n') {
		return(-1);
	}
	*sptr = '\0';	/* null termingate the data string */
	*eptr = ++sptr;
	return(1);	/* this is the good return */
}


void CMainFrame::loadFontsNew()
{
	CFile fontFile, testFile;
	CString testPath, savePath;
	int ret, j, valid=1, inDotted=TRUE;
	int realCount=0;
	ULONGLONG fileLen;
	char far *fptr, *sptr, *endptr, *eptr, *kptr;
	char lastFontName[128];
	int swVersion = 2;
	int retv;
#ifdef LATER_WRW
	redVal, grnVal,bluVal;
#endif
	char *lineType;
	int *lineColor, lineMask;
	bool done=false, finished=false;
	// Let's set the default point size while we are here
	defaultSize = theApp.m_defPoint;
	defaultSizeLoc = 8;

	for (j = 0; j < sizeof(iFontSizes)/sizeof(iFontSizes[0]); j++) {
		if (iFontSizes[j] == defaultSize)
			defaultSizeLoc = j;
	}

	// Font path...                                            
	FontPath = (CString)AfxGetApp()->m_pszHelpFilePath;
	FontPath = FontPath.Left(FontPath.ReverseFind('\\'));
	FontPath += "\\FONTS\\";
	savePath = FontPath;		// remember this path
    FontPath += "swfonts4.fnt";
    
	ret = fontFile.Open(FontPath, CFile::modeRead);
	FontPath = savePath;
	if (ret != FALSE) { 
		fileLen = fontFile.GetLength();
		fptr = (char *) malloc((int)fileLen+6);
		if (fptr != NULL) {
			fontFile.Read(fptr, (int)fileLen);
			endptr = fptr+fileLen;
#ifdef _CRT_SECURE_NO_DEPRECATE
			strcpy(endptr, "{END}");	// Force the end of file string, just in case
#else
			strcpy_s(endptr, sizeof("{END}"),"{END}");	// Force the end of file string, just in case
#endif
			if (0 != strncmp(fptr, headerStr, strlen(headerStr))) {
				free(fptr);
				fontFile.Close();
				return;
			}

			sptr = fptr + strlen(headerStr) + 1;
			
			// Check for new stuff (Cursive) as of Version 3
			if (!strncmp(sptr, versionStr4, strlen(versionStr4))) {
				swVersion = 4;
			}
			else {
				AfxMessageBox("Incorrect SWFONTS files.  Require Version 4");
				free(fptr);
				fontFile.Close();
				return;
			}

			realCount = 0;
			for(j=0; !finished && (realCount < MAX_ALLOWED_FONTS) && (sptr < endptr);j++) {
				valid=TRUE;
				lineMask=0;
				while (*sptr == '\n') {
					sptr++;
				}
				if ((j==0) || (*sptr == '#')) {
					sptr = strchr(sptr, '\n');		// go to end of first line
					sptr++;
					continue;
				}

				/* Get the header word for this line */
				if (getNextWord(&sptr, &eptr)) {	// Get font filename
					numSwFonts = realCount;
					inDotted = FALSE;					// done with dotted
					break;	// hit the end
				}

				/* Thickline thing */
				if (!strncmp(sptr, "ThickLine=", 10)) {	/* If the thick line flag is here */
					if ((*(sptr+10) == 'Y') || (*(sptr+10) == 'y')) {
						theApp.m_doThick = 1;
					}
					sptr = eptr+1;
					continue;
				}

				//if (!strcmp(sptr, "NEWMATH")) { 	// if flag for list of normal fonts
				//	beginMathFonts = realCount;
				//	inDotted = FALSE;					// done with dotted
				//		sptr = eptr+1;
				//	continue;
				//}
				if ((beginMathFonts == -1) && !strcmp(sptr, "MATHFONT")) { 	// if flag for list of normal fonts
					beginMathFonts = realCount;
					inDotted = FALSE;					// done with dotted
				}
				if ((beginMathFonts != -1) || !strcmp(sptr, "SWFONT")) {
					
					eptr++;	/* getnextpair uses the eptr to get current position */
					
					/* Set everything to zero first */
					memset(&szFonts[realCount], 0, sizeof(FONTINFO));

					if (beginMathFonts != -1) {
						szFonts[realCount].nPitchAndFamily = 2;
						szFonts[realCount].f_MathFlag = 1;
					}

					for (done=false;!done;) {
						retv = getNextPair(&kptr, &sptr, &eptr);
						if (retv == 0) {	/* end of file */
							done=true;
							finished=true;
							continue;
						}
						if (retv == -1) {
							done=true;
							continue;
						}

						if (!strcmp(kptr, "FF")) {	/* font filename */
							lstrcpyn(szFonts[realCount].f_filename, sptr, sizeof(szFonts[realCount].f_filename));
							if (inDotted) {	/* don't test the math fonts */
								// Get full path to font file
								testPath = savePath + sptr;
							
								// Open to see if it is there
								ret = testFile.Open(testPath, CFile::modeRead);

								if (ret == FALSE) {
									valid = FALSE;
								}
								else {
									testFile.Close();

									if (*swType == swHPD) {
									// This forces only the HOP Manuscript to be on the menu.
										if (!((*sptr == 's') && (*(sptr+1) == 'w') &&
											(*(sptr+2) == 'f') && (*(sptr+3) == 'n') &&
											(*(sptr+4) == 't') && (*(sptr+5) == '0') &&
											(*(sptr+6) == '4') && (*(sptr+7) == '_') &&
											(*(sptr+8) == '.') && (*(sptr+9) == 't') &&
											(*(sptr+10) == 't') && (*(sptr+11) == 'f') &&
											(*(sptr+12) == '\0'))) {
											valid = FALSE;	// only allow HOP Manuscript
										}
									}
								}
							}
							else if (beginMathFonts != -1) {
								testPath = savePath + sptr;
								if (AddFontResource(testPath)) {
									testPath.Empty(); // ok
								}
							}
							continue;
						}
						if (!strcmp(kptr, "FN")) {	/* Fontname */
							lstrcpyn(szFonts[realCount].f_fontname, sptr, sizeof(szFonts[realCount].f_fontname));

							if ((j != 0) && !strncmp(sptr, lastFontName, sizeof(lastFontName))) {
								valid = FALSE;		// Don't allow duplicate names
							}
							lstrcpyn(lastFontName, sptr, sizeof(lastFontName));	// remember the last name

							// If this is a valid font And it matches the default
							// then set the default font information
							if (valid && (!strcmp(sptr, theApp.m_defFont))) {
								defaultFont = realCount;
								szFonts[realCount].f_default = 1;
							}
							else {
								szFonts[realCount].f_default = 0;
							}
							continue;
						}


						if (!strcmp(kptr, "Kern")) {
							if ((*sptr == 'Y') || (*sptr == 'y')) {
								szFonts[realCount].f_iscursive |= DO_KERNING;
							}
							continue;
						}

						if (!strcmp(kptr, "Cursive")) {
							if (!strcmp(sptr, "Cursive")) {
								szFonts[realCount].f_iscursive |= CUR_ZAN1;
							}
							else if (!strcmp(sptr, "ItalicCursive")) {
								szFonts[realCount].f_iscursive |= CUR_ITAL;
							}
							else if (!strcmp(sptr, "DNealCursive")) {
								szFonts[realCount].f_iscursive |= CUR_DNEL;
							}
							else if (!strcmp(sptr, "AmericanCursive")) {
								szFonts[realCount].f_iscursive |= CUR_AMER;
							}
							else if (!strcmp(sptr, "SimpleCursive")) {
								szFonts[realCount].f_iscursive |= CUR_ZAN1|CUR_ZAN2;
							}
							else if (!strcmp(sptr, "UprightCursive")) {
								szFonts[realCount].f_iscursive |= CUR_UPRT;
							}
							else if (!strcmp(sptr, "FTLCursive")) {
								szFonts[realCount].f_iscursive |= CUR_FRML;
							}
							else if (!strcmp(sptr, "VictCursive")) {	/* Victorian Cursive */
								szFonts[realCount].f_iscursive |= CUR_VICT;
							}
							else if (!strcmp(sptr, "QueenCursive")) {	/* Victorian Cursive */
								szFonts[realCount].f_iscursive |= CUR_QUEEN;
							}
							else if (!strcmp(sptr, "NSWCursive")) {	/* Victorian Cursive */
								szFonts[realCount].f_iscursive |= CUR_NSW;
							}
							else if (!strcmp(sptr, "PalmerCursive")) {	/* Palmer Cursive */
								szFonts[realCount].f_iscursive |= CUR_PALMR;
							}
							else if (!strcmp(sptr, "PLMRCursive")) {	/* Palmer Cursive */
								szFonts[realCount].f_iscursive |= CUR_PALMR;
							}
							else if (!strcmp(sptr, "WOTCursive")) {	/* Palmer Cursive */
								szFonts[realCount].f_iscursive |= CUR_WOT;
							}
							else if (!strcmp(sptr, "MathOne")) {
								szFonts[realCount].f_MathFlag |= MATH_ONE;
							}
							else if (!strcmp(sptr, "N") || !strcmp(sptr, "n")) {
								/* Not cursive */
							}
							continue;
						}
						if (!strcmp(kptr, "AF")) {
							if (!strcmp(sptr, "NOARROW")) {
								szFonts[realCount].f_arrowname[0] = 0;
							}
							else {
								lstrcpyn(szFonts[realCount].f_arrowname, sptr, sizeof(szFonts[realCount].f_arrowname));
							}
							continue;
						}
						if (!strcmp(kptr, "CF")) {
							if (!strcmp(sptr, "NOCFFONT")) {
								szFonts[realCount].f_cffont[0] = 0;
							}
							else {
								lstrcpyn(szFonts[realCount].f_cffont, sptr, sizeof(szFonts[realCount].f_cffont));
							}
							continue;
						}
						if (!strcmp(kptr, "OF")) {
							if (!strcmp(sptr, "NOARROW")) {
								szFonts[realCount].f_overlayname[0] = 0;
							}
							else {
								lstrcpyn(szFonts[realCount].f_overlayname, sptr, sizeof(szFonts[realCount].f_overlayname));
							}
							continue;
						}
						if (!strcmp(kptr, "MF")) {		/* MATH font */
							szFonts[realCount].f_arrowname[0] = 0;
							lstrcpyn(szFonts[realCount].f_arrowname, sptr, sizeof(szFonts[realCount].f_arrowname));
							continue;
						}
						if (!strcmp(kptr, "DF")) {		/* DOT font */
							if (!strcmp(sptr, "NODOT")) {
								szFonts[realCount].f_dotname[0] = 0;
							}
							else {
								lstrcpyn(szFonts[realCount].f_dotname, sptr, sizeof(szFonts[realCount].f_dotname));
							}
							continue;
						}
						if (!strcmp(kptr, "DD")) {		/* DOT font */
							if (!strcmp(sptr, "NODEC")) {
								szFonts[realCount].f_ddfont[0] = 0;
							}
							else {
								lstrcpyn(szFonts[realCount].f_ddfont, sptr, sizeof(szFonts[realCount].f_ddfont));
							}
							continue;
						}
						lineType=NULL;
						lineColor=NULL;
//						lineColorInd=NULL;
						if (!strcmp("Top", kptr)) {
							lineType = &szFonts[realCount].f_TopLine;
							lineMask = SWLINE_TOP;
							lineColor = &szFonts[realCount].f_TopColor;
//							lineColorInd = &szFonts[realCount].f_TopColorInd;
						}
						if (!strcmp("Mid", kptr)) {
							lineType = &szFonts[realCount].f_MidLine;
							lineMask = SWLINE_MID;
							lineColor = &szFonts[realCount].f_MidColor;
//							lineColorInd = &szFonts[realCount].f_MidColorInd;
						}
						if (!strcmp("Bas", kptr)) {
							lineType = &szFonts[realCount].f_BasLine;
							lineMask = SWLINE_BAS;
							lineColor = &szFonts[realCount].f_BasColor;
//							lineColorInd = &szFonts[realCount].f_BasColorInd;
						}
						if (!strcmp("Bot", kptr)) {
							lineType = &szFonts[realCount].f_BotLine;
							lineMask = SWLINE_BOT;
							lineColor = &szFonts[realCount].f_BotColor;
//							lineColorInd = &szFonts[realCount].f_BotColorInd;
						}
						
						if (lineType != NULL) {
							if (*sptr == 'N') {
								/* no line */
								*lineType = 0;
								continue;
							}
							if (*sptr == 'D') {
								/* dotted line */
								*lineType |= (/*SWLINE_ON|*/SWLINE_DOT);	/* dotted line one */
								szFonts[realCount].f_fontLine |= lineMask;

							}
							else if (*sptr == 'S') {
								/* solid line */
								*lineType |= (SWLINE_ON);	/* solid line one */
								szFonts[realCount].f_fontLine |= lineMask;
							}
							sptr += 2;
							switch(*sptr) {
							default:
							case 'B':
							case 'b':
								*lineColor = RGB(0,0,255);
//								*lineColorInd = 1;
								break;
							case 'R':
							case 'r':
								*lineColor = RGB(255,0,0);
//								*lineColorInd = 0;
								break;
							case 'G':
							case 'g':
								*lineColor = RGB(0,255,0);
//								*lineColorInd = 3;
								break;
							case 'K':
							case 'k':
								*lineColor = RGB(0,0,0);
//								*lineColorInd = 2;
								break;
							}
#ifdef LATER_WRW	/* the RGB method */
							redVal = atoi(sptr);
							sptr = strchr(sptr, ',');	// find first bracket for font name
							if (sptr == NULL) {
								continue;
							}
							sptr++;
							grnVal = atoi(sptr);
							sptr = strchr(sptr, ',');	// find first bracket for font name
							if (sptr == NULL) {
								continue;
							}
							sptr++;
							bluVal = atoi(sptr);
							*lineColor = RGB(redVal, grnVal, bluVal);
#endif
							continue;
						}

					}/* for !done */
					if (valid == TRUE) {
						realCount++;
					}
					sptr = eptr+1;
				}
			}
			// Make sure the last one is nulled
			szFonts[realCount].f_filename[0] = 0;
			szFonts[realCount].f_fontname[0] = 0;
			szFonts[realCount].f_default = 0;
			szFonts[realCount].f_arrowname[0] = 0;
	
			free(fptr);
		}
		fontFile.Close();
	}
	if (beginMathFonts == -1) {
		beginMathFonts  = numSwFonts;
	}

 	fontsLoaded = 1;

	/* Now get any font ledger settings the user may have selected */
	theApp.swGetLedgerSettings();

}



/****************************************************************************
 *                                                                          *
 *  FUNCTION   : DrawEntireItem(LPDRAWITEMSTRUCT, int)                      *
 *                                                                          *
 *  PURPOSE    : Draws an item and frames it with a selection frame and/or  *
 *               a focus frame when appropriate.                            *
 *                                                                          *
 ****************************************************************************/
void FAR PASCAL DrawEntireItem(LPDRAWITEMSTRUCT lpdis, int inflate)
{
	RECT	rc;
	HBRUSH	hbr;
	inflate;	/* get rid of compiler warning */

	/* Resize rectangle to leave space for frames */
	CopyRect ((LPRECT)&rc, (LPRECT)&lpdis->rcItem);
//	InflateRect ((LPRECT)&rc, inflate, inflate);

	/* Create a brush using the value in the item data field (this value
	 * was initialized when we added the item to the list/combo box using
	 * LB_ADDSTRING/CB_ADDSTRING) and draw the color in the list/combo box.
	 */
	if (lpdis->itemState & (ODS_SELECTED | ODS_FOCUS))
	{
		hbr = CreateSolidBrush(GetSysColor(COLOR_HIGHLIGHT));
		FillRect (lpdis->hDC, &rc, hbr);
		DeleteObject (hbr);                                                  
	}
	else
		FillRect(lpdis->hDC, (LPRECT)&rc, (HBRUSH) GetStockObject(WHITE_BRUSH));

	if (lpdis->itemState & ODS_FOCUS)
		DrawFocusRect(lpdis->hDC, &rc);

	SetBkMode(lpdis->hDC, TRANSPARENT);

	rc.top += 2;

	if (lpdis->itemID != -1) {

		unsigned long old_color=0;
		
		if (lpdis->itemID >= (unsigned int)numSwFonts) {	/* display regular font icon */
			DrawBitmap(lpdis->hDC, hbmpMaskTT, rc.left, rc.top, SRCAND);
			DrawBitmap(lpdis->hDC, hbmpTT,	rc.left, rc.top, SRCPAINT);
		}
		else if (lpdis->itemID >= (unsigned int) beginMathFonts) {	/* display MathFont icon */
			DrawBitmap(lpdis->hDC, hbmpMaskMM,  rc.left, rc.top, SRCAND);
			DrawBitmap(lpdis->hDC, hbmpM, 	rc.left, rc.top, SRCPAINT);
		}
		else {	/*  And display Dotted font icon */
			DrawBitmap(lpdis->hDC, hbmpMaskA, rc.left, rc.top, SRCAND);
			DrawBitmap(lpdis->hDC, hbmpA, rc.left, rc.top, SRCPAINT);
		}

		if (lpdis->itemState & ODS_SELECTED) {
			// Set text to white when selected
			old_color = SetTextColor(lpdis->hDC, RGB(255,255,255));
		}

		TextOut(lpdis->hDC, rc.left + 15, rc.top - 1, szFonts[lpdis->itemID].f_fontname, 
			lstrlen(szFonts[lpdis->itemID].f_fontname));

		if (lpdis->itemState & ODS_SELECTED) {
			// restore the old color
			SetTextColor(lpdis->hDC, old_color);
		}

		// Draw the seperator between TT and SW fonts.
		if (lpdis->itemID == (unsigned int)(numSwFonts-1))
		{
			RECT rect;

			::GetClientRect(lpdis->hwndItem, &rect);

			//if (rc.bottom > rect.bottom)
			if (1) { // || (rc.bottom > FONT_ITEM_SIZE + 5))
				POINT tpoint;
				MoveToEx(lpdis->hDC, rc.left, rc.bottom - 1, &tpoint);
				LineTo(lpdis->hDC, rc.right, rc.bottom - 1);
			}
		}
		else if (lpdis->itemID == (unsigned int)(beginMathFonts-1))
		{
			RECT rect;

			::GetClientRect(lpdis->hwndItem, &rect);

			//if (rc.bottom > rect.bottom)
			if (1) { // || (rc.bottom > FONT_ITEM_SIZE + 5))
				POINT tpoint;
				MoveToEx(lpdis->hDC, rc.left, rc.bottom - 1, &tpoint);
				LineTo(lpdis->hDC, rc.right, rc.bottom - 1);
			}
		}

	}

	/* Draw or erase appropriate frames */
	//HandleSelectionState(lpdis, inflate + 4);
	//HandleFocusState(lpdis, inflate + 2);
}

void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx, int cy)
{
	BITMAP bm;
	HDC hdcMem;
	POINT ptSize, ptOrg;

	hdcMem = CreateCompatibleDC(hdc);
	SelectObject(hdcMem, hBitmap);
	SetMapMode(hdcMem, GetMapMode(hdc));

	GetObject(hBitmap, sizeof (BITMAP), (LPSTR) &bm);

	if (cx == -1)
		cx = bm.bmWidth;
	if (cy == -1)
		cy = bm.bmWidth;

	ptSize.x = cx;
	ptSize.y = cy;
	DPtoLP(hdc, &ptSize, 1);

	ptOrg.x = 0;
	ptOrg.y = 0;
	DPtoLP(hdcMem, &ptOrg, 1);

	BitBlt(hdc, x, y, ptSize.x, ptSize.y, hdcMem, ptOrg.x, ptOrg.y, dwCode);

	DeleteDC(hdcMem);
}



BEGIN_MESSAGE_MAP(CSWStatusBar, CStatusBar)
	//{{AFX_MSG_MAP(CSWStatusBar)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	// Global help commands
	ON_WM_WINDOWPOSCHANGED()
END_MESSAGE_MAP()

/*
LRESULT CSWStatusBar::OnMyCommand(WPARAM wParam, LPARAM lParam)
{
	GetParent()->PostMessage(WM_COMMAND, ID_EDIT_GOTO, 0);

	return 0;
}
*/

void CSWStatusBar::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos)
{
	CStatusBar::OnWindowPosChanged(lpwndpos);

	FixButtonPos(&m_buttonPageDec, PAGEDEC);
	FixButtonPos(&m_buttonPageInc, PAGEINC);
	FixButtonPos(&m_buttonZoomDec, ZOOMDEC);
	FixButtonPos(&m_buttonZoomInc, ZOOMINC);
}

void CSWStatusBar::FixButtonPos(CButton *pButton, int iPane)
{
	if (!::IsWindow(m_hWnd) || !::IsWindow(pButton->m_hWnd))
		return;

	RECT rect;

	GetItemRect(iPane, &rect);
	pButton->SetWindowPos(NULL, rect.left, rect.top, rect.right - rect.left,
		rect.bottom - rect.top, SWP_NOZORDER);

}

void CSWStatusBar::CreateButtons()
{
	RECT rect;

	GetItemRect(PAGEDEC, &rect);
	m_buttonPageDec.Create("<", WS_VISIBLE | WS_CHILD, rect, this, IDC_PAGE_PREV);

	GetItemRect(PAGEINC, &rect);
	m_buttonPageInc.Create(">", WS_VISIBLE | WS_CHILD, rect, this, IDC_PAGE_NEXT);

	GetItemRect(ZOOMDEC, &rect);
	m_buttonZoomDec.Create("-", WS_VISIBLE | WS_CHILD, rect, this, IDC_ZOOM_DEC);

	GetItemRect(ZOOMINC, &rect);
	m_buttonZoomInc.Create("+", WS_VISIBLE | WS_CHILD, rect, this, IDC_ZOOM_INC);
}


void CMainFrame::AddFontSizes(CComboBox *pBox)
{
	for (int i = 0; i < sizeof(iFontSizes)/sizeof(iFontSizes[0]); i++)
	{
		CString str;

		str.Format("%d", iFontSizes[i]);
		pBox->AddString(str);
	}
}

TextItem *CMainFrame::GetCurrentTextItem()
{
	CFrameWnd *pFrame = GetActiveFrame();

	if (!pFrame)
		return NULL;

	CSwView *pView = (CSwView *) pFrame->GetActiveView();

	if (!pView)
		return NULL;

	{
		WINDOWPLACEMENT lpwndpl;
		GetWindowPlacement( &lpwndpl );
	}

	return pView->GetCurrentTextItem();
}

void CMainFrame::InvalidateCurrentView()
{
	CFrameWnd *pFrame = GetActiveFrame();

	if (pFrame) {
		pFrame->Invalidate();
		pFrame->SetFocus();
	}
}

// reserve lobyte for charset
#define PRINTER_FONT 0x0100
#define TT_FONT 0x0200
#define DEVICE_FONT 0x0400

class CFontDesc
{
public:
	CFontDesc(LPCTSTR lpszName, LPCTSTR lpszScript, BYTE nCharSet,
		BYTE nPitchAndFamily);
	CString m_strName;
	CString m_strScript;
	BYTE m_nCharSet;
	BYTE m_nPitchAndFamily;
	BYTE m_isUsed;
};

CFontDesc::CFontDesc(LPCTSTR lpszName, LPCTSTR lpszScript, BYTE nCharSet,
	BYTE nPitchAndFamily)
{
	m_strName = lpszName;
	m_strScript = lpszScript;
	m_nCharSet = nCharSet;
	m_nPitchAndFamily = nPitchAndFamily;
	m_isUsed = 0;
}

void CFontComboBox::EmptyContents()
{
	// destroy all the CFontDesc's
	int nCount = GetCount();
	for (int i=0;i<nCount;i++)
		delete (CFontDesc*)GetItemData(i);
}


void CFontComboBox::EnumFontFamiliesEx(CDC& dc, BYTE nCharSet)
{
	CMapStringToPtr map;
	CString str;
	int i, nIndex;
	LOGFONT lf;
	CFontDesc* pDesc;

//	if (!fontsLoaded) {
//		loadFontsNew();
//	}

	GetTheText(str);
	EmptyContents();
	ResetContent();


	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfCharSet = nCharSet;

	if (dc.m_hDC != NULL)
	{
		::EnumFontFamiliesEx(dc.m_hDC, &lf,
			(FONTENUMPROC) EnumFamPrinterCallBackEx, (LPARAM) this, NULL);
	}
	// now walk through the fonts and remove (charset) from fonts with only one

	int nCount = m_arrayFontDesc.GetSize();
	// walk through fonts adding names to string map
	// first time add value 0, after that add value 1
	for (i = 0; i<nCount;i++) {
		CFontDesc* pDesc = (CFontDesc*)m_arrayFontDesc[i];
		void* pv = NULL;
		if (map.Lookup(pDesc->m_strName, pv)) {// found it
			if (pv == NULL) { // only one entry so far
				map.RemoveKey(pDesc->m_strName);
				map.SetAt(pDesc->m_strName, (void*)1);
			}
		}
		else {// not found
			map.SetAt(pDesc->m_strName, (void*)0);
		}
	}

	int realCnt = 0;
	for (i = 0; (i<nCount) && ((realCnt + numSwFonts) < MAX_ALLOWED_FONTS);i++) {
		pDesc = (CFontDesc*)m_arrayFontDesc[i];
		CString str = pDesc->m_strName;
		void* pv = NULL;
		VERIFY(map.Lookup(str, pv));
		if (FindStringExact(0, str) >= 0) {		// If already there
			continue;						// don't do it
		}
		pDesc->m_isUsed = 1;
		nIndex = AddString(str);
		ASSERT(nIndex >=0);
		if (nIndex >=0) {
			if ((nIndex + numSwFonts) < MAX_ALLOWED_FONTS) {	//no error
//	do this below, once nIndex is set at actual
//  sorting threw this off so that blanks were left
//				SetItemData(nIndex, (DWORD)pDesc);
				realCnt++;
			}
			else {
				DeleteString(nIndex);
			}
		}
	}

	for (i=0; realCnt && (i < nCount); i++) {
		pDesc = (CFontDesc*)m_arrayFontDesc[i];
		
		if (pDesc == NULL)
			continue;	// This probably should not happen

		CString str = pDesc->m_strName;
		if (pDesc->m_isUsed == 0) {
			delete (CFontDesc*)pDesc;
			continue;
		}

		nIndex = FindStringExact(0, str);
		if (nIndex < 0) {
			continue;
		}
		realCnt--;

		SetItemData(nIndex, (DWORD)pDesc);

		//pDesc = (CFontDesc*)GetItemData(i);
			
		//nIndex = i + numSwFonts; // + 1;	// adjust for sw fonts
		nIndex += numSwFonts;	// adjust for sw fonts
		
		if (!pDesc->m_strScript.IsEmpty()) {
#ifdef _CRT_SECURE_NO_DEPRECATE
			_snprintf(szFonts[nIndex].f_fontname, sizeof(szFonts[nIndex].f_fontname),
				"%s", pDesc->m_strName);
#else
			_snprintf_s(szFonts[nIndex].f_fontname, sizeof(szFonts[nIndex].f_fontname),sizeof(szFonts[nIndex].f_fontname),
				"%s", pDesc->m_strName);
#endif
			szFonts[nIndex].f_fontname[sizeof(szFonts[nIndex].f_fontname)-1] = '\0';
		}
		else {
			lstrcpyn(szFonts[nIndex].f_fontname, pDesc->m_strName, sizeof(szFonts[nIndex].f_fontname));
		}

		szFonts[nIndex].f_iscursive=0;
		szFonts[nIndex].f_filename[0] = 0;
		szFonts[nIndex].f_default=0;         // 1 if default font
		szFonts[nIndex].f_arrowname[0]=0;	// matching arrowfont name
		szFonts[nIndex].f_overlayname[0]=0;	// matching overlay name
		szFonts[nIndex].nCharSet = pDesc->m_nCharSet;
		szFonts[nIndex].nPitchAndFamily = pDesc->m_nPitchAndFamily;
	}

	SetTheText(str);
	m_arrayFontDesc.RemoveAll();
	EmptyContents();	// We don't use this stuff, so free it up


	// Now insert our fonts in front of the system
	for (i = 0; i < numSwFonts; i++)
		InsertString(i, szFonts[i].f_fontname);

}

void CFontComboBox::AddFont(ENUMLOGFONT* pelf, LPCTSTR lpszScript)
{
	LOGFONT& lf = pelf->elfLogFont;
	if (lf.lfCharSet == MAC_CHARSET) // don't put in MAC fonts, commdlg doesn't either
		return;
	// Don't display vertical font for FE platform
	if ((GetSystemMetrics(SM_DBCSENABLED)) && (lf.lfFaceName[0] == '@'))
		return;
	// don't put in non-printer raster fonts
	CFontDesc* pDesc = new CFontDesc(lf.lfFaceName, lpszScript,
		lf.lfCharSet, lf.lfPitchAndFamily);
	m_arrayFontDesc.Add(pDesc);
}


BOOL CALLBACK AFX_EXPORT CFontComboBox::EnumFamPrinterCallBack(ENUMLOGFONT* pelf,
	NEWTEXTMETRICEX* /*lpntm*/, int FontType, LPVOID pThis)
{
	if (FontType & TRUETYPE_FONTTYPE) {
		((CFontComboBox *)pThis)->AddFont(pelf);
		return 1;
	}
// We aren't going to handle printer fonts
//	else if (FontType & DEVICE_FONTTYPE)
//		dwData |= DEVICE_FONT;
//	((CFontComboBox *)pThis)->AddFont(pelf);
	return 1;
}


BOOL CALLBACK AFX_EXPORT CFontComboBox::EnumFamPrinterCallBackEx(ENUMLOGFONTEX* pelf,
	NEWTEXTMETRICEX* /*lpntm*/, int FontType, LPVOID pThis)
{
	/* Sherston does not want windows fonts */
	if (theApp.m_allowWindowsFonts == 0)
		return 1;

	if (FontType & TRUETYPE_FONTTYPE) {
		((CFontComboBox *)pThis)->AddFont((ENUMLOGFONT*)pelf, CString(pelf->elfScript));
		return 1;
	}
// We aren't going to handle printer fonts
//	else if (FontType & DEVICE_FONTTYPE)
//		dwData |= DEVICE_FONT;
//	((CFontComboBox *)pThis)->AddFont((ENUMLOGFONT*)pelf, CString(pelf->elfScript));
	return 1;
}

void CFontComboBox::GetTheText(CString& str)
{
	int nIndex = GetCurSel();
	if (nIndex == CB_ERR)
		GetWindowText(str);
	else
		GetLBText(nIndex, str);
}
void CFontComboBox::SetTheText(LPCTSTR lpszText,BOOL bMatchExact)
{
	int idx = (bMatchExact) ? FindStringExact(-1,lpszText) :
		FindString(-1, lpszText);
	SetCurSel( (idx==CB_ERR) ? -1 : idx);
	if (idx == CB_ERR)
		SetWindowText(lpszText);
}

void CMainFrame::OnClose()
{
	RECT pRect;
	GetWindowRect( &pRect );

	theApp.WriteProfileInt("Settings", "TopY", pRect.top);
	theApp.WriteProfileInt("Settings", "TopX", pRect.left);
	theApp.WriteProfileInt("Settings", "BottomY", pRect.bottom-pRect.top);
	theApp.WriteProfileInt("Settings", "BottomX", pRect.right-pRect.left);


	CMDIFrameWnd::OnClose();
}


void CMainFrame::MyHelpCheck()
{
 	char sBuf[256];
	char sBufErr[256];
	CFile confFile;
	int retv;
 	CString fileName = "";
	
	fileName = (CString)AfxGetApp()->m_pszHelpFilePath;
	fileName = fileName.Left(fileName.ReverseFind('\\'));
	fileName += "\\StartWrite_User_Manual_Version_6.pdf";
	retv = confFile.Open(fileName, CFile::modeRead);
	if (retv != FALSE) {
		confFile.Close();
		lstrcpyn(sBuf, fileName, sizeof(sBuf));	
		HINSTANCE retH ;

		retH = ShellExecute(NULL, NULL, sBuf, NULL, NULL, SW_SHOW);
		if ((int) retH < 32) {
			_snprintf(sBufErr, sizeof(sBufErr), "Unable to open %s (%d)", sBuf, (int)retH);
			AfxMessageBox(sBufErr);
		}
	}
	else {
		AfxMessageBox("Help Unavailable.  Please download PDF Manual from Website at www.startwrite.com");
	}


}

void CMainFrame::OnPurchase()
{
	ShellExecute(NULL, NULL, "http://www.startwrite.com/purchase_version.php", NULL, NULL, SW_SHOWNORMAL);
}

void CMainFrame::OnUpdateHelpEnterRegistration(CCmdUI *pCmdUI)
{
	pCmdUI->Enable((theApp.m_isDemo == DEMO_RELEASE) ? TRUE : FALSE);
}

void CMainFrame::OnHelpEnterRegistration()
{
	CRegistration60 CDlg;

	CDlg.DoModal();
}

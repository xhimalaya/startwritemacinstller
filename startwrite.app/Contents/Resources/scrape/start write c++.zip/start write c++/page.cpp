// Page Class Implementation

#include "page.h"
#include "miscutil.h"
#include "swdoc.h"
#include "swview.h"
#include "sw.h"

extern int doZoom;
static float saveZoom = -1;
static CDC m_DC;
static BOOL m_bDCCreated = FALSE;

Page::Page(int doInitPage, int defOrientation)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::Page()"); 
	#endif

	nChangePaper = PAGE_PAPER_LETTER;
	nChangeOrientation = defOrientation; // PAGE_ORIENTATION_PORTRAIT;
	SetPixelsFromMembers( nChangePaper, nChangeOrientation);

	// A null bbox slot is an 'empty' slot and can be used
	for(int i=0; i <= MAX_BBOXES; ++i) { 
		pBBoxes[i] = NULL; 
	}

	dCurrentZoom = 1.0;	// This gets set from the document class later
	nCurrentBBox = 0;
	nCurrentRedraw = 0;
	nHoldingLButton = FALSE;
	nDontDraw = FALSE;	// ok to draw
	    
    //CPoint HoldingPosition;
	TmpPosition = CPoint(0,0);

	pHiliteBBox = &HiliteBBox;
	int status = 0;
	pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, &status);

	nCurrentTool = TOOL_NONE;
	nSelection = SEL_OFF;
	nFirstStoryBox = 0;
	nStoryBoxes = 0;

	if (doInitPage) {
		// Create a new text box
		Message(PAGE_NEW_TEXTBOX, 0, &status);
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::Page"); 
	#endif
}

Page::~Page()
{
	for(int i=0; i <= MAX_BBOXES; ++i){ 
		if( pBBoxes[i] != NULL)	{
			delete pBBoxes[i];
			pBBoxes[i] = NULL;
		} 
	}
}

void
Page::Delete()
{
	//wrw?? do we need this one -- delete this;
}

void 
Page::Read(fstream *fin, Module *pmodule, int *status)
{
	char line[128];
	//char string[128];
	pmodule;	/* get rid of compiler warning */
	while( ! fin->eof())
	{
		fin->getline( line, 128, SWD_EQ);

		//wsprintf(string,"Page Tag = %s", line);
		//AfxMessageBox(string);

		if( strcmp(line,SWD_ENDPAGE) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			return;
		}
		else if( strcmp(line,SWD_BEGINBBOX) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			int ncb = PageBBoxNew( status);
			//wsprintf(string,"Doc status = %d", *status);
			//AfxMessageBox(string);
			if( *status == OK)
			{
				// These next two lines fix the last box loaded appears at origin problem.
				// Apparently something happens when the last loaded box is the current box.
				//pBBoxes[nCurrentBBox]->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
				nCurrentBBox = 0;

				pBBoxes[ncb]->Read( fin, NULL, status);

				pBBoxes[ncb]->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
				pBBoxes[ncb]->Message( TEXT_SET_ORIENTATION, nChangeOrientation, status);
			}
		}
		else
		{
			// Ignore the BBoxes, etc...
			fin->getline( line, 128, SWD_NL);
		}
	}
}

int Page::GetBoxScootSnapPos(int nDirection, int curPos)
{
	int nRetVal = curPos;
	int x = 1;
	int y = 0;
	int unzoomedGridX = 0;
	int unzoomedGridY = 0;

	switch (nDirection)
	{
	case BOX_SCOOT_UP_ALT:
		for (y = 39; y >=0; y--) {
			unzoomedGridY = (int)((float)(theApp.m_iGridY[y]) / dCurrentZoom);
			if (unzoomedGridY <= 0 && unzoomedGridY > curPos + BORDER_WIDTH) {
				nRetVal = unzoomedGridY - BORDER_WIDTH;
				if (y < 1) {
					nRetVal -= (DOC_Y_BORDER_PIXELS + 25);
				}
				break;
			}
		}
		break;
	case BOX_SCOOT_DOWN_ALT:
		for (y = 0; y < 40; y++) {
			unzoomedGridY = (int)((float)(theApp.m_iGridY[y]) / dCurrentZoom);
			if (unzoomedGridY < 0 && unzoomedGridY < curPos - BORDER_WIDTH) {
				nRetVal = unzoomedGridY - BORDER_WIDTH;
				if (y < 1) {
					nRetVal -= (DOC_Y_BORDER_PIXELS + 25);
				}
				break;
			}
		}
		break;
	case BOX_SCOOT_LEFT_ALT:
		for (x = 39; x >= 0; --x) {
			unzoomedGridX = (int)((float)(theApp.m_iGridX[x]) / dCurrentZoom);
				if (unzoomedGridX > 0 && unzoomedGridX < curPos - BORDER_WIDTH) {
				nRetVal = unzoomedGridX + BORDER_WIDTH;
				if (x < 1) {
					nRetVal += (DOC_X_BORDER_PIXELS - 25);
				}
				break;
			}
		}
		break;
	case BOX_SCOOT_RIGHT_ALT:
		for (x = 0; x < 40; x++) {
			unzoomedGridX = (int)((float)(theApp.m_iGridX[x]) / dCurrentZoom);
			if (unzoomedGridX > curPos) {
				nRetVal = unzoomedGridX + BORDER_WIDTH;
				if (x < 1) {
					nRetVal += (DOC_X_BORDER_PIXELS - 25);
				}
				break;
			}
		}
		break;
	}

	return nRetVal;
}
void
Page::Write(fstream *fout, Module *pmodule, int *status)
{
	pmodule;	/* get rid of compiler warning */
	*fout << SWD_BEGINPAGE 	<< SWD_EQ 	<< "*" 		<< SWD_NL;

	for(int i=0; i <= MAX_BBOXES; ++i){ 
		if( pBBoxes[i] != NULL)	{
			pBBoxes[i]->Write( fout, NULL, status);
		} 
	}

	*fout << SWD_ENDPAGE		<< SWD_EQ	<< "*"		 << SWD_NL;

	*status = OK;
}


float Page::Message(int message, float number, int *status)
{
	float RI = 0.0;
	int j;

	switch(message) {
		case PAGE_SET_ZOOM:
			RI = dCurrentZoom;
			dCurrentZoom = number;
			*status = OK;
			for( j = 1; j <= MAX_BBOXES; j++) {
				if (pBBoxes[j]) {
					pBBoxes[j]->Message( BBOX_SET_ZOOM, number, status);
				}
			}

			break;
	}
	return(RI);
}

int 
Page::Message( int message, int number, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::Message(int,int,int*)"); 
	#endif

	// Return Integer
	int RI = 0;
	int saveGrow;

	CPoint cpTemp(0, 0);

	switch(message)
	{
		case PAGE_NEW_TEXTBOX:
			{
			int nbbox = PageBBoxNew(status);
			if( *status == OK) {
				BBox *pcbbox = pBBoxes[nbbox];
				CPoint newbox, newsize, curBox;
				int tempStatus, increase, savezoom;

				newbox.y = -5*DOC_Y_BORDER_PIXELS + number;
				newbox.x = DOC_X_BORDER_PIXELS + 200;

				newsize.y = -200;
				newsize.x = nXPixels - (2*DOC_X_BORDER_PIXELS)-500;

				// Off set the box from another if necessary
				increase = 200;	//(int)((float)200 * dCurrentZoom);
				savezoom = doZoom;
				doZoom = 0;
				for(int i=1; i <= MAX_BBOXES; ++i) 
				{ 
					BBox* pbbox = pBBoxes[i];
					if( pbbox != NULL) {
						tempStatus = 0;//-5;
						curBox = pbbox->Message(BBOX_POSITION_GET, CPoint(0,0), &tempStatus);
						if (curBox == newbox) {
							newbox.x += increase;			// adjust down and over
							newbox.y -= increase;
							if (newsize.x > increase) {
								newsize.x -= increase;		// and shrink size if possible
							}
							i = 0;	// restart check
						}
					}
				}
				doZoom = savezoom;
				
				
				*status = CLEAROLD;
				TmpPosition = pcbbox->Message( BBOX_POSITION_SET, newbox, status);
				*status = CLEAROLD;
				
				saveGrow = pcbbox->Message(BBOX_CAN_GROW, 1, status);
				
				pcbbox->Message(BBOX_SET_GROW, 1, status);

				TmpPosition = pcbbox->Message( BBOX_SIZE_SET, newsize, status);

				TextItem *item = new TextItem();

				// Make sure the zoom is set properly
				pcbbox->Message( BBOX_SET_ZOOM, dCurrentZoom, status);
				item->Message(TEXT_SET_DZOOM, dCurrentZoom, status);

				// Make sure the text box is large enough for one char height
				int miny = item->Message(TEXTITEM_GET_LINEHEIGHT, 0, status);
				if (-miny < newsize.y) {    	// If we are not big enough
					newsize.y = -miny;		// set to minimum
					if (miny > newsize.x) {	// make sure width is at least as long
						newsize.x = miny;
					}
					*status = CLEAROLD;
					pcbbox->Message( BBOX_SIZE_SET, newsize, status);
				}


				pcbbox->Message( BBOX_ITEM_SET, item, status);
				item->Message( ITEM_PARENT_SET, pcbbox, status);

				pcbbox->Message( BBOX_VISIBLE_SET, TRUE, status);
    			pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
	    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);    

				pcbbox->Message( ITEM_ENTER_EDIT_MODE, EMPTY_INT, status);
				pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);

				// restore grow state
				pcbbox->Message(BBOX_SET_GROW, saveGrow, status);
				tempStatus = ERROR;
				ClearArtBoxesOverlappedByThisBox(pcbbox, TRUE, MAX_BBOXES);
			}
			}
			break;
		case PAGE_UPDATE_OVERLAP:
			{
				// If number passed is 0, use current bbox
				// If > 0, use that box (index in pBBoxes[])
				RI = 0;
				int tempStatus = ERROR;
				int nBoxToCheck = 0;
				if (number > 0) {
					nBoxToCheck = number;
				}
				else {
					nBoxToCheck = nCurrentBBox;
				}
				if (nBoxToCheck > 0 && nBoxToCheck <= MAX_BBOXES && pBBoxes[nBoxToCheck] != NULL) {
					BBox *pcbbox = pBBoxes[nBoxToCheck];
					RI = ClearArtBoxesOverlappedByThisBox(pcbbox, TRUE, MAX_BBOXES);
				}
			}
			break;

		case PAGE_ACTIVATED:
	    	if (pBBoxes[nCurrentBBox] != NULL)
	    		pBBoxes[nCurrentBBox]->Item->Message(message, number, status);

        	*status = 0;

	    	break;
	    
			        
        case PAGE_NONE:
        	*status = ERROR;
        break;

		case PAGE_CHANGE_PAPER:
			nChangePaper = number;
			SetPixelsFromMembers( nChangePaper, nChangeOrientation);
			*status = OK;
		break;
        
		case PAGE_CHANGE_ORIENTATION:
			nChangeOrientation = number;
			SetPixelsFromMembers( nChangePaper, nChangeOrientation);
// WRW
			{
			int j;
				for( j = 1; j <= MAX_BBOXES; j++) {
					if (pBBoxes[j]) {
						pBBoxes[j]->Message( BBOX_MAX_XY_SET, CPoint(nXPixels,-nYPixels), status);
						pBBoxes[j]->Message( TEXT_SET_ORIENTATION, number, status);
					}
				}
			}

			*status = OK;
		break;
	    
	    case PAGE_BBOX_NEW:
			RI = PageBBoxNew( status);
	    break;

		case TOOL_GET:
			RI = nCurrentTool;
			*status = OK;
		break;

		case TOOL_SET:
			RI = nCurrentTool;
			nCurrentTool = number;
			*status = OK;
		break;

		case BBOX_CENTER_ON_PAGE:

			*status = CLEAROLD;
			//
			if( pBBoxes[nCurrentBBox] != NULL) {
				int tempStatus = 0;
				CPoint curPos(0,0);
				CPoint curSize(0,0);
				int minx, maxx, miny, maxy;
				int tempX, tempY;
				int savezoom = doZoom;
				doZoom = 0;
				
				curPos = pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_GET, cpTemp, status);
				curSize = pBBoxes[nCurrentBBox]->Message( BBOX_SIZE_GET, cpTemp, status);
				minx =  DOC_Y_BORDER_PIXELS;
				maxx = nXPixels - DOC_Y_BORDER_PIXELS;
				miny = -DOC_Y_BORDER_PIXELS;
				maxy = (nYPixels - DOC_Y_BORDER_PIXELS);

				tempX = maxx - minx - curSize.x;
				if (tempX  > 0) {
					tempX /= 2;	// divide the space in half
					curPos.x = tempX+minx; //(int)((double)(tempX+minx)  * dCurrentZoom);
					
					tempY = maxy - miny + curSize.y;
					if (tempY > 0) {
						tempY /= 2;
						curPos.y = -(tempY + miny); // (int) ((double)-(tempY + miny)  * dCurrentZoom);
			    		pBBoxes[nCurrentBBox]->Message(ART_SET_RELOAD, TRUE, &tempStatus);
						pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_SET, curPos, status);
					}
				}
				doZoom = savezoom;
				Message(PAGE_UPDATE_OVERLAP, 0, &tempStatus);
			}
			break;

		case BBOX_CENTER_HORIZONTAL:

			*status = CLEAROLD;
			//
			if( pBBoxes[nCurrentBBox] != NULL) {
				int tempStatus = 0;
				CPoint curPos(0,0);
				CPoint curSize(0,0);
				int minx, maxx;
				int tempX;
				int savezoom = doZoom;
				doZoom = 0;
				
				curPos = pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_GET, cpTemp, status);
				curSize = pBBoxes[nCurrentBBox]->Message( BBOX_SIZE_GET, cpTemp, status);
				minx =  DOC_Y_BORDER_PIXELS;
				maxx = nXPixels - DOC_Y_BORDER_PIXELS;
				tempX = maxx - minx - curSize.x;
				if (tempX  > 0) {
					tempX /= 2;	// divide the space in half
					curPos.x = tempX+minx; //(int)((double)(tempX+minx)  * dCurrentZoom);
					
			    	pBBoxes[nCurrentBBox]->Message(ART_SET_RELOAD, TRUE, &tempStatus);
					pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_SET, curPos, status);
				}
				doZoom = savezoom;
				Message(PAGE_UPDATE_OVERLAP, 0, &tempStatus);
			}
			break;

		case BBOX_CENTER_VERTICAL:

			*status = CLEAROLD;
			//
			if( pBBoxes[nCurrentBBox] != NULL) {
				CPoint curPos(0,0);
				CPoint curSize(0,0);
				int miny, maxy;
				int tempY;
				int savezoom = doZoom;
				doZoom = 0;
				
				curPos = pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_GET, cpTemp, status);
				curSize = pBBoxes[nCurrentBBox]->Message( BBOX_SIZE_GET, cpTemp, status);
				miny = -DOC_Y_BORDER_PIXELS;
				maxy = (nYPixels - DOC_Y_BORDER_PIXELS);

				tempY = maxy - miny + curSize.y;
				if (tempY > 0) {
					tempY /= 2;
					curPos.y = -(tempY + miny); // (int) ((double)-(tempY + miny)  * dCurrentZoom);
					pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_SET, curPos, status);
				}
				doZoom = savezoom;
			}
			break;

		case DELETE_SELECTED_ITEM:

	    	*status = ERROR;
	    	if( pBBoxes[nCurrentBBox] != NULL)
	    	{
				BBox *pcbbox = pBBoxes[nCurrentBBox];
				pBBoxes[nCurrentBBox] = NULL;
				nCurrentBBox = 0;
				delete(pcbbox);
				*status = OK;
	    	}	    
	    break;
		case DOC_SET_DONTDRAW:
			nDontDraw = number;
			*status = OK;
			message = ART_CLEAR_IMAGE;
			// Allow to fall through

		case ART_SET_RELOAD:	// Set to rebuild each graphic
		case ART_CLEAR_IMAGE:	// disable/clear each graphic
			{
			int j;
				for( j = 1; j <= MAX_BBOXES; j++) {
					if (pBBoxes[j]) {
						pBBoxes[j]->Message( message, number, status);
					}
				}
			}
			*status = OK;
		break;
		case KEY_DOWN_SPECIAL:
			*status = CLEAROLD;
			if( pBBoxes[nCurrentBBox] != NULL) {
				int moveVal = 15;
				int moveValLarge = 150;
				int moveValGrid = (PIXELS_PER_INCH / 4/*!!! * dCurrentZoom*/);
				CPoint curPos(0,0);
				CPoint newPos(0,0);
				int savezoom = doZoom;
				doZoom = 0;

				CPoint curSize = pBBoxes[nCurrentBBox]->Message( BBOX_SIZE_GET, EMPTY_CPOINT, status);
				curPos = pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status);
				newPos = curPos;
				CPoint cpRet2 = pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status);
				switch(number){
				case BOX_SCOOT_UP:// Moves one pixel
					newPos.y += moveVal;
					break;
				case BOX_SCOOT_DOWN:// Moves one pixel
					newPos.y -= moveVal;
					break;
				case BOX_SCOOT_LEFT:// Moves one pixel
					newPos.x -= moveVal;
					break;
				case BOX_SCOOT_RIGHT:// Moves one pixel
					newPos.x += moveVal;
					break;
				case BOX_SCOOT_UP_ALT:// A larger move, and it depends on the state of the grid
					if (!theApp.m_isGridVisible) {
						newPos.y += moveValLarge;
					}
					else if (theApp.m_isGridVisible && !theApp.m_isGridSnapTo) {
						newPos.y += moveValGrid;
					}
					else if (theApp.m_isGridVisible && theApp.m_isGridSnapTo) {
						// Snaps to grid
						newPos.y = GetBoxScootSnapPos(BOX_SCOOT_UP_ALT, newPos.y);
					}
					break;
				case BOX_SCOOT_DOWN_ALT:// A larger move, and it depends on the state of the grid
					if (!theApp.m_isGridVisible) {
						newPos.y -= moveValLarge;
					}
					else if (theApp.m_isGridVisible && !theApp.m_isGridSnapTo) {
						newPos.y -= moveValGrid;
					}
					else if (theApp.m_isGridVisible && theApp.m_isGridSnapTo) {
						// Snaps to grid
						newPos.y = GetBoxScootSnapPos(BOX_SCOOT_DOWN_ALT, newPos.y);
					}
					break;
				case BOX_SCOOT_LEFT_ALT:// A larger move, and it depends on the state of the grid
					if (!theApp.m_isGridVisible) {
						newPos.x -= moveValLarge;
					}
					else if (theApp.m_isGridVisible && !theApp.m_isGridSnapTo) {
						newPos.x -= moveValGrid;
					}
					else if (theApp.m_isGridVisible && theApp.m_isGridSnapTo) {
						// Snaps to grid
						newPos.x = GetBoxScootSnapPos(BOX_SCOOT_LEFT_ALT, newPos.x);
					}
					break;
				case BOX_SCOOT_RIGHT_ALT:// A larger move, and it depends on the state of the grid
					if (!theApp.m_isGridVisible) {
						newPos.x += moveValLarge;
					}
					else if (theApp.m_isGridVisible && !theApp.m_isGridSnapTo) {
						newPos.x += moveValGrid;
					}
					else if (theApp.m_isGridVisible && theApp.m_isGridSnapTo) {
						// Snaps to grid
						newPos.x = GetBoxScootSnapPos(BOX_SCOOT_RIGHT_ALT, newPos.x);
					}
					break;
				}
				// Don't let it move off the left side of the page
				if (newPos.x < DOC_X_BORDER_PIXELS + 25 + BORDER_WIDTH)
					newPos.x = DOC_X_BORDER_PIXELS + 25 + BORDER_WIDTH;
				// Don't let it move above the top of the page
				if (newPos.y > -(DOC_Y_BORDER_PIXELS + 25 + BORDER_WIDTH))
					newPos.y = -(DOC_Y_BORDER_PIXELS + 25 + BORDER_WIDTH);
				// Don't let it move off the right side of the page
				if (newPos.x + curSize.x > nXPixels-(2*DOC_X_BORDER_PIXELS)-25)
					newPos.x = curPos.x;
				// Don't let it move off the bottom of the page
				if (newPos.y + curSize.y < -nYPixels+(2*DOC_Y_BORDER_PIXELS)+25)
					newPos.y = curPos.y;

				if (newPos.y != curPos.y || newPos.x != curPos.x)
				{
					theApp.m_isGridWiped = TRUE;
					*status = CLEAROLD;
					pBBoxes[nCurrentBBox]->Message( BBOX_POSITION_SET, newPos, status);
					pBBoxes[nCurrentBBox]->Message( ART_SET_RELOAD, TRUE, status);
					int tempStatus = ERROR;
					pBBoxes[nCurrentBBox]->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
					ClearArtBoxesOverlappedByThisBox(pBBoxes[nCurrentBBox], TRUE, MAX_BBOXES);
					pBBoxes[nCurrentBBox]->Message(TEXT_SELECTION_OFF, EMPTY_CPOINT, status);
				}

				doZoom = savezoom;
			}

			*status = OK;
			break;
 
		case DOC_STORY_PUSH_TEXT:	// Handle Story textitem overflow text (push text)
			{
				int j;
				RI = 0;

				int failsafe = 0;
				while (theApp.m_iStoryOverflowBox > 0 && theApp.m_iStoryOverflowBox >= nFirstStoryBox && theApp.m_iStoryOverflowBox < nFirstStoryBox + nStoryBoxes && theApp.m_iStoryOverflowDirection) {
					for (j = 1; j <= MAX_BBOXES; j++) {
						if (pBBoxes[j] != NULL
						&& theApp.m_iStoryOverflowBox > 0
						&& pBBoxes[j]->Item->m_iType == ITEM_TEXT_TYPE
						&& ((TextItem *)(pBBoxes[j]->Item))->StoryItemOrder == theApp.m_iStoryOverflowBox
						&& ((TextItem *)(pBBoxes[j]->Item))->StoryNumber == 1) {
							pBBoxes[j]->Message( message, 0, status);
							if (m_bDCCreated) {
								*status = TEXT_DRAW_ALL;
								pBBoxes[j]->Draw(&m_DC, status);
							}
							if (((TextItem *)(pBBoxes[j]->Item))->StoryBoxFull) {
								((TextItem *)(pBBoxes[j]->Item))->StoryFlowInState = STORY_FLOW_INSERT;
							}
							break;
						}
					}
					if (++failsafe > 999) {
						//Trace("//!!!ERROR: DOC_STORY_PUSH_TEXT STOPPED BY FAILSAFE!!!");
						break;
					}
				}
			}
			*status = OK;
		break;
 
		case DOC_STORY_COLLECT: // Collect Story text as required for redistribution
			{
				int j;
				RI = 0;

				int failsafe = 0;
				while (theApp.m_iStoryOverflowBox > 0 && theApp.m_iStoryOverflowBox >= nFirstStoryBox && theApp.m_iStoryOverflowBox < nFirstStoryBox + nStoryBoxes) {
					for (j = 1; j <= MAX_BBOXES; j++) {
						if (pBBoxes[j] != NULL
						&& theApp.m_iStoryOverflowBox > 0
						&& pBBoxes[j]->Item->m_iType == ITEM_TEXT_TYPE
						&& ((TextItem *)(pBBoxes[j]->Item))->StoryItemOrder == theApp.m_iStoryOverflowBox
						&& ((TextItem *)(pBBoxes[j]->Item))->StoryNumber == 1) {
							pBBoxes[j]->Message( message, 0, status);
							break;
						}
					}
					if (++failsafe > 999) {
						//Trace("//!!!ERROR: DOC_STORY_COLLECT STOPPED BY FAILSAFE!!!");
						break;
					}
				}
			}
			*status = OK;
		break;
 
		case TEXT_SET_STORY_ITEM_ORDER:	// Put Story textitems into their correct order in the story
			{
				nFirstStoryBox = number;
				int setLast = 0;

				CPoint cpBoxPos[MAX_BBOXES+1];
				int nStoryBoxesInDoc = number - 1;
				int nStoryBoxesInPage = 0;
				int nStoryBoxInPage = 0;
				// A Story flows through its related textitems from page 1 to end, top to bottom, and left to right
				int nBox;
				// First, count the story boxes in the page
				for(nBox = 1; nBox <= MAX_BBOXES; nBox++) {
					if (pBBoxes[nBox] != NULL
					&& pBBoxes[nBox]->Item->m_iType == ITEM_TEXT_TYPE
					&& ((TextItem *)(pBBoxes[nBox]->Item))->StoryNumber == 1) {
						cpBoxPos[nBox] = pBBoxes[nBox]->Message( BBOX_POSITION_GET, cpTemp, status);
						++nStoryBoxesInPage;
					}
				}
				// Put story boxes in flow order until we have accounted for all of the Story boxes in the page
				int nCurrentBox = 0;
				int nHigherBox = 0;
				while (nStoryBoxInPage < nStoryBoxesInPage) {
					bool bFoundHigher = FALSE;
					bool bFoundLower = FALSE;
					for(nBox = 1; pBBoxes[nBox] && (nBox <= MAX_BBOXES); nBox++) {
						if (pBBoxes[nBox] != NULL
						&& pBBoxes[nBox]->Item->m_iType == ITEM_TEXT_TYPE
						&& ((TextItem *)(pBBoxes[nBox]->Item))->StoryNumber == 1) {
							if (!bFoundHigher && (nCurrentBox == 0 || abs(cpBoxPos[nBox].y) > abs(cpBoxPos[nCurrentBox].y)
							|| abs(cpBoxPos[nBox].y) == abs(cpBoxPos[nCurrentBox].y) && cpBoxPos[nBox].x < cpBoxPos[nCurrentBox].x)) {
								nHigherBox = nBox;
								bFoundHigher = TRUE;
							}
							else if (bFoundHigher && abs(cpBoxPos[nBox].y) > abs(cpBoxPos[nCurrentBox].y) && abs(cpBoxPos[nBox].y) < abs(cpBoxPos[nHigherBox].y)) {
								nHigherBox = nBox;
								bFoundLower = TRUE;
							}
						}
					}
					nCurrentBox = nHigherBox;
					++nStoryBoxInPage;
					setLast = 0;
					pBBoxes[nCurrentBox]->Message( message, nStoryBoxesInDoc + nStoryBoxInPage, &setLast);
				}
				nStoryBoxes = nStoryBoxesInPage;
				RI = nStoryBoxesInDoc + nStoryBoxesInPage;
			}
			*status = OK;
		break;
 
		default:
			if( pBBoxes[nCurrentBBox] != NULL)
			{
				RI = pBBoxes[nCurrentBBox]->Message( message, number, status);
			}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::Message: %d", status); 
	#endif

	return RI;
}

CPoint
Page::Message( int message, CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::Message(int,CPoint,int*)"); 
	#endif

	// Return CPoint
	CPoint RCP;
	RCP.x = 0;
	RCP.y = 0;
    
	switch(message)
	{

        case PAGE_NONE:
        	*status = ERROR;
        break;

		case PAGE_PIXELS_GET:
			RCP.x = nXPixels;
			RCP.y = nYPixels;
			*status = OK;
		break;

		case PAGE_PIXELS_MAX_GET:
			if( nXPixels > nYPixels) {
				RCP.x = nXPixels;
				RCP.y = nXPixels;
		    }
		    else  {
				RCP.x = nYPixels;
				RCP.y = nYPixels;		    
		    }
		    *status = OK;
		break;

		case MOUSE_LBUTTON_DOWN:
			//Trace("Button down, tool = %d", nCurrentTool);

			if( nCurrentTool == TOOL_NONE)
			{
				RCP = MouseLButtonDown( point, status);
			}
			else
			{
				RCP = ToolBeginUsing( point, status);
			}
		break;

		case MOUSE_MOVE:
			//Trace("Mouse move, tool = %d", nCurrentTool);

			if( nCurrentTool == TOOL_NONE)
			{
				RCP = MouseMove( point, status);
			}
			else
			{
				nDontDraw = TRUE;	// stop allowing redraw
				RCP = ToolWhileUsing( point, status);
			}
		break;

		case MOUSE_LBUTTON_UP:
			//Trace("Button up, tool = %d", nCurrentTool);

			nDontDraw = FALSE;	// reset drawing
			if( nCurrentTool == TOOL_NONE) {
				RCP = MouseLButtonUp( point, status);
			}
			else {
				RCP = ToolEndUsing( point, status);
			}
		break;

		case PAGE_NEW_ARTBOX:
			{
			int nbbox = PageBBoxNew( status);
			if( *status == OK) {
				BBox *pcbbox = pBBoxes[nbbox];
				CPoint newbox, newsize, curBox, newScroll;
				int tempStatus;

				ArtItem *item = new ArtItem();
				item->Message( ITEM_DIALOG_EDIT, EMPTY_INT, status);

				pcbbox->Message( BBOX_ITEM_SET, item, status);
				if (*status == ERROR) {
					*status = ERROR;
				}
				else {
					item->Message( ITEM_PARENT_SET, pcbbox, status);

					newbox.x = 400 + point.x;
					newbox.y = (-400 + point.y);
					newsize.x = 2400;
					newsize.y = -2400;

					newScroll.y = point.y;
					newScroll.x = point.x;
					pcbbox->Message(ART_SET_SCROLL, newScroll, &tempStatus);
					pcbbox->Message( BBOX_SET_ZOOM, dCurrentZoom, &tempStatus);

					// Off set the box from another if necessary
					for(int i=1; i <= MAX_BBOXES; ++i) 
					{ 
						BBox* pbbox = pBBoxes[i];
						if( pbbox != NULL) {
							tempStatus = -5;
							curBox = pbbox->Message(BBOX_POSITION_GET, CPoint(0,0), &tempStatus);
							if (curBox == newbox) {
								newbox.x += 250;			// adjust down and over
								newbox.y -= 250;
								i = 0;	// restart check
							}
						}
					}
					
					*status = CLEAROLD;
  					pcbbox->Message( BBOX_POSITION_SET, newbox, status);
   
					*status = CLEAROLD;
	   				pcbbox->Message( BBOX_SIZE_SET, newsize, status);

					pcbbox->Message( BBOX_VISIBLE_SET, TRUE, status);
	    			pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
					pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);    
				}
				tempStatus = ERROR;
				ClearArtBoxesOverlappedByThisBox(pcbbox, TRUE, MAX_BBOXES);
			}
			}

			break;

		case ART_SET_SCROLL:
			{
			int j;
				for( j = 1; j <= MAX_BBOXES; j++) {
					if (pBBoxes[j]) {
						pBBoxes[j]->Message( message, point, status);
					}
				}
			}
		break;
		
		case TEXT_SET_BORDER_ART_SCROLL:
			{
			int j;
				for( j = 1; j <= MAX_BBOXES; j++) {
					if (pBBoxes[j] != NULL) {
						pBBoxes[j]->Message( message, point, status);
					}
				}
			}
		break;
		
		case TEXT_SELECTION_OFF:		// Special case to turn off selection
			nSelection = SEL_OFF;		// We need to tell the page too
			// Fall through

		default:
			if( pBBoxes[nCurrentBBox] != NULL)
			{
				//AfxMessageBox("Passing from page to bbox!");
				RCP = pBBoxes[nCurrentBBox]->Message( message, point, status);
			}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::Message: %d", status); 
	#endif

	return RCP;
}

Module*
Page::Message( int message, Module *pmodule, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::Message(int,Module*,int*)"); 
	#endif

	// Return Module
	Module *RM = NULL;
	int isvisible = FALSE;

	switch(message)
	{
        case PAGE_NONE:
        	*status = ERROR;
        break;

		case GET_ITEM_FOR_REDRAW:
    		isvisible = pHiliteBBox->Message( BBOX_VISIBLE_GET, EMPTY_INT, status);
    		if( isvisible == TRUE)
    		{
    			RM = pHiliteBBox;
    		}
			else if (pBBoxes[nCurrentRedraw] != NULL) {
				RM = pBBoxes[nCurrentRedraw];
				nCurrentRedraw = 0;
			}
    		else if( pBBoxes[nCurrentBBox] != NULL)
			{
				RM = pBBoxes[nCurrentBBox];
    		}

		break;

		case COPY_AND_PASTE_THIS_BOX:
			if( pmodule != NULL)
			{
				Module *null_module = NULL;
				RM = pmodule->Message( ITEM_RETURN_COPY, null_module, status);
				PageBBoxAdd( (BBox *)RM, status);
			}
		break;

		default:
			if( pBBoxes[nCurrentBBox] != NULL)
			{
				RM = pBBoxes[nCurrentBBox]->Message( message, pmodule, status);
			}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::Message: %d", status); 
	#endif

	return RM;
}

//DEVMODE 	devmode;

void
Page::Draw(CDC* pDC, int *status)
{
	if (!m_bDCCreated) {
		m_DC.CreateCompatibleDC(pDC);
		m_bDCCreated = TRUE;
		m_DC.SetMapMode(MM_TWIPS);
	}

	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::Draw(CDC,int*)"); 
	#endif

	// Just don't display while in printmode
	if (nDontDraw &&  !pDC->IsPrinting()) {
		*status = OK;
		return;
	}

    /*  Draw the page border */ 
    if( ! pDC->IsPrinting())   {
		SetPixelsFromMembers( nChangePaper, nChangeOrientation);
		int xval, yval;
		int xpix, ypix;

		xval = (int)((float)DOC_X_BORDER_PIXELS * dCurrentZoom);
		yval = (int)((float)DOC_Y_BORDER_PIXELS * dCurrentZoom);
		xpix = (int)((float)(nXPixels+DOC_X_BORDER_PIXELS) * dCurrentZoom);
		ypix = (int)((float)(nYPixels+DOC_Y_BORDER_PIXELS) * dCurrentZoom);
		int adjval = (int)((float)5.0 * dCurrentZoom);

/* NEWPAGE */
		int FULLPAGE = (int)((nXPixels > nYPixels) ? nXPixels : nYPixels);
		FULLPAGE += (FULLPAGE / 4);
		if (dCurrentZoom > 1.0) {	// only do it on larger zooms, otherwise white space on outer edge
			FULLPAGE = (int)((float)(FULLPAGE * dCurrentZoom));
			if (FULLPAGE > (32*1024))
				FULLPAGE = (32*1024)-1;
		}

		//CPen newOutline(PS_SOLID, 1, RGB( 100, 100, 100));
		CPen newOutline(PS_NULL, 1, RGB( 255, 0, 0));
		CPen *oldpen = pDC->SelectObject(&newOutline);
		pDC->SelectStockObject(GRAY_BRUSH);
		pDC->Rectangle(CRect(0,0, FULLPAGE, -yval));
		pDC->Rectangle(CRect(0,0, xval, -FULLPAGE));
		pDC->Rectangle(CRect(xpix-xval, 0, FULLPAGE, -FULLPAGE));
		pDC->Rectangle(CRect(0, -(ypix-yval), FULLPAGE, -FULLPAGE));

		// Draw the grid
		for (int i = 0; i < 50; i++) {
			theApp.m_iGridX[i] = 0;
			theApp.m_iGridXUsed[i] = 0;
		}
		for (int i = 0; i < 50; i++) {
			theApp.m_iGridY[i] = 0;
			theApp.m_iGridYUsed[i] = 0;
		}
		theApp.m_isGridWiped = FALSE;
		if (theApp.m_isGridVisible) {
			CPen penGridInch(PS_SOLID, 1, RGB(128,128,255));
			CPen penGridFraction(PS_SOLID, 1, RGB(204,204,255));

			// Calculate Y increment and Y numlines
			//int yTotal = -ypix + yval + 25;
			int yInc = -(int)(PIXELS_PER_INCH / 4 * dCurrentZoom);// 1/4-inch grid squares
			int yLine = 0;
			// Draw the horizontal gridline
			int yPos = -yval + 25;
			for (yLine=1; yLine < theApp.m_iGridMaxY; yLine++) {
				pDC->SelectObject(((yLine+1) % 4) ? &penGridFraction : &penGridInch);
				yPos += yInc;
				theApp.m_iGridY[yLine] = yPos;
				pDC->MoveTo(xval - 25, yPos);// Left side start of gridline
				pDC->LineTo(xpix - xval, yPos);// To right side
			}

			// Calculate X increment and X numlines
			//int xTotal = (xpix - xval) - (xval-adjval-25);
			int xInc = (int)(PIXELS_PER_INCH / 4 * dCurrentZoom);// 1/4-inch grid squares
			int xLine = 0;
			// Draw the horizontal gridline
			int xPos = xval-adjval-25;
			theApp.m_iGridX[xLine] = xPos;
			for (xLine=1; xLine < theApp.m_iGridMaxX; xLine++) {
				pDC->SelectObject(((xLine + 1) % 4) ? &penGridFraction : &penGridInch);
				xPos += xInc;
				theApp.m_iGridX[xLine] = xPos;
				pDC->MoveTo(xPos, -yval);// Top start of gridline
				pDC->LineTo(xPos, -(ypix - yval));// To bottom
			}
		}


/* NEWPAGE */
		
//		pDC->SelectObject(&outlinepen);
//		pDC->MoveTo( xval, -yval+adjval);	// top/left
//		pDC->LineTo( xpix - xval, -yval+adjval);	// to top/right
		CPen shadowpen(PS_SOLID, 25, RGB(0,0,0));

		pDC->SelectObject(&shadowpen);
		pDC->MoveTo(xpix - xval, -yval-25);
		pDC->LineTo( xpix - xval, -(ypix - yval));	// to bottom/right
		pDC->LineTo( xval+25, -(ypix - yval));			// to bottom/left
		pDC->MoveTo( xval-adjval, -(ypix - yval));
//		pDC->SelectObject(&outlinepen);
//		pDC->LineTo( xval-adjval, -yval);					// to top/left

		pDC->SelectObject(oldpen);
	}
	/**/

	int 	j;
	BBox	*pboxCurrent;
	CPoint cpTemp(0, 0);

	if (nCurrentBBox > 0)
		pboxCurrent = pBBoxes[nCurrentBBox];
	else
		pboxCurrent = NULL;

	BBox* pbbox = NULL;
	int tempStatus = ERROR;
	int isOverlapped = FALSE;
	int drawOrder[MAX_BBOXES + 1];
	// Draw overlapped/underneath art boxes first so they stay underneath
	// (And collect the draw order information for all the boxes)
	for(j=1; j <= MAX_BBOXES; ++j) { 
		pbbox = pBBoxes[j];
		if (( pbbox != NULL) && (pbbox != pboxCurrent)) {
			isOverlapped = pbbox->Message(ART_GET_OVERLAPPED, 0, &tempStatus);
			drawOrder[j] = isOverlapped ? 1 : (2 + tempStatus);// tempStatus = ERROR if a text box (not an art box)
			if (drawOrder[j] == 1) {
				pbbox->Draw(pDC, status);
			}
		}
	}
	// Now draw other boxes that aren't overlapped art boxes
	// The text boxes
	for(j=1; j <= MAX_BBOXES; ++j) { 
		pbbox = pBBoxes[j];
		if (( pbbox != NULL) && (pbbox != pboxCurrent) && (drawOrder[j] == 2)) {
			pbbox->Draw(pDC, status);
		}
	}
	// Lastly, the art boxes that were not cleared must be on top
	for(j=1; j <= MAX_BBOXES; ++j) { 
		pbbox = pBBoxes[j];
		if (( pbbox != NULL) && (pbbox != pboxCurrent) && (drawOrder[j] == 3)) {
			pbbox->Draw(pDC, status);
		}
	}

	// Draw the current bbox on it's proper layer
	// (so it appears in front of others when moving)
	if (pboxCurrent != NULL) {
		pboxCurrent->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
		pboxCurrent->Draw(pDC, status);		                  
		theApp.m_bStoryTextWasMoved = FALSE;
	}

	if( pHiliteBBox->Message( BBOX_VISIBLE_GET, EMPTY_INT, status) == TRUE)	{
		if (pHiliteBBox != pboxCurrent) {
			pHiliteBBox->Draw(pDC, status);
		}
	}

	// We currently can't draw the red-hot grid line where items exist
	if (theApp.m_isGridVisible) {
		for(j=1; j <= MAX_BBOXES; ++j) { 
			pbbox = pBBoxes[j];
			if (pbbox != NULL) {
				CPoint tSize;
				CPoint tPos;
				tSize = pbbox->Message( BBOX_SIZE_GET, cpTemp, status);
				tPos = pbbox->Message( BBOX_POSITION_GET, cpTemp, status);
				for (int yLine=1; yLine < theApp.m_iGridMaxY; yLine++) {
					if (theApp.m_iGridY[yLine] <= tPos.y && theApp.m_iGridY[yLine] > tPos.y + tSize.y) {
						theApp.m_iGridYUsed[yLine] = 1;
					}
				}
				for (int xLine=1; xLine < theApp.m_iGridMaxX; xLine++) {
					if (theApp.m_iGridX[xLine] > tPos.x && theApp.m_iGridX[xLine] < tPos.x + tSize.x) {
						theApp.m_iGridXUsed[xLine] = 1;
					}
				}
			}
		}
	}
#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::Draw: void"); 
	#endif
}

/////////////////////////////////////////////////////////////////////////////
// Private Member Functions
/////////////////////////////////////////////////////////////////////////////

void
Page::SetPixelsFromMembers(int nPaper, int nOrientation)
{
	theApp.m_iGridMaxX = 0;
	theApp.m_iGridMaxY = 0;
	if( nPaper == PAGE_PAPER_LETTER)
	{
		float xval,yval;
		if (doRunUKVersion || (*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {	//SHERSTON
			xval = PAGE_A1_WD;
			yval = PAGE_A1_HT;
		}
		else {					// ALL ELSE
			xval = PAGE_US_WD;
			yval = PAGE_US_HT;
		}

		if( nOrientation == PAGE_ORIENTATION_PORTRAIT)
		{
			nXPixels = (int) (xval * (float)PIXELS_PER_INCH);
			nYPixels = (int) (yval * (float)PIXELS_PER_INCH);
			theApp.m_iGridMaxX = min(50, (int)(xval * 4.00 + 0.5));// 1/4 inch grid
			theApp.m_iGridMaxY = min(50, (int)(yval * 4.00 + 0.5));// 1/4 inch grid
		}
		else if( nOrientation == PAGE_ORIENTATION_LANDSCAPE)
		{
			nXPixels = (int) (yval * (float)PIXELS_PER_INCH);
			nYPixels = (int) (xval * (float)PIXELS_PER_INCH); 
			theApp.m_iGridMaxX = min(50, (int)(yval * 4.00 + 0.5));// 1/4 inch grid
			theApp.m_iGridMaxY = min(50, (int)(xval * 4.00 + 0.5));// 1/4 inch grid
		}
		else
		{
			nXPixels = 0;
			nYPixels = 0;
		}
	}
	else
	{
		nXPixels = 0;
		nYPixels = 0;
	}
}

int
Page::PageBBoxNew( int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::PageBBoxNew(int*)"); 
	#endif

	BBox *pcbbox = NULL;

	*status = ERROR;		// Assume failure.  Need a default for the MAX_BOXES case

	for(int i=1; i <= MAX_BBOXES; ++i) 
	{ 
		BBox* pbbox = pBBoxes[i];

		if( pbbox == NULL)
		{
			// Deselect the current box...
			if( nCurrentBBox > 0)
			{
				pcbbox = pBBoxes[nCurrentBBox];
				if (pcbbox) {
					pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
				}
			}

			pBBoxes[i] = new BBox();
			nCurrentBBox = i;

			pcbbox = pBBoxes[nCurrentBBox];

			if (pcbbox) {
				pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
				pcbbox->Message( BBOX_MAX_XY_SET, CPoint(nXPixels,-nYPixels), status);
			}

			break;
		}
	}

	if( *status == ERROR)
	{
		Report( TO_LIST, "\tPage::PageBBoxNew: Error in creating new bbox...");
		Report( TO_LIST, "\tPage::AddBBox: At MAX_BBOXES?");
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::PageBBoxNew: %d", status); 
	#endif

	return nCurrentBBox;
}

int
Page::PageBBoxAdd( BBox *pnbbox, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::PageBBoxAdd(int*)"); 
	#endif

	BBox *pcbbox = NULL;
	CPoint cpTemp(0, 0);

	CPoint tSize(0, 0);
	CPoint tPos(0, 0), otherPos(0,0);
	int savezoom = doZoom;
	doZoom = 0;
	tSize = pnbbox->Message( BBOX_SIZE_GET, cpTemp, status);
	tPos = pnbbox->Message( BBOX_POSITION_GET, cpTemp, status);

	// Make sure there isn't any box at this position
	int increase = 200;
	for(int i=1; i <= MAX_BBOXES; i++) 
	{ 
		BBox* pbbox = pBBoxes[i];

		if( pbbox != NULL) {
			otherPos = pbbox->Message(BBOX_POSITION_GET, cpTemp, status);
			if (tPos == otherPos) {
				// Found one at the current position, so move this
				// and try again
				tPos.x += increase;
				tPos.y -= increase;
				if ((tPos.x + tSize.x) > (nXPixels)) {
					tPos.x = (100);
				}
				if ((tPos.y + tSize.y) < (-nYPixels)) {
					tPos.y = -(100);
				}
				i = 0;
				continue;	
			}
		}
	}
	doZoom = savezoom;

	// Deselect the current box...
	if( nCurrentBBox > 0)
	{
		pcbbox = pBBoxes[nCurrentBBox];
		if (pcbbox) {
			pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
		}
	}

	for(int i=1; i <= MAX_BBOXES; ++i) 
	{ 
		BBox* pbbox = pBBoxes[i];

		if( pbbox == NULL)
		{
			pnbbox->Message( BBOX_POSITION_SET, tPos, status);

			pBBoxes[i] = pnbbox;

			nCurrentBBox = i;

			pcbbox = pBBoxes[nCurrentBBox];
			if (pcbbox) {
				pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
			}

			break;
		}
	}

	if( *status == ERROR)
	{
		Report( TO_LIST, "\tPage::PageBBoxAdd: Error in adding new bbox...");
		Report( TO_LIST, "\tPage::AddBBox: At MAX_BBOXES?");
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::PageBBoxAdd: %d", status); 
	#endif

	return nCurrentBBox;
}

CPoint
Page::MouseLButtonDown( CPoint point, int *status)
{
	CPoint RCP(0, 0);
	int iRet = TEXT_DRAW_CURSOR;
	int iOldBox = 0;
	int specRet = 0;
	CPoint cp(0, 0);
	int wasSel = 0;

	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::MouseLButtonDown(CPoint,int*)"); 
	#endif
    
    //if( nCurrentTool != TOOL_NONE ) { return CPoint(0,0); }
    
	BBox* pcbbox = NULL;

    nHoldingLButton = TRUE;
    HoldingPosition = point;

	CPoint cpTemp(0, 0);
  
    // Get bbox at clicked point...
    int nbbox = GetBBoxAtPoint(point, status);

	if (nSelection == SEL_ON) {
		// pass on the current point in the selection creation
		if (nCurrentBBox > 0) {
			pBBoxes[nCurrentBBox]->Message( TEXT_SELECTION_OFF, point, status);
			nCurrentTool = TOOL_NONE;
			wasSel++;
			iRet = TEXT_DRAW_ALL;		// redraw the text box
//			if (nbbox > 0) {
//				nSelection = SEL_OFF;
//				return CPoint(0,0);
//			}
		}
	}

	nSelection = SEL_OFF;
    //ClickPoint = point;

    // If bbox is already current bbox it should be selected!
    // Clicked on a different bbox
    if (nbbox > 0) {
		iOldBox = nCurrentBBox;

    	if (nCurrentBBox != nbbox && nCurrentBBox > 0) {	// Another box selected?
			// Yes
			pcbbox = pBBoxes[nCurrentBBox];
			nCurrentRedraw = nCurrentBBox;
			pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
			specRet = TEXT_DRAW_OLD_NEW;
			iRet = TEXT_DRAW_OLD_NEW;
    	}

		nCurrentBBox = nbbox;
		pcbbox = pBBoxes[nCurrentBBox];
		//Trace("Clicked on %d", nCurrentBBox);
		int tempStatus = ERROR;
		pcbbox->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
		ClearArtBoxesOverlappedByThisBox(pcbbox, TRUE, MAX_BBOXES);

		m_saveGrow = pHiliteBBox->Message(BBOX_CAN_GROW, 1, status);
		pHiliteBBox->Message(BBOX_SET_GROW, 1, status);

		CPoint tmppoint = pcbbox->Message(BBOX_WHAT_IS_AT_POINT, point, status);
		if (tmppoint.x == BBOX_HANDLE_BBOX) {
			nCurrentTool = TOOL_BBOX_MOVE;

    		pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
			pcbbox->Message( ITEM_ENTER_EDIT_MODE, point, status);

			cp = pcbbox->Message( BBOX_POSITION_GET, cpTemp, status);
			*status = SAVEOLD;
    		pHiliteBBox->Message( BBOX_POSITION_SET, cp, status);

			cp = pcbbox->Message( BBOX_SIZE_GET, cpTemp, status);
			*status = SAVEOLD;
    		pHiliteBBox->Message( BBOX_SIZE_SET, cp, status);
    
    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);
			
			iRet = STATUS_CAPTURE_MOUSE;
    		// pHiliteBBox is set VISIBLE = TRUE in MouseMove
    	}
    	else if( tmppoint.x >= BBOX_HANDLE_MIN && tmppoint.x <= BBOX_HANDLE_MAX) {
    		nCurrentTool = tmppoint.x;

    		pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
			pcbbox->Message( ITEM_ENTER_EDIT_MODE, point, status);

			cp = pcbbox->Message( BBOX_POSITION_GET, cpTemp, status);
			*status = SAVEOLD;
    		pHiliteBBox->Message( BBOX_POSITION_SET, cp, status);
    
    		cp = pcbbox->Message( BBOX_SIZE_GET, cpTemp, status);
    		*status = SAVEOLD;
    		pHiliteBBox->Message( BBOX_SIZE_SET, cp, status);
    
    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);    
			
			iRet = STATUS_CAPTURE_MOUSE;
    	}
    	else {
			//pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_OPEN, status);
			theApp.m_strStoryOverflowText.Empty();
			theApp.m_strStoryDistributeText.Empty();
			theApp.m_strStoryOverflowShapes.Empty();
			theApp.m_strStoryDistributeShapes.Empty();
			theApp.m_bInStoryDistributeMode = FALSE;
			theApp.m_iStoryOverflowDirection = 0;
			theApp.m_iStoryOverflowBox = 0;
			theApp.m_bStoryTextWasMoved = FALSE;
    		nCurrentTool = TOOL_NONE;
    		pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);
			pcbbox->Message( ITEM_ENTER_EDIT_MODE, point, status);
			if (!wasSel)
				nSelection = SEL_MAYBE;	// If they drag, then selection is coming on
			//*status = 0;

			//wrw  nHoldingLButton = FALSE;	// this seems redundant
    
    		// If this box was previous grayed out, we need to redraw
    		// the entire box instead of just moving the cursor.
			// WRW -- Why? Doing the cursor actually sets the selection too
			// so let's let it fall through as just a cursor setting
    		//if (!iOldBox)
    		//	iRet = TEXT_DRAW_ALL;
    	}
    }
    // Clicked on page (didn't click on any bboxes)
    else {
  		nCurrentTool = TOOL_NONE;
		//*status = 0;

		int tstatus = 0;
    	if (nCurrentBBox > 0)
    	{
    		pcbbox = pBBoxes[nCurrentBBox];
	        pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, &tstatus);
    		pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, &tstatus);
    		pcbbox->Message(ART_SET_RELOAD, TRUE, &tstatus );
			iRet = TEXT_DRAW_CURRENT;  //TEXT_DRAW_ALL;
			nCurrentRedraw = nCurrentBBox; // Remember the box

    		nCurrentBBox = 0;
			
    	}
    }


	*status = iRet;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::MouseLButtonDown: %d", status); 
	#endif

	if (specRet != iRet) {
		RCP.x = specRet;
	}
	return RCP;
}

//CPoint
//Page::MouseMove( CPoint point, int *status)
//{
//	#ifdef DEBUG_ENTER
//	Report( TO_LIST, "ENTER Page::MouseMove(CPoint,int*)"); 
//	#endif
//    
//	if (nSelection == SEL_MAYBE) {		// if this move is first indication of text select 
//		nSelection = SEL_ON;			// then set to selection on
//	}
//	if (nHoldingLButton == FALSE) {
//		return TmpPosition;
//	}
//    
//	if (nSelection == SEL_ON) {
//		// pass on the current point in the selection creation
//		if (nCurrentBBox > 0) {
//			pBBoxes[nCurrentBBox]->Message( TEXT_SET_SELECTION, point, status);
//		}
//	}
//	// Moving the current box
//    else if( nCurrentBBox > 0) {
//    
//    	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
//        
//        CPoint pos = pHiliteBBox->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status);
//        CPoint size = pHiliteBBox->Message( BBOX_SIZE_GET, EMPTY_CPOINT, status);
//
//		if( nCurrentTool == TOOL_NONE) {        
//	    	// The X coordinate        
//    		if( (pos.x + (point.x - HoldingPosition.x) >= 0) &&
//    			(pos.x + (point.x - HoldingPosition.x) + size.x <= nXPixels))	{
//		        pos.x += point.x - HoldingPosition.x;
//    			HoldingPosition.x = point.x;
//	    	}
//    
//    		// The Y coordinate
//    		if( (pos.y + (point.y - HoldingPosition.y) <= 0) &&
//	    		(pos.y + (point.y - HoldingPosition.y) + size.y >= -nYPixels))
//    		{    
//    			pos.y += point.y - HoldingPosition.y;
//    			HoldingPosition.y = point.y;
//	    	}
//
//			*status = SAVEOLD;
//			TmpPosition = pHiliteBBox->Message( BBOX_POSITION_SET, pos, status);
//		}
//    }    
//
//	#ifdef DEBUG_EXIT
//	Report( TO_LIST, "EXIT Page::MouseMove: %d", status); 
//	#endif
//
//	return TmpPosition;
//}

CPoint Page::MouseMove( CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::MouseMove(CPoint,int*)"); 
	#endif
    
	CPoint cpTemp(0, 0);
	if (nSelection == SEL_MAYBE) {		// if this move is first indication of text select 
		nSelection = SEL_ON;			// then set to selection on
	}
	if (nHoldingLButton == FALSE) {
		return TmpPosition;
	}
    
	if (nSelection == SEL_ON) {
		// pass on the current point in the selection creation
		if (nCurrentBBox > 0) {
			pBBoxes[nCurrentBBox]->Message( TEXT_SET_SELECTION, point, status);
		}
	}
	// Moving the current box
    else if( nCurrentBBox > 0) {
    
    	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
        
        CPoint pos = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
        CPoint size = pHiliteBBox->Message( BBOX_SIZE_GET, cpTemp, status);
		if( nCurrentTool == TOOL_NONE) {        
	    	// The X coordinate        
    		if( (pos.x + (point.x - HoldingPosition.x) >= 0) &&
    			(pos.x + (point.x - HoldingPosition.x) + size.x <= nXPixels))	{
		        pos.x += point.x - HoldingPosition.x;
    			HoldingPosition.x = point.x;
	    	}
    
    		// The Y coordinate
    		if( (pos.y + (point.y - HoldingPosition.y) <= 0) &&
	    		(pos.y + (point.y - HoldingPosition.y) + size.y >= -nYPixels))
    		{    
    			pos.y += point.y - HoldingPosition.y;
    			HoldingPosition.y = point.y;
	    	}

			*status = SAVEOLD;
			TmpPosition = pHiliteBBox->Message( BBOX_POSITION_SET, pos, status);
		}
    }    

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::MouseMove: %d", status); 
	#endif

	return TmpPosition;
}


CPoint
Page::MouseLButtonUp( CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::MouseLButtonUp(CPoint,int*)"); 
	#endif
    
    BBox* pcbbox;
	point;	/* get rid of compiler warning */
    
	nHoldingLButton = FALSE;
	CPoint cpTemp(0, 0);

   	if( nCurrentBBox > 0)
   	{
		// Check to be sure the current box is not on top of another box
		pcbbox = pBBoxes[nCurrentBBox];
#ifdef DO_OVERLAP
		if( IsOverlappingAnythingOnLayer( 1, pHiliteBBox, status) == FALSE)	{
#endif
			//AfxMessageBox("HERE!");
			CPoint cp = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
			*status = CLEAROLD;

	    	pcbbox->Message( BBOX_POSITION_SET, cp, status);
	    	pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);
#ifdef DO_OVERLAP
		}
		else
		{
	    	pHiliteBBox->Message( BBOX_POSITION_SET, pcbbox->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status), status);
		}
#endif
		nCurrentTool = TOOL_NONE;
		int tempStatus = ERROR;
		pHiliteBBox->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
		ClearArtBoxesOverlappedByThisBox(pHiliteBBox, TRUE, MAX_BBOXES);
   	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::MouseLButtonUp: %d", status); 
	#endif

	return TmpPosition;
}


CPoint
Page::ToolBeginUsing( CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::ToolBeginUsing(CPoint,int*)"); 
	#endif

	if (saveZoom == -1) {
		doZoom = 0;
		saveZoom = dCurrentZoom;
		dCurrentZoom = 1.0;
	}

	if (point.y > (-DOC_Y_BORDER_PIXELS-25)) {	// We need to start in a valid state
		//point.y = -DOC_Y_BORDER_PIXELS-25;
		*status = ERROR;
		return 1;	// Invalid area on the screen
	}
	else if (point.y < (-nYPixels+(2*DOC_Y_BORDER_PIXELS)+25)) {
		//point.y = -nYPixels+(2*DOC_Y_BORDER_PIXELS)+25;
		*status = ERROR;	// Invalid area on the screen
		return 1;
	}

	if (point.x > nXPixels-(2*DOC_X_BORDER_PIXELS)-25){
		//point.x = ((2*DOC_X_BORDER_PIXELS)-25);
		*status = ERROR;	// Invalid area on the screen
		return 1;
	}
	else if (point.x < (DOC_X_BORDER_PIXELS+25)) {
		//point.x = DOC_X_BORDER_PIXELS+25;
		*status = ERROR;	// Invalid area on the screen
		return 1;
	}

	// Only have one tool right now...
	nHoldingLButton = TRUE;
	HoldingPosition = point;
#ifdef OLD_WAY
	/* if( nCurrentTool == TOOL_TEXT_NEW ||
		nCurrentTool == TOOL_ART_NEW )	{
		*status = CLEAROLD;
    	pHiliteBBox->Message( BBOX_POSITION_SET, point, status);
		*status = CLEAROLD;
    	pHiliteBBox->Message( BBOX_SIZE_SET, EMPTY_CPOINT, status);
    
    	pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);
		pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);

		if( nCurrentBBox > 0)
		{
			pBBoxes[nCurrentBBox]->Message( BBOX_STATE_SET, BBOX_STATE_NORMAL, status);
			nCurrentBBox = 0;
		}

		*status = STATUS_CAPTURE_MOUSE;   // clicked on the open page
	}
    else  */
#endif

	m_saveGrow = pHiliteBBox->Message(BBOX_CAN_GROW, 1, status);
	pHiliteBBox->Message(BBOX_SET_GROW, TRUE, status);

	if( nCurrentTool == TOOL_TRASH)  {
		MouseLButtonDown( point, status);

        if( nCurrentBBox > 0)
        {
		    BBox* pcbbox;
			pcbbox = pBBoxes[nCurrentBBox];
			pcbbox->Delete();
			pBBoxes[nCurrentBBox] = NULL;
			nCurrentBBox = 0;
		}    

		// IMPORTANT!!!
		nCurrentTool = TOOL_NONE;
		*status = STATUS_CAPTURE_MOUSE;
	}
	else         
	{
		//nCurrentTool = TOOL_NONE;
		//MouseLButtonDown( point, status);
		*status = STATUS_CAPTURE_MOUSE;
   }
   
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::ToolBeginUsing: %d", status); 
	#endif


	return TmpPosition;
}

CPoint
Page::ToolWhileUsing( CPoint point, int *status)
{

	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::ToolWhileUsing(CPoint,int*)"); 
	#endif
    
    int minx, maxx, miny, maxy;
    int leftOK, rightOK, topOK, botOK;
	CPoint cpTemp(0, 0);
        
	if (saveZoom == -1) {
		doZoom = 0;
		saveZoom = dCurrentZoom;
		dCurrentZoom = 1.0;
	}

    CPoint pos = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
    CPoint size = pHiliteBBox->Message( BBOX_SIZE_GET, cpTemp, status);
    

	// The X coordinate            
	minx = (pos.x + (point.x - HoldingPosition.x) - 25 - DOC_X_BORDER_PIXELS - BORDER_WIDTH);
	maxx = (pos.x + (point.x - HoldingPosition.x) + size.x + 25 + (DOC_X_BORDER_PIXELS) + BORDER_WIDTH);
	leftOK = minx > 0 ? TRUE : FALSE;
	rightOK = maxx < (int)((float)nXPixels * saveZoom);

	// The Y Coordinate
	miny = (pos.y + (point.y - HoldingPosition.y) + 25 + DOC_Y_BORDER_PIXELS + BORDER_WIDTH);
	maxy = (pos.y + (point.y - HoldingPosition.y) + size.y -(25 + DOC_Y_BORDER_PIXELS + BORDER_WIDTH));

	topOK = miny < 0 ? TRUE : FALSE;
	botOK = maxy > (int)((float)-nYPixels * saveZoom);

	switch(nCurrentTool) {
#ifdef OLD_WAY
/*		case TOOL_TEXT_NEW:
		case TOOL_ART_NEW:
			int diff;
			if (leftOK && rightOK) {
  				size.x += point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			else if (rightOK) {
				diff = point.x - HoldingPosition.x;
				if (diff < 0) {
  					size.x += diff; 
					HoldingPosition.x = point.x;
				}
			}

			if (topOK && botOK) {
		   		size.y += point.y - HoldingPosition.y;
				HoldingPosition.y = point.y;
			}
			else if (botOK) {
				diff = point.y - HoldingPosition.y;
				if (diff > 0) {
		   			size.y += diff; 
					HoldingPosition.y = point.y;
				}
			}

			break; */
#endif
		case TOOL_BBOX_MOVE:
			pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
	       	if (leftOK && rightOK) {
		        pos.x += point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			if (topOK && botOK) {
   				pos.y += point.y - HoldingPosition.y;
				HoldingPosition.y = point.y;
			}
			break;

		case BBOX_CORNER_TOP_LEFT:
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (leftOK) {
			    pos.x += point.x - HoldingPosition.x;
		        size.x -= point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			if (topOK) {
	   			pos.y += point.y - HoldingPosition.y;
   				size.y -= point.y - HoldingPosition.y;
   				HoldingPosition.y = point.y;
   			}
			break;

		case BBOX_CORNER_TOP_RIGHT:
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (rightOK) {
		        size.x += point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			if (topOK) {
	   			pos.y += point.y - HoldingPosition.y;
   				size.y -= point.y - HoldingPosition.y;
   				HoldingPosition.y = point.y;
   			}
			break;

		case BBOX_CORNER_BOTTOM_RIGHT:
       		pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (rightOK) {
			    size.x += point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			if (botOK) {
	   			size.y += point.y - HoldingPosition.y;
   				HoldingPosition.y = point.y;
   			}
			break;

		case BBOX_CORNER_BOTTOM_LEFT:
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (leftOK) {
			    pos.x += point.x - HoldingPosition.x;
		        size.x -= point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			if (botOK) {
  				size.y += point.y - HoldingPosition.y;
   				HoldingPosition.y = point.y;
   			}
			break;

		case BBOX_CENTER_TOP:
				// This is always true for x value
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			HoldingPosition.x = point.x;
			if (topOK) {
	   			pos.y += point.y - HoldingPosition.y;
   				size.y -= point.y - HoldingPosition.y;
   				HoldingPosition.y = point.y;
			}
			break;

		case BBOX_CENTER_RIGHT:
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (rightOK) {
			    size.x += point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			// no y problem
			HoldingPosition.y = point.y;
			break;
			break;

		case BBOX_CENTER_BOTTOM:
				// This is always ok for x pos
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			HoldingPosition.x = point.x;
			if (botOK) {
				size.y += point.y - HoldingPosition.y;
				HoldingPosition.y = point.y;
			}
			break;

		case BBOX_CENTER_LEFT:
	       	pHiliteBBox->Message( BBOX_VISIBLE_SET, TRUE, status);
			if (leftOK) {
			    pos.x += point.x - HoldingPosition.x;
		        size.x -= point.x - HoldingPosition.x;
				HoldingPosition.x = point.x;
			}
			// no problem
			HoldingPosition.y = point.y;
			break;
	}

	*status = SAVEOLD;
	TmpPosition = pHiliteBBox->Message( BBOX_POSITION_SET, pos, status);
	*status = SAVEOLD;
	TmpPosition = pHiliteBBox->Message( BBOX_SIZE_SET, size, status);

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::ToolWhileUsing: %d", status); 
	#endif
	
	return TmpPosition;
}

CPoint
Page::ToolEndUsing( CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::ToolEndUsing(CPoint,int*)"); 
	#endif

	int MINBOXSIZE=200;
	point;	/* get rid of compiler warning */

	CPoint cpTemp(0, 0);
	// Do a quick normalization of the hilite box.
    CPoint cp;
    CPoint hipos = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
    CPoint hisize = pHiliteBBox->Message( BBOX_SIZE_GET, cpTemp, status);
	// If Snap-to-Grid is on, or even if it seems they are aiming for the red (hot) gridline, snap to the line
	if (theApp.m_isGridSnapTo || theApp.m_iGridHotX != 0 || theApp.m_iGridHotY != 0) {
		theApp.m_iGridHotX = 0;
		theApp.m_iGridHotY = 0;
		for (int x = 0; x < 40; x++) {
			if (((x < 1 && theApp.m_isGridSnapTo) || (theApp.m_iGridX[x] > 0 && hipos.x > theApp.m_iGridX[x - 1])) && hipos.x < theApp.m_iGridX[x + 1]) {
				hipos.x = theApp.m_iGridX[x] + BORDER_WIDTH;
				if (x < 1) {
					hipos.x += (DOC_X_BORDER_PIXELS - 25);
				}
				break;
			}
		}
		for (int y = 0; y < 40; y++) {
			if (((y < 1 && theApp.m_isGridSnapTo) || (theApp.m_iGridY[y] < 0 && hipos.y < theApp.m_iGridY[y - 1])) && hipos.y > theApp.m_iGridY[y + 1]) {
				hipos.y = theApp.m_iGridY[y] - BORDER_WIDTH;
				if (y < 1) {
					hipos.y -= (DOC_Y_BORDER_PIXELS + 25);
				}
				break;
			}
		}
	}
    
	// Need to do these calculations as if at 100% zoom     
	if (saveZoom != -1) {
    	hipos.x = (int)((float)hipos.x / saveZoom);
   		hipos.y = (int)((float)hipos.y / saveZoom);
	    hisize.x = (int)((float)hisize.x / saveZoom);
    	hisize.y = (int)((float)hisize.y / saveZoom);
    }
    else {
    	hipos.x = (int)((float)hipos.x / dCurrentZoom);
   		hipos.y = (int)((float)hipos.y / dCurrentZoom);
	    hisize.x = (int)((float)hisize.x / dCurrentZoom);
    	hisize.y = (int)((float)hisize.y / dCurrentZoom);
    }

	if( hisize.x < 0 || hisize.y > 0) {
		if( hisize.x < 0) { 
			hisize.x *= -1;
			if( hisize.x < MINBOXSIZE) {
				hisize.x = MINBOXSIZE;
			}
			hipos.x -= hisize.x;
		}
		if( hisize.y > 0) { 
			hisize.y *= -1;
			if( hisize.y > -MINBOXSIZE) { 
				hisize.y = -MINBOXSIZE;
			}
			hipos.y -= hisize.y;
		}
	}
	else {
		if( hisize.x < MINBOXSIZE) { 
			hisize.x = MINBOXSIZE;
		}
		if( hisize.y > -MINBOXSIZE) { 
			hisize.y = -MINBOXSIZE;
		}
	}
    
	if (hipos.y > (-DOC_Y_BORDER_PIXELS-25)) {	// We need to start in a valid state
		hipos.y = -DOC_Y_BORDER_PIXELS;
	}
	else if (hipos.y < (-nYPixels+(2*DOC_Y_BORDER_PIXELS)+25)) {
		hipos.y = -nYPixels+(2*DOC_Y_BORDER_PIXELS)+25;
	}

	if (hipos.x < (DOC_X_BORDER_PIXELS+25)) {
		hipos.x = (DOC_X_BORDER_PIXELS+25);
	}
	else if (hipos.x >= (nXPixels-(2*DOC_X_BORDER_PIXELS)-25)) {
		hipos.x = (nXPixels-(2*DOC_X_BORDER_PIXELS)-25);
	}

	*status = CLEAROLD;
   	pHiliteBBox->Message( BBOX_POSITION_SET, hipos, status);
	*status = CLEAROLD;
   	pHiliteBBox->Message( BBOX_SIZE_SET, hisize, status);

#ifdef OLD_WAY
	/*if( nCurrentTool == TOOL_TEXT_NEW) {
		int nbbox = PageBBoxNew(status);
		if( *status == OK) {
			BBox *pcbbox = pBBoxes[nbbox];

			TextItem *item = new TextItem();

			// Make sure the text box is large enough for one char height
			int miny = item->Message(TEXTITEM_GET_LINEHEIGHT, 0, status);
			if (-miny < hisize.y) {    	// If we are not big enough
				hisize.y = -miny;		// set to minimum
				if (miny > hisize.x) {	// make sure width is at least as long
					hisize.x = miny;
				}
				*status = CLEAROLD;
				pHiliteBBox->Message( BBOX_SIZE_SET, hisize, status);
			}


			pcbbox->Message( BBOX_ITEM_SET, item, status);
			item->Message( ITEM_PARENT_SET, pcbbox, status);

			cp = pHiliteBBox->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status);
			*status = CLEAROLD;
   			pcbbox->Message( BBOX_POSITION_SET, cp, status);
   
   			cp = pHiliteBBox->Message( BBOX_SIZE_GET, EMPTY_CPOINT, status);
   			*status = CLEAROLD;
   			pcbbox->Message( BBOX_SIZE_SET, cp, status);

			pcbbox->Message( BBOX_VISIBLE_SET, TRUE, status);
    		pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);    

			pcbbox->Message( ITEM_ENTER_EDIT_MODE, EMPTY_INT, status);
		}
		pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);
	}
	else if( nCurrentTool == TOOL_ART_NEW)
	{
		int nbbox = PageBBoxNew( status);
		if( *status == OK) {
			BBox *pcbbox = pBBoxes[nbbox];

			ArtItem *item = new ArtItem();
			item->Message( ITEM_DIALOG_EDIT, EMPTY_INT, status);

			pcbbox->Message( BBOX_ITEM_SET, item, status);
			item->Message( ITEM_PARENT_SET, pcbbox, status);

			cp = pHiliteBBox->Message( BBOX_POSITION_GET, EMPTY_CPOINT, status);
			*status = CLEAROLD;
  			pcbbox->Message( BBOX_POSITION_SET, cp, status);
   
			cp = pHiliteBBox->Message( BBOX_SIZE_GET, EMPTY_CPOINT, status);
			*status = CLEAROLD;
   			pcbbox->Message( BBOX_SIZE_SET, cp, status);

			pcbbox->Message( BBOX_VISIBLE_SET, TRUE, status);
    		pcbbox->Message( BBOX_STATE_SET, BBOX_STATE_SELECT, status);
    		pHiliteBBox->Message( BBOX_STATE_SET, BBOX_STATE_HILITE, status);    

		}
		pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);

	}
	else
		*/
#endif
		if( nCurrentTool == TOOL_BBOX_MOVE) {
			BBox* pcbbox;
	    
			nHoldingLButton = FALSE;
	        
			if( nCurrentBBox > 0) {
	   			// Check to be sure the current box is not on top of another box
				pcbbox = pBBoxes[nCurrentBBox];
				if (saveZoom != -1) {    // if we have actually moved
					CPoint cpHilite = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
					*status = CLEAROLD;
    				pcbbox->Message( BBOX_POSITION_SET, cpHilite, status);
        		}
    			pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);
				pcbbox->Message( ART_SET_RELOAD, TRUE, status);
				int tempStatus = ERROR;
				pcbbox->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
				ClearArtBoxesOverlappedByThisBox(pcbbox, TRUE, MAX_BBOXES);
			}
		}
	else if( nCurrentTool >= BBOX_HANDLE_MIN &&
		nCurrentTool <= BBOX_HANDLE_MAX )
	{
	    BBox* pcbbox;
    
		nHoldingLButton = FALSE;
        
        if( nCurrentBBox > 0)
        {
	   		// Check to be sure the current box is not on top of another box
			pcbbox = pBBoxes[nCurrentBBox];

				CPoint cpHilite = pHiliteBBox->Message( BBOX_POSITION_GET, cpTemp, status);
	    		*status = CLEAROLD;
	    		pcbbox->Message( BBOX_POSITION_SET, cpHilite, status);

				cpHilite = pHiliteBBox->Message( BBOX_SIZE_GET, cpTemp, status);
				*status = CLEAROLD;	    
	    		pcbbox->Message( BBOX_SIZE_SET, cpHilite, status);

	    		pHiliteBBox->Message( BBOX_VISIBLE_SET, FALSE, status);
				pcbbox->Message( ART_SET_RELOAD, TRUE, status);
		}
	}

	// IMPORTANT!!!
	nCurrentTool = TOOL_NONE;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::ToolEndUsing: %d", status); 
	#endif

	if (saveZoom != -1) {
		doZoom = 1;
		dCurrentZoom = saveZoom;
		saveZoom = -1;
	}
	pHiliteBBox->Message(BBOX_SET_GROW, m_saveGrow, status);

	return TmpPosition;
}

BBox *Page::GetBBoxAtPoint(CPoint point)
{
	int   status,
			iWhich = GetBBoxAtPoint(point, &status);

	if (!iWhich || iWhich > MAX_BBOXES)
		return NULL;
	else
		return pBBoxes[iWhich];
}


int
Page::GetBBoxAtPoint( CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::GetBBoxAtPoint(CPoint,int*)"); 
	#endif

	// First, if there is a currently active box, see if the current box is at the point
	// That is the one the user is most likely trying to grab, even if others are there
	if (pBBoxes[nCurrentBBox] != NULL && pBBoxes[nCurrentBBox]->Message( BBOX_IS_AT_POINT, point, status) == point) {
		return nCurrentBBox;
	}

	// Find the box at the point
	int j;
	for( j = MAX_BBOXES; j >= 1; --j) {
		if( pBBoxes[j] != NULL) { 
			if( pBBoxes[j]->Message( BBOX_IS_AT_POINT, point, status) == point) {
				return j;
			}
		}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::GetBBoxAtPoint: 0"); 
	#endif

	return 0;
}

BOOL Page::ClearArtBoxesOverlappedByThisBox(BBox *pCurrentBox, BOOL doReshow, int nMax)
{
	int nBoxesCleared = 0;// Returns TRUE if any art box was cleared or any art box was restored
	int nBoxesRestored = 0;
	if (pCurrentBox == NULL) {
		return FALSE;
	}
	int status = ERROR;
	CPoint cpCheckSize(0, 0);
	CPoint cpCheckPos(0, 0);
	CPoint cpTemp(0, 0);
	cpCheckSize = pCurrentBox->Message(BBOX_SIZE_GET, cpTemp, &status);
	cpCheckPos = pCurrentBox->Message(BBOX_POSITION_GET, cpTemp, &status);
	int tempStatus = ERROR;

	int j = 0;
	CPoint cpBoxSize(0, 0);
	CPoint cpBoxPos(0, 0);
	BBox* pbbox = NULL;
	BOOL bIsYIntersect = FALSE;
	BOOL bIsXIntersect = FALSE;
	int isArtBox = 0;
	int isCurrentlyOverlapped = 0;

	for (j=1; j <= nMax; ++j) { 
		pbbox = pBBoxes[j];
		bIsYIntersect = FALSE;
		bIsXIntersect = FALSE;
		if (pbbox != NULL && j != nCurrentBBox) {
			isArtBox = (pbbox->Message(BBOX_ITEM_WHATAMI, 0, &tempStatus) == ITEM_ART_TYPE) ? TRUE : FALSE;
			if (isArtBox) {
				if (doReshow) {
					isCurrentlyOverlapped = pbbox->Message(ART_GET_OVERLAPPED, 0, &tempStatus);
					if (isCurrentlyOverlapped) {
						nBoxesRestored += ShowArtBoxIfNotOverlapped(pbbox, pbbox->Item, j, &tempStatus);
					}
				}
				isCurrentlyOverlapped = pbbox->Message(ART_GET_OVERLAPPED, 0, &tempStatus);
				if (!isCurrentlyOverlapped) {
					cpBoxSize = pbbox->Message(BBOX_SIZE_GET, cpTemp, &status);
					cpBoxPos = pbbox->Message(BBOX_POSITION_GET, cpTemp, &status);
					if ((cpCheckPos.y + cpCheckSize.y) <= cpBoxPos.y && (cpCheckPos.y + cpCheckSize.y) >= cpBoxPos.y + cpBoxSize.y
					|| (cpCheckPos.y) <= cpBoxPos.y && (cpCheckPos.y) >= cpBoxPos.y + cpBoxSize.y
					|| (cpCheckPos.y) >= cpBoxPos.y && (cpCheckPos.y + cpCheckSize.y) <= cpBoxPos.y + cpBoxSize.y) {
						bIsYIntersect = TRUE;
					}
					if ((cpCheckPos.x + cpCheckSize.x) >= cpBoxPos.x && (cpCheckPos.x + cpCheckSize.x) <= cpBoxPos.x + cpBoxSize.x
					|| (cpCheckPos.x) >= cpBoxPos.x && (cpCheckPos.x) <= cpBoxPos.x + cpBoxSize.x
					|| (cpCheckPos.x) <= cpBoxPos.x && (cpCheckPos.x + cpCheckSize.x) >= cpBoxPos.x + cpBoxSize.x) {
						bIsXIntersect = TRUE;
					}
					if (bIsYIntersect && bIsXIntersect) {
						tempStatus = ERROR;
						pbbox->Message(ART_SET_OVERLAPPED, TRUE, &tempStatus);
						++nBoxesCleared;
					}
				}
			}
		}
	}

	return (nBoxesCleared > 0 || nBoxesRestored > 0);
}

BOOL Page::ShowArtBoxIfNotOverlapped(BBox *pCurrentBox, Module *pcItem, int nBBoxIndex, int *status)
{
	BOOL bRet = FALSE;// Will return TRUE if the box gets shown
	BOOL bIsArtBoxOverlapped = FALSE;
	if (pCurrentBox == NULL || pcItem == NULL || pcItem->m_iType != ITEM_ART_TYPE) {
		return bRet;
	}
	CPoint cpCheckSize(0, 0);
	CPoint cpCheckPos(0, 0);
	CPoint cpTemp(0, 0);
	cpCheckSize = pCurrentBox->Message(BBOX_SIZE_GET, cpTemp, status);
	cpCheckPos = pCurrentBox->Message(BBOX_POSITION_GET, cpTemp, status);
	int tempStatus = ERROR;

	int j = 0;
	CPoint cpBoxSize(0, 0);
	CPoint cpBoxPos(0, 0);
	BBox* pbbox = NULL;
	BOOL bIsYIntersect = FALSE;
	BOOL bIsXIntersect = FALSE;

	for (j=1; j <= MAX_BBOXES; ++j) {
		if (j != nCurrentBBox || nCurrentTool == TOOL_NONE) {
			pbbox = pBBoxes[j];
		}
		else {
			pbbox = this->pHiliteBBox;
		}
		bIsYIntersect = FALSE;
		bIsXIntersect = FALSE;
		if (pbbox != NULL && j != nBBoxIndex) {
			cpBoxSize = pbbox->Message(BBOX_SIZE_GET, cpTemp, status);
			cpBoxPos = pbbox->Message(BBOX_POSITION_GET, cpTemp, status);
			if ((cpCheckPos.y + cpCheckSize.y) <= cpBoxPos.y && (cpCheckPos.y + cpCheckSize.y) >= cpBoxPos.y + cpBoxSize.y
			|| (cpCheckPos.y) <= cpBoxPos.y && (cpCheckPos.y) >= cpBoxPos.y + cpBoxSize.y
			|| (cpCheckPos.y) >= cpBoxPos.y && (cpCheckPos.y + cpCheckSize.y) <= cpBoxPos.y + cpBoxSize.y) {
				bIsYIntersect = TRUE;
			}
			if ((cpCheckPos.x + cpCheckSize.x) >= cpBoxPos.x && (cpCheckPos.x + cpCheckSize.x) <= cpBoxPos.x + cpBoxSize.x
			|| (cpCheckPos.x) >= cpBoxPos.x && (cpCheckPos.x) <= cpBoxPos.x + cpBoxSize.x
			|| (cpCheckPos.x) <= cpBoxPos.x && (cpCheckPos.x + cpCheckSize.x) >= cpBoxPos.x + cpBoxSize.x) {
				bIsXIntersect = TRUE;
			}
			if (bIsYIntersect && bIsXIntersect) {
				bIsArtBoxOverlapped = TRUE;
				break;
			}
		}
	}
	if (!bIsArtBoxOverlapped) {
		tempStatus = ERROR;
		pCurrentBox->Message(ART_SET_OVERLAPPED, FALSE, &tempStatus);
		pCurrentBox->Message(ART_SET_RELOAD, TRUE, &tempStatus);
		bRet = TRUE;
	}

	return bRet;
}

#ifdef DO_OVERLAP

int
Page::IsOverlappingAnythingOnLayer(int nlayer, BBox* pcbbox, int *status)
{
	// Check to see if nbbox is touching anything on the current layer
	// Remember we can't touch ourself
	// Only have to check 4 corners for each box

	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER Page::IsOverlappingAnytingOnLayer(int,BBox*,int*)"); 
	#endif

	int i;
	BBox *pbbox;

	if( pcbbox == NULL) 
	{ 
		Report( TO_LIST, "\tPage::IsOverlappingAnythingOnLayer: BBoxes[nbbox] == NULL!");
		Report( TO_LIST, "\tPage::IsOverlappingAnythingOnLayer: Returning TRUE");
		return TRUE; 
	}

    for( i=1; (pBBoxes[i] != NULL) && (i <= MAX_BBOXES); ++i) {          
   		pbbox = pBBoxes[i];

		// Don't check if we overlap ourself
		if( pbbox == pBBoxes[nCurrentBBox] ) { 
			continue; 
		}

		//if( pcbbox->IsOverlapping(pbbox))
		Module *retptr;
		retptr = pcbbox->Message( BBOX_IS_OVERLAPPING, (Module *)pbbox, status);
		if( retptr == pbbox) {
			return TRUE;
		}
    }
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT Page::IsOverlappingAnythingOnLayer: FALSE"); 
	#endif
	return FALSE;
}
#endif


BBox *Page::GetCurrentBox()
{
	return pBBoxes[nCurrentBBox];
}

TextItem *Page::GetStoryItem(int orderNumber)
{
	TextItem *pItem = NULL;
	if (orderNumber < 1) {// Just getting the current story item
		if (pBBoxes[nCurrentBBox]->Item->m_iType == ITEM_TEXT_TYPE && ((TextItem *)pBBoxes[nCurrentBBox]->Item)->StoryNumber > 0) {
			pItem = (TextItem *) pBBoxes[nCurrentBBox]->Item;
		}
		return pItem;
	}
	// Find the TextItem that is the Story Box in the specified Order in the Story
	for (int j = 1; j <= MAX_BBOXES; j++) {
		if (pBBoxes[j] != NULL
		&& pBBoxes[j]->Item->m_iType == ITEM_TEXT_TYPE
		&& ((TextItem *)(pBBoxes[j]->Item))->StoryItemOrder == orderNumber
		&& ((TextItem *)(pBBoxes[j]->Item))->StoryNumber == 1) {
			pItem = (TextItem *)(pBBoxes[j]->Item);
			break;
		}
	}
	return pItem;
}


// swdoc.cpp : implementation of the CSwDoc class
//

#include "stdafx.h"
#include "sw.h"

#include "swdoc.h"
#include "miscutil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CSwDoc

IMPLEMENT_DYNCREATE(CSwDoc, CDocument)

BEGIN_MESSAGE_MAP(CSwDoc, CDocument)
	//{{AFX_MSG_MAP(CSwDoc)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSwDoc construction/destruction

CSwDoc::CSwDoc()
{
	// TODO: add one-time construction code here
	// On new documents, be sure we reset the document path
	if (theApp.m_strDocPath.GetLength() > 0) {
		_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
		_chdir(theApp.m_strDocPath);
	}

	CurrentZoom = 100.0;
	ThisDocument=NULL;	// At least null this out
// This is useless because OnNewDocument gets called again
// and clobbers this assignment
//	if (CDocument::OnNewDocument()) {
//		ThisDocument = new Document();
//	}
}

CSwDoc::~CSwDoc()
{ 
	delete ThisDocument;
}

BOOL CSwDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	int status = ERROR;

	ThisDocument = new Document();
	if (ThisDocument == NULL) {
		return FALSE;
	}

	ThisDocument->Message( DOC_PAGE_NEW, DOC_PAGE_FIRST, &status);

	if( status == OK) { return TRUE; }
	else { return FALSE; }

	return TRUE;
}

BOOL CSwDoc::OnOpenDocument(const char* pszPathName)
{
	int status = FALSE;
	char tBuf[1024];

	if(CDocument::OnNewDocument())
	{
		fstream fin(pszPathName, ios::_Nocreate| ios::in);		

    	if (!fin)
    	{
			_snprintf(tBuf, sizeof(tBuf), "Unable to open file %s for reading", pszPathName);
	  		AfxMessageBox(tBuf);
   			return FALSE;
    	}

		ThisDocument = new Document();
		if (ThisDocument == NULL) {
	  		AfxMessageBox("Unable to open new document!");
			fin.close();
			return(ERROR);
		}

		ThisDocument->Read(&fin, NULL, &status);
        
    	if (status == ERROR)
    	{
    		CString str;
    
    		str.Format(
    			"Unable to open '%s'.\n\n"
    			"This file was not a valid Startwrite document.",
    			pszPathName);
    
    		AfxMessageBox(str, MB_OK | MB_ICONEXCLAMATION);
    	}
    
    	fin.close();
	}

	return status;
}

BOOL CSwDoc::OnSaveDocument( const char* pszPathName )
{
	int status = ERROR;

	CDocument::OnSaveDocument(pszPathName);

	fstream fout(pszPathName, ios::out);

    if (!fout)
    {
  		AfxMessageBox("OnSaveDocument: Unable to open file for writing!");
   		return FALSE;
    }

    if (ThisDocument != NULL) 
		ThisDocument->Write( &fout, NULL, &status);
        
	fout.close();    

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSwDoc serialization

void CSwDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSwDoc diagnostics

#ifdef _DEBUG
void CSwDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSwDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestDoc Custom Code

//JRL

// Prepares the Viewport and the Scroll bars for this document
int
CSwDoc::PrepareDC(CDC *pDC)
{
	int status = ERROR;
    int newZoom = ThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);
	float nzoom = (float)newZoom;
    
    // Always print at 100%
    if( pDC->IsPrinting()) { 
    	nzoom = 100;
    	newZoom = 100;
    }
	// This sets the 'zoom'
	pDC->SetMapMode(MM_TWIPS);

	return status;
}


int
CSwDoc::PrepareScrollView(CScrollView* view)
{
	int status = ERROR;
	int newZoom;
	CPoint cpTemp(0, 0);

	newZoom = ThisDocument->Message( DOC_ZOOM_GET, EMPTY_INT, &status);
	float nzoom = (float)newZoom;

	// Added for Windows 3.1...
	if( nzoom == CurrentZoom) {
		ThisDocument->Message(TEXT_SET_ZOOM, newZoom, &status);
		return OK;
	}

	CPoint paper_pixels = ThisDocument->Message( PAGE_PIXELS_MAX_GET, cpTemp, &status);

	// Scroll Bars
	CSize totalSize = CSize(
		(long)((paper_pixels.x + (paper_pixels.x/4)) * (nzoom / 100)),
		(long)((paper_pixels.y + (paper_pixels.y/4)) * (nzoom / 100)));


	// Program can't handle largner than 32K size (TWIPS does that)
	if (totalSize.cx > (32*1024))
		totalSize.cx = (32*1024)-1;

	if (totalSize.cy > (32*1024))
		totalSize.cy = (32*1024)-1;


	//CSize pageSize = CSize( DOC_X_EXTENT, DOC_Y_EXTENT);
	CSize pageSize = CSize( totalSize.cx / 2, totalSize.cy / 2);

	CSize lineSize = CSize( totalSize.cx / 5, totalSize.cy / 50);

	view->SetScrollSizes( MM_TWIPS, totalSize, pageSize, lineSize);

	CurrentZoom = nzoom; 

	ThisDocument->Message(TEXT_SET_ZOOM, newZoom, &status);

	return status;
}

Document*
CSwDoc::GetThisDocument()
{
	return ThisDocument;
}

int
CSwDoc::DrawThisDocument(CDC* pDC)
{
	int status = ERROR;
	ThisDocument->Draw(pDC, &status);
	return status;
}

/////////////////////////////////////////////////////////////////////////////
// CSwDoc commands


void CSwDoc::OnFileSave()
{
	CString title = GetTitle();
	CString path = GetPathName();

	if( title.Find("newdoc.swd") > -1 || path.IsEmpty()) {
		OnFileSaveAs();
	}
	else {
		CDocument::OnFileSave();
	}
}

void CSwDoc::OnFileSaveAs()
{
	CString newFileName;
	int ind;

	CString oldFilename = CDocument::GetPathName();
	if (oldFilename.IsEmpty()) {
		if (theApp.m_lastDocPath.IsEmpty() == false ) {
			_chdrive(toupper(theApp.m_lastDocPath[0]) - 64);
			_chdir(theApp.m_lastDocPath);

			newFileName = theApp.m_lastDocPath + "newdoc.swd";
		}
		else if (theApp.m_strDocPath.GetLength() > 0) {
			_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
			_chdir(theApp.m_strDocPath);
			newFileName = theApp.m_strDocPath + "newdoc.swd";
		}

		CDocument::SetPathName(newFileName, false);
	}
	else {
		ind = oldFilename.ReverseFind('\\');
		if (ind > 0) {
			theApp.m_lastDocPath = oldFilename.Left(ind+1);
			_chdrive(toupper(theApp.m_strDocPath[0]) - 64);
			_chdir(theApp.m_lastDocPath);
		}
	}

	CDocument::OnFileSaveAs();
	
	CString path = GetPathName();
	ind = path.ReverseFind('\\');
	if (ind > 0) {
		theApp.m_lastDocPath = path.Left(ind+1);
	}

}
void CSwDoc::OnCloseDocument()
{
	int status;
	
	if (ThisDocument != NULL) 
		ThisDocument->Message( DOC_PAGE_DELETE, DOC_PAGE_DELALL, &status);
    
	CDocument::OnCloseDocument();

	return;
}

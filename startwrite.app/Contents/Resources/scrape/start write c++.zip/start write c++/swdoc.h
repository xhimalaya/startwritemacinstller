// swdoc.h : interface of the CSwDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include <direct.h>
//JRL
#include "docunits.h"
#include "document.h"

class CSwDoc : public CDocument
{

//JRL
private:
	Document *ThisDocument;

protected: // create from serialization only
	CSwDoc();
	DECLARE_DYNCREATE(CSwDoc)

// Attributes
public:
// Operations
public:

// Implementation
public:
	virtual ~CSwDoc();
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
	virtual BOOL OnOpenDocument(const char* pszPathName);

	//JRL
	float CurrentZoom; // Added for Windows 3.1...
	Document* GetThisDocument();
	int PrepareDC(CDC* pDC);
	int PrepareScrollView(CScrollView* view);
	int DrawThisDocument(CDC* pDC);		

protected:
	virtual BOOL OnNewDocument();
//	virtual BOOL OnOpenDocument(const char* pszPathName);
	virtual BOOL OnSaveDocument( const char* pszPathName );

// Generated message map functions
protected:
	//{{AFX_MSG(CSwDoc)
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileSave();
	afx_msg void OnCloseDocument();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

// InsertPage.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "InsertPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsertPage dialog


CInsertPage::CInsertPage(CWnd* pParent /*=NULL*/)
	: CDialog(CInsertPage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInsertPage)
	m_insertPage = -1;
	//}}AFX_DATA_INIT
	m_which = 0;
}


void CInsertPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsertPage)
	DDX_Radio(pDX, IDC_AFTER_PAGE, m_insertPage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsertPage, CDialog)
	//{{AFX_MSG_MAP(CInsertPage)
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDC_AFTER_PAGE, OnAfterPage)
	ON_BN_CLICKED(IDC_BEFORE_PAGE, OnBeforePage)
	ON_BN_CLICKED(IDC_BEG_DOCUMENT, OnBegDocument)
	ON_BN_CLICKED(IDC_END_DOCUMENT, OnEndDocument)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsertPage message handlers

void CInsertPage::OnOk() 
{
	UpdateData(TRUE);
	CDialog::OnOK();
}

void CInsertPage::OnBegDocument() 
{
	m_which = m_insertPage = 2;	
	UpdateData(FALSE);
}

void CInsertPage::OnBeforePage() 
{
	m_which = m_insertPage = 1;
	UpdateData(FALSE);
}

void CInsertPage::OnAfterPage() 
{
	m_which = m_insertPage = 0;
	UpdateData(FALSE);
}

void CInsertPage::OnEndDocument() 
{
	m_which = m_insertPage = 3;
	UpdateData(FALSE);
}

BOOL CInsertPage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_insertPage = m_which;	
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

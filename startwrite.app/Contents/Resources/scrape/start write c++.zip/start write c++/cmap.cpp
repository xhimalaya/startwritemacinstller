// Character to Glyph Index Mapping Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "CMap.h"
 
#include <stdio.h>
 
CMapTable::CMapTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER CMapTable::CMapTable()"); 
	#endif

	pFormat0 = NULL;
	pFormat6 = NULL;
	Records = NULL;
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT CMapTable::CMapTable: void"); 
	#endif
}

void CMapTable::FreeMem()
{
	// malloc #1
	if (Records)
	{
		free(Records);
		Records = NULL;
	}
	
	// malloc #2
	if (pFormat0)
	{
		free(pFormat0);
		pFormat0 = NULL;
	}
	
	// malloc #3
	if (pFormat6)
	{
		free(pFormat6);
		pFormat6 = NULL;
	}
	
}

CMapTable::~CMapTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER CMapTable::~CMapTable()"); 
	#endif

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT CMapTable::~CMapTable: void"); 
	#endif
	
	FreeMem();
}

int
CMapTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER CMapTable::Read(ifstream,DirectoryTable*)"); 
	#endif
	
	// Read name table
	
	// Check for existence of name table
	if( !dir->GetTag("cmap"))
	{
		Report( TO_LIST, "ERROR CMapTable::Read: Unable to GetTag(cmap)"); 
		return ERROR;
	}
	
	// Cmap table begins at offset specified in directory table		 
	fin->seekg(dir->GetOffset());	 
	fin->read( (char *)&Table, sizeof(Table));	
 	
 	FreeMem();
 	
 	// Swab the shorts...
    myswab( (unsigned char *)&Table, sizeof(Table));
    
    // CMap encoding records begin after table
    // malloc #1
    Records = (EncodingRecord *)malloc( Table.NumRecords * sizeof(EncodingRecord));
    if( Records == NULL)
    {
		Report( TO_LIST, "ERROR CMapTable::Read: Malloc #1 == NULL"); 
		return ERROR;    
    }
    
    fin->read( (char *)Records, Table.NumRecords * sizeof(EncodingRecord));
	                                               
 	// Swab the shorts...
    myswab( (unsigned char *)Records, Table.NumRecords * sizeof(EncodingRecord));
    
	int i = 0;
	EncodingRecord *entry;
	EncodingRecord_LE *entry_le;
	unsigned short tmp;    

	// Swap the His & Los of the longs...
   	for( i = 0; i < (int)Table.NumRecords; ++i)
   	{
		entry_le = (EncodingRecord_LE *)Records + i;		
		tmp = entry_le->EncodingOffsetHi; 
		entry_le->EncodingOffsetHi = entry_le->EncodingOffsetLo; 
		entry_le->EncodingOffsetLo = tmp;
	}	

	// Choose only from PlatformID == 1 and SpecificID == 0 (Mac style (read simple!))
	// and choose from encoding formats:
	//	6: Trimmed Table Mapping
	//	0: Byte Encoding Table
   	for( i = 0; i < (int)Table.NumRecords; ++i)
   	{
		entry = (EncodingRecord *)Records + i;    
		
        if( entry->PlatformID == 1 && entry->SpecificID == 0)
        {
			// Now need to get format type from first ushort (format field)
			// cout << "Found a 1 && 0 combination!" << endl;
		    fin->seekg( dir->GetOffset() + entry->EncodingOffset);
		    fin->read( (char *)&tmp, sizeof(tmp));
		    myswab( (unsigned char *)&tmp, sizeof(tmp));
			//cout << " tmp == " << tmp << endl;
			
		    if( tmp == 0 )
		    {
			    fin->seekg( dir->GetOffset() + entry->EncodingOffset);
			    // malloc #2
			    pFormat0 = (CMapFormat0 *)malloc(sizeof(CMapFormat0));
			    if( pFormat0 == NULL)
			    {
					Report( TO_LIST, "ERROR CMapTable::Read: Malloc #2 == NULL"); 
					return ERROR;			    	
				}
			    fin->read( (char *)pFormat0, sizeof(CMapFormat0));			    	
			 	// Swab the shorts...
    			myswab( (unsigned char *)pFormat0, sizeof(UShort) * 3);
		    }
		    else if( tmp == 6 )
		    {
			    fin->seekg( dir->GetOffset() + entry->EncodingOffset);
			    // malloc #3
			    pFormat6 = (CMapFormat6 *)malloc(sizeof(CMapFormat6));
			    if( pFormat6 == NULL)
			    {
					Report( TO_LIST, "ERROR CMapTable::Read: Malloc #3 == NULL"); 
					return ERROR;			    	
				}
			    fin->read( (char *)pFormat6, sizeof(CMapFormat6));		    
			 	// Swab the shorts...
    			myswab( (unsigned char *)pFormat6, sizeof(CMapFormat6));
		    }
		}		
	}	

	if( pFormat0 != NULL || pFormat6 != NULL ) { return OK;}
		                                               
	return ERROR;
}

int CMapTable::GetIndex( ULong* index, unsigned short* c)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER CMapTable::GetIndex(ULong*,char*)"); 
	#endif

	//#ifdef DEBUG_2
	//cout << "\tCMapTable::GetIndex: character = " << *c << dec << endl << flush;
	//cout << "\tCMapTable::GetIndex: ascii = " << dec << (int)(*c) << dec << endl << flush;
	//#endif

	if( pFormat0 != NULL)
	{
		*index = (ULong)pFormat0->GlyphIDArray[(int)(*c)];
		return OK;
	}
	else if( pFormat6 != NULL)
	{	
		int indVal;
		if( (int)(*c) >= pFormat6->EntryCount ) { *index = 0; return ERROR; }
		indVal = (int)*c;
		*index = (ULong)pFormat6->GlyphIDArray[indVal];
		return OK;
	}
	
	//#ifdef DEBUG_2
	//cout << "\tCMapTable::GetIndex: index = " << dec << *index << dec << endl << flush;
	//#endif
	
	*index = 0;
	
	return ERROR;
}

int
CMapTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER CMapTable::Print()"); 
	#endif

	cout << "** CMap **" << endl;
	cout << dec;
	cout << "Version:\t" << Table.Version << endl;
	cout << "NumRecords:\t" << Table.NumRecords << endl;
	cout << dec;
   
    cout << endl << "** CMap Records **" << endl;
	EncodingRecord *record;
	for( unsigned short i = 0; i < Table.NumRecords; ++i)
	{
		record = Records + i;
		cout << dec;
		cout << "Record: " << i << endl;
		cout << "\t   Platform ID:   " << record->PlatformID << endl;
		cout << "\t   Specific ID:   " << record->SpecificID << endl;
		cout << "\tEncodingOffset: 0x" << hex << record->EncodingOffset << endl;
		cout << dec << endl;
	}

	if( pFormat0 != NULL)
	{
		cout << endl << "** Format 0 CMap Table **" << endl;
		cout << "Format: " << pFormat0->Format << endl;
		cout << "Length: " << pFormat0->Length << endl;
		cout << "Version: " << pFormat0->Version << endl;
		
		for(unsigned short i = 0; i < 256; ++i)
		{
			cout << i << " = " << (int)pFormat0->GlyphIDArray[i] << endl;
			//printf("char %d = glyph %d\n", i, format.GlyphIDArray[i]);
		}
	}
	else if( pFormat6 != NULL)
	{
		cout << endl << "** Format 6 CMap Table **" << endl;
		cout << "Format: " << pFormat6->Format << endl;
		cout << "Length: " << pFormat6->Length << endl;
		cout << "Version: " << pFormat6->Version << endl;
		cout << "FirstCode: " << pFormat6->FirstCode << endl;
		cout << "EntryCount: " << pFormat6->EntryCount << endl;

		for(unsigned short i = 0; i < 257; ++i)
		{
			cout << i << " = " << (int)pFormat6->GlyphIDArray[i] << endl;
			//printf("char %d = glyph %d\n", i, format.GlyphIDArray[i]);
		}
	}
	else
	{
		cout << "All character mapping tables are NULL!" << endl;
	}
	
	return OK;
}
// setdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetDlg dialog

class CSetDlg : public CDialog
{
// Construction
public:
	CSetDlg(CWnd* pParent = NULL);	// standard constructor

	int 	m_iDensity,
			m_iShading,
			m_iArrows,
			m_iLines,
			m_iShadeType;
			
// Dialog Data
	//{{AFX_DATA(CSetDlg)
	enum { IDD = IDD_SETTINGS };
	CString	m_strDocPath;
	CString	m_strArtPath;
	int		m_YellowGuide;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CSetDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

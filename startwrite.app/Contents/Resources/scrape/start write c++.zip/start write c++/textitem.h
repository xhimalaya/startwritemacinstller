// Text Item Class Header

#ifndef _TEXT_ITEM_H_
#define _TEXT_ITEM_H_

#include "resource.h"
#include "module.h"
#include "messages.h"
#include "barinfo.h"
#include "docunits.h"
#include "filefmt.h"
#include "ttfont.h"
#include "miscutil.h"
#include "storyprompt.h"

#define MAX_GLYF_ARRAY 60

#define DENSITY_NORMAL			10
#define DENSITY_FIRST_LINE		11
#define DENSITY_FIRST_WORD		12
#define DENSITY_ALTER_WORD		13
#define DENSITY_ALLFIRST_WORD	14

#define SHADING_NORMAL			14
#define SHADING_FIRST_LINE      15
#define SHADING_FIRST_WORD		16
#define SHADING_ALTER_WORD		17
#define SHADING_ALLFIRST_WORD	18

#define ARROWS_NORMAL			18
#define ARROWS_FIRST_LINE		19
#define ARROWS_FIRST_WORD		20
#define ARROWS_ALTER_WORD		21
#define ARROWS_ALLFIRST_WORD	22

#define SHADETYPE_SHADE			22
#define SHADETYPE_NARROW		23

//#define SPACENARROW	2
#define SPACENORMAL 5
#define SPACEWIDE	7

#define SW_EOL	0x08	// End of line
#define SW_HNL	0x0C	// Hard new line
#define SW_SNL	0x0B	// Soft new line


// Bit definitions of TxtAttrs
//	0	0	0	0	0	0	0	0
//	Sel	CharMsk	Shade	Dens	Arrows

#define ARROW_ON	1

#define DENS00	0x100	// first bit in the high byte
#define DENS25	0x00
#define DENS50	0x02
#define DENS75	0x04
#define DENS100	0x06
#define DENSMASK 0x106

#define SHAD25	0x00
#define SHAD50	0x08
#define	SHAD75  0x10
#define SHAD100	0x18
#define SHADMASK	0x18

#define NORMAL_CHAR	0x40	// 01000000 - means this is a normal char attribute
#define FUNCT_CHAR	0x60	// 01100000 - means this is a function information
#define CHARTYPEMSK	0x60	// Mask out the character type
//#define CHAR_UNDERLINE	0x80	// Do underline on this character
#define OVERLAY_ON	0x80

#define EOL_SOFT	0x02
#define EOL_HARD	0x03
#define EOL_MASK	(EOL_SOFT | EOL_HARD)

#define SW_BOL	0x20	// Temp beginning of line, when nothing else is there
//#define szSW_BOL " "
#define SW_TAB	0x09	// tab character
#define SPC_DEL	0x04	// Deleteable space
#define SPC_MASK	0x04	// Mask for space functions
#define DELCHAR (FUNCT_CHAR|SPC_DEL)
//#define szDELCHAR	"d"
#define EOLHCHAR (FUNCT_CHAR|EOL_HARD)

#define MAX_UNDO_CHARS 1024

typedef struct Undo_Struct {
	int uType;
	int uCount;
	int charCount;
	CPoint uClick;
	unsigned short uChars[MAX_UNDO_CHARS];

} UNDO_STRUCT;

#define UNDO_DEL_LEFT		1
#define UNDO_INSERT_CHAR	2
#define UNDO_MOUSECLICK		3
#define UNDO_INSERT_CHAR_R	4

#define MAX_FS_FONTS  5
#define STROKE_COUNT 4	// 0-3 is the color stuff
#define STROKE_ONE_IND	0
#define STROKE_TWO_IND	1
#define STROKE_THR_IND	2
#define STROKE_FOR_IND	3
#define DECISN_DOT_IND	4

#define SHAPE_NONE 1
#define SHAPE_UNSIGNED 2
#define SHAPE_EXTENDED 3

#define SHAPES_START_UNSIGNED 130
#define SHAPES_END_UNSIGNED 255
#define SHAPES_START_EXTENDED 256
#define SHAPES_END_EXTENDED 420
#define SHAPES_MAX (SHAPES_END_EXTENDED - SHAPES_START_UNSIGNED + 1)

#define SHAPES_CELL_WIDTH 600
#define SHAPES_GRID_COLS 16
#define SHAPES_GRID_WIDTH (SHAPES_CELL_WIDTH * SHAPES_GRID_COLS)

#define SHAPES_KEY_SENT 0

typedef struct GlyfHold {
	int charVal;	// Character
	int width;		// remember the width of the character
	char arrowFlag;	// set if we have the arrow data
	char overlayFlag;	// set if we have the overlay data
	char connectTheDotsFlag;	// connection stuff
	char dotFlag;	// indiate that the dot pos is set
	char mathFlag;	// This char is a math char
	int valUsed;	// Count how many times this has been accessed
	GlyfData CharData;	// character data
	GlyfData ArrowData;	// Arrow data
	GlyfData ConnectTheDotsData;	
	GlyfData OverlayData;	// Overlay data
	GlyfData DotData;	// StartDot Data
	int fsFlag[MAX_FS_FONTS];
	GlyfData DataFS[MAX_FS_FONTS];
} GLYFHOLD;

typedef struct FontStuff {
	bool DoThisFS;
	CString FilenameFS;
	TTFont TTFontFS;
	int ArrayInfoFS[MAX_GLYF_ARRAY];
	GlyfData ArrayFontFS[MAX_GLYF_ARRAY];
	int nDrawingFontFS;
	int nWidthFS;
	int nDot2DotFS;
	char nAnnoyingMsgFS;
	int nDot2DotFSButton;
	int FormatFS;
} FONT_STUFF;


//#define ARect RECT
#define EWhichDraw int
//#define ZPoint CPoint
//#define cprow cp.y
//#define cpcol cp.x
//#define zPosy zPos.y
//#define zPosx zPos.x
//#define zSizey zSize.y
//#define zSizex zSize.x
//#define zCurposy zCurpos.y
//#define zCurposx zCurpos.x
//#define ScrollPosX ScrollPos.x
//#define ScrollPosY ScrollPos.y
//#define zPtx zPt.x
//#define zPty zPt.y
//#define zPt1x zPt1.x
///#define zPt1y zPt1.y
//#define zPt2x zPt2.x
//#define zPt2y zPt2.y
//#define zPt3x zPt3.x
//#define zPt3y zPt3.y
//#define zPt4x zPt4.x
//#define zPt4y zPt4.y
//#define ptLookingForX ptLookingFor.x
//#define ptLookingForY ptLookingFor.y
//#define CursorIndexX CursorIndex.x
//#define CursorIndexY CursorIndex.y
//#define SelCursorIndexX SelCursorIndex.x
//#define SelCursorIndexY SelCursorIndex.y
//#define CursorDrawnX CursorDrawn.x
//#define CursorDrawnY CursorDrawn.y

#define kDotDens00	0
#define kDotDens25	1
#define kDotDens50	2
#define kDotDens75	3
#define kDotDens100	4
#define kDotShad25	1
#define kDotShad50	2
#define kDotShad75	3
#define kDotShad100	4

//#define MoveTo(x,y) pDC->MoveTo(x,y)
//#define LineTo(x,y) pDC->LineTo(x,y)


class TextItem : public Module
{
public:

			TextItem();
		~TextItem();

		void InitTextItem();
		void Read(fstream *fin, Module *pmodule, int *status);
		void Write(fstream *fout, Module *pmodule, int *status);
		unsigned short getNormalChar(unsigned short c);
		int GetColoredStroke();
		void SetColoredStroke(int newVal);
		int GetFSFontSetting(int index);
		void SetFSFontSetting(int fsIndex, int newVal);

		void Delete();

		float Message(int message, float number, int *status);
		int Message( int message, int number, int *status);
		CPoint Message( int message, CPoint point, int *status);
		Module* Message( int message, Module *pmodule, int *status);
		
		virtual int GetCharacterWidth( CDC* pDC, unsigned short *c, unsigned short *nc, int lx, int ly, int *status);
		void DrawTextString( CDC* pDC, int x, int y, 
								CWordArray *cstring, int *status, 
								bool bEntireString = TRUE, CPoint size=CPoint(0,0), int strCnt=0, int TextY=0, int lx=0, int ly=0);
		virtual int DrawLedgerLines( CDC *pDC, CPoint pos, CPoint size, int MarginVal, int startX, int ly);		
		int DrawGlyf(CDC *pDC, GlyfData *pGD, CPoint point, int fsIndex=-1);
		void SetBorderArtMargins(CDC *pDC, bool isDistributeStory);
#ifdef SW50
		int DrawStartDot(CDC *pDC, GlyfData *pGD, CPoint zPt, bool doDecisionDots);
		void DrawEllipse(CDC *pDC, GlyfData *pGD, int dotIndex, CPoint zPt);
#endif
		//int DrawCurve( CDC *pDC, CPoint p1, CPoint p2, CPoint p3, bool recurse);
		
		void doCursorLeft(int doSetCursor=TRUE, int *x=NULL, int *y=NULL);
		unsigned short getCursiveCharItal(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharReg(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharUpright(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharFromTheLine(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharVictorian(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharQueens(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharNSW(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharPalmer(unsigned short c, unsigned short prevChar, unsigned short nextChar);
		unsigned short getCursiveCharWithOutTears(unsigned short c, unsigned short prevChar, unsigned short nextChar);


		int IsCharInSelection(int testx=-1, int testy=-1);
		int DeleteSelection();
		int FixSelectionPostion();
private:
		void doTextCutCopy(int message);
		void doTextPaste();
		void MoveCursorToNextStoryBox();
public:

		void Draw(CDC* pDC, int *status);
		int KeyDown( int nchar, int *status);
		
		void DrawCursor(CDC *pDC, int flag);

		int InsertCharacter(unsigned short nc);
		int DeleteRight(unsigned short *delChar);
		int DeleteLeft(unsigned short *delChar);

		int SetCursor(CPoint cp);
		void SetCursorPos(CPoint cp, int curlen);
		
		int RemoveLine(int line, bool setCur);
		int OpenLine(int line);
		
		int CalcLinePointSpace();
		int ReadTextBar(BOOL bIncludeFont = TRUE);
		int WriteTextBar();
		int DisableButtons();
		
		int UseTools(int iNewDensity, int iNewShading, int iNewArrows/*, int iNewShadeType*/);

		int SkipFormatsAndSpaces();
		int SkipToNextSpace();
		void TestAttrState();
		int DoSpellCheck();
		
		int DoFontDialog(int);

		void SetViaMembers(int doFullReset=0);
		void SetViaMembersReverse();
		void buildNewAttributes(void);
        void ReformatText(void);
		void RestoreBorderArt();
		bool AdjustBoxSize(CDC *pDC, bool isUserSizing);

private:
		void DrawUnderline(CDC *pDC, CPoint pos, CPoint size);
		unsigned short GetCursiveChar(unsigned short c, unsigned short prevchar, unsigned short nextchar); 
		int DoBorderArtDialog();
		void DrawBorderArt(CDC *pDC, bool doClear);
		void PrintBorderArt(CDC *pDC);
		void PrintBorderArtPreview(CDC *pDC);
		void FreeBorderArtBuffers();
		void ClearBorderArtFiles(bool clearBase);
		void AdjustBorderArt(CDC *pDC, CPoint &size, int sign, bool withZoom);
		bool IsPositionOKForBorderArt();
//#ifdef OPTIGLYF
		void resetGlyfPos(void);
		int getGlyfPos(unsigned short c);
//#endif
	
	
public:	
	CString sFontName;
	int	sFontIndex;	// current font index
	int apos_wid;	// Set for sherston fonts apostrophe spacing
	int apos_wid2;
#define BASE_SPACEWID  180
	int spaceWidth;			// set space width 
	int lastSpaceWidth;
	int doYellowGuide;
	int lineWidthMult;
	int doReformatText;

	int lastGoodPointSize;
	bool inPasteMode;

//	int LedgerPenWidthOrig;
	int LedgerPenTopWidth;
	int LedgerPenMidWidth;
	int LedgerPenBasWidth;
	int LedgerPenBotWidth;

#define LINE_THICK_NORMAL		14
#define LINE_THICK_THICK		28
#define LINE_THICK_THICKER		42
#define LINE_THICK_THICKEST		56

private:
	bool boxIsOverFull;
	int mWhichDraw;
#define MAX_UNDO 10
	UNDO_STRUCT undoList[MAX_UNDO];
	int undoCount;
	int inUndo;
	void InsertUndoItem(int flag, unsigned short item);
	void textHandleUndo();
	void IncUndoLevel();
private:
		int sign;		// sign for MAC vrs. Win32 places -1 in Win32

		Module *pParentBBox;
		CString FontPath;
		CPoint	m_ptClicked;
		bool	m_bSetCursorToClicked;

		int		m_bSetSelCursor;		// set when calculating character pos
		BOOL	keepBackspacePos;
		int lastWordPos;

#define MAX_TEXT_LINES	75
#define kDefaultPointSize  48
#define kLineWidthThreshold 48
		int lastPointSize; 
		float zLastPointSize;
		CString lastFont;
		int zBorderArtMargin;	// Zoomed additional Border Art margin value
		float dCurrentZoom;
		int lastOverlay;

#define MIN_BORDERARTSIZE	30
#define MAX_BORDERARTSIZE	70
#define INC_BORDERARTSIZE	5

#define BORDER_ART_TYPE_NONE		0
#define BORDER_ART_TYPE_SIMPLE		1
#define BORDER_ART_TYPE_COMPLEX		2

#define BORDER_ART_SOURCE_NONE		0
#define BORDER_ART_SOURCE_SWCOLOR	1
#define BORDER_ART_SOURCE_SWBW		2
#define BORDER_ART_SOURCE_USER		3
		long borderArtBufId[8];
		CPoint BorderArtSize;
		CPoint BorderArtZoomSize;
		CPoint BorderArtMarginSize;
		CPoint BorderArtMarginZoomSize;
		CPoint BorderArtAdjustment;
		CPoint BorderArtAdjustmentZoom;
		CPoint BorderArtScrollPos;
		float BorderArtCurrentZoom;
		bool BorderArtZoomChanged;
public:
		bool BorderArtChanged;
		int BorderArtSizeOption;
		CString BorderArtFile[8];
		int BorderArtType;
		int BorderArtSource;
		int BorderArtShrink;

		CPoint StoryCursorMousePos;

		BOOL saveAreaTop;
		BOOL saveAreaMid;
		BOOL saveAreaBot;
		bool saveAreaIsSet;

#define STORY_FLOW_APPEND		0
#define STORY_FLOW_INSERT		1
		bool StoryLinesChanged;
		bool StoryBoxFull;
		int StoryNumber;
		int StoryLines;
		int StoryItemOrder;
		int StoryFlowInState;
		int StoryFlowOutState;
		bool IsLastItemInStory;
		CPoint CursorIndex; //MAC_CHECL TablePoint

		bool allowFixWrap;
		bool allowAdjustBox;
		CString ArrowFile;
		CString OverlayFile;
		CString ConnectTheDotsFile;
#ifdef SW50
		CString StartDotFile;
#endif

protected:
		int	TextLineYs;
        float zPointSize;
		int zMargin;			// Zoomed margin value
		int mDescender;
		CString TxtLines[MAX_TEXT_LINES+1];
		CStringW TxtAttrs[MAX_TEXT_LINES+1];
		CString TxtShapes[MAX_TEXT_LINES+1];

private:
		// This is the line height
		int uzTextLineYs;		// un-zoomed value
		int mDescentLeading;  // used for normal fonts
		CFont TextFont;
		TTFont Dot2DotFont;
		TTFont ArrowFont;
		TTFont ConnectTheDotsFont;
		TTFont OverlayFont;
		bool doOverlay;
#ifdef SW50
		TTFont StartDotFont;
#endif

		GLYFHOLD CharArray[MAX_GLYF_ARRAY];
		GlyfData GlyfArray[MAX_GLYF_ARRAY];
		GlyfData ArrowArray[MAX_GLYF_ARRAY];
		GlyfData OverlayArray[MAX_GLYF_ARRAY];
		GlyfData ConnectTheDotsArray[MAX_GLYF_ARRAY];
		GlyfData StartDotArray[MAX_GLYF_ARRAY];
		FONT_STUFF fsData[MAX_FS_FONTS];

		// Format arrays correspont to button numbers
		int DensityFormatArray[MAX_GLYF_ARRAY];
		int ShadeFormatArray[MAX_GLYF_ARRAY];
		int ArrowsFormatArray[MAX_GLYF_ARRAY];
		int OverlayFormatArray[MAX_GLYF_ARRAY];
		int ConnectTheDotsFormatArray[MAX_GLYF_ARRAY];
		int UnderlineArray[MAX_GLYF_ARRAY];
#ifdef SW50
		int StartDotFormatArray[MAX_GLYF_ARRAY];
#endif

#define ATTR_UND_ON		1
#define DO_UNDERLINE	2
		int nUnderline;

		int SelectedArray[MAX_GLYF_ARRAY];
		int nSelected;
		CPoint SelCursorDrawn;
		CPoint SelCursorPos;
		CPoint SelCursorIndex;

		int nGlyfArrayIndex;
        int nPenWidth;
        int nArrowWidth;
		int nOverlayWidth;
	 	bool mKeyAction;


		// should use system define here... _needs_ to be same as ttfont array size.
		CString FontFile;
		wchar_t cCurrAttr;			// Value of the current attribute
		wchar_t cFirstWordOfLineAttr;
		wchar_t cFirstAllWordOfLineAttr;
		wchar_t cFirstLetOfWordAttr;
		wchar_t cFirstLetOfWord2Attr;
		int doKerning;		// TRUE means to do kerning
		unsigned short inCursive;
		int nLetterSpacing;		// auto space for non-cursive fonts
		int nLinePointSpace;
		
		// Dot2Dot Properties used to fill format arrays
		int nDot2DotDensity;
		int nDot2DotShade;
		int nDot2DotArrows;
		int nDot2DotOverlay;
		int nDot2DotConnectTheDots;
		int nDot2DotStartDot;
		// Dot2Dot Properties used for drawing glyf
		int nDot2DotGlyfDensity;
		int nDot2DotGlyfShade;
		//int nDot2DotGlyfArrows;

		int CursorLength;
		CPoint CursorPos;
		CPoint CursorDrawn;	
		
		int nCursorActive;
		bool doFonts;
		int nLastActive;	/* Watch for change of state */
		int nOrientation;	

		//int nCursorIndex;
		CPoint ScrollPos;
		CPoint ScrollDrawn;
		
		int FindBeginOfWord(int doSkip);
		int FindEndOfWord(void);
		int BeginPreviousWord(void);
public:
		BOOL SelectionOn;
		int nStartDot;
		int nDot2Dot;
		int nPointSize;
		bool isMathFont;
		bool isMathFont2;
		char nAnnoyingFontMsg;
		char nAnnoyingArrowMsg;
		char nAnnoyingOverlayMsg;
		char nAnnoyingStartdotMsg;
		char nAnnoyingConnectTheDotsMsg;
		int nOverfullWarning;
		int noGrowState;
		int nDrawingArrows;
		int nDrawingOverlay;
		int nDrawingConnectTheDots;
		bool nDrawingStartDot;
		bool IsFromSpecialCharDlg;
		
		// Dot2Dot Properties taken from button
		int nDot2DotDensityButton;
		int nDot2DotShadeButton;
		int nDot2DotLinesButton;
		int nDot2DotArrowsButton;
		int nDot2DotOverlayButton;
		// These use the defines from texttool.h
		int DensityFormat;
		int ShadeFormat;
		int ArrowsFormat;
		int OverlayFormat;
		int ShadeType;
		//bool doDrawGlyf;
		bool doDrawConnectTheDots;
		bool tempGuideLinesOff;
		bool inDialogDisplay;
		FONTINFO myFontInfo;

		// The options and colors the user selected for area shading
		COLORREF ColorTopAreaShading;
		BOOL IsShadingOnTopArea;
		COLORREF ColorMiddleAreaShading;
		BOOL IsShadingOnMiddleArea;
		COLORREF ColorDescenderAreaShading;
		BOOL IsShadingOnDescenderArea;
		// The color the user selected for stroke arrows
		COLORREF ColorStrokeArrows;
		// The color the user selected for starting dot
		COLORREF ColorStartingDot;
		// The color the user selected for outline (outline overlay of outline font)
		COLORREF ColorOutlineOverlay;
		// The color the user selected for decision dots
		COLORREF ColorDecisionDots;
		COLORREF ColorConnectTheDots;
		// The four colors the user chose for drawing colored letters
		COLORREF ColorFirstStrokeLetters;
		COLORREF ColorSecondStrokeLetters;
		COLORREF ColorThirdStrokeLetters;
		COLORREF ColorFourthStrokeLetters;
		// The four colors the user chose for drawing guidelines
		COLORREF ColorGuidelineTop;
		COLORREF ColorGuidelineMiddle;
		COLORREF ColorGuidelineBase;
		COLORREF ColorGuidelineBottom;
};

#endif // _TEXT_ITEM_H_

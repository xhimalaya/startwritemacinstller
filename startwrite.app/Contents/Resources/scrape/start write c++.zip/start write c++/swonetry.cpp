// swOneTry.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swOneTry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// swOneTry dialog


swOneTry::swOneTry(CWnd* pParent /*=NULL*/)
	: CDialog(swOneTry::IDD, pParent)
{
	//{{AFX_DATA_INIT(swOneTry)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void swOneTry::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(swOneTry)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(swOneTry, CDialog)
	//{{AFX_MSG_MAP(swOneTry)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// swOneTry message handlers

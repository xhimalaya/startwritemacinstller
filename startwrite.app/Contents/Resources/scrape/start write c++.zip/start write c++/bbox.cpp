// Bounding Box Class Implementation
//#define FIXED_BOXES


#include "bbox.h"
#include "miscutil.h"
#include "sw.h"
#include "Artdisp.h"

extern unsigned int defaultFont, defaultSize;
extern FONTINFO szFonts[];

#define DEFBOXSIZE (4)

int doZoom = 1;
static int inHere=0;

// global
int doingPrinting = 0;

BBox::BBox()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::BBox()"); 
	#endif

	Position.x = DOC_X_BORDER_PIXELS;
	Position.y = -DOC_Y_BORDER_PIXELS;
	PosHasScroll = FALSE;
	dCurrentZoom = 1.0;
	Size.x = DEFBOXSIZE;
	Size.y = -DEFBOXSIZE;

	if (doRunUKVersion || (*swType == swSHR) || (*swType == swOXF) || (*swType == swOXD)) {	//SHERSTON
		MaxXY.x = (long)PAGE_A1_X_PIXELS;
		MaxXY.y = (long)-PAGE_A1_Y_PIXELS;
	}
	else {
		MaxXY.x = (long)PAGE_US_X_PIXELS;
		MaxXY.y = (long)-PAGE_US_Y_PIXELS;
	}

	ScrollOffset.x = 0;
	ScrollOffset.y = 0;

	OldPosition = Position;
	OldSize = Size;

	nVisible = TRUE;

	nState = BBOX_STATE_NORMAL;

	nWarning = FALSE;

	Item = NULL;

	FrameInfo = BBOX_FRAME_NONE;

	HandleRadius = BORDER_WIDTH;

	int offset = HandleRadius;
	HandleOffsets[0] = CPoint(offset,-offset);
	HandleOffsets[1] = CPoint(-offset,-offset);
	HandleOffsets[2] = CPoint(-offset,offset);
	HandleOffsets[3] = CPoint(offset,offset);

	HandleOffsets[4] = CPoint(0,-offset);
	HandleOffsets[5] = CPoint(-offset,0);
	HandleOffsets[6] = CPoint(0,offset);
	HandleOffsets[7] = CPoint(offset,0);

#ifdef FIXED_BOXES
	m_bAllowGrow = FALSE;
#else
	m_bAllowGrow = TRUE;
#endif
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::BBox"); 
	#endif
}


extern BBox *pCopyBBox;

BBox::~BBox()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::~BBox()"); 
	#endif

	if( Item != NULL) {   
		Item->Delete();
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::~BBox"); 
	#endif
}

void
BBox::Delete()
{
	delete this;		// this is BAD code ->~BBox();
}

void 
BBox::Read(fstream *fin, Module *pmodule, int *status)
{
	char line[128];
	pmodule;	/* get rid of compiler warning */

	while( ! fin->eof())
	{
		fin->getline( line, 128, SWD_EQ);

		if( strcmp(line,SWD_POSITIONX) == S1_EQUALS_S2)
		{            
			*fin >> Position.x;
			OldPosition.x = Position.x;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_POSITIONY) == S1_EQUALS_S2)
		{            
			*fin >> Position.y;
			OldPosition.y = Position.y;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_SIZEX) == S1_EQUALS_S2)
		{            
			*fin >> Size.x;
			OldSize.x = Size.x;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_SIZEY) == S1_EQUALS_S2)
		{            
			*fin >> Size.y;
			OldSize.y = Size.y;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_VISIBLE) == S1_EQUALS_S2)
		{
			*fin >> nVisible;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_STATE) == S1_EQUALS_S2)
		{
			*fin >> nState;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_ENDBBOX) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);
			return;
		}
		else if( strcmp(line,SWD_BOXLINES) == S1_EQUALS_S2)
		{
			*fin >> FrameInfo;
			fin->getline( line, 128, SWD_NL);
		}
		else if( strcmp(line,SWD_BEGINTEXTITEM) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);

			TextItem *item = new TextItem();
			Item = (Module *)item;
			item->Message( ITEM_PARENT_SET, this, status);

			item->Read( fin, NULL, status);
		}
		else if( strcmp(line,SWD_BEGINARTITEM) == S1_EQUALS_S2)
		{
			fin->getline( line, 128, SWD_NL);

			ArtItem *item = new ArtItem();
			Item = (Module *)item;
			item->Message( ITEM_PARENT_SET, this, status);

			item->Read( fin, NULL, status);
		}
		else
		{
			fin->getline( line, 128, SWD_NL);
		}
	}
}

void
BBox::Write(fstream *fout, Module *pmodule, int *status)
{
	pmodule;	/* get rid of compiler warning */

	*fout << SWD_BEGINBBOX 	<< SWD_EQ 	<< "*" 			<< SWD_NL;
	*fout << SWD_POSITIONX 	<< SWD_EQ 	<< Position.x 	<< SWD_NL;
	*fout << SWD_POSITIONY 	<< SWD_EQ 	<< Position.y 	<< SWD_NL;
	*fout << SWD_SIZEX 		<< SWD_EQ 	<< Size.x 		<< SWD_NL;
	*fout << SWD_SIZEY		<< SWD_EQ	<< Size.y 		<< SWD_NL;
	*fout << SWD_VISIBLE		<< SWD_EQ	<< nVisible 	<< SWD_NL;
	*fout << SWD_STATE		<< SWD_EQ	<< nState 		<< SWD_NL;
	*fout << SWD_BOXLINES	<< SWD_EQ	<< FrameInfo	<< SWD_NL;
	if( Item != NULL)
	{
		Item->Write( fout, NULL, status);
	}

	*fout << SWD_ENDBBOX		<< SWD_EQ	<< "*" 			<< SWD_NL;

	*status = OK;
}

                                
                                
void
BBox::resetFontInfo()
{
	char string[32];

	CComboBox *pcombobox = NULL;

	pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_POINT_COMBO);
	wsprintf(string,"%d", defaultSize);

	if (pcombobox->FindString(0, string) == CB_ERR)
		pcombobox->SetWindowText(string);
	else
		pcombobox->SelectString(-1, string);

	pcombobox = (CComboBox*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(IDC_EDIT_BAR_FONT_COMBO);
	wsprintf(string,"%s", szFonts[defaultFont].f_fontname);
	pcombobox->SelectString(-1, string);
}

float BBox::Message(int message, float number, int *status)
{
	float RI = 0.0;

	switch(message) {
		case BBOX_SET_ZOOM:
			RI = dCurrentZoom;
			dCurrentZoom = number;
			if (this->Message(BBOX_ITEM_WHATAMI, 0, status) == ITEM_TEXT_TYPE) {
				Item->Message(TEXT_SET_DZOOM, number, status);
			}
			*status = OK;
			break;
	}
	return(RI);
}
                                
int 
BBox::Message( int message, int number, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::Message(int,int,int*)"); 
	#endif

	// Return Integer
	int RI = 0;

	switch(message)
	{

		case BBOX_NONE:
			*status = ERROR;
		break;

	    case BBOX_VISIBLE_GET:
	    	RI = nVisible;
	    	*status = OK;
	    break;
	    
	    case BBOX_VISIBLE_SET:
	    	RI = nVisible;
	    	nVisible = number;
	    	*status = OK;
	    break;
	    
	    case BBOX_STATE_GET:
	    	RI = nState;
	    	*status = OK;
	    break;
	    
	    case BBOX_STATE_SET:
	    	RI = nState;
	    	nState = number;
	    	
	    	if (nState == BBOX_STATE_NORMAL) {
	    		// Reset the box state to the default font 
	    		resetFontInfo();
	    	}
	    	
	    	*status = OK;
	    break;

		case BBOX_SET_FRAME:
			if (number == BBOX_FRAME_DOUBLE_6) {
			//	doCreateBorderGraphic();
			}
			FrameInfo = number;
			*status = OK;
			break;
	    
	    case BBOX_WARNING_SET:
	    	nWarning = number;
	    	*status = OK;
	    break;

		case BBOX_CAN_GROW:
			*status = OK;
			RI = (m_bAllowGrow ? 1 : 0);
			break;

		case BBOX_SET_GROW:
			*status = OK;
			m_bAllowGrow = number;
			break;

		case ART_GET_OVERLAPPED:
			if (Item == NULL || Item->m_iType != ITEM_ART_TYPE) {
				RI = FALSE;	    
				*status = ERROR;
	    	}
			else {
				RI = Item->Message( message, number, status);	    
			}
			break;

		default:
	    	//if( nState == BBOX_STATE_OPEN && Item != NULL)
	    	if (Item != NULL) {
				RI = Item->Message( message, number, status);	    
	    	}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::Message: %d", status); 
	#endif

	return RI;
}

CPoint
BBox::Message( int message, CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::Message(int,CPoint,int*)"); 
	#endif

	// Return CPoint
	CPoint RCP;
	RCP.x = 0;
	RCP.y = 0;    

	switch(message)
	{

		case BBOX_NONE:
			*status = ERROR;
		break;
	    
	    case BBOX_IS_AT_POINT:
    		if( IsAtPoint( point, status) == TRUE)
    		{
    			RCP = point;
    			*status = OK;
    		}
	    break;

		case BBOX_SCROLL_OFFSET_SET:
			ScrollOffset = point;
			ScrollOffset.x = (int)((float)(point.x / dCurrentZoom));
			ScrollOffset.y = (int)((float)(point.y / dCurrentZoom));
			*status = OK;
		break;

		case BBOX_WHAT_IS_AT_POINT:
			RCP = WhatIsAtPoint( point, status);
			*status = OK;
		break;

	    case BBOX_POSITION_GET:
			RCP = Position;

			if ((*status == -5) && PosHasScroll) {
				RCP.x  += ScrollOffset.x;
				RCP.y  += ScrollOffset.y;
			}
	    	if (doZoom) {
	    		RCP.x = (int)((float)(RCP.x * dCurrentZoom));
	    		RCP.y = (int)((float)(RCP.y * dCurrentZoom));
	    	}
	    	*status = OK;
	    break;
	    
	    case BBOX_POSITION_SET:
	    	RCP = Position;
	    	if (*status == SAVEOLD || *status == DRAG_TRANSPARENT) {
	    		OldPosition = Position;
	    	}
	    	else {	// CLEAROLD
	    		OldPosition = point;
	    	}
	    	Position = point;
	    	*status = OK;
	    break;
	    
	    case BBOX_SIZE_GET:
	    	RCP = Size;
	    	if (doZoom) {
	    		RCP.x = (int)((float)(RCP.x * dCurrentZoom));
	    		RCP.y = (int)((float)(RCP.y * dCurrentZoom));
	    	}
	    	*status = OK;	    
	    break;
	    
	    case BBOX_SIZE_SET:
	    	{
	    		int maxy = MaxXY.y;	//(int) ((float)MaxXY.y * dCurrentZoom);
				int tempy = Position.y;
				if (PosHasScroll) {
					tempy += ScrollOffset.y;
				}
				if (tempy > 0) 
					tempy = -tempy;
                
				//?int posy = (int) ((float)Position.y * dCurrentZoom);
		    	RCP = Size;
		    	if (*status == SAVEOLD) {
	   	 			OldSize = Size;
	   		 	}
				else if (*status == CLEAROLD) {
    				OldSize = point;	    
    			}
	   	 		if ((point.y + tempy) <= maxy) {		// don't allow size to grow beyond page
	    			*status = ERROR;	// report error -- but allow
				}
				else if (m_bAllowGrow == FALSE) {
					*status = NO_GROWING;
				}
				else {
					*status = OK;		// report error, but allow
				}
				if (Size != point) {
					if (m_bAllowGrow == TRUE) {
						Size = point;
					}
					else {
						Size = point;
					}
				}

		    }
		    break;

		case BBOX_MAX_XY_SET:
		    MaxXY = point;
			*status = OK;
	    break;

		case BBOX_MAX_XY_GET:
			RCP = MaxXY;
			*status = OK;
		break;
	    
		default:
	    	if( Item != NULL) {
				RCP = Item->Message( message, point, status);
			}
			//*status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::Message: %d", status); 
	#endif

	return RCP;
}

Module*
BBox::Message( int message, Module *pmodule, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::Message(int,Module*,int*)"); 
	#endif

	// Return Module
	Module *RM = NULL;
	BBox *pnbbox = NULL;

	switch(message)
	{

		case BBOX_NONE:
			*status = ERROR;
		break;
	    
	    case BBOX_IS_OVERLAPPING:
		    break;

		case BBOX_ITEM_SET:
			Item = pmodule;
		break;

		case GET_ITEM_FOR_REDRAW:
			RM = this;
			*status = OK;
		break;

		case ITEM_RETURN_COPY:
			pnbbox = new BBox();
			pnbbox->nVisible = nVisible;
			pnbbox->nState = BBOX_STATE_NORMAL;
			pnbbox->Position = Position;


			pnbbox->Size = Size;

			if( Item != NULL)
			{
				Module *null_module = NULL;
				pnbbox->Item = Item->Message( ITEM_RETURN_COPY, null_module, status);
				if(pnbbox->Item != NULL) {
					pnbbox->Item->Message( ITEM_PARENT_SET, pnbbox, status);
				}
			}

			RM = pnbbox;
		break;

		default:
			if( Item != NULL)
			{
				RM = Item->Message( message, pmodule, status);
			}
			//*status = ERROR;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::Message: %d", status); 
	#endif

	return RM;
}

void
BBox::Draw(CDC *pDC, int *status)
{
	if (*status == DRAG_TRANSPARENT) {
		int addWidth = BORDER_WIDTH;

		CPen penGridInch(PS_SOLID, 1, RGB(128,128,255));
		CPen penGridFraction(PS_SOLID, 1, RGB(204,204,255));
		CPen penGridHot(PS_SOLID, 1, RGB(255,0,0));
		CPen *penSave = pDC->SelectObject(&penGridFraction);
		int nPosOldYSign = OldPosition.y <= ScrollOffset.y ? 1 : -1;
		int nPosYSign = Position.y <= ScrollOffset.y ? 1 : -1;
		int nPosOldXSign = OldPosition.x >= ScrollOffset.x ? 1 : -1;
		int nPosXSign = Position.x >= ScrollOffset.x ? 1 : -1;
		CPoint lPosNormalOld(OldPosition.x - addWidth - ScrollOffset.x, OldPosition.y - ScrollOffset.y + addWidth);
		CPoint lSizeNormalOld(OldSize.x + (2 * addWidth), OldSize.y - (2 * addWidth));
		CPoint lPosNormal(Position.x - addWidth - ScrollOffset.x, Position.y - ScrollOffset.y + addWidth);
		CPoint lSizeNormal(Size.x + (2 * addWidth), Size.y - (2 * addWidth));
		CPoint lPosOnGrid(Position.x - addWidth, Position.y + addWidth);
		int prevHotY = theApp.m_iGridHotY;
		int prevHotX = theApp.m_iGridHotX;
		theApp.m_iGridHotY = 0;
		theApp.m_iGridHotX = 0;
		for (int xLine=1; xLine < 44; xLine++) {
			if (theApp.m_iGridXUsed[xLine] == 0 && theApp.m_iGridX[xLine] > 0 && lPosOnGrid.x > theApp.m_iGridX[xLine] - 50 && lPosOnGrid.x < theApp.m_iGridX[xLine] + 50) {
				theApp.m_iGridHotX = xLine;
				break;
			}
		}
		for (int yLine=1; yLine < 44; yLine++) {
			if (theApp.m_iGridYUsed[yLine] == 0 && theApp.m_iGridY[yLine] != 0 && lPosOnGrid.y > theApp.m_iGridY[yLine] - 50 && lPosOnGrid.y < theApp.m_iGridY[yLine] + 50) {
				theApp.m_iGridHotY = yLine;
				break;
			}
		}
		// If a previous vertical grid line (x position) is no longer hot, change the previously red one to normal color
		if (prevHotX != 0 && theApp.m_iGridHotX != prevHotX) {
			pDC->SelectObject((prevHotX + 1) % 4 ? &penGridFraction : &penGridInch);
			pDC->MoveTo(theApp.m_iGridX[prevHotX], theApp.m_iGridY[1] - ScrollOffset.y);
			pDC->LineTo(theApp.m_iGridX[prevHotX], theApp.m_iGridY[theApp.m_iGridMaxY - 1] - ScrollOffset.y);
		}
		// If a previous horizontal grid line (y position) is no longer hot, change the previously red one to normal color
		if (prevHotY != 0 && theApp.m_iGridHotY != prevHotY) {
			pDC->SelectObject((prevHotY + 1) % 4 ? &penGridFraction : &penGridInch);
			pDC->MoveTo(theApp.m_iGridX[1] - ScrollOffset.x, theApp.m_iGridY[prevHotY] - ScrollOffset.y);
			pDC->LineTo(theApp.m_iGridX[theApp.m_iGridMaxX - 1] - ScrollOffset.x, theApp.m_iGridY[prevHotY] - ScrollOffset.y);
		}
		// Restore pen
		pDC->SelectObject(penSave);

		lSizeNormalOld.y = abs(lSizeNormalOld.y);//Before conversion
		lSizeNormalOld.x = abs(lSizeNormalOld.x);//Before conversion
		lPosNormalOld.y = abs(lPosNormalOld.y);//Before conversion
		lPosNormalOld.x = abs(lPosNormalOld.x);//Before conversion
		pDC->LPtoDP(&lPosNormalOld);
		pDC->LPtoDP(&lSizeNormalOld);
		lSizeNormalOld.y = abs(lSizeNormalOld.y);//And after conversion
		lSizeNormalOld.x = abs(lSizeNormalOld.x);//And after conversion
		lPosNormalOld.y = abs(lPosNormalOld.y) * nPosOldYSign;//And after conversion
		lPosNormalOld.x = abs(lPosNormalOld.x) * nPosOldXSign;//And after conversion

		lSizeNormal.y = abs(lSizeNormal.y);//Before conversion
		lSizeNormal.x = abs(lSizeNormal.x);//Before conversion
		lPosNormal.y = abs(lPosNormal.y);//Before conversion
		lPosNormal.x = abs(lPosNormal.x);//Before conversion
		pDC->LPtoDP(&lPosNormal);
		pDC->LPtoDP(&lSizeNormal);
		lSizeNormal.y = abs(lSizeNormal.y);//And after conversion
		lSizeNormal.x = abs(lSizeNormal.x);//And after conversion
		lPosNormal.y = abs(lPosNormal.y) * nPosYSign;//And after conversion
		lPosNormal.x = abs(lPosNormal.x)* nPosXSign;//And after conversion
		pDC->SetMapMode(MM_TEXT);

		CRect rctInTextOld(lPosNormalOld.x, lPosNormalOld.y, lPosNormalOld.x + lSizeNormalOld.x, lPosNormalOld.y + lSizeNormalOld.y);
		CRect rctInText(lPosNormal.x, lPosNormal.y, lPosNormal.x + lSizeNormal.x, lPosNormal.y + lSizeNormal.y);

		if (rctInTextOld.Width() > rctInText.Width() || rctInTextOld.Height() > rctInText.Height()) {
			pDC->DrawFocusRect(rctInTextOld);
		}

		pDC->DrawFocusRect(rctInText);
		pDC->SetMapMode(MM_TWIPS);

		// If a new vertical grid line (x position) is now hot, make it red
		if (theApp.m_iGridHotX != 0 && theApp.m_iGridHotX != prevHotX) {
			pDC->SelectObject(&penGridHot);
			pDC->MoveTo(theApp.m_iGridX[theApp.m_iGridHotX], theApp.m_iGridY[1] - ScrollOffset.y);
			pDC->LineTo(theApp.m_iGridX[theApp.m_iGridHotX], theApp.m_iGridY[theApp.m_iGridMaxY - 1] - ScrollOffset.y);
		}
		// If a new horizontal grid line (y position) is now hot, make it red
		if (theApp.m_iGridHotY != 0 && theApp.m_iGridHotY != prevHotY) {
			pDC->SelectObject(&penGridHot);
			pDC->MoveTo(theApp.m_iGridX[1] - ScrollOffset.x, theApp.m_iGridY[theApp.m_iGridHotY] - ScrollOffset.y);
			pDC->LineTo(theApp.m_iGridX[theApp.m_iGridMaxX - 1] - ScrollOffset.x, theApp.m_iGridY[theApp.m_iGridHotY] - ScrollOffset.y);
		}
		// Restore pen
		pDC->SelectObject(penSave);

		return;
	}
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::Draw(CDC,int*)"); 
	#endif
	int frameType=0;
	int frameWidth=0;
	int spacer=0;
#define TMP_TOPBUF 20
	int topBuffer= 0;
	bool doDouble=false;
	bool doGraphics=false;
	bool dontPrint=false;

	//original CPen outlinepen( PS_DOT, 1, RGB( 200, 200, 200));
	switch(FrameInfo) {
	default:
	case BBOX_FRAME_NONE:
		frameType = PS_DOT;
		frameWidth = 1;
		dontPrint=true;
		break;
	case BBOX_FRAME_SINGLE_1:
		frameType = PS_SOLID;
		frameWidth = 10;
		break;
	case BBOX_FRAME_SINGLE_2:
		frameType = PS_SOLID;
		frameWidth = 20;
		break;
	case BBOX_FRAME_SINGLE_3:
		frameType = PS_SOLID;
		frameWidth = 30;
		break;
	case BBOX_FRAME_SINGLE_6:
		frameType = PS_SOLID;
		frameWidth = 60;
		break;
	case BBOX_FRAME_DOUBLE_1:
		frameType = PS_SOLID;
		frameWidth = 10;
		spacer=40;
		doDouble=true;
		break;
	case BBOX_FRAME_DOUBLE_2:
		frameType = PS_SOLID;
		frameWidth = 20;
		spacer=30;
		doDouble=true;
		break;
	case BBOX_FRAME_DOUBLE_3:
		frameType = PS_SOLID;
		frameWidth = 30;
		spacer=24;
		doDouble=true;
		break;
	case BBOX_FRAME_DOUBLE_6:
		frameType = PS_SOLID;
		frameWidth = 60;
		spacer=16;
		doDouble=true;
		break;
	case BBOX_FRAME_GRAPHIC_01:
		doGraphics=true;
		break;
	}

	/* Don't draw during print process */
	// that just makes extra drawing
	if (doingPrinting && !pDC->IsPrinting()) {
		return;
	}
	
	
	int tempStatus;
	int isArt = (this->Message(BBOX_ITEM_WHATAMI, 0, &tempStatus) == ITEM_ART_TYPE) ? TRUE : FALSE;
	int nStoryBoxOrder = 0;
	if (this->Message(BBOX_ITEM_WHATAMI, 0, &tempStatus) == ITEM_TEXT_TYPE) {
		nStoryBoxOrder = ((TextItem *)Item)->StoryItemOrder;
	}
	CPoint pos, sz;
	int os=-1;
	int textIsFull;

	textIsFull = this->Message(TEXT_IS_OVERFULL, 0, &tempStatus);

	if (inHere == 0) {
		Position.x -= ScrollOffset.x;
		Position.y -= ScrollOffset.y;

		OldPosition.x -= ScrollOffset.x;
		OldPosition.y -= ScrollOffset.y;
		PosHasScroll = TRUE;
	}
	inHere++;

	int isVisible = TRUE;

	// Draw box accoring to state
	if ((nVisible == TRUE) && (isArt || isVisible)) { // pDC->RectVisible(&vRect))) {
		if (*status == TEXT_DRAW_ALL && !theApp.m_bStoryTextWasMoved) {

			if( !pDC->IsPrinting()) {

				CPen line_pen(PS_SOLID, 1, RGB(255,255,255));
				CPen *old_pen = pDC->SelectObject(&line_pen);

				pDC->SelectStockObject(WHITE_BRUSH);


				if (doZoom) {
					os = (int)((float)BORDER_WIDTH * dCurrentZoom);
					pos.x = (int)((float)OldPosition.x * dCurrentZoom);
					pos.y = (int)((float)OldPosition.y * dCurrentZoom);
					sz.x = (int)((float)OldSize.x * dCurrentZoom);
					sz.y = (int)((float)OldSize.y * dCurrentZoom);
				}
				else {
					os = BORDER_WIDTH;

					pos.x = OldPosition.x;
					pos.y = OldPosition.y;
					sz.x = OldSize.x;
					sz.y = OldSize.y;
				}
				
				// If the small default box, don't clear the screen
				if (OldSize.y != (-DEFBOXSIZE)) {
					pDC->Rectangle(CRect( 
						pos.x-os, 	
						pos.y+os,
						(pos.x + sz.x) + (2*os), 
						(pos.y + sz.y) -(2*os)));
				}
				if (doZoom) {
					os = (int)((float)BORDER_WIDTH * dCurrentZoom);
					pos.x = (int)((float)Position.x * dCurrentZoom);
					pos.y = (int)((float)Position.y * dCurrentZoom);
					sz.x = (int)((float)Size.x * dCurrentZoom);
					sz.y = (int)((float)Size.y * dCurrentZoom);
				}
				else {
					os = BORDER_WIDTH;

					pos.x = Position.x;
					pos.y = Position.y;
					sz.x = Size.x;
					sz.y = Size.y;

				}
				pDC->Rectangle(CRect( 
						pos.x - os, 
						pos.y + os,
						(pos.x + sz.x) + (2*os),	
						(pos.y + sz.y) - (2*os)));

				pDC->SelectObject(old_pen);
			}
		}
		// The item will be 'behind' the bbox
    	if (Item != NULL) {
    		int iOldStatus = *status;
    
    		// Give the item a chance to change it's status and start all
    		// over again.
    		Item->Draw(pDC, status);


			if (*status != iOldStatus) {

				// Reset the position stuff before leaving and entering again
				if (inHere == 1) {
					
					Position.x += ScrollOffset.x;
					Position.y += ScrollOffset.y;
			
					OldPosition.x += ScrollOffset.x;
					OldPosition.y += ScrollOffset.y;
					PosHasScroll = FALSE;
				}

				inHere--;
	    		Draw(pDC, status);
	    		return;
	    	} 
	    
		}
		else {
			int iOldStatus = *status;
			iOldStatus = 2;
		}

		if( nState == BBOX_STATE_HILITE) {
			pDC->SelectStockObject(WHITE_BRUSH);

			CPoint posHilite, szHilite;
			posHilite.x = (int)((float)(Position.x-BORDER_WIDTH) * dCurrentZoom);
			posHilite.y = (int)((float)(Position.y+BORDER_WIDTH) * dCurrentZoom);
			szHilite.x = (int)((float)(Size.x+(2*BORDER_WIDTH)) * dCurrentZoom);
			szHilite.y = (int)((float)(Size.y-(2*BORDER_WIDTH)) * dCurrentZoom);

			pDC->Rectangle(CRect( 
					posHilite.x, posHilite.y,
					(posHilite.x + szHilite.x),	(posHilite.y + szHilite.y)));
		}
		else if( nState == BBOX_STATE_SELECT) {
			CPen line_pen(frameType, frameWidth, RGB(0,0,0));
			CPen *old_pen = pDC->SelectObject(&line_pen);
			os = (int)((float)BORDER_WIDTH * dCurrentZoom);
			
			// I don't remember why we have this  buffer.
			// but it makes the square  handles look detached from the edge
			// when really the top line is too high
			topBuffer = TMP_TOPBUF;	//  was 60
			pos.x = (int)((float)Position.x * dCurrentZoom);
			pos.y = (int)((float)Position.y * dCurrentZoom);
			sz.x = (int)((float)Size.x * dCurrentZoom);
			sz.y = (int)((float)Size.y * dCurrentZoom);

			pDC->MoveTo(pos.x - os, pos.y + os + topBuffer);
			pDC->LineTo(pos.x + sz.x + os, pos.y + os + topBuffer);
			pDC->LineTo(pos.x + sz.x + os, pos.y + sz.y - os);
			pDC->LineTo(pos.x - os, pos.y + sz.y - os);
			pDC->LineTo(pos.x - os, pos.y + os + topBuffer);

			if(doDouble) {
				int myOff=frameWidth + spacer;
				pos.x += myOff;
				pos.y -= myOff;
				pDC->MoveTo(pos.x - os, pos.y + os + topBuffer);
				pDC->LineTo(pos.x + sz.x -(2*myOff) + os, pos.y + os + topBuffer);	// Top Line
				pDC->LineTo(pos.x + sz.x -(2*myOff) + os, pos.y + sz.y - os +(2*myOff)+10);	// right going down
				pDC->LineTo(pos.x - os, pos.y + sz.y - os + (2*myOff)+10);	// bottom to the left
				pDC->LineTo(pos.x - os, pos.y + os + topBuffer);	// left to the top

			}

			pDC->SelectObject(old_pen);
			pDC->SelectStockObject(GRAY_BRUSH);

			CBrush line_brush;
			
			if (nStoryBoxOrder > 0)
		    	line_brush.CreateSolidBrush(RGB(255,255,0));// Story Boxes have yellow handles
			else if ((nWarning == TRUE) || (textIsFull == TRUE))
		    	line_brush.CreateSolidBrush(RGB(255,0,0));
			else
		    	line_brush.CreateSolidBrush(RGB(64,64,64));

	    	CBrush *old_brush = pDC->SelectObject(&line_brush);
		    
			int i = 0;
			int nRadiusSz = (int)((float)HandleRadius * dCurrentZoom);

			// Draw the handles
			// fix this?
			for( i = BBOX_CORNER_MIN; i <= BBOX_CENTER_MAX; ++i) {
				TmpPos = GetHandlePoint( BORDER_WIDTH, i, status);
				pDC->Rectangle(CRect(
						TmpPos.x, TmpPos.y,
						(TmpPos.x - nRadiusSz), (TmpPos.y + nRadiusSz)));
			}
			pDC->SelectObject(old_brush);
		}
		else if (!doingPrinting || (doingPrinting && (dontPrint == false))) { //if( !pDC->IsPrinting()) {		// Only do boxes on display for now
			BYTE ColorValue;
			if (frameType != 1) {
				ColorValue=0;
			}
			else {
				ColorValue=200;
			}
			CPen outlinepen( frameType, frameWidth, RGB( ColorValue, ColorValue, ColorValue));
			CPen *oldpen = pDC->SelectObject(&outlinepen);
			
			os = (int)((float)BORDER_WIDTH * dCurrentZoom);
			pos.x = (int)((float)Position.x * dCurrentZoom);
			pos.y = (int)((float)Position.y * dCurrentZoom);
			sz.x = (int)((float)Size.x * dCurrentZoom);
			sz.y = (int)((float)Size.y * dCurrentZoom);
			topBuffer = TMP_TOPBUF;
			pDC->MoveTo(pos.x - os, pos.y + os + topBuffer);
			pDC->LineTo(pos.x + sz.x + os, pos.y + os + topBuffer);
			pDC->LineTo(pos.x + sz.x + os, pos.y + sz.y - os);
			pDC->LineTo(pos.x - os, pos.y + sz.y - os);
			pDC->LineTo(pos.x - os, pos.y + os + topBuffer);


			if(doDouble) {
				int myOff=frameWidth + spacer;
				pos.x += myOff;
				pos.y -= myOff;
				pDC->MoveTo(pos.x - os, pos.y + os + topBuffer);
				pDC->LineTo(pos.x + sz.x -(2*myOff) + os, pos.y + os + topBuffer);
				pDC->LineTo(pos.x + sz.x -(2*myOff) + os, pos.y + sz.y - os +(2*myOff)+10);
				pDC->LineTo(pos.x - os, pos.y + sz.y - os + (2*myOff)+10);
				pDC->LineTo(pos.x - os, pos.y + os + topBuffer);

			}


			pDC->SelectObject(oldpen);
		}
	}

	if (inHere == 1) {
		Position.x += ScrollOffset.x;
		Position.y += ScrollOffset.y;
	    
		OldPosition.x += ScrollOffset.x;
		OldPosition.y += ScrollOffset.y;
		PosHasScroll = FALSE;
	}
	inHere--;
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::Draw: void"); 
	#endif
}

/////////////////////////////////////////////////////////////////////////////
// Private Member Functions
/////////////////////////////////////////////////////////////////////////////

int
BBox::IsAtPoint(CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::IsAtPoint(CPoint,int*)"); 
	#endif

	CPoint pos;
	CPoint sz;
	pos.x = (int)((float)(Position.x-BORDER_WIDTH) * dCurrentZoom);
	pos.y = (int)((float)(Position.y+BORDER_WIDTH) * dCurrentZoom);
	sz.x = (int)((float)(Size.x+(BORDER_WIDTH*2)) * dCurrentZoom);
	sz.y = (int)((float)(Size.y-(BORDER_WIDTH*2)) * dCurrentZoom);

	if( (point.x >= pos.x) &&
		(point.y <= pos.y) &&
		(point.x <= (pos.x + sz.x)) &&
		(point.y >= (pos.y + sz.y)))
	{
		*status = OK;
		return TRUE;
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::IsAtPoint: %d", status); 
	#endif

	return FALSE;
}

CPoint
BBox::WhatIsAtPoint(CPoint point, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::WhatIsAtPoint(CPoint,int*)"); 
	#endif

	CPoint pos;
	CPoint sz;

	int adjust = (int)((float)BORDER_WIDTH * dCurrentZoom);

	pos.x = (int)((float)(Position.x-BORDER_WIDTH) * dCurrentZoom);
	pos.y = (int)((float)(Position.y+BORDER_WIDTH) * dCurrentZoom);
	sz.x = (int)((float)(Size.x+(BORDER_WIDTH*2)) * dCurrentZoom);
	sz.y = (int)((float)(Size.y-(BORDER_WIDTH*2)) * dCurrentZoom);

	if( (point.x >= pos.x) &&
		(point.y <= pos.y) &&
		(point.x <= (pos.x + sz.x)) &&
		(point.y >= (pos.y + sz.y)))
	{
		// Check all the handles here, and return corresponding define
		int ho, i;
		int return_value = 0;
		
		for( ho = BBOX_HANDLE_MIN, i = 0; ho <= BBOX_HANDLE_MAX; ++ho, ++i){
			switch(ho){

				case BBOX_CORNER_TOP_LEFT:
					TmpPos = Position;
					TmpPos.x += HandleOffsets[i].x - adjust;
					TmpPos.y += HandleOffsets[i].y + adjust;
					return_value = ho;
				break;

				case BBOX_CORNER_TOP_RIGHT:
					TmpPos = Position;
					TmpPos.x += Size.x + HandleOffsets[i].x + adjust;
					TmpPos.y += HandleOffsets[i].y + adjust;
					return_value = ho;
				break;

				case BBOX_CORNER_BOTTOM_RIGHT:
					TmpPos = Position;
					TmpPos.x += Size.x + HandleOffsets[i].x + adjust;
					TmpPos.y += HandleOffsets[i].y + Size.y - adjust;
					return_value = ho;
				break;

				case BBOX_CORNER_BOTTOM_LEFT:
					TmpPos = Position;
					TmpPos.y += Size.y + HandleOffsets[i].y - adjust;
					TmpPos.x += HandleOffsets[i].x - adjust;
					return_value = ho;
				break;

				case BBOX_CENTER_TOP:
					TmpPos = Position;
					TmpPos.x += (Size.x / 2) + HandleOffsets[i].x;
					TmpPos.y += HandleOffsets[i].y + adjust;
					return_value = ho;
				break;

				case BBOX_CENTER_RIGHT:
					TmpPos = Position;
					TmpPos.x += Size.x + HandleOffsets[i].x + adjust;
					TmpPos.y += (Size.y / 2) + HandleOffsets[i].y;
					return_value = ho;
				break;

				case BBOX_CENTER_BOTTOM:
					TmpPos = Position;
					TmpPos.x += (Size.x / 2) + HandleOffsets[i].x;
					TmpPos.y += Size.y + HandleOffsets[i].y - adjust;
					return_value = ho;
				break;

				case BBOX_CENTER_LEFT:
					TmpPos = Position;
					TmpPos.y += (Size.y / 2) + HandleOffsets[i].y;
					TmpPos.x += HandleOffsets[i].x - adjust;
					return_value = ho;
				break;

				default:
					TmpPos.x = BBOX_HANDLE_BBOX;
					TmpPos.y = BBOX_HANDLE_BBOX;
					return TmpPos;
				break;

			}

			// Adjust the temp pos to zoom 
			TmpPos.x = (int)((float)TmpPos.x * dCurrentZoom);
			TmpPos.y = (int)((float)TmpPos.y * dCurrentZoom);
			int nRadius = (int)((float)HandleRadius * dCurrentZoom);

			if( return_value != 0) {
				if( abs(point.x - TmpPos.x) <= nRadius &&
					abs(point.y - TmpPos.y) <= nRadius ) {

					TmpPos.x = return_value;
					TmpPos.y = return_value;
					return TmpPos;
				}
        	}
		}
	}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::WhatIsAtPoint: %d", status); 
	#endif

    /// For ART boxes, just always show the move cursor
	if (this->Message(BBOX_ITEM_WHATAMI, 0, status) == ITEM_ART_TYPE) {
		TmpPos.x = BBOX_HANDLE_BBOX;
		TmpPos.y = BBOX_HANDLE_BBOX;
	}
	else {	// for text boxes
		// Now see if we're in the border area, which would be a move operation.
		if (abs(point.x - pos.x) <= BORDER_WIDTH ||
			abs(point.x - (pos.x + sz.x)) <= BORDER_WIDTH ||
			abs(point.y - pos.y) <= BORDER_WIDTH ||
			abs(point.y - (pos.y + sz.y)) <= BORDER_WIDTH)
		{
			TmpPos.x = BBOX_HANDLE_BBOX;
			TmpPos.y = BBOX_HANDLE_BBOX;
		}
		else
		{
			TmpPos.x = BBOX_HANDLE_TEXTMODE;
			TmpPos.y = BBOX_HANDLE_TEXTMODE;
		}

	}
	return TmpPos;
}


CPoint
BBox::GetHandlePoint(int adjust, int handle, int *status)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER BBox::GetHandlePoint(int,int*)"); 
	#endif
	status;	/* get rid of compiler warning */
    
	int nRadiusSz = (int)HandleRadius;
    
	switch(handle) {

		case BBOX_CORNER_TOP_LEFT:
			TmpPos = Position;
			TmpPos.x += HandleOffsets[0].x - adjust;
			TmpPos.y += HandleOffsets[0].y + adjust;
		break;

		case BBOX_CORNER_TOP_RIGHT:
			TmpPos = Position;
			TmpPos.x += Size.x + HandleOffsets[1].x + adjust + nRadiusSz;
			TmpPos.y += HandleOffsets[1].y + adjust ;
		break;

		case BBOX_CORNER_BOTTOM_RIGHT:
			TmpPos = Position;
			TmpPos.x += Size.x + HandleOffsets[2].x + adjust + nRadiusSz;
			TmpPos.y += Size.y + HandleOffsets[2].y - adjust - nRadiusSz;
		break;

		case BBOX_CORNER_BOTTOM_LEFT:
			TmpPos = Position;
			TmpPos.x += HandleOffsets[3].x - adjust;
			TmpPos.y += Size.y + HandleOffsets[3].y - adjust - nRadiusSz;
		break;

 		case BBOX_CENTER_TOP:
			TmpPos = Position;
			TmpPos.x += (Size.x / 2) + HandleOffsets[4].x;
			TmpPos.y += HandleOffsets[4].y + adjust;
 		break;

		case BBOX_CENTER_RIGHT:
			TmpPos = Position;
			TmpPos.x += Size.x + HandleOffsets[5].x + adjust + nRadiusSz;
			TmpPos.y += (Size.y / 2) + HandleOffsets[5].y;
		break;

		case BBOX_CENTER_BOTTOM:
			TmpPos = Position;
			TmpPos.x += (Size.x / 2) + HandleOffsets[6].x;
			TmpPos.y += Size.y + HandleOffsets[6].y - adjust - nRadiusSz;
		break;

		case BBOX_CENTER_LEFT:
			TmpPos = Position;
			TmpPos.y += (Size.y / 2) + HandleOffsets[7].y;
			TmpPos.x += HandleOffsets[7].x - adjust;
		break;

		default:
			TmpPos.x = BBOX_HANDLE_BBOX;
			TmpPos.y = BBOX_HANDLE_BBOX;
		break;
	}
    
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT BBox::GetHandlePoint: %d", status); 
	#endif

	TmpPos.x = (int)((float)TmpPos.x * dCurrentZoom);
	TmpPos.y = (int)((float)TmpPos.y * dCurrentZoom);
	return TmpPos;
}

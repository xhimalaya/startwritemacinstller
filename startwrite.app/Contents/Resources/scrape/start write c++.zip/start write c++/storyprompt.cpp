// storyprompt.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "storyprompt.h"


// CStoryPrompt dialog

IMPLEMENT_DYNAMIC(CStoryPrompt, CDialog)

CStoryPrompt::CStoryPrompt(CWnd* pParent /*=NULL*/)
	: CDialog(CStoryPrompt::IDD, pParent)
{
	m_nTimesFlashed = 0;
	m_nTimerID = 1;
    m_pBkBrush = new CBrush(STORYPROMPT_BG_COLOR);
}

CStoryPrompt::~CStoryPrompt()
{
	delete m_pBkBrush;
}

void CStoryPrompt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CStoryPrompt, CDialog)
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_SHOWWINDOW()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CStoryPrompt message handlers

void CStoryPrompt::OnTimer(UINT_PTR nIDEvent)
{
	nIDEvent;
	++m_nTimesFlashed;
	if (m_nTimesFlashed < MAX_FLASHES) {
		CStatic * text = ((CStatic *)GetDlgItem(IDC_STATICPROMPT));
		if (text->IsWindowVisible()) {
			text->ShowWindow(SW_HIDE);
		}
		else {
			text->ShowWindow(SW_SHOW);
		}
	}
	else {
		this->ShowWindow(SW_HIDE);
	}

	//CDialog::OnTimer(nIDEvent);
}

int CStoryPrompt::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_nTimesFlashed = 0;
	m_nTimerID = 1;

	return 0;
}

void CStoryPrompt::OnLButtonDown(UINT nFlags, CPoint point)
{
	CDialog::OnLButtonDown(nFlags, point);
	this->ShowWindow(SW_HIDE);
}

void CStoryPrompt::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	CRect rc;
	GetClientRect(&rc);
	dc.FillSolidRect(rc,STORYPROMPT_BG_COLOR);

	// Do not call CDialog::OnPaint() for painting messages
}

void CStoryPrompt::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);

   // Set timer to cause dialog to flash
	m_nTimesFlashed = 0;
	if (bShow) {
		m_nTimesFlashed = 0;
		m_nTimerID = this->SetTimer(1, 500, NULL);
		MessageBeep(MB_ICONASTERISK);
	}
	else {
		m_nTimesFlashed = MAX_FLASHES;
		this->KillTimer(m_nTimerID);
	}
}

HBRUSH CStoryPrompt::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// Change any attributes of the DC here
	pDC->SetTextColor(RGB(0, 0, 0));
	pDC->SetBkColor(STORYPROMPT_BG_COLOR);

	// Return a different background brush if the default is not desired
	return (HBRUSH)(m_pBkBrush->GetSafeHandle());
}

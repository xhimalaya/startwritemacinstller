#pragma once
#include "afxwin.h"
#include "colorcombo.h"


// CColorLettersDlg dialog

class CColorLettersDlg : public CDialog
{
	DECLARE_DYNAMIC(CColorLettersDlg)

public:
	CColorLettersDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CColorLettersDlg();

	COLORREF m_crFirst;
	COLORREF m_crSecond;
	COLORREF m_crThird;
	COLORREF m_crFourth;
	COLORREF * m_pCustomColors;

	BBox *m_pBox;
	TextItem *m_pTextItem;
	CRect m_rectPreview, m_rectBox;

// Dialog Data
	enum { IDD = IDD_COLORLETTERS };

protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()
protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
public:
	afx_msg void OnParentNotify(UINT message, LPARAM lParam);
private:
	CColorCombo m_ColorComboFirst;
	CColorCombo m_ColorComboSecond;
	CColorCombo m_ColorComboThird;
	CColorCombo m_ColorComboFourth;

public:
	bool m_SetAsDefault;
	afx_msg void OnBnClickedSetColorlinesDefault();
};

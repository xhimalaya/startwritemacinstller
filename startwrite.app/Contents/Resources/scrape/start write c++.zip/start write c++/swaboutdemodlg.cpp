// swAboutDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include <stdio.h>
#include "sw.h"
#include "resource.h"
#include "swAboutDemoDlg.h"
#include "swregister.h"
#include "artdisp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoAboutDlg dialog


CDemoAboutDlg::CDemoAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDemoAboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDemoAboutDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDemoAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDemoAboutDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDemoAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CDemoAboutDlg)
	ON_BN_CLICKED(IDC_ACTIVATE, OnActivate)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CDemoAboutDlg::OnBnClickedPurchase)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoAboutDlg message handlers
extern void doRegister(int is50Reg);

BOOL CDemoAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CString SetLicenseInfo();

	CWnd	*pChild = GetDlgItem(IDS_SPLASH);
	pChild->GetClientRect(&m_rectSplash);
	pChild->MapWindowPoints(this, &m_rectSplash); 

	if (*swType == swOXD) {
		/* turn off the activate button */
		CWnd	*pChildButton = GetDlgItem(IDC_ACTIVATE);
		pChildButton->DestroyWindow();
	}

	CString strAbout, strAbout2;
	if (*swType == swDEM) { 
		if (theApp.m_isDemo == DEMO_ON) {
			strAbout.LoadString(IDS_ABOUT_DEMO_POST);	// In disabled demo mode
			strAbout2.LoadString(IDS_ABOUT_STR2_DEMO);	
		}
		else {	// In Full Demo, 
			char tbuf[8];
			strAbout.LoadString(IDS_ABOUT_STRING_DEMO);	
			if (theApp.m_daysLeft < 0) {
				theApp.m_daysLeft =0;
			}
			_snprintf_s(tbuf, sizeof(tbuf), _TRUNCATE,"%d", theApp.m_daysLeft);
			strAbout += tbuf;
			strAbout2.LoadString(IDS_ABOUT_STR2_DEMO);	

		}
	}
	else {
		strAbout.LoadString(IDS_ABOUT_STRING);		// Regular Startwrite, Inc About
		strAbout2 = SetLicenseInfo();
	}

	//SetDlgItemText(IDS_ABOUT_STRING, strAbout);
	//SetDlgItemText(IDS_ABOUT_STR2, strAbout2);

	// now paint the graphics in the the dialog
	CPoint pos = CPoint(m_rectSplash.left,m_rectSplash.top);
	CPoint size = CPoint(m_rectSplash.right-m_rectSplash.left, m_rectSplash.bottom - m_rectSplash.top);
	CString dummy = "";

	artDisplay(m_hWnd, ABOUTVIEW1, ABOUTBUF1, pos, size, SWA_FLUSH|SWA_RESOURCE, theApp.m_splashStr, 0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CDemoAboutDlg::OnActivate() 
{
	doRegister(1);
	EndDialog(0);	// bring down the about dialog here.
}

CString SetLicenseInfo()
{
	char email[128];
	char fullname[128];
	char keyval[50]={0};
	char tmpbuf[256];
	int flag;
	bool serialFound=false;

	if (theApp.m_isDemo == DEMO_RELEASE) {
		_snprintf_s((char *)tmpbuf, sizeof(tmpbuf), _TRUNCATE,"Limited Version of Startwrite.\nWaiting for valid Registration.  Serial Number has not been entered\nPlease enter by clicking on 'Enter Serial Number'"); 
	}
	else {
		if (*swType == swREL) {
			if (theApp.GetSerialNumber(keyval) != 0) {
				lstrcpyn(keyval, "NotFound", sizeof(keyval));
			}
			else {
				serialFound = true;
			}
			_snprintf_s((char *)tmpbuf, sizeof(tmpbuf), _TRUNCATE,"Full Version of Startwrite.\nSerial Number %s\nAny unauthorized use is a violation of the license agreement.", keyval); 
		}
		if (serialFound == false) {
			theApp.GetRegistration(email, fullname, keyval, &flag, true);

			if ((keyval[0] != '\0') || ((*swType != swREL) && (*swType != swRL5) && (*swType != swSHR) && (*swType != swOXF) && (*swType != swNAC) && (*swType != swNAU))) {
				if (fullname[0] == '\0') {
					strcpy_s(fullname, sizeof(fullname),"UNKNOWN");
				}
				if (email[0] == '\0') {
					strcpy_s(email, sizeof(email),"UNKNOWN");
				}
				if (keyval[0] == '\0') {
					strcpy_s(keyval, sizeof(keyval),"UNKNOWN");
				}
				_snprintf_s((char *)tmpbuf, sizeof(tmpbuf), _TRUNCATE,
				"This Program Licensed to: %s (%s)\nActivation Key: %s\nAny other unauthorized use is a violation of the license agreement.", 
				fullname, email,keyval);
			}
			else {
				_snprintf_s((char *)tmpbuf, sizeof(tmpbuf), _TRUNCATE,"Full Version of Startwrite.\nAny unauthorized use is a violation of the license agreement."); 
			}
		}
	}
	return((CString)tmpbuf);
}

void CDemoAboutDlg::OnBnClickedPurchase()
{
	HINSTANCE retv;

	retv = ShellExecute(NULL, NULL, "http://www.startwrite.com/purchase_version.php", NULL, NULL, SW_SHOWNORMAL);
	if (retv == NULL) {
		AfxMessageBox("Problem opening browser. Go to http://www.startwrite.com/purchase_version.php");
	}
}

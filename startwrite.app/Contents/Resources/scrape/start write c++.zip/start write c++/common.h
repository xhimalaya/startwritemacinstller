// TrueType Common Header

#ifndef _COMMON_H_
#define _COMMON_H_

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

// Level 1 debug is entry and exit info
//#define DEBUG_ENTER
//#define DEBUG_EXIT
//#define DEBUG_TT

#define OK		1
#define ERROR	0

// for string compares
#define S1_EQUALS_S2 0

void myswab( unsigned char *ptr, int bytes);

//wrw unsigned char *copy_short( unsigned char *src, short *dest);
//wrw unsigned char *copy_ushort( unsigned char *src, unsigned short *dest);
//wrw unsigned char *copy_byte2short( unsigned char *src, short *dest);
//wrw unsigned char *copy_byte2ushort( unsigned char *src, unsigned short *dest);


#endif // _COMMON_H_
// Glyph Table Header

#ifndef _GLYF_TABLE_H_
#define _GLYF_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"
#include "Dir.h"
#include "Cmap.h"
#include "Head.h"
#include "Loca.h"

#include "GlyfData.h"

class GlyfTable
{
	private:

	unsigned char* Data;
	
	public:
	
		GlyfTable( HeadTable *head);
		~GlyfTable();
		int GetGlyf( GlyfData* glyfdata, fstream *fin, 
					DirectoryTable *dir, CMapTable *cmap, 
					LocaTable *loca, unsigned short *c);

		int ReadGlyf( GlyfData* glyfdata, unsigned char *cpraw);
		
		int 	Read(fstream *fin, DirectoryTable *dir);		
		
		int 	Print();
};

#endif // _GLYF_TABLE_H_
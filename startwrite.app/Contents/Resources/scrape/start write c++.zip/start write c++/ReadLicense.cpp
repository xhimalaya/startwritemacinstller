// ReadLicense.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "ReadLicense.h"

// CReadLicense dialog

IMPLEMENT_DYNAMIC(CReadLicense, CDialog)

CReadLicense::CReadLicense(CWnd* pParent /*=NULL*/)
	: CDialog(CReadLicense::IDD, pParent)
{
	int whichLicense;
	int retv;
	m_LicenseText = _T("");

	if (theApp.isNetwork)
		whichLicense = IDR_LICENSE3;
	else if (theApp.isLabPack)
		whichLicense = IDR_LICENSE2;
	else if (theApp.isCorporateVersion) 
		whichLicense = IDR_LICENSE4;
	else 
		whichLicense = IDR_LICENSE1;

	HRSRC hResInfo = FindResource( AfxGetResourceHandle(), MAKEINTRESOURCE(whichLicense), "license");
	if (hResInfo != NULL) {
		HGLOBAL hGlobal = LoadResource( AfxGetInstanceHandle(), hResInfo);
		if (hGlobal != NULL) {
			m_LicenseText = (char *) LockResource(hGlobal);
		}
		else {
			m_LicenseText = "License text not available.  Contact Startwrite for information";
		}
	}
	else {
		retv =  GetLastError();
		m_LicenseText = "License text not available.  Contact Startwrite for information";
	}
}

CReadLicense::~CReadLicense()
{
}

void CReadLicense::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_LICENSE, m_LicenseWindow);
	DDX_Text(pDX, IDC_EDIT_LICENSE, m_LicenseText);

}


BEGIN_MESSAGE_MAP(CReadLicense, CDialog)
END_MESSAGE_MAP()


// CReadLicense message handlers

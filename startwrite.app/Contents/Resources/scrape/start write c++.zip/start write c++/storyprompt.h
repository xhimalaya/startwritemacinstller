#pragma once


// CStoryPrompt dialog

class CStoryPrompt : public CDialog
{
	DECLARE_DYNAMIC(CStoryPrompt)

public:
	CStoryPrompt(CWnd* pParent = NULL);   // standard constructor
	virtual ~CStoryPrompt();

// Dialog Data
	enum { IDD = IDD_STORYPROMPT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

private:
	int m_nTimesFlashed;
	int m_nTimerID;
	CBrush *m_pBkBrush;

#define MAX_FLASHES 6
#define STORYPROMPT_BG_COLOR RGB(255, 255, 0)

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};

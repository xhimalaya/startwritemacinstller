// fontdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFontDlg dialog
#include "mainfrm.h" // for the font combo

class CFontDlg : public CDialog
{
// Construction
public:
	CFontDlg(CWnd* pParent = NULL);	// standard constructor
	~CFontDlg();

// Dialog Data
	//{{AFX_DATA(CFontDlg)
	enum { IDD = IDD_FONT };
	CFontComboBox	m_ctlFonts;
	CComboBox	m_ctlSizes;
	//}}AFX_DATA
	
	CString m_strFont;
	int m_nSize;
	int m_nFontIndex;
	int m_setAsDefault;
	int m_fontLines;
	COLORREF * m_pCustomColors;
	bool m_showGuidelinesButton;

	BBox 		*m_pBox;
	TextItem	*m_pTextItem;
	CRect		m_rectPreview,
				m_rectBox;
	
protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void UpdateTextItem();
	void DrawTextItem(CDC *pDC = NULL);

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CFontDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnPaint();
	afx_msg void OnSelchangeFonts();
	afx_msg void OnEditupdateSizes();
	afx_msg void OnSelchangeSizes();
	afx_msg void OnFontdefault();
	afx_msg void OnEditLedger();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

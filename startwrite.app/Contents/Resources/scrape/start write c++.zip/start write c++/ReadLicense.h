#pragma once
#include "afxwin.h"
#include "resource.h"

// CReadLicense dialog

class CReadLicense : public CDialog
{
	DECLARE_DYNAMIC(CReadLicense)

public:
	CReadLicense(CWnd* pParent = NULL);   // standard constructor
	virtual ~CReadLicense();

// Dialog Data
	enum { IDD = IDD_READ_LICENSE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_LicenseWindow;
	CString m_LicenseText;
};

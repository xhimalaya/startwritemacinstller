// Bar related info

#ifndef _BAR_INFO_H_
#define _BAR_INFO_H_

// Index of button in power bar
#define D2D_DENSITY_BUTTON	7
#define D2D_SHADE_BUTTON	8
#define D2D_LINES_BUTTON	9
#define D2D_ARROWS_BUTTON	10

// Location of images in powerbar.bmp (beginning at image 0)
#define D2D_BASE_IMAGE		8
#define D2D_DENSITY_IMAGE	D2D_BASE_IMAGE
#define D2D_SHADE_IMAGE		D2D_BASE_IMAGE+6
#define D2D_LINES_IMAGE		D2D_BASE_IMAGE+12
#define D2D_ARROWS_IMAGE	D2D_BASE_IMAGE+17

#endif // _BAR_INFO_H_

// specialcharsdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpecialCharsDlg dialog
#include "mainfrm.h" // for the font combo
#include "specialcharsitem.h"
#include "afxwin.h"

class CSpecialCharsDlg : public CDialog
{
// Construction
public:
	CSpecialCharsDlg(CWnd* pParent = NULL);	// standard constructor
	~CSpecialCharsDlg();

// Dialog Data
	//{{AFX_DATA(CSpecialCharsDlg)
	enum { IDD = IDD_SPECIALCHARS };
	//}}AFX_DATA
#define GRID_ROWS_MAX 19
	
	CString m_strFont;
	int m_nSize;
	int m_nFontIndex;

	int m_nGridCellWidth;
	int m_nGridCellHeight;
	int m_nGridWidth;
	int m_nGridHeight;
	int m_nGridCols;
	int m_nGridRows;

	int m_nCharIndexPrevious;
	int m_nCharIndexCurrent;

	BBox 		*m_pBox;
	SpecialCharsItem	*m_pSpecialCharsItem;
	TextItem	*m_pTextItem;
	CSwView *m_pView;
	CRect		m_rectPreview,
				m_rectBox;

	RECT m_rectChar[SHAPES_MAX];
	
protected:
	void InitPreview();
	void PrepareDC(CDC *pDC);
	void DrawSpecialCharsItem(CDC *pDC = NULL);
	void DrawSpecialCharsGrid(CDC *pDC = NULL);

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CSpecialCharsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	CButton m_buttonInsert;
	afx_msg void OnBnClickedButtonInsert();
};

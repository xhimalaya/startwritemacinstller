/** Art Graphic Display and Print Management **/
/** ArtDisp.cpp **/

#include "stdafx.h"
#include "imagn.h"
#include "artdisp.h"
#include "windows.h"
#include "miscutil.h"


long artDisplay(HWND hWndPtr, long ViewId, long BufId, CPoint pos, CPoint size, 
						long flag, CString artpath, int artResource)
{	
	long retval;
	unsigned long dispFlag=0;
	char string[128];
	static int inHere=0;

	inHere = 1;	//stop the crash

	if (inHere) {
		return -1;
	}
	inHere++;

	if (!(flag & SWA_RESOURCE)) {
		dispFlag += USE_TWIPS;
		dispFlag += VIEW_PROGRESSIVE;
	}

	CPoint newSize = size;
	CPoint newPos = pos;

//	newPos.x = pos.x + 150;
//	newPos.y = pos.y + 150;
//	newSize.x = size.x - 300;
//	newSize.y = size.y - 300;
	try {
	retval = IM_DeleteView(ViewId);	// Delete the memory for this view

	retval = IM_DefineView(hWndPtr, ViewId, (BufId & SWA_MASK),	newPos.x, newPos.y, newSize.x, newSize.y, dispFlag);
	if (flag & SWA_FILL) {
		IM_SetViewScale(ViewId, -2);
	}
	else {
		IM_SetViewScale(ViewId, 0);
	}


	if (!retval) {
		if (BufId & SWA_LOADED) {
			retval = 0;		// Don't need to load again.  It is in memory already
		}
		else if (flag & SWA_FLUSH) {		
			retval = IM_Load(BufId, (const char*)artpath.GetBuffer());
			if (retval) {
				_snprintf_s(string, sizeof(string),sizeof(string), "IM_Load Failed (%d) %s",retval, artpath);
			}
		}
		else if (flag & SWA_RESOURCE) {
			retval = IM_LoadRes(BufId, AfxGetResourceHandle(), MAKEINTRESOURCE(artResource), RT_BITMAP);
			if (retval) {
				_snprintf_s(string,sizeof(string),sizeof(string), "Load Res Failed (%d)",retval);
			}
			
		} else {			
			retval = IM_DefineImage(BufId, artpath);
			if (retval) {
				_snprintf_s(string,sizeof(string),sizeof(string), "Define Image2 Failed (%d)",retval);
			}
		}
		if (!retval || (retval == ERR_IN_PROGRESS)) {
			retval = 0;
		}
		else {
			retval = 1;
		}
	}
	else {
		_snprintf_s(string,sizeof(string),sizeof(string), "%d Define View Failed (%d)",retval, retval);
		retval = 1;
	}

	if (retval && !(flag & SWA_RESOURCE)) {
		AfxMessageBox(string);		// show message if not a splash screen error
	}

	} catch(...) {
		TRACE("ART EXCPETION");
	}
	inHere--;
	return (retval);
}


long artPrint(CDC *pDC, long BufId, CPoint pos, CPoint size, long flag, CString artpath)
{
	RECT vRect;
	unsigned long retval=0;
	
	long pFlag = flag & SWA_FILL ? 16 : 0;	// print to fill box if necessary

	// First set the view area on the page
	vRect.left = pos.x;
	vRect.top = pos.y;
	vRect.right = pos.x + size.x;
	vRect.bottom = pos.y + size.y;

	// Reload the buffer
	if (!(BufId & SWA_LOADED)) {
		retval = IM_DefineImage(BufId, artpath);	// make sure the buffer is loaded
	}

	BufId &= SWA_MASK;	// remove load flag
	if (!retval || (retval == ERR_IN_PROGRESS)) {
		if (pFlag) {
			RECT prect;
			prect = vRect;
			prect.right -= 1;
			prect.bottom -= 1;
			retval = IM_PaintDCClip( pDC->m_hDC, BufId, &vRect, NULL, NULL, pFlag, &prect);
		}
		else {
			retval = IM_PaintDC( pDC->m_hDC, BufId, &vRect, NULL, NULL, 0);
		}
		if (retval == ERR_IN_PROGRESS) {
			retval = 0;
		}
	}
	
	return(retval);
}

void artFreeBuffer(long *BufId)
{
	*BufId = *BufId & SWA_MASK;	// remove loaded value
	IM_DefineImage(*BufId, NULL);
}

void artFreeView(long *ViewId)
{
	*ViewId = *ViewId & SWA_MASK;
	IM_DeleteView(*ViewId);
}

long borderArtDisplay(CDC *pDC, long BufId, CPoint pos, CPoint size, CString artpath, bool show, CPoint padsize, CPoint &imagesize)
{
	RECT vRect;
	unsigned long retval=0;
	long flag = SWA_FILL;
	long pFlag = flag & SWA_FILL ? 16 : 0;

	// First set the view area on the page
	vRect.left = pos.x;
	vRect.top = pos.y;
	vRect.right = pos.x + size.x + padsize.x;
	vRect.bottom = pos.y + size.y + padsize.y;

	// Reload the buffer
	if (!(BufId & SWA_LOADED)) {
		retval = IM_DefineImage(BufId, artpath);	// make sure the buffer is loaded
	}

	imagesize.x = IM_SizeX(BufId);
	imagesize.y = IM_SizeY(BufId);

	BufId &= SWA_MASK;	// remove load flag

	if (pDC != NULL && show) {
		if (!retval || (retval == ERR_IN_PROGRESS)) {
			retval = IM_PaintDC(pDC->m_hDC, BufId, &vRect, NULL, NULL, pFlag);
			if (retval == ERR_IN_PROGRESS) {
				retval = 0;
			}
		}
	}
	
	return(retval);
}

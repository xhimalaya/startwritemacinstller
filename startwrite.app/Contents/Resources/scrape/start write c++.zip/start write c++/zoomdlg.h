// zoomdlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CZoomDlg dialog

class CZoomDlg : public CDialog
{
// Construction
public:
	CZoomDlg(CWnd* pParent = NULL);	// standard constructor

	void EnableOther(BOOL bVal);

// Dialog Data
	//{{AFX_DATA(CZoomDlg)
	enum { IDD = IDD_ZOOM };
	int		m_iZoom;
	BOOL	m_DoDefZoom;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CZoomDlg)
	afx_msg void On100();
	afx_msg void On50();
	afx_msg void On75();
	afx_msg void OnOther();
	afx_msg void On125();
	afx_msg void On150();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
};

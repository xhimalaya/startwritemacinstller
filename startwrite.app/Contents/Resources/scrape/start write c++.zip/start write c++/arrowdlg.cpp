// arrowdlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "arrowdlg.h"

#include "miscutil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CArrowDlg dialog


CArrowDlg::CArrowDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CArrowDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CArrowDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

int iArrowIDs[] = {IDC_ARROWS_NORMAL, IDC_ARROWS_FIRST_LINE, 
							IDC_ARROWS_FIRST_WORD, IDC_ARROWS_ALTER_WORD, IDC_ARROWS_ALLFIRST_WORD};

void CArrowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CArrowDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
		GetRadioRowValue(m_hWnd, &m_iArrows, iArrowIDs, sizeof(iArrowIDs)/sizeof(int));
	else
		SetRadioRowValue(m_hWnd, m_iArrows, iArrowIDs, sizeof(iArrowIDs)/sizeof(int));
}

BEGIN_MESSAGE_MAP(CArrowDlg, CDialog)
	//{{AFX_MSG_MAP(CArrowDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CArrowDlg message handlers

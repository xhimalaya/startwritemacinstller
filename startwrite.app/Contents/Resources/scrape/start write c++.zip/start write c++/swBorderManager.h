// Startwrite Border File Management
// Created:  Dec 14, 2009
// Wayne Wylie
// 
//
//
///
// File Format:
// SW[0x01]WRW[0x01]BRDR[int count]
// [int Item#][int namelen][filename][int filesize][filedata]
// [int Item#][int namelen][filename][int filesize][filedata]
// [int Item#][int namelen][filename][int filesize][filedata]
// [int Item#][int namelen][filename][int filesize][filedata]
#include <fstream>
#include <map>
#include <vector>

typedef struct BorderListHeader
{
	char sw[2];
	char buf1;
	char wrw[3];
	char buf2;
	char brdr[4];
	int mainCount;
} BORDERLISTHEADER;

typedef struct BorderItem
{
	int itemID;
	int namelen;
	char filename[256];
	int filesize;
	char *filedata;
} BORDERITEM;

typedef struct FileNameSize {
	long position;
	long dataSize;
	char filename[96];
} FILENAMESIZE;



class SwBorderManagement
{
	private:
		BORDERLISTHEADER mainHeader;

		//std::fstream *borderFP; //(pszPathName, ios::_Nocreate| ios::in);
		//int iBorderCount;
		//std::vector<BORDERITEM> borderList;
		void LoadSingleFile(BORDERITEM &bItem);
		void resetMainFile();
		int currBorderIndex;
		FILE *iMasterFP;
		
		char BorderFileHeader[128];
		FILENAMESIZE fileListBuf[1000];
		int fileCount;
		long HeaderSize;
		long FileHeaderSize;
		long DataBeginLocation;

	public:
		SwBorderManagement(int Type);
		~SwBorderManagement();

		void SwBorderGetList();
		int SwBorderBuildFile();
		void AddToMainFile();
		int getNextItem(bool isFirst, CString &name);

	
};


#pragma once


// CColorDlg

class CColorDlg : public CColorDialog
{
	DECLARE_DYNAMIC(CColorDlg)

public:
	CColorDlg(COLORREF clrInit = 0, DWORD dwFlags = 0, CWnd* pParentWnd = NULL);
	virtual ~CColorDlg();
	CPoint m_pos;

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnDestroy();
	virtual BOOL OnInitDialog();
};



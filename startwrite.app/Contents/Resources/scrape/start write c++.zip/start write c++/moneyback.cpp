// MoneyBack.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "MoneyBack.h"

extern int CreateHashBuf(unsigned char *dest, char *ipptr, char *rnum, int versionFlag);

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMoneyBack dialog


CMoneyBack::CMoneyBack(CWnd* pParent /*=NULL*/)
	: CDialog(CMoneyBack::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMoneyBack)
	m_moneyBackCode = _T("");
	m_email = _T("");
	//}}AFX_DATA_INIT
}


void CMoneyBack::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMoneyBack)
	DDX_Text(pDX, IDC_DEACTIVATE_CODE, m_moneyBackCode);
	DDX_Text(pDX, IDC_EDIT2, m_email);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMoneyBack, CDialog)
	//{{AFX_MSG_MAP(CMoneyBack)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMoneyBack message handlers

void CMoneyBack::OnOK() 
{
	/*  Store the Money Back Code	*/
	CDialog::OnOK();
}

BOOL CMoneyBack::OnInitDialog() 
{
	FILE *fp;
	int flag;
	char email[128];
	char fullname[128];
	char keyval[128];
	unsigned char tbuf[256], sbuf[33], rbuf[12];

	CDialog::OnInitDialog();
	
	theApp.GetRegistration(email, fullname, keyval, &flag, true);
	if (*email == '\0')
		return TRUE;
#ifdef _CRT_SECURE_NO_DEPRECATE
	strcpy((char *)tbuf, email);
	strcpy((char *)rbuf, (char *)"9797");
#else
	strcpy_s((char *)tbuf,sizeof(email), email);
	strcpy_s((char *)rbuf,sizeof("9797"), (char *)"9797");
#endif

	CreateHashBuf(sbuf, (char *)tbuf, (char *)rbuf, 0);

	m_email = email;
	m_moneyBackCode = sbuf;
#ifdef _CRT_SECURE_NO_DEPRECATE
	strcpy(keyval, email);
	strcat(keyval, "\n");
	strcat(keyval, (char *)sbuf);
	strcat(keyval, "\n");
#else
	strcpy_s(keyval, sizeof(keyval),email);
	strcat_s(keyval, sizeof(keyval),"\n");
	strcat_s(keyval, sizeof(keyval),(char *)sbuf);
	strcat_s(keyval, sizeof(keyval),"\n");
#endif
	fopen_s(&fp,"MoneyBack.txt", "w");
	fwrite( keyval, 1, strlen(keyval), fp);
	fclose(fp);

	theApp.DoCancelProduct();
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// Name Table Header

#ifndef _NAME_TABLE_H_
#define _NAME_TABLE_H_

#include "TTCommon.h"
#include "TTTypes.h"

// Platform ID Defines
#define PlatformID_AppleUnicode 	0
#define PlatformID_Macintosh		1
#define	PlatformID_ISO				2
#define	PlatformID_Microsoft		3

class NameTable
{
	private:
	
	// Name Table
	struct
	{
		UShort	Format;				// Format selector
		UShort	NumRecords;			// Number of NameRecords that follow n
		UShort	StorageOffset;		// Offset to start of string storage (from start of table)
	} Table;

	// Name Record
	typedef struct NameRecord
	{
		UShort	PlatformID;			// Platform ID
		UShort	SpecificID;			// Platform-specific encoding ID
		UShort	LanguageID;			// Language ID
		UShort	NameID;				// Name ID
		UShort	StringLength;		// String length (in bytes)
		UShort	StringOffset;		// String offset from start of storage ares (in bytes)
	} NameRecord;

	NameRecord *Records;
	char *Data;
	
	// Code meanings from name id table
	char *Copyright;
	char *FontFamily;
	char *FontSubFamily;
	char *UniqeFontID;
	char *FullFontName;
	char *Version;
	char *PostscriptName;
	char *Trademark;
	
	void FreeMem();
	
	public:
	
		NameTable();
		~NameTable();

		int	GetNameIDInfo(unsigned short id, unsigned short spec, unsigned short lang);
		char *GetCopyright();
		char *GetFontFamily();
		char *GetFontSubfamily();
		char *GetUniqueFontID();
		char *GetFullFontName();
		char *GetVersion();
		char *GetPostscriptName();
		char *GetTrademark(); 		
		
		int 	Read(fstream *fin, DirectoryTable *dir);		
		int 	Print();
};

#endif // _NAME_TABLE_H_
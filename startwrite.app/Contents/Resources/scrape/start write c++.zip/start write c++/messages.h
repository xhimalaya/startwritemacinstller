// Messages for Derived Modules

// Application                     
#define BOX_SCOOT_DOWN_ALT		-21
#define BOX_SCOOT_UP_ALT		-20
#define BOX_SCOOT_LEFT_ALT		-19
#define BOX_SCOOT_RIGHT_ALT		-18
#define TEXT_CURSOR_GOTO_BEGIN	-17
#define TEXT_CURSOR_GOTO_END	-16
#define TEXT_CURSOR_WORDLEFT	-15
#define TEXT_CURSOR_WORDRIGHT	-14
#define TEXT_CURSOR_END			-13
#define TEXT_CURSOR_HOME		-12
#define TEXT_CURSOR_DELETE		-11
#define TEXT_CURSOR_LEFT		-10
#define TEXT_CURSOR_RIGHT		-9
#define TEXT_CURSOR_UP			-8
#define TEXT_CURSOR_DOWN		-7
#define BOX_SCOOT_DOWN			-6
#define BOX_SCOOT_UP			-5
#define BOX_SCOOT_LEFT			-4
#define BOX_SCOOT_RIGHT			-3

#define MOUSE_NONE				10

#define MOUSE_LBUTTON_DOWN		11
#define MOUSE_LBUTTON_UP		12

#define MOUSE_MOVE				13

#define TOOL_GET				14
#define TOOL_SET				15
#define TOOL_NONE				16
#define TOOL_TEXT_NEW			17
#define TOOL_BBOX_MOVE			18
#define TOOL_ART_NEW			19
#define TOOL_ABC_NEW			20
#define TOOL_TRASH				21
#define TOOL_TEXTSEL			22
#define MOUSE_LBUTTON_DOUBLE_CLICK	23

#define KEY_DOWN	24
#define KEY_DOWN_SPECIAL 25

#define SEL_OFF		50
#define SEL_MAYBE	51
#define SEL_ON		52

// Document

#define DOC_NONE				100

#define DOC_ZOOM_SET			101
#define DOC_ZOOM_GET			102

#define DOC_PAGE_FIRST			103
#define DOC_PAGE_PREVIOUS		104
#define DOC_PAGE_CURRENT		105
#define DOC_PAGE_NEXT			106
#define DOC_PAGE_LAST			107

#define	DOC_PAGE_NEW			108

#define DOC_PAGE_CURRENT_GET	109
#define DOC_PAGE_CURRENT_SET	110

#define DOC_PAGE_TOTAL_GET		111

#define DOC_EXTENT_GET			112

#define DOC_ITEM_COPY			113
#define DOC_ITEM_PASTE			114

#define DOC_PAGE_DELETE			115
#define DOC_PAGE_DELALL			116
#define DOC_SET_DONTDRAW		117

#define DOC_STORY_PUSH_TEXT		118
#define DOC_STORY_COLLECT		119
#define DOC_STORY_GET_MOVEPOINT	120

// Page

#define	PAGE_NONE					200

#define PAGE_PAPER_LETTER			201
#define PAGE_PIXELS_GET				202

#define PAGE_ORIENTATION_GET		203
#define PAGE_ORIENTATION_SET		204
#define PAGE_ORIENTATION_ROTATE		205

#define PAGE_ORIENTATION_PORTRAIT	206
#define PAGE_ORIENTATION_LANDSCAPE	207

#define PAGE_BBOX_NEW				208

#define PAGE_PIXELS_MAX_GET			209

#define PAGE_CHANGE_PAPER			210
#define PAGE_CHANGE_ORIENTATION		211

#define PAGE_NEW_TEXTBOX			220
#define PAGE_NEW_ARTBOX				221
#define PAGE_SET_ZOOM				222
#define PAGE_UPDATE_OVERLAP			223

#define PAGE_ACTIVATED				250
// Bounding Box

#define BBOX_NONE					300

//#define BBOX_SELECT					301
//#define BBOX_DESELECT				302

#define BBOX_LAYER_SET				303

#define BBOX_POSITION_GET			304
#define BBOX_POSITION_SET			305

#define BBOX_SIZE_GET				306
#define BBOX_SIZE_SET				307

#define BBOX_IS_AT_POINT			308
#define BBOX_IS_OVERLAPPING			309
                         
#define BBOX_STATE_ERROR			310
#define BBOX_STATE_HILITE			311
#define	BBOX_STATE_NORMAL			312
#define BBOX_STATE_SELECT			313
#define BBOX_STATE_OPEN				314

#define BBOX_STATE_GET				315
#define BBOX_STATE_SET				316

#define BBOX_VISIBLE_SET			317
#define BBOX_VISIBLE_GET			318

#define BBOX_ITEM_SET				319

#define BBOX_HANDLE_MIN				320
#define BBOX_CORNER_MIN				320
// This must be in order with increments of 1
#define BBOX_CORNER_TOP_LEFT		320
#define BBOX_CORNER_TOP_RIGHT		321
#define BBOX_CORNER_BOTTOM_RIGHT	322
#define BBOX_CORNER_BOTTOM_LEFT		323
#define BBOX_CORNER_MAX				323
// This must be in order with increments of 1
#define BBOX_CENTER_MIN				324                                             
#define BBOX_CENTER_TOP				324
#define BBOX_CENTER_RIGHT			325
#define BBOX_CENTER_BOTTOM			326
#define BBOX_CENTER_LEFT			327
#define BBOX_CENTER_MAX				327
#define BBOX_HANDLE_MAX				327
#define BBOX_HANDLE_NONE			328
#define BBOX_HANDLE_BBOX			329 
#define BBOX_WHAT_IS_AT_POINT		330
#define BBOX_CORNER_POINT_GET		331
#define BBOX_SCROLL_OFFSET_SET		332
#define BBOX_WARNING_SET			333
#define BBOX_MAX_XY_SET				334
#define BBOX_SELECTION_SET			335
#define BBOX_HANDLE_TEXTMODE		350
#define BBOX_SET_ZOOM				351
#define BBOX_SET_FRAME				352
#define BBOX_CAN_GROW				353
#define BBOX_SET_GROW				354
#define BBOX_MAX_XY_GET				355
#define BBOX_FRAME_NONE	1
#define BBOX_FRAME_SINGLE_1		2
#define BBOX_FRAME_SINGLE_2		3
#define BBOX_FRAME_SINGLE_3		4
#define BBOX_FRAME_SINGLE_6		5
#define BBOX_FRAME_DOUBLE_1		6
#define BBOX_FRAME_DOUBLE_2		7
#define BBOX_FRAME_DOUBLE_3		8
#define BBOX_FRAME_DOUBLE_6		9
#define BBOX_FRAME_GRAPHIC_01	10

// Items...

#define ITEM_NONE					400
#define ITEM_DIALOG_EDIT			401
#define ITEM_PARENT_SET				402
#define ITEM_ENTER_EDIT_MODE		403
#define ITEM_EXIT_EDIT_MODE			404

// Added in no oder for demo...
#define DOC_GET_INVALIDATE_POS		405
#define DOC_GET_INVALIDATE_SIZE		406
#define GET_ITEM_FOR_REDRAW			407
#define GET_BBOX_SELECTED			407

#define DELETE_SELECTED_ITEM		408
#define ITEM_USE_TOOLS				409
#define SPELL_SELECTED_ITEM			410

#define ITEM_RETURN_COPY			411
#define COPY_AND_PASTE_THIS_BOX		412
#define	TEXTITEM_GET_LINEHEIGHT		413
#define BBOX_ITEM_WHATAMI			414
#define ART_GET_PROPORTIONAL_SET	415
#define ART_SET_PROPORTIONAL		416
#define TEXT_SET_SCROLL_POS			417
#define TEXT_GET_CURSOR_POS			418
#define TEXT_SET_ZOOM				419
#define TEXT_SET_SELECTION			420
#define TEXT_SELECTION_OFF			421
#define TEXT_DOCOPY					422
#define TEXT_DOCUT					423
#define TEXT_DOPASTE				424
#define ART_SET_RELOAD				425
#define ART_SET_SCROLL				426
#define ART_CLEAR_IMAGE				427
#define TEXT_GET_KERNING			428
#define TEXT_SET_KERNING			429
#define TEXT_SET_DZOOM				430
#define TEXT_SET_ORIENTATION		431
#define TEXT_SET_SPACE_WIDTH		432
#define TEXT_UNDO					433
#define TEXT_DO_BORDER_ART_DLG		434
#define TEXT_SET_BORDER_ART			435
#define TEXT_SET_BORDER_ART_SCROLL	436
#define BBOX_CENTER_HORIZONTAL		437
#define BBOX_CENTER_VERTICAL		438
#define BBOX_CENTER_ON_PAGE			439
#define TEXT_IS_OVERFULL			440
#define TEXT_SET_STORY_INCLUDE		441
#define TEXT_SET_STORY_ITEM_ORDER	442
#define ART_SET_OVERLAPPED			443
#define ART_GET_OVERLAPPED			444
#define STATUS_CAPTURE_MOUSE		500
/*
#define TEXT_ITEM_D2D_SHADE1		1
#define	TEXT_ITEM_D2D_SHADE2		2
#define TEXT_ITEM_D2D_SHADE3		3
#define TEXT_ITEM_D2D_SHADE4		4
*/

#define TEXT_DRAW_ALL         	OK
#define TEXT_DRAW_CURSOR_LINE	2
#define TEXT_DRAW_CURSOR		3
#define TEXT_DRAW_CHAR			4
#define TEXT_DRAW_CURSOR_LINE1	5 
#define TEXT_DRAW_FROM_CURSOR	6
#define TEXT_DRAW_NOTHING		7
#define TEXT_DRAW_SELECTION		8
#define TEXT_DRAW_CURRENT		9
#define TEXT_DRAW_OLD_NEW		10
#define TEXT_DRAW_ALL_AGAIN		11
#define TEXT_EXTEND_SELECTION	12
#define TEXT_NO_TEXT_COPY		13
#define ITEM_TEXT_TYPE				101
#define ITEM_ART_TYPE				102 

// Name Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Name.h"
 
#include <stdio.h>
 
NameTable::NameTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER NameTable::NameTable()"); 
	#endif
	
	// Code meanings from name id table
	Copyright = NULL;
	FontFamily = NULL;
	FontSubFamily = NULL;
	UniqeFontID = NULL;
	FullFontName = NULL;
	Version = NULL;
	PostscriptName = NULL;
	Trademark = NULL;

	Data = NULL;
	Records = NULL;
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT NameTable::NameTable"); 
	#endif
}

NameTable::~NameTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER NameTable::~NameTable()"); 
	#endif

	FreeMem();
	// malloc #1
	//if( Data != NULL) { free(Data);}

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT NameTable::~NameTable"); 
	#endif
}

void NameTable::FreeMem()
{
	if (Data)
	{
		free(Data);
		Data = NULL;
	}
	
	if (Records)
	{
		free(Records);
		Records = NULL;
	}
}

int
NameTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER NameTable::Read(ifstream,DirectoryTable*)"); 
	#endif
	
	// Read name table
	
	// Check for existence of name table
	if( !dir->GetTag("name"))
	{
		Report( TO_LIST, "ERROR NameTable::Read: Unable to GetTag(name)"); 
		return ERROR;
	}
	
	FreeMem();
	
	// Name table begins at offset specified in directory table		 
	fin->seekg(dir->GetOffset());	 
	fin->read( (char *)&Table, sizeof(Table));	
 	
 	// Swab the shorts...
    myswab( (unsigned char *)&Table, sizeof(Table));

    // Name records begin after name table
    Records = (NameRecord *)malloc( Table.NumRecords * sizeof(NameRecord));
    fin->read( (char *)Records, Table.NumRecords * sizeof(NameRecord));
	                                               
 	// Swab the shorts...
    myswab( (unsigned char *)Records, Table.NumRecords * sizeof(NameRecord));
    
    // String data
    int datasize = (int)dir->GetLength() - 
    				( sizeof(Table) + 
    				( Table.NumRecords * sizeof(NameRecord)));

	// malloc #1    				
    if(( Data = (char *)malloc(datasize)) == NULL)
    {
		Report( TO_LIST, "ERROR NameTable::Read: Malloc #1 == NULL"); 
		return ERROR;	
    }
    
    fin->read( (char *)Data, datasize);    

	return OK;
}


// Leaving this unfinished until I know how it is used better.....
int	
NameTable::GetNameIDInfo( unsigned short id, unsigned short spec, unsigned short lang)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER NameTable::GetNameIDInfo(?,?,?)"); 
	#endif
	
	NameRecord *record;
	for( unsigned short i = 0; i < Table.NumRecords; ++i)
	{
		record = Records + i;
		if( record->PlatformID = id &&
			record->SpecificID == spec &&
			record->LanguageID == lang )
		{
			// Copy string into tmp array
			
			switch( record->NameID)
			{
				case 0:
				
				break;
				case 1:
				
				break;
				case 2:
				
				break;
				case 3:
				
				break;
				
				case 4:
				
				break;
				
			}		
		}		
	}	
	
	return ERROR;
}

int
NameTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER NameTable::Print()"); 
	#endif

	cout << "** Name **" << endl;
	cout << dec;
	cout << "Format:\t" << Table.Format << endl;
	cout << "NumRecords:\t" << Table.NumRecords << endl;
	cout << "StorageOffset:\t0x" << hex << Table.StorageOffset << endl;
	cout << dec;
    
    cout << endl << "** Name Records **" << endl;
	NameRecord *record;
	for( unsigned short i = 0; i < Table.NumRecords; ++i)
	{
		record = Records + i;
		cout << dec;
		cout << "Record: " << i << endl;
		cout << "\t  Platform ID:   " << record->PlatformID << endl;
		cout << "\t  Specific ID:   " << record->SpecificID << endl;
		cout << "\t  Language ID: 0x" << hex << record->LanguageID << dec << endl;
		cout << "\t      Name ID:   " << record->NameID << endl;
		cout << "\tString Length:   " << record->StringLength << endl;
		cout << "\tString Offset: 0x" << hex <<  record->StringOffset << endl;
		cout << "\t         Data:   " << dec << endl;
		{
			unsigned short i = 0;
			char *datap = Data + record->StringOffset - 1;
			while( i++ < record->StringLength ) 
			{ 
				cout << datap[i];
			}
		} 
		cout << dec << endl;
	}

//{
//int i = 0;
//for( i = 0; i <= 8; ++i ) {
//	printf("0x%x\n", ((short *)table)[i] );
//}}
	
	return OK;
}
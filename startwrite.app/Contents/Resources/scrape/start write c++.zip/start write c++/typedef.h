// typedef.h

// Defines for global use
#ifndef _TYPEDEF_H
#define _TYPEDEF_H

typedef unsigned char WBOOL;


#endif

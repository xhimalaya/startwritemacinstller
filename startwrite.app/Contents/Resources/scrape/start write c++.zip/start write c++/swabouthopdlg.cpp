// swAboutHOPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "resource.h"
#include "artdisp.h"
#include "swAboutHOPDlg.h"
#include "swupgrade.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CHOPAboutDlg dialog


CHOPAboutDlg::CHOPAboutDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHOPAboutDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHOPAboutDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	doUpgrade=0;
}


void CHOPAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHOPAboutDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHOPAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CHOPAboutDlg)
	ON_BN_CLICKED(IDC_HELP_ORDER, OnHelpOrder)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHOPAboutDlg message handlers


BOOL CHOPAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CWnd	*pChild = GetDlgItem(IDS_SPLASH);
	pChild->GetClientRect(&m_rectSplash);
	pChild->MapWindowPoints(this, &m_rectSplash); 

	CString strAbout;

	CString strAboutHooked;
	if (doUpgrade) {
		strAbout.LoadString(IDS_ABOUT_UPGRADE1);		// Regular Startwrite, Inc About
		strAboutHooked.LoadString(IDS_HOPUPGRADE);
	}
	else {
		CString cancelTxt;
		cancelTxt.LoadString(IDS_CANCEL);
		SetDlgItemText(IDC_HELP_ORDER, cancelTxt);

		strAbout.LoadString(IDS_ABOUT_STRING);		// Regular Startwrite, Inc About
		strAboutHooked.LoadString(IDS_ABOUT_STRING_HOOKED);
	}

	SetDlgItemText(IDS_ABOUT_STRING, strAbout);
	SetDlgItemText(IDS_ABOUT_STRING2, strAboutHooked);


	// now paint the graphics in the the dialog
	CPoint pos = CPoint(m_rectSplash.left,m_rectSplash.top);
	CPoint size = CPoint(m_rectSplash.right-m_rectSplash.left, m_rectSplash.bottom - m_rectSplash.top);

	artDisplay(m_hWnd, ABOUTVIEW1, ABOUTBUF1, pos, size, SWA_RESOURCE+SWA_FLUSH, theApp.m_splashStr, 0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CHOPAboutDlg::OnHelpOrder() 
{
	// TODO: Add your control notification handler code here
	if (doUpgrade) {
		swUpgrade upgradeDlg;
		CTime time2( 2004, 1, 1, 0, 0, 0 );	// 1/1/01	default expiration date
		upgradeDlg.m_hopReg = "HOP";		// Set the reg type.
		upgradeDlg.m_expiration = time2;
		upgradeDlg.m_Price = "Price: $17.95 + $2.00 Shipping/Handling";
		upgradeDlg.didPrint = 0;
		upgradeDlg.DoModal();
	}
	CDialog::OnCancel();	
}

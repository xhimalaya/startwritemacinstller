// splash.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "splash.h"
#include "artdisp.h"
#include <time.h>

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif
//#define FREEZ
/////////////////////////////////////////////////////////////////////////////
// CSplash

CSplash::CSplash()
{
}

CSplash::~CSplash()
{
}

BEGIN_MESSAGE_MAP(CSplash, CWnd)
	//{{AFX_MSG_MAP(CSplash)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplash message handlers


void CSplash::OnTimer(UINT nIDEvent)
{
	CWnd::OnTimer(nIDEvent);
}

void CSplash::OnPaint()
{
	CWnd::OnPaint();
}

void CSplash::OnDestroy()
{
	CWnd::OnDestroy();
}

int CSplash::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

void CSplash::StartSplash()
{
#ifdef FREEZ
	RECT		rect;
	rect.left = 0;
	rect.top = 0;
/*#ifdef SW_HOOKED
	rect.right = 369;
	rect.bottom = 369;
#else
	rect.right = 395;
	rect.bottom = 120;
#endif
*/
	if ((*swType == swHOP) || (*swType == swHPD)) {
		rect.right = 369;
		rect.bottom = 369;
	}
	else if ((*swType == swOXF) || (*swType == swOXD)) {
		rect.right = 425;
		rect.bottom = 576;	//120;
	}
	else {
		rect.right = 302;
		rect.bottom = 285;	//120;
	}

	GetCenterWindowPos(&rect);

	m_strClassName = AfxRegisterWndClass(0);
	CreateEx(
		WS_EX_TOPMOST,
		m_strClassName, 
		"", 
		WS_POPUP | WS_VISIBLE, 
		rect.left,
		rect.top,
		rect.right - rect.left,
		rect.bottom - rect.top, 
		NULL, 
		NULL);

	CPoint pos = CPoint(0,0);	// pos and size are both zero
	CPoint size = CPoint(0,0);

	artDisplay(m_hWnd, SPLASHVIEW, SPLASHBUF, pos, size, SWA_RESOURCE+SWA_FLUSH, theApp.m_splashStr, 0);

	UpdateWindow();

	time( &m_startTime );		// Get starting time of splash
#endif
}

void CSplash::KillSplash()
{   
#ifdef DO_THE_SPLASH
#ifdef FREEZ
	static int beenHere=0;

	if (!beenHere) {
		long junk;

		beenHere++;
		// Don't let it die before 2 seconds have passed
		do {
			time( &m_endTime );
		} while( (m_endTime-2) <= m_startTime);
		
		junk = SPLASHBUF;
		artFreeBuffer(&junk);
		junk = SPLASHVIEW;
		artFreeView(&junk);
		DestroyWindow();
		theApp.m_InSplash = false;

		if (theApp.m_DoPowerReload == true) {
			CToolBar *ptoolbar = (CToolBar*)AfxGetApp()->m_pMainWnd->GetDescendantWindow(ID_VIEW_TOOLBAR);
			if (ptoolbar != NULL) {
				ptoolbar->LoadBitmap(IDB_EDIT_BAR);
				ptoolbar->Invalidate();
			}
		}
	}
#else
	theApp.m_InSplash = false;
#endif
#else
	theApp.m_InSplash = false;
#endif
}

void CSplash::GetCenterWindowPos(RECT *lpRect)
{
#ifdef FREEZ
	RECT	rectSelf = *lpRect,
			rectParent;

	::GetWindowRect(::GetDesktopWindow(), &rectParent);
	lpRect->left = ((rectParent.right - rectParent.left) - 
							(rectSelf.right - rectSelf.left)) / 2;
	lpRect->top = ((rectParent.bottom - rectParent.top) - 
							(rectSelf.bottom - rectSelf.top)) / 2;
	lpRect->right = lpRect->left + (rectSelf.right - rectSelf.left);
	lpRect->bottom = lpRect->top + (rectSelf.bottom - rectSelf.top);
#endif
}

// TrialHelp.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "TrialHelp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrialHelp dialog


CTrialHelp::CTrialHelp(CWnd* pParent /*=NULL*/)
	: CDialog(CTrialHelp::IDD, pParent)
{
	DLGTEMPLATE dlgTemp;  

/*	dlgTemp.style=0;
	dlgTemp.dwExtendedStyle=0; 
    dlgTemp.cdit=1;
	dlgTemp.x=0;
	dlgTemp.y=0;
	dlgTemp.cx=500;
	dlgTemp.cy=500; */

	Create(IDD_TRIAL_HELP, pParent);
	ShowWindow(SW_SHOW);

	//Create(IDD, pParent);
	//{{AFX_DATA_INIT(CTrialHelp)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTrialHelp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrialHelp)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTrialHelp, CDialog)
	//{{AFX_MSG_MAP(CTrialHelp)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrialHelp message handlers

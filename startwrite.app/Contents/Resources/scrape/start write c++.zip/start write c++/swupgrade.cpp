// swUpgrade.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "swUpgrade.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// swUpgrade dialog
extern unsigned char *swType;

swUpgrade::swUpgrade(CWnd* pParent /*=NULL*/)
	: CDialog(swUpgrade::IDD, pParent)
{
	//{{AFX_DATA_INIT(swUpgrade)
	m_fullName = _T("");
	m_Address = _T("");
	m_City = _T("");
	m_zipcode = _T("");
	m_phone = _T("");
	m_state = _T("");
	m_country = _T("");
	m_faxnumber = _T("");
	m_email = _T("");
	m_hopReg = _T("");
	m_HOPRegnum = _T("");
	m_cardnum = _T("");
	m_expiration = 0;
	m_address2 = _T("");
	m_Price = _T("");
	//}}AFX_DATA_INIT
	paymentType = 0;
}


void swUpgrade::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(swUpgrade)
	DDX_Text(pDX, IDC_FULLNAME, m_fullName);
	DDX_Text(pDX, IDC_ADDRESS, m_Address);
	DDX_Text(pDX, IDC_CITY, m_City);
	DDX_Text(pDX, IDC_ZIPCODE, m_zipcode);
	DDX_Text(pDX, IDC_PHONE, m_phone);
	DDX_Text(pDX, IDC_STATE, m_state);
	DDX_Text(pDX, IDC_COUNTRY, m_country);
	DDX_Text(pDX, IDC_FAX, m_faxnumber);
	DDX_Text(pDX, IDC_EMAIL, m_email);
	DDX_Text(pDX, IDC_EDIT13, m_hopReg);
	DDX_Text(pDX, IDC_HOPREGISTRATION, m_HOPRegnum);
	DDX_Text(pDX, IDC_CARDNUM, m_cardnum);
	DDX_DateTimeCtrl(pDX, IDC_EXPIRATION, m_expiration);
	DDX_Text(pDX, IDC_ADDRESS2, m_address2);
	DDX_Text(pDX, IDC_PRICE, m_Price);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(swUpgrade, CDialog)
	//{{AFX_MSG_MAP(swUpgrade)
	ON_BN_CLICKED(IDC_PRINTFORM, OnPrintform)
	ON_BN_CLICKED(IDC_AMERICANEX, OnAmericanex)
	ON_BN_CLICKED(IDC_DISCOVER, OnDiscover)
	ON_BN_CLICKED(IDC_MASTERCARD, OnMastercard)
	ON_BN_CLICKED(IDC_VISA, OnVisa)
	ON_BN_CLICKED(IDC_CHECK, OnCheck)
	ON_BN_CLICKED(IDOK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// swUpgrade message handlers
static BOOL doPrint(swUpgrade *ptr);

void swUpgrade::OnPrintform() 
{
	// TODO: Add your control notification handler code here
	// Print all the information
	if (checkEntries() == TRUE) {
		doPrint(this);
		OnOK();
	}
}

// Check the entries that are filled to be sure we have all we need
// Return TRUE if all is well
// Return False if more to do
int swUpgrade::checkEntries()
{
	UpdateData(TRUE);

	if (paymentType == 0) {
		return FALSE;
	}
	if (m_fullName.IsEmpty()) {
		return FALSE;
	}
//	m_Address
//	m_City
//	m_zipcode
	if (m_phone.IsEmpty()) {
		return FALSE;
	}
	if (m_state.IsEmpty()) {
		return FALSE;
	}
//	m_country
//	m_faxnumber
	if (m_email.IsEmpty()) {
		return FALSE;
	}
	if (m_HOPRegnum.IsEmpty()) {
		return FALSE;
	}
//	m_cardnum
//	m_expiration
	return TRUE;
}

/* This is the final proposal report */
static BOOL doPrint (swUpgrade *pptr)
	  {

	CDC ThePrintDC; //create a device context to use
	CPrintDialog PrintDialog(FALSE);  //make a print dialog too

	if(PrintDialog.DoModal()==IDOK) //pressed the ok button on the print dialog?
	{
		ThePrintDC.Attach(PrintDialog.GetPrinterDC());//if so get settings
	}
	else
		return FALSE; //leave this procedure, before anything bad happens

	//long CharRange=0;
	long LastChar=0;//will store document length

	//HDC hdc=ThePrintDC.GetSafeHdc();        //get handle to DC we are using
	//int nHorizRes = ThePrintDC.GetDeviceCaps(HORZRES);                 //width P in MM
	//int nVertRes = ThePrintDC.GetDeviceCaps(VERTRES);        //hight in raster lines
	//int nLogPixelsX = ThePrintDC.GetDeviceCaps(LOGPIXELSX);  //pixels per inch along x
	//int nLogPixelsY = ThePrintDC.GetDeviceCaps(LOGPIXELSY);  //pixels per inch along y
	int ErrorStatus=0;

	//create cancel dialog
//	CPrintAbortDialog* pAbort=new CPrintAbortDialog();
//	pAbort->Create(IDD_ABORTPRINT, this);
//	pAbort->ShowWindow(SW_SHOW);
   //Start Printing
	DOCINFO di; //make a docinfo structure
	::ZeroMemory(&di, sizeof(DOCINFO)); //need to be claer, so clear stuff from it
	di.cbSize=sizeof(DOCINFO);     //set size member
	di.lpszDocName="Startwrite";	//set doc name, was passed via another funtion
	ThePrintDC.StartDoc(&di); //start printing document
	do {
//		pAbort->Increment();//show it on print abort dialog
		CString s;
		char *tptr;
		int ypos = 300;
		ThePrintDC.StartPage(); //start the page
		tptr = "STARTWRITE UPGRADE REQUEST FORM";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));	ypos += 100;
		tptr = "Fax form to StartWrite. (801) 936-7777";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 50;
		tptr = "Attention StartWrite Orders";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 100;
		tptr = "or Mail to:";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 100;
		tptr = "Startwrite Orders";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 50;
		tptr = "Startwrite, Inc.";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 50;
		tptr = "Suite 215";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 50;
		tptr = "80 South Redwood Road";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 50;
		tptr = "North Salt Lake City, UT 84054";
		ThePrintDC.TextOut( 200, ypos, (LPCTSTR)tptr, strlen(tptr));ypos += 200;

		ThePrintDC.TextOut( 200, ypos, pptr->m_fullName);ypos += 50;
		ThePrintDC.TextOut( 200, ypos, pptr->m_Address);ypos += 50;
		if (!pptr->m_address2.IsEmpty()) {
			ThePrintDC.TextOut( 200, ypos, pptr->m_address2);ypos += 50;
		}
		
		s = pptr->m_City + "," + pptr->m_state + "  " + pptr->m_zipcode;
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;
		ThePrintDC.TextOut( 200, ypos, pptr->m_country);ypos += 100;
		s = "Phone: " + pptr->m_phone;
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;

		s = "Fax: " + pptr->m_faxnumber;
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;

		s = "e-mail: " + pptr->m_email;
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;

		s = pptr->m_hopReg + "-" + pptr->m_HOPRegnum;
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;

		s = "Payment Method: ";

		CString paytype;
		switch(pptr->paymentType) {
		case PAY_CHECK:
			paytype = "Check or Money Order";
			break;
		case PAY_VISA:
			paytype = "VISA";
			break;
		case PAY_MASTER:
			paytype = "MASTERCARD";
			break;
		case PAY_AMEX:
			paytype = "AMERICAN EXPRESS";
			break;
		case PAY_DISC:
			paytype = "DISCOVER";
			break;
		}
		s += paytype;
		ThePrintDC.TextOut( 200, ypos, s); ypos += 50;
		if (pptr->paymentType != PAY_CHECK) {
			ThePrintDC.TextOut( 200, ypos, pptr->m_cardnum);ypos += 50;
			s = "Exp: ";
			s += pptr->m_expiration.Format( "%B %Y"); 
			ThePrintDC.TextOut( 200, ypos, s);ypos += 50;
		}

		ypos += 100;
		if (*swType == swHPD) {
			s = "Price: $17.95 + $2.00 shipping = $19.95";
		}
		else {
			s = "Price: $39.95 + $5.00 shipping and handling";
		}
		ThePrintDC.TextOut( 200, ypos, s);ypos += 50;

		
		//of last fitting char
		ErrorStatus=ThePrintDC.EndPage();//end this page, and record status
		LastChar++;
	}while(LastChar==0); //while there is stuff to print ot there

	ThePrintDC.EndDoc();
	pptr->didPrint = 1;	   
	  return 0;
}





void swUpgrade::OnAmericanex() 
{
	paymentType = PAY_AMEX;
}

void swUpgrade::OnDiscover() 
{
	paymentType = PAY_DISC;	
}

void swUpgrade::OnMastercard() 
{
	paymentType = PAY_MASTER;	
}

void swUpgrade::OnVisa() 
{
	paymentType = PAY_VISA;	
}

void swUpgrade::OnCheck() 
{
	paymentType = PAY_CHECK;
}

void swUpgrade::OnOk() 
{
	int retVal;
	while (didPrint == 0) {
		retVal = AfxMessageBox(IDS_PRINTORDER, MB_YESNOCANCEL, NULL);

		if (retVal == IDYES) {
			OnPrintform();
		}
		else if (retVal == IDCANCEL) {
			return;
		}
		else if (retVal == IDNO) {
			CDialog::OnCancel();
			return;
		}
	}
	
	CDialog::OnOK();
}

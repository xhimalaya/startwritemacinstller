// SetDlg50.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "SetDlg50.h"
#include "stdlib.h"
#include "FolderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetDlg50 dialog


CSetDlg50::CSetDlg50(CWnd* pParent /*=NULL*/)
	: CDialog(CSetDlg50::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetDlg50)
	m_artFolder = _T("");
	m_shadeRadio = -1;
	m_densityRadio = -1;
	m_shadeTypeRadio = -1;
	m_docFolder = _T("");
	//}}AFX_DATA_INIT
}


void CSetDlg50::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetDlg50)
	DDX_Control(pDX, IDC_ARROWCHECK, m_arrowCheck);
	DDX_Control(pDX, IDC_STARTDOT_ON, m_startDotCheck);
	DDX_Text(pDX, IDC_ART_FOLDER, m_artFolder);
	DDX_Radio(pDX, IDC_SHADING_25, m_shadeRadio);
	DDX_Radio(pDX, IDC_DENSITY_25, m_densityRadio);
	DDX_Radio(pDX, IDC_SHADE_SHADE, m_shadeTypeRadio);
	DDX_Text(pDX, IDC_DOC_FOLDER, m_docFolder);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSetDlg50, CDialog)
	//{{AFX_MSG_MAP(CSetDlg50)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(FIND_WORK_DIR, &CSetDlg50::OnBnClickedFindWorksheetDir)
	ON_BN_CLICKED(FIND_ART_DIR, &CSetDlg50::OnBnClickedArtDir)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetDlg50 message handlers

BOOL CSetDlg50::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_startDotCheck.SetCheck(m_startDotSetting ? true : false);
	m_arrowCheck.SetCheck(m_arrowSetting ? true : false);
	// TODO: Add extra initialization here
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSetDlg50::OnOK() 
{
	UpdateData(TRUE);
	m_startDotSetting = m_startDotCheck.GetCheck() ? 1 : 0;
	m_arrowSetting = m_arrowCheck.GetCheck() ? 1 : 0;
	CDialog::OnOK();
}

void CSetDlg50::OnBnClickedFindWorksheetDir()
{
	int ret = 0;
	CString m_strFolderPath = _T(m_docFolder);

	CFolderDialog fDlg( _T("Select Default Worksheet Folder"), m_strFolderPath, this); 

	if (fDlg.DoModal() == IDOK) {
		m_docFolder = fDlg.GetFolderPath();
		UpdateData(FALSE);
	}
}

void CSetDlg50::OnBnClickedArtDir()
{
	CString m_strFolderPath = _T(m_artFolder);

	CFolderDialog fDlg( _T("Select Default Art Folder"), m_strFolderPath, this); 

	if (fDlg.DoModal() == IDOK) {
		m_artFolder = fDlg.GetFolderPath();
		UpdateData(FALSE);
	}

}

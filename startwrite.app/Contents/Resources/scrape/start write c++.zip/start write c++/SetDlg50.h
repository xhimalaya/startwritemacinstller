#if !defined(AFX_SETDLG50_H__A8CF3FAF_2CD9_46D7_A635_A5A12F75266D__INCLUDED_)
#define AFX_SETDLG50_H__A8CF3FAF_2CD9_46D7_A635_A5A12F75266D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetDlg50.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetDlg50 dialog

class CSetDlg50 : public CDialog
{
// Construction
public:
	CSetDlg50(CWnd* pParent = NULL);   // standard constructor
	int m_startDotSetting;
	int m_yellowSetting;
	int m_arrowSetting;
// Dialog Data
	//{{AFX_DATA(CSetDlg50)
	enum { IDD = IDD_SETTINGS_50 };
	CButton	m_arrowCheck;
	CButton	m_startDotCheck;
	CString	m_artFolder;
	int		m_shadeRadio;
	int		m_densityRadio;
	int		m_shadeTypeRadio;
	CString	m_docFolder;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetDlg50)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSetDlg50)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedFindWorksheetDir();
	afx_msg void OnBnClickedArtDir();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETDLG50_H__A8CF3FAF_2CD9_46D7_A635_A5A12F75266D__INCLUDED_)


#include "stdafx.h"
#include <iostream>
using namespace std;
#include "sw.h"

#include "SwBorderManager.h"

static char *colorName = "swBorderColor.swb";
static char *bandwName = "swBorderBW.swb";

SwBorderManagement::SwBorderManagement(int type)
{
	char *borderFileName;
	iMasterFP=NULL;
	
	memset(&fileListBuf, 0, sizeof(fileListBuf));
	fileCount=0;
	HeaderSize=sizeof(fileListBuf);
	FileHeaderSize=sizeof(BorderFileHeader);
	DataBeginLocation=HeaderSize+FileHeaderSize;

	long readLen;
	int retv;

	if (type == 1)
		borderFileName = colorName;
	else
		borderFileName = bandwName;
	
	CString sPath = theApp.m_BasePath + "\\bdMisc\\"+borderFileName;
	retv = fopen_s(&iMasterFP, sPath, "rb");
	if (iMasterFP == NULL) {
		AfxMessageBox("Unable to open Borderfile for reading");
		return;
	}

	readLen = fread_s(BorderFileHeader, sizeof(BorderFileHeader), 1, sizeof(BorderFileHeader), iMasterFP);
	
	
	memset(fileListBuf, 0, sizeof(fileListBuf));
	readLen = fread_s(fileListBuf, sizeof(fileListBuf), 1, sizeof(fileListBuf), iMasterFP);
	currBorderIndex=0;
}

SwBorderManagement::~SwBorderManagement()
{
	currBorderIndex=0;
	if (iMasterFP != NULL)
		fclose(iMasterFP);
}

void SwBorderManagement::resetMainFile()
{
}

void SwBorderManagement::SwBorderGetList()
{

}

void SwBorderManagement::LoadSingleFile(BORDERITEM &bItem) 
{
}

int SwBorderManagement::SwBorderBuildFile()
{
	return(0);
}


int SwBorderManagement::getNextItem(bool isFirst, CString &name)
{
	char tBuf[128];
	int j;

	if (isFirst)
		currBorderIndex=0;

	if (fileListBuf[currBorderIndex].filename[0]) {
		for(j=0; j < sizeof(fileListBuf[currBorderIndex].filename) && fileListBuf[currBorderIndex].filename[j];j++) {
			tBuf[j] = fileListBuf[currBorderIndex].filename[j] & 0x7F;
		}
		tBuf[j] = '\0';
		name = tBuf;
		currBorderIndex++;
		return(currBorderIndex);
	}
	return(0);
}

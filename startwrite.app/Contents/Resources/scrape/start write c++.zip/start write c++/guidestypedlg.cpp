// GuideStypeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "fontdlg.h"
#include "miscutil.h"
#include "guidestypedlg.h"

extern unsigned int defaultFont;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGuideStypeDlg dialog


CGuideStypeDlg::CGuideStypeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGuideStypeDlg::IDD, pParent)
	, m_ThicknessRadioVal(0)
	, m_setGuidelinesAsDefault(false)
{
	//{{AFX_DATA_INIT(CGuideStypeDlg)
	m_midType = 2;
	m_topType = 1;
	m_basType = 1;
	m_botType = 0;
	m_fontName = _T("");
	fromMainPage=0;
	//}}AFX_DATA_INIT
	m_topThickness = 0;
	m_midThickness = 0;
	m_basThickness = 0;
	m_botThickness = 0;

	m_pCustomColors = NULL;
	m_crGuideTop = RGB(0,0,255);
	m_crGuideMiddle = RGB(0,0,255);
	m_crGuideBase = RGB(255,0,0);
	m_crGuideBottom = RGB(0,0,255);
	m_LedgeThickness = 0;
	m_setGuidelinesAsDefault = false;
	m_pBox = new BBox;
	m_pTextItem = NULL;
}

CGuideStypeDlg::~CGuideStypeDlg()
{
	if (m_pBox)
		delete m_pBox;
}

void CGuideStypeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGuideStypeDlg)
	DDX_Radio(pDX, IDC_MIDLINE_OFF, m_midType);
	DDX_Radio(pDX, IDC_TOPLINE_OFF, m_topType);
	DDX_Radio(pDX, IDC_BASLINE_OFF, m_basType);
	DDX_Radio(pDX, IDC_BOTLINE_OFF, m_botType);
	DDX_Radio(pDX, IDC_RADIO_THICK_TOP_NORMAL, m_topThickness);
	DDX_Radio(pDX, IDC_RADIO_THICK_MID_NORMAL, m_midThickness);
	DDX_Radio(pDX, IDC_RADIO_THICK_BAS_NORMAL, m_basThickness);
	DDX_Radio(pDX, IDC_RADIO_THICK_BOT_NORMAL, m_botThickness);
	DDX_Control(pDX, IDC_COLORCOMBO_GUIDETOP, m_ColorComboGuideTop);
	DDX_Control(pDX, IDC_COLORCOMBO_GUIDEMID, m_ColorComboGuideMiddle);
	DDX_Control(pDX, IDC_COLORCOMBO_GUIDEBAS, m_ColorComboGuideBase);
	DDX_Control(pDX, IDC_COLORCOMBO_GUIDEBOT, m_ColorComboGuideBottom);
	DDX_Text(pDX, IDC_FONTNAME, m_fontName);
	//}}AFX_DATA_MAP
	if (pDX->m_bSaveAndValidate){
	}
	else {
		InitPreview();
	}
	DDX_Control(pDX, IDC_CHECK_GUIDELINE_DEFAULT, m_SetGuidesAsDefault);
}

BEGIN_MESSAGE_MAP(CGuideStypeDlg, CDialog)
	//{{AFX_MSG_MAP(CGuideStypeDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_TOPLINE_OFF, OnLineChange)
	ON_BN_CLICKED(IDC_MIDLINE_OFF, OnLineChange)
	ON_BN_CLICKED(IDC_BASLINE_OFF, OnLineChange)
	ON_BN_CLICKED(IDC_BOTLINE_OFF, OnLineChange)
	ON_BN_CLICKED(IDC_TOPLINE_DASHED, OnLineChange)
	ON_BN_CLICKED(IDC_MIDLINE_DASHED, OnLineChange)
	ON_BN_CLICKED(IDC_BASLINE_DASHED, OnLineChange)
	ON_BN_CLICKED(IDC_BOTLINE_DASHED, OnLineChange)
	ON_BN_CLICKED(IDC_TOPLINE_SOLID, OnLineChange)
	ON_BN_CLICKED(IDC_MIDLINE_SOLID, OnLineChange)
	ON_BN_CLICKED(IDC_BASLINE_SOLID, OnLineChange)
	ON_BN_CLICKED(IDC_BOTLINE_SOLID, OnLineChange)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_RADIO_THICK_TOP_NORMAL, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_TOP_THICK, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_TOP_THICKER, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_TOP_THICKEST, OnLineChange)

	ON_BN_CLICKED(IDC_RADIO_THICK_MID_NORMAL, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_MID_THICK, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_MID_THICKER, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_MID_THICKEST, OnLineChange)

	ON_BN_CLICKED(IDC_RADIO_THICK_BAS_NORMAL, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BAS_THICK, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BAS_THICKER, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BAS_THICKEST, OnLineChange)

	ON_BN_CLICKED(IDC_RADIO_THICK_BOT_NORMAL, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BOT_THICK, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BOT_THICKER, OnLineChange)
	ON_BN_CLICKED(IDC_RADIO_THICK_BOT_THICKEST, OnLineChange)

//	ON_BN_CLICKED(IDC_RADIO_THICK_NORMAL, &CGuideStypeDlg::OnBnClickedRadioThickNormal)
//	ON_BN_CLICKED(IDC_RADIO_THICK_THICK, &CGuideStypeDlg::OnBnClickedRadioThickThick)
//	ON_BN_CLICKED(IDC_RADIO_THICK_THICKER, &CGuideStypeDlg::OnBnClickedRadioThickThicker)
//	ON_BN_CLICKED(IDC_RADIO_THICK_THICKEST, &CGuideStypeDlg::OnBnClickedRadioThickThickest)
	ON_BN_CLICKED(IDOK, OnOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGuideStypeDlg message handlers

BOOL CGuideStypeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_ColorComboGuideTop.m_crSelectedColor = m_crGuideTop;
	m_ColorComboGuideTop.m_pCustomColors = m_pCustomColors;
	m_ColorComboGuideMiddle.m_crSelectedColor = m_crGuideMiddle;
	m_ColorComboGuideMiddle.m_pCustomColors = m_pCustomColors;
	m_ColorComboGuideBase.m_crSelectedColor = m_crGuideBase;
	m_ColorComboGuideBase.m_pCustomColors = m_pCustomColors;
	m_ColorComboGuideBottom.m_crSelectedColor = m_crGuideBottom;
	m_ColorComboGuideBottom.m_pCustomColors = m_pCustomColors;

	switch(this->m_LedgeThickness)
	{
	case LINE_THICK_NORMAL:
	default:
		this->m_ThickRadio=0;
		m_ThicknessRadioVal = 0;
		break;
	case LINE_THICK_THICK:
		this->m_ThickRadio=1;
		m_ThicknessRadioVal = 1;
		break;
	case LINE_THICK_THICKER:
		this->m_ThickRadio=2;
		m_ThicknessRadioVal = 2;
		break;
	case LINE_THICK_THICKEST:
		this->m_ThickRadio=3;
		m_ThicknessRadioVal = 3;
		break;
	}


	CWnd *cPtr;

	if (fromMainPage) {
		cPtr = GetDlgItem(IDC_GUIDELINE_TITLE_STATIC);
		if (cPtr) {
			cPtr->ShowWindow(FALSE);
		}

		cPtr = GetDlgItem(IDC_FONTNAME);
		if (cPtr) {
			cPtr->ShowWindow(FALSE);
		}
	}
	
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CGuideStypeDlg::InitPreview()
{
	int status;
	int saveGrow;
	CString strToAdd;
	int testSize = theApp.m_defPoint;

	testSize = testSize * 1440 / 72;

	// TextItem should be set by the caller, but if it is null, create it
	if (m_pTextItem == NULL) {
		m_pTextItem = new TextItem();
	}
	m_pTextItem->inDialogDisplay = true;
	m_pBox->Message(BBOX_ITEM_SET, m_pTextItem, &status);
	m_pTextItem->Message(ITEM_PARENT_SET, m_pBox, &status);

	RECT 		rect;
	CPaintDC	dc(this);
	CWnd		*pPreview = GetDlgItem(IDC_GUIDE_PREVIEW);

	pPreview->GetClientRect(&rect);
	m_rectPreview = rect;
	pPreview->MapWindowPoints(this, &m_rectPreview);

	// Give the 3D look stuff some room.
	InflateRect(&rect, -2, -2);

	PrepareDC(&dc);
	dc.DPtoLP(&rect);
	m_rectBox = rect;

	int middle = (rect.bottom + rect.top)/2;
	middle += testSize;
	if (middle > rect.top) {
		middle = rect.top;
	}

	m_pBox->Message(BBOX_POSITION_SET, CPoint(rect.left, middle), &status);
	saveGrow = m_pBox->Message(BBOX_CAN_GROW, 1, &status);
	m_pBox->Message(BBOX_SET_GROW, 1, &status);
	
	m_pBox->Message(BBOX_SIZE_SET, 
		CPoint((rect.right - rect.left) * 4, 
		(rect.bottom - rect.top) * 4), 
		&status);
	
	m_pBox->Message(BBOX_SET_GROW, saveGrow, &status);

	m_pBox->Message(BBOX_VISIBLE_SET, TRUE, &status);
	m_pBox->Message(BBOX_STATE_SET, BBOX_STATE_NORMAL, &status);

	m_pBox->Message(ITEM_ENTER_EDIT_MODE, EMPTY_INT, &status);

	if (theApp.m_isDemo == DEMO_ON) {
		strToAdd = "Aa Gg Ww";
	}
	else {
		strToAdd = "Dog and Cat";
	}

	m_pTextItem->sFontName = theApp.m_defFont;
	m_pTextItem->sFontIndex = defaultFont;
	m_pTextItem->nPointSize = 48;
	m_pTextItem->SetViaMembers();

	m_pTextItem->nAnnoyingFontMsg = TRUE;
	m_pTextItem->nAnnoyingArrowMsg = TRUE;
	m_pTextItem->nAnnoyingOverlayMsg = TRUE;
	m_pTextItem->nOverfullWarning = FALSE;

	for (int i = 0; i < strToAdd.GetLength(); i++)
		m_pTextItem->KeyDown(strToAdd[i], &status);
}

void CGuideStypeDlg::PrepareDC(CDC *pDC)
{
	pDC->SetMapMode(MM_ANISOTROPIC);

	pDC->SetWindowExt( DOC_X_EXTENT, DOC_Y_EXTENT);

	pDC->SetViewportExt((int)(pDC->GetDeviceCaps(LOGPIXELSX) * (100 / 100)),
		(int)(-pDC->GetDeviceCaps(LOGPIXELSY) * (100 / 100)));
}

void CGuideStypeDlg::OnLineChange() 
{
	UpdateData(true);

	UpdateTextItem();
}

//void CGuideStypeDlg::OnPaint() 
//{
//	CDC *pDC = new CClientDC(this);
//
//	CPen bluePen, redPen, blackPen;
//	int top, mid, bas, bot, left, right;
//	int i, j, iPos, iColor, iType;
//
//	bluePen.CreatePen(PS_SOLID, 2, RGB(0,0,255));
//	redPen.CreatePen(PS_SOLID, 2, RGB(255,0,0));
//	blackPen.CreatePen(PS_SOLID, 2, RGB(0,0,0));
//	
//	top = m_rectPreview.top + 10;
//	bot = m_rectPreview.bottom - 10;
//	mid = top + ((bot - top) / 3);
//	bas = top + (((bot - top) * 2) / 3);
//	left = m_rectPreview.left + 10;
//	right = m_rectPreview.right-10;
//
//	pDC->FillRect(&m_rectPreview, WHITE_BRUSH);
//		
//	for(i=0; i < 4; i++) {
//		switch(i) {
//		default:
//		case 0:
//			iColor = m_topColor;
//			iType = m_topType;
//			iPos = top;
//			break;
//		case 1:
//			iColor = m_midColor;
//			iType = m_midType;
//			iPos = mid;
//			break;
//		case 2:
//			iColor = m_basColor;
//			iType = m_basType;
//			iPos = bas;
//			break;
//		case 3:
//			iColor = m_botColor;
//			iType = m_botType;
//			iPos = bot;
//			break;
//		}
//
//		switch(iColor) {
//		case 0:
//			pDC->SelectObject(&redPen);
//			break;
//		case 1:
//			pDC->SelectObject(&bluePen);
//			break;
//		case 2:
//		default:
//			pDC->SelectObject(&blackPen);
//			break;
//		}
//
//		if (iType) {
//			if (iType == 1) {
//				pDC->MoveTo(left, iPos);
//				pDC->LineTo(right, iPos);
//			}
//			else {
//				for(j=left; j < right; j += 20) {
//					pDC->MoveTo(j, iPos);
//					if ((j+10) > right) {
//						pDC->LineTo(right, iPos);
//						break;
//					}
//					pDC->LineTo(j+10, iPos);
//				}
//			}
//		}
//	}
//
//	bluePen.DeleteObject();
//	redPen.DeleteObject();
//	blackPen.DeleteObject();
//	
//	delete pDC;
//	// Do not call CDialog::OnPaint() for painting messages
//	CWnd::OnPaint();
//
//}
void CGuideStypeDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	DrawTextItem(&dc);
}

BOOL CGuideStypeDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	if (wParam == IDC_COLORCOMBO_GUIDETOP) {
		m_crGuideTop = m_ColorComboGuideTop.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_GUIDEMID) {
		m_crGuideMiddle = m_ColorComboGuideMiddle.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_GUIDEBAS) {
		m_crGuideBase = m_ColorComboGuideBase.m_crSelectedColor;
		UpdateTextItem();
	}
	else if (wParam == IDC_COLORCOMBO_GUIDEBOT) {
		m_crGuideBottom = m_ColorComboGuideBottom.m_crSelectedColor;
		UpdateTextItem();
	}
	return CDialog::OnNotify(wParam, lParam, pResult);
}

extern void DrawBitmap(HDC hdc, HBITMAP hBitmap, int x, int y, DWORD dwCode, 
	int cx = -1, int cy = -1);

void CGuideStypeDlg::DrawTextItem(CDC *pDC)
{
	int 		status;
	BOOL		bDelete;     

	if (!pDC)                    
	{
		pDC = new CClientDC(this);
		bDelete = TRUE;
	}
	else
		bDelete = FALSE;

	// First draw the 3D look stuff.
	CPen 	*ppenOld,
			pen;

	// We need to clear the window first
	int testSize = theApp.m_defPoint;

	testSize = testSize * 1440 / 72;

	int middle = (m_rectBox .bottom + m_rectBox .top)/2;
	middle += testSize;
	if (middle > m_rectBox .top) {
		middle = m_rectBox .top;
	}
	m_pBox->Message(BBOX_POSITION_SET, CPoint(m_rectBox .left, middle), &status);

	// Dk gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNSHADOW));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.left, m_rectPreview.top);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Black
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNTEXT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.left + 1, m_rectPreview.top + 1);
	pDC->LineTo(m_rectPreview.right - 2, m_rectPreview.top + 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// Lt gray
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNFACE));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left + 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 2);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	// White
	pen.CreatePen(PS_SOLID, 1, GetSysColor(COLOR_BTNHIGHLIGHT));
	ppenOld = pDC->SelectObject(&pen);
	pDC->MoveTo(m_rectPreview.left, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.bottom - 1);
	pDC->LineTo(m_rectPreview.right - 1, m_rectPreview.top - 1);
	pDC->SelectObject(ppenOld);
	pen.DeleteObject();

	CDC		dcTemp;   
	CBrush *holdBrush;
	CBitmap	bmpTemp,
				*pbmpOld;
	RECT		rectBmp = {0, 0, 
								(m_rectPreview.right - m_rectPreview.left) * 4, 
								(m_rectPreview.bottom - m_rectPreview.top) * 4};

	if (dcTemp.CreateCompatibleDC(NULL) == FALSE) {
		return;
	}
	if (bmpTemp.CreateCompatibleBitmap(pDC, rectBmp.right, rectBmp.bottom) == FALSE) {
		return;
	}

	pbmpOld = dcTemp.SelectObject(&bmpTemp);
	if (pbmpOld == NULL) {
		return;
	}

	holdBrush = (CBrush *) GetStockObject(HOLLOW_BRUSH);
	if (holdBrush == NULL) {
		return;
	}

	// Get a null pen and white brush and clear the rectangle
	CPen *oldpen = (CPen *) dcTemp.SelectStockObject(NULL_PEN);

	dcTemp.SelectStockObject(WHITE_BRUSH);
	dcTemp.Rectangle(&rectBmp);
	dcTemp.SelectObject(oldpen);		// Restore pen

	// Get the DC ready.
	PrepareDC(&dcTemp);

	m_pTextItem->Draw(&dcTemp, &status);

   // Now blt the TextItem stuff onto the preview area.
	dcTemp.SelectObject(pbmpOld);


	DrawBitmap(pDC->m_hDC, (HBITMAP) bmpTemp.m_hObject, 
		m_rectPreview.left + 2, m_rectPreview.top + 2, SRCCOPY,
		m_rectPreview.right - m_rectPreview.left - 4,
		m_rectPreview.bottom - m_rectPreview.top - 4
		);

	dcTemp.DeleteDC();
	bmpTemp.DeleteObject();

	if (bDelete)
		delete pDC;
}

void CGuideStypeDlg::UpdateTextItem()
{
	int newSetting = 0;

	m_pTextItem->ColorGuidelineTop = m_crGuideTop;
	m_pTextItem->ColorGuidelineMiddle = m_crGuideMiddle;
	m_pTextItem->ColorGuidelineBase = m_crGuideBase;
	m_pTextItem->ColorGuidelineBottom = m_crGuideBottom;

	//!!! work here-- Not sure which set of colors will be used
	//!!! perhaps the FontInfo set are defaults and the TextItem members are specific to text item
	//m_pTextItem->myFontInfo.f_TopColor = m_crGuideTop;
	//m_pTextItem->myFontInfo.f_MidColor = m_crGuideMiddle;
	//m_pTextItem->myFontInfo.f_BasColor = m_crGuideBase;
	//m_pTextItem->myFontInfo.f_BotColor = m_crGuideBottom;

	newSetting |= (m_topType ? SWLINE_TOP : 0);
	newSetting |= (m_midType ? SWLINE_MID : 0);
	newSetting |= (m_basType ? SWLINE_BAS : 0);
	newSetting |= (m_botType ? SWLINE_BOT : 0);
	m_pTextItem->nDot2DotLinesButton = newSetting;
	m_pTextItem->myFontInfo.f_TopLine = m_topType & SWLINESET;
	m_pTextItem->myFontInfo.f_BasLine = m_basType & SWLINESET;
	m_pTextItem->myFontInfo.f_BotLine = m_botType & SWLINESET;
	m_pTextItem->myFontInfo.f_MidLine = m_midType & SWLINESET;
	switch(m_topThickness) {
		default:
		case 0:
			m_pTextItem->LedgerPenTopWidth = LINE_THICK_NORMAL;
			break;
		case 1:
			m_pTextItem->LedgerPenTopWidth = LINE_THICK_THICK;
			break;
		case 2:
			m_pTextItem->LedgerPenTopWidth = LINE_THICK_THICKER;
			break;
		case 3:
			m_pTextItem->LedgerPenTopWidth = LINE_THICK_THICKEST;
			break;
	}
	switch(m_midThickness) {
		default:
		case 0:
			m_pTextItem->LedgerPenMidWidth = LINE_THICK_NORMAL;
			break;
		case 1:
			m_pTextItem->LedgerPenMidWidth = LINE_THICK_THICK;
			break;
		case 2:
			m_pTextItem->LedgerPenMidWidth = LINE_THICK_THICKER;
			break;
		case 3:
			m_pTextItem->LedgerPenMidWidth = LINE_THICK_THICKEST;
			break;
	}
	switch(m_basThickness) {
		default:
		case 0:
			m_pTextItem->LedgerPenBasWidth = LINE_THICK_NORMAL;
			break;
		case 1:
			m_pTextItem->LedgerPenBasWidth = LINE_THICK_THICK;
			break;
		case 2:
			m_pTextItem->LedgerPenBasWidth = LINE_THICK_THICKER;
			break;
		case 3:
			m_pTextItem->LedgerPenBasWidth = LINE_THICK_THICKEST;
			break;
	}
	switch(m_botThickness) {
		default:
		case 0:
			m_pTextItem->LedgerPenBotWidth = LINE_THICK_NORMAL;
			break;
		case 1:
			m_pTextItem->LedgerPenBotWidth = LINE_THICK_THICK;
			break;
		case 2:
			m_pTextItem->LedgerPenBotWidth = LINE_THICK_THICKER;
			break;
		case 3:
			m_pTextItem->LedgerPenBotWidth = LINE_THICK_THICKEST;
			break;
	}


	m_pTextItem->SetViaMembersReverse();
	m_pTextItem->SetViaMembers();

	DrawTextItem();
}
#if 0
void CGuideStypeDlg::doThicknessUpdate(int iWhich)
{
	if (iWhich == 0) {
		m_pTextItem->LedgerPenWidthOrig = LINE_THICK_NORMAL;
	}
	else if (iWhich == 1) {
		m_pTextItem->LedgerPenWidthOrig = LINE_THICK_THICK;
	}
	else if (iWhich == 2) {
		m_pTextItem->LedgerPenWidthOrig = LINE_THICK_THICKER;
	}
	else if (iWhich == 3) {
		m_pTextItem->LedgerPenWidthOrig = LINE_THICK_THICKEST;
	}
	
	m_LedgeThickness = m_pTextItem->LedgerPenWidthOrig;
	
	DrawTextItem();
}

void CGuideStypeDlg::OnBnClickedRadioThickNormal()
{
	doThicknessUpdate(0);
}

void CGuideStypeDlg::OnBnClickedRadioThickThick()
{
	doThicknessUpdate(1);
}

void CGuideStypeDlg::OnBnClickedRadioThickThicker()
{
	doThicknessUpdate(2);
}

void CGuideStypeDlg::OnBnClickedRadioThickThickest()
{
	doThicknessUpdate(3);
}

#endif
void CGuideStypeDlg::OnOk()		// This is the replace code
{
	m_setGuidelinesAsDefault  = this->m_SetGuidesAsDefault.GetCheck() ? true : false;
	CDialog::OnOK();
}

// zoomdlg.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "zoomdlg.h"
#include "docunits.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZoomDlg dialog


CZoomDlg::CZoomDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZoomDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CZoomDlg)
	m_iZoom = 0;
	m_DoDefZoom = FALSE;
	//}}AFX_DATA_INIT
}

void CZoomDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZoomDlg)
	DDX_Check(pDX, IDC_DEF_ZOOM_CHECK, m_DoDefZoom);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
	{
		if (IsDlgButtonChecked(IDC_OTHER))
		{
			DDX_Text(pDX, IDC_EDIT1, m_iZoom);
			DDV_MinMaxInt(pDX, m_iZoom, MIN_ZOOM, MAX_ZOOM);
		}
	}
	else
	{
		int iWhich;

		switch(m_iZoom)
		{
			case 50:
				iWhich = IDC_50;
				break;

			case 75:
				iWhich = IDC_75;
				break;

			case 100:
				iWhich = IDC_100;
				break;

			case 125:
				iWhich = IDC_125;
				break;

			case 150:
				iWhich = IDC_150;
				break;

			default:
				iWhich = IDC_OTHER;
				break;
		}

		CheckDlgButton(iWhich, TRUE);
		GetDlgItem(IDC_EDIT1)->EnableWindow(iWhich == IDC_OTHER);
		SetDlgItemInt(IDC_EDIT1, m_iZoom);
	}
}

BEGIN_MESSAGE_MAP(CZoomDlg, CDialog)
	//{{AFX_MSG_MAP(CZoomDlg)
	ON_BN_CLICKED(IDC_100, On100)
	ON_BN_CLICKED(IDC_50, On50)
	ON_BN_CLICKED(IDC_75, On75)
	ON_BN_CLICKED(IDC_OTHER, OnOther)
	ON_BN_CLICKED(IDC_125, On125)
	ON_BN_CLICKED(IDC_150, On150)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CZoomDlg message handlers

void CZoomDlg::On100()
{
	m_iZoom = 100;
	EnableOther(FALSE);
}

void CZoomDlg::On150()
{
	m_iZoom = 150;
	EnableOther(FALSE);
}

//void CZoomDlg::On200()
//{
//	m_iZoom = 150;	// This was 200
//	EnableOther(FALSE);
//}

void CZoomDlg::On50()
{
	m_iZoom = 50;
	EnableOther(FALSE);
}

void CZoomDlg::On75()
{
	m_iZoom = 75;
	EnableOther(FALSE);
}

void CZoomDlg::OnOther()
{
	EnableOther(TRUE);
}

void CZoomDlg::EnableOther(BOOL bVal)
{
	GetDlgItem(IDC_EDIT1)->EnableWindow(bVal);
}

void CZoomDlg::On125() 
{
	m_iZoom = 125;
	EnableOther(FALSE);
	
}

//// GIF.H

#include "bufffile.h"

#define N 8
#define MAXTEST   100
#define MAXSTRING 16000
#define MAXENTRY  4093
#define BAD_CODE_SIZE -20
#define MAX_CODES 4096

class CGIF : public CPics
{
private:

protected:

private:
	unsigned char *dstack;
	unsigned char *suffix;
	unsigned int *prefix;
	int *rowtable;
	unsigned char *decoderline;

	int curr_size;
	int clear;
	int ending;
	int newcodes;
	int top_slot;
	int slot;
	int navail_bytes;
	int nbits_left;
	unsigned char b1;
	unsigned char byte_buff[257*2];
	unsigned char *pbytes;
	int rowcount;
	int bad_code_count;
	
	int mInterlaced;
	unsigned char huge *mDBuffer;
	int mGIFVersion;
	long mSeekTo;

public:
	CGIF (char *Filename);

	virtual BOOL LoadPicture (CDC *pDC, int Flags = 0);
	virtual BOOL SavePicture (char *Filename = NULL, int PictureType = -1);

private:
	BOOL GetGIFPalette (void);
	BOOL GetGIFHeader (void);
	void WriteGIFHeader (CFile *);
	BOOL PrepareGIFPicture (char *);

	int GetByte (CBufferedFile *);
	int InitExp (int);
	int GetNextCode (CBufferedFile *);
	int Decoder (int, CBufferedFile *);
	int OutLine (unsigned char *, unsigned int);
	int Raster (unsigned int, int *,int *, unsigned char *,
		int *, int *, unsigned char *, CBufferedFile *);

};



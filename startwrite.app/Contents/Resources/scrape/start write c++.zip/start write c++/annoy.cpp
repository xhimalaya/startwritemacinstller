// Annoy.cpp : implementation file
//

#include "stdafx.h"
#include "sw.h"
#include "Annoy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnnoy dialog


CAnnoy::CAnnoy(CWnd* pParent /*=NULL*/)
	: CDialog(CAnnoy::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAnnoy)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	Counter=0;
}


void CAnnoy::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAnnoy)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAnnoy, CDialog)
	//{{AFX_MSG_MAP(CAnnoy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnnoy message handlers

void CAnnoy::OnOK() 
{
	CDialog::OnOK();
}

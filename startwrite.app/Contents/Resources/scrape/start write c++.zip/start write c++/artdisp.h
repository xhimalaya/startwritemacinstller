/** Header file for artdisp.c -- **/
/** ArtDisp.h ***/



#define SW_IMAGN	1		/** if defined => we are doing art withj imagn **/

#define SWA_FILL	1
#define SWA_NORMAL	2
#define SWA_FLUSH	4
#define SWA_RESOURCE	8


#define ABOUTVIEW1	994
#define ABOUTVIEW2	995
#define ABOUTBUF1	996
#define ABOUTBUF2	997
#define SPLASHVIEW	998
#define SPLASHBUF	999
#define BASE_ARTID	1000
#define SWA_LOADED	0x00800000
#define SWA_MASK	0x000FFFFF
#define BORDER_VIEW1	1001
#define BORDER_BUF1		1002


extern long artDisplay(HWND hWndPtr, long ViewId, long BufId, 
							CPoint pos, CPoint size, long flag, CString artpath, int artResource);

extern long artDisplayBuf(long BufId, CString artpath);
extern long artPrint(CDC *pDC, long BufId, CPoint pos, CPoint size, long flag, CString artpath);
extern void artFreeBuffer(long *BufId);
extern void artFreeView(long *ViewId);
extern long borderArtDisplay(CDC *pDC, long BufId, CPoint pos, CPoint size, CString artpath, bool show, CPoint padsize, CPoint &imagesize);

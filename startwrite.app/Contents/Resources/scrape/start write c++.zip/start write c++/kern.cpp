//kern.cpp
// Font Header Table Class Implementation

#include "stdafx.h"
#include "Dir.h"
#include "Kern.h"
 
#include <stdio.h>
 
KernTable::KernTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER KernTable::KernTable()"); 
	#endif

	Offsets = NULL;
	KernTabP = NULL;
	NumPairs = 0;

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT KernTable::KernTable: void"); 
	#endif
}

KernTable::~KernTable()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER KernTable::~KernTable()"); 
	#endif

	FreeMem();
	
	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT KernTable::~KernTable: void"); 
	#endif
}

void KernTable::FreeMem()
{
	if (Offsets) {
		free(Offsets);
		Offsets = NULL;
	}
	if (KernTabP) {
		free(KernTabP);
		KernTabP = NULL;
	}
}

int
KernTable::Read(fstream *fin, DirectoryTable *dir)
{	
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER KernTable::Read(?,?,?,?)"); 
	#endif

    // Save to args to instance vars
    Format = 0; //format;
    
	// Read Kern table
	
	// Check for existence of Kern table
	if( !dir->GetTag("kern"))
	{
//		Report( TO_LIST, "ERROR KernTable::Read: Unable to GetTag(Kern)"); 
		return ERROR;
	}
	
	// Head table begins at offset specified in directory table
	//Offsets = (Offsets *)malloc(dir->GetLength());
	// malloc #1		 
	FreeMem();
	if(( Offsets = (char *)malloc((int)dir->GetLength())) == NULL)
	{
//		Report( TO_LIST, "ERROR KernTable::Read: Malloc #1 == NULL"); 
		return ERROR;	
	}
	unsigned long flen;

	fin->seekg(flen = dir->GetOffset());
	fin->read( (char *)Offsets, (int)dir->GetLength());
 	
 	// Swab the shorts...
    myswab( (unsigned char *)Offsets, (int)dir->GetLength());

	UShort *uOffsets = (UShort *)Offsets;

    //UShort format = uOffsets[1];
	//UShort version = uOffsets[2];
	//UShort subtablesize = uOffsets[3];
	//UShort sbits = uOffsets[4];
	
	NumPairs = uOffsets[5];
	
	//UShort srange = uOffsets[6];
	//UShort esel = uOffsets[7];
	//UShort rshift = uOffsets[8];

	// KernTabP = (Offsets *)malloc(dir->GetLength());
	// malloc #2
	if(( KernTabP = (KERNTAB *)malloc((int)NumPairs * sizeof(KERNTAB))) == NULL)
	{
//		Report( TO_LIST, "ERROR KernTable::Read: Malloc #1 == NULL"); 
		return ERROR;	
	}

	flen = NumPairs * sizeof(KERNTAB);

	// Fill the tables -- This is not portable code
	memcpy(KernTabP, &uOffsets[9], flen);

	return OK;
}

Short
KernTable::GetKerning( UShort cleft, UShort cright)
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER KernTable::GetOffset(ULong*,ULong)"); 
	#endif
	
	for (int i = 0; i < NumPairs; i++) {
		if ((KernTabP[i].LeftG == cleft) &&
			(KernTabP[i].RightG == cright)) {
			return(KernTabP[i].kernVal);
		}
	}

	return 0;	// No Kern 
}


int
KernTable::Print()
{
	#ifdef DEBUG_ENTER
	Report( TO_LIST, "ENTER KernTable::Print()"); 
	#endif

	#ifdef DEBUG_EXIT
	Report( TO_LIST, "EXIT KernTable::Print()"); 
	#endif

	return OK;
}


// dnstydlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDnstyDlg dialog

class CDnstyDlg : public CDialog
{
// Construction
public:
	CDnstyDlg(CWnd* pParent = NULL);	// standard constructor

	int m_iDensity;
	
// Dialog Data
	//{{AFX_DATA(CDnstyDlg)
	enum { IDD = IDD_DENSITY };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	// Generated message map functions
	//{{AFX_MSG(CDnstyDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedDensityAlterWord2();
};

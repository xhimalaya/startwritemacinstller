#pragma once

class CRegGenerator
{
private:
	char listOne[14];
	char listTwo[14];
public:
	CRegGenerator(void);
	~CRegGenerator(void);

	bool VerifyRegistration(char *regVal);
};

#if !defined(AFX_SWSPACE_H__14E1D661_E414_11D3_B60B_444553540000__INCLUDED_)
#define AFX_SWSPACE_H__14E1D661_E414_11D3_B60B_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// swspace.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// swspace dialog

class swspace : public CDialog
{
// Construction
public:

	int m_iSpace;

	swspace(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(swspace)
	enum { IDD = IDD_SPACE_WIDTH };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(swspace)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(swspace)
	afx_msg void OnOk();
	afx_msg void OnSpaceNormal();
	afx_msg void OnSpaceWide();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWSPACE_H__14E1D661_E414_11D3_B60B_444553540000__INCLUDED_)

# A-Z start Dot
def manuscript_start_dot_A():
    x = [752]
    y = [1501]
    return x, y


def manuscript_start_dot_B():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_C():
    x = [1294]
    y = [1272]
    return x, y


def manuscript_start_dot_D():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_E():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_F():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_G():
    x = [1365]
    y = [1188]
    return x, y


def manuscript_start_dot_H():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_I():
    x = [159]
    y = [1500]
    return x, y


def manuscript_start_dot_J():
    x = [751]
    y = [1500]
    return x, y


def manuscript_start_dot_K():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_L():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_M():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_N():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_O():
    x = [752]
    y = [1500]
    return x, y


def manuscript_start_dot_P():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_Q():
    x = [752]
    y = [1500]
    return x, y


def manuscript_start_dot_R():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_S():
    x = [923]
    y = [1396]
    return x, y


def manuscript_start_dot_T():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_U():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_V():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_W():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_X():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_Y():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_Z():
    x = [0]
    y = [1500]
    return x, y

#--------------------------------
# a-z Start Dot
def manuscript_start_dot_a():
    x = [754]
    y = [375]
    return x, y


def manuscript_start_dot_b():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_c():
    x = [647]
    y = [635]
    return x, y


def manuscript_start_dot_d():
    x = [754]
    y = [394]
    return x, y


def manuscript_start_dot_e():
    x = [0]
    y = [375]
    return x, y


def manuscript_start_dot_f():
    x = [468]
    y = [1334]
    return x, y


def manuscript_start_dot_g():
    x = [754]
    y = [356]
    return x, y


def manuscript_start_dot_h():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_i():
    x = [40]
    y = [748]
    return x, y


def manuscript_start_dot_j():
    x = [599]
    y = [748]
    return x, y


def manuscript_start_dot_k():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_l():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_m():
    x = [0]
    y = [750]
    return x, y


def manuscript_start_dot_n():
    x = [0]
    y = [750]
    return x, y


def manuscript_start_dot_o():
    x = [377]
    y = [749]
    return x, y


def manuscript_start_dot_p():
    x = [0]
    y = [753]
    return x, y


def manuscript_start_dot_q():
    x = [759]
    y = [390]
    return x, y


def manuscript_start_dot_r():
    x = [0]
    y = [748]
    return x, y


def manuscript_start_dot_s():
    x = [504]
    y = [694]
    return x, y


def manuscript_start_dot_t():
    x = [255]
    y = [1127]
    return x, y


def manuscript_start_dot_u():
    x = [1]
    y = [752]
    return x, y


def manuscript_start_dot_v():
    x = [0]
    y = [746]
    return x, y


def manuscript_start_dot_w():
    x = [0]
    y = [752]
    return x, y


def manuscript_start_dot_x():
    x = [0]
    y = [747]
    return x, y


def manuscript_start_dot_y():
    x = [0]
    y = [746]
    return x, y


def manuscript_start_dot_z():
    x = [0]
    y = [748]
    return x, y


#------------------------------------
# 0-9 Start Dot
def manuscript_start_dot_0():
    x = [541]
    y = [1500]
    return x, y


def manuscript_start_dot_1():
    x = [0]
    y = [1500]
    return x, y


def manuscript_start_dot_2():
    x = [7]
    y = [1125]
    return x, y


def manuscript_start_dot_3():
    x = [0]
    y = [1125]
    return x, y


def manuscript_start_dot_4():
    x = [0]
    y = [1497]
    return x, y


def manuscript_start_dot_5():
    x = [7]
    y = [1500]
    return x, y


def manuscript_start_dot_6():
    x = [385]
    y = [1500]
    return x, y


def manuscript_start_dot_7():
    x = [0]
    y = [1497]
    return x, y


def manuscript_start_dot_8():
    x = [700]
    y = [1464]
    return x, y


def manuscript_start_dot_9():
    x = [763]
    y = [1147]
    return x, y


def return_startdot_manuscript(xxx):
    c1 = []
    c2 = []
    if xxx == 'A':
        c1, c2 = manuscript_start_dot_A()
    elif xxx == 'B':
        c1, c2 = manuscript_start_dot_B()
    elif xxx == 'C':
        c1, c2 = manuscript_start_dot_C()
    elif xxx == 'D':
        c1, c2 = manuscript_start_dot_D()
    elif xxx == 'E':
        c1, c2 = manuscript_start_dot_E()
    elif xxx == 'F':
        c1, c2 = manuscript_start_dot_F()
    elif xxx == 'G':
        c1, c2 = manuscript_start_dot_G()
    elif xxx == 'H':
        c1, c2 = manuscript_start_dot_H()
    elif xxx == 'I':
        c1, c2 = manuscript_start_dot_I()
    elif xxx == 'J':
        c1, c2 = manuscript_start_dot_J()
    elif xxx == 'K':
        c1, c2 = manuscript_start_dot_K()
    elif xxx == 'L':
        c1, c2 = manuscript_start_dot_L()
    elif xxx == 'M':
        c1, c2 = manuscript_start_dot_M()
    elif xxx == 'N':
        c1, c2 = manuscript_start_dot_N()
    elif xxx == 'O':
        c1, c2 = manuscript_start_dot_O()
    elif xxx == 'P':
        c1, c2 = manuscript_start_dot_P()
    elif xxx == 'Q':
        c1, c2 = manuscript_start_dot_Q()
    elif xxx == 'R':
        c1, c2 = manuscript_start_dot_R()
    elif xxx == 'S':
        c1, c2 = manuscript_start_dot_S()
    elif xxx == 'T':
        c1, c2 = manuscript_start_dot_T()
    elif xxx == 'U':
        c1, c2 = manuscript_start_dot_U()
    elif xxx == 'V':
        c1, c2 = manuscript_start_dot_V()
    elif xxx == 'W':
        c1, c2 = manuscript_start_dot_W()
    elif xxx == 'X':
        c1, c2 = manuscript_start_dot_X()
    elif xxx == 'Y':
        c1, c2 = manuscript_start_dot_Y()
    elif xxx == 'Z':
        c1, c2 = manuscript_start_dot_Z()

    elif xxx == 'a':
        c1, c2 = manuscript_start_dot_a()
    elif xxx == 'b':
        c1, c2 = manuscript_start_dot_b()
    elif xxx == 'c':
        c1, c2 = manuscript_start_dot_c()
    elif xxx == 'd':
        c1, c2 = manuscript_start_dot_d()
    elif xxx == 'e':
        c1, c2 = manuscript_start_dot_e()
    elif xxx == 'f':
        c1, c2 = manuscript_start_dot_f()
    elif xxx == 'g':
        c1, c2 = manuscript_start_dot_g()
    elif xxx == 'h':
        c1, c2 = manuscript_start_dot_h()
    elif xxx == 'i':
        c1, c2 = manuscript_start_dot_i()
    elif xxx == 'j':
        c1, c2 = manuscript_start_dot_j()
    elif xxx == 'k':
        c1, c2 = manuscript_start_dot_k()
    elif xxx == 'l':
        c1, c2 = manuscript_start_dot_l()
    elif xxx == 'm':
        c1, c2 = manuscript_start_dot_m()
    elif xxx == 'n':
        c1, c2 = manuscript_start_dot_n()
    elif xxx == 'o':
        c1, c2 = manuscript_start_dot_o()
    elif xxx == 'p':
        c1, c2 = manuscript_start_dot_p()
    elif xxx == 'q':
        c1, c2 = manuscript_start_dot_q()
    elif xxx == 'r':
        c1, c2 = manuscript_start_dot_r()
    elif xxx == 's':
        c1, c2 = manuscript_start_dot_s()
    elif xxx == 't':
        c1, c2 = manuscript_start_dot_t()
    elif xxx == 'u':
        c1, c2 = manuscript_start_dot_u()
    elif xxx == 'v':
        c1, c2 = manuscript_start_dot_v()
    elif xxx == 'w':
        c1, c2 = manuscript_start_dot_w()
    elif xxx == 'x':
        c1, c2 = manuscript_start_dot_x()
    elif xxx == 'y':
        c1, c2 = manuscript_start_dot_y()
    elif xxx == 'z':
        c1, c2 = manuscript_start_dot_z()

    elif xxx == '0':
        c1, c2 = manuscript_start_dot_0()
    elif xxx == '1':
        c1, c2 = manuscript_start_dot_1()
    elif xxx == '2':
        c1, c2 = manuscript_start_dot_2()
    elif xxx == '3':
        c1, c2 = manuscript_start_dot_3()
    elif xxx == '4':
        c1, c2 = manuscript_start_dot_4()
    elif xxx == '5':
        c1, c2 = manuscript_start_dot_5()
    elif xxx == '6':
        c1, c2 = manuscript_start_dot_6()
    elif xxx == '7':
        c1, c2 = manuscript_start_dot_7()
    elif xxx == '8':
        c1, c2 = manuscript_start_dot_8()
    elif xxx == '9':
        c1, c2 = manuscript_start_dot_9()
    else:
        c1 = []
        c2 = []

    return c1, c2
